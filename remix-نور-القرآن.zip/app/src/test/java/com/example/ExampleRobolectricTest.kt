package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.firebase.AdminPrivilegeStatus
import com.example.data.firebase.AudioHostingProvider
import com.example.data.firebase.AuthRateLimiter
import com.example.data.firebase.FirebaseAuthManager
import com.example.data.firebase.FirebaseRecitationTrack
import com.example.data.firebase.FirebaseReciter
import com.example.data.firebase.FirebaseUserBookmark
import com.example.data.firebase.FreeAudioHostingService
import com.example.data.firebase.OperationType
import com.example.data.firebase.handleFirestoreError
import com.example.data.firebase.maskEmailForLog
import com.example.data.firebase.maskUidForLog
import com.example.data.local.AdhkarSeedData
import com.example.data.local.BookmarkEntity
import com.example.data.local.DownloadedAudioEntity
import com.example.data.local.NoorQuranDatabase
import com.example.data.local.QuranSeedData
import com.example.data.model.AdhkarCategory
import com.example.data.model.KhatmahPlan
import com.example.data.model.QuranCatalog
import com.example.data.remote.AlQuranApiService
import com.example.data.remote.Mp3QuranApiService
import com.example.data.repository.QuranRepository
import com.example.dhikr.DhikrSpeechMatcher
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import java.io.File
import java.io.IOException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string, web client id, and firestore database id from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals("نور القرآن", context.getString(R.string.app_name))
    assertEquals(
      "ai-studio-android-3e077e8e-16b3-485e-a78a-e49778517a58",
      context.getString(R.string.firestore_database_id),
    )
    assertTrue(context.getString(R.string.default_web_client_id).endsWith(".apps.googleusercontent.com"))
    assertEquals("com.aistudio.noorquran.k8m3vx.chltcp", context.packageName)
  }

  @Test
  fun `firebase app, authentication, and named firestore initialize cleanly on Spark configuration`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val firebaseApp =
      FirebaseApp.getApps(context).firstOrNull() ?: FirebaseApp.initializeApp(context)
    assertNotNull(firebaseApp)
    assertEquals("gen-lang-client-0050745687", firebaseApp!!.options.projectId)

    val container = NoorAppContainer(context)
    val firestore =
      FirebaseFirestore.getInstance(context.getString(R.string.firestore_database_id))
    assertNotNull(firestore)
    assertNotNull(container.firebaseAuthManager)
    assertNotNull(container.firebaseBackendRepository)
    assertEquals(null, container.firebaseAuthManager.currentUser())
  }

  @Test
  fun `firebase owner privileges enforce sole verified OWNER_EMAIL and reject non-owner or unverified accounts`() {
    assertEquals("mlwnhlnh@gmail.com", FirebaseAuthManager.OWNER_EMAIL)

    // Unauthenticated rejected even if flags set
    assertFalse(
      AdminPrivilegeStatus(
        isAuthenticated = false,
        hasCustomSuperAdminClaim = true,
        isVerifiedOwnerEmail = true,
      ).isSuperAdmin
    )

    // Standard authenticated user rejected
    assertFalse(
      AdminPrivilegeStatus(
        isAuthenticated = true,
        email = "user@example.com",
        isEmailVerified = true,
      ).isSuperAdmin
    )

    // Lookalike email mlwnhInh@gmail.com (capital I) MUST NOT be granted owner email status
    assertFalse(FirebaseAuthManager.isVerifiedOwnerEmail("mlwnhInh@gmail.com", true))
    assertFalse(FirebaseAuthManager.isVerifiedOwnerEmail("mlwnhlnh@gmail.com", false))
    assertTrue(FirebaseAuthManager.isVerifiedOwnerEmail("mlwnhlnh@gmail.com", true))
    assertTrue(FirebaseAuthManager.isVerifiedOwnerEmail("MLWNHLNH@GMAIL.COM", true))

    // Unverified account rejected even with custom claim or admin doc
    assertFalse(
      AdminPrivilegeStatus(
        isAuthenticated = true,
        email = "mlwnhlnh@gmail.com",
        isEmailVerified = false,
        hasCustomSuperAdminClaim = true,
        hasAdminsDocument = true,
        isVerifiedOwnerEmail = false,
      ).isSuperAdmin
    )

    // Non-owner email rejected EVEN if stale custom claim or admin doc exists
    assertFalse(
      AdminPrivilegeStatus(
        isAuthenticated = true,
        email = "user@example.com",
        isEmailVerified = true,
        hasCustomSuperAdminClaim = true,
        hasAdminsDocument = true,
        isVerifiedOwnerEmail = false,
      ).isSuperAdmin
    )
    assertFalse(
      AdminPrivilegeStatus(
        isAuthenticated = true,
        email = "mlwnhInh@gmail.com",
        isEmailVerified = true,
        hasCustomSuperAdminClaim = true,
        hasAdminsDocument = true,
        isVerifiedOwnerEmail = false,
      ).isSuperAdmin
    )

    // Verified sole OWNER_EMAIL accepted (with or without optional claims/doc)
    assertTrue(
      AdminPrivilegeStatus(
        isAuthenticated = true,
        email = "mlwnhlnh@gmail.com",
        isEmailVerified = true,
        hasCustomSuperAdminClaim = true,
        hasAdminsDocument = true,
        isVerifiedOwnerEmail = true,
      ).isSuperAdmin
    )
    assertTrue(
      AdminPrivilegeStatus(
        isAuthenticated = true,
        email = "mlwnhlnh@gmail.com",
        isEmailVerified = true,
        isVerifiedOwnerEmail = true,
      ).isSuperAdmin
    )
  }

  @Test
  fun `auth rate limiter locks out after 5 failures and resets on success`() {
    var fakeNow = 1_000_000L
    val limiter =
      AuthRateLimiter(
        maxAttemptsBeforeLockout = 5,
        windowMs = 120_000L,
        baseCooldownMs = 30_000L,
        nowProvider = { fakeNow },
      )
    repeat(4) {
      assertTrue(limiter.checkAllowed().isSuccess)
      limiter.recordFailure()
    }
    // 5th failure triggers 30s lockout
    assertTrue(limiter.checkAllowed().isSuccess)
    limiter.recordFailure()
    assertTrue(limiter.checkAllowed().isFailure)
    assertEquals(30L, limiter.remainingLockoutSeconds())

    // After 31s lockout expires
    fakeNow += 31_000L
    assertTrue(limiter.checkAllowed().isSuccess)

    // Reset clears strikes & lockout
    repeat(5) { limiter.recordFailure() }
    assertTrue(limiter.checkAllowed().isFailure)
    limiter.recordSuccess()
    assertTrue(limiter.checkAllowed().isSuccess)
  }

  @Test
  fun `free audio hosting blocks http, SSRF internal IPs, userinfo spoofing, non-443 ports, and path traversal`() {
    val service = FreeAudioHostingService(OkHttpClient())

    assertEquals(
      setOf("github_releases", "internet_archive", "mp3quran", "direct_https"),
      AudioHostingProvider.validIds,
    )

    val ghUrl =
      service.buildGitHubReleaseDownloadUrl(
        owner = "Buasker",
        repo = "noor-quran-audio",
        tag = "reciters-v1",
        fileName = "khalid_jaleel_001.mp3",
      )
    assertEquals(
      "https://github.com/Buasker/noor-quran-audio/releases/download/reciters-v1/khalid_jaleel_001.mp3",
      ghUrl,
    )
    assertEquals(ghUrl, service.validatePublicAudioUrl("  $ghUrl  "))

    val archiveUrl = service.buildInternetArchiveDownloadUrl("noor-quran-khalid", "018.mp3")
    assertEquals("https://archive.org/download/noor-quran-khalid/018.mp3", archiveUrl)
    assertEquals(archiveUrl, service.validatePublicAudioUrl(archiveUrl))

    val mp3QuranUrl = service.buildMp3QuranSurahUrl("https://server10.mp3quran.net/jleel", 114)
    assertEquals("https://server10.mp3quran.net/jleel/114.mp3", mp3QuranUrl)

    // Insecure HTTP, spaces, userinfo '@', loopback/metadata/private IPs, non-443 port, path traversal
    val maliciousInputs =
      listOf(
        "http://insecure.example.com/001.mp3",
        "https://example.com/bad space.mp3",
        "https://evil.com@github.com/001.mp3",
        "https://127.0.0.1/001.mp3",
        "https://localhost/001.mp3",
        "https://169.254.169.254/latest/meta-data/",
        "https://192.168.1.10/001.mp3",
        "https://10.0.0.5/001.mp3",
        "https://172.16.0.2/001.mp3",
        "https://example.com:8443/001.mp3",
      )
    maliciousInputs.forEach { badUrl ->
      assertThrows(IllegalArgumentException::class.java) {
        service.validatePublicAudioUrl(badUrl)
      }
    }

    assertThrows(IllegalArgumentException::class.java) {
      service.buildGitHubReleaseDownloadUrl("Buasker", "../secret", "v1", "001.mp3")
    }
    assertThrows(IllegalArgumentException::class.java) {
      service.buildInternetArchiveDownloadUrl("item/../../etc", "001.mp3")
    }
  }

  @Test
  fun `firestore error handler masks emails and UIDs from sanitized output`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    if (FirebaseApp.getApps(context).isEmpty()) {
      FirebaseApp.initializeApp(context)
    }
    assertEquals("m***@gmail.com", maskEmailForLog("mlwnhlnh@gmail.com"))
    assertEquals("abcd...90", maskUidForLog("abcdef1234567890"))
    val jsonOutput =
      handleFirestoreError(
        RuntimeException("Access denied"),
        OperationType.WRITE,
        "users/secretUid123456/bookmarks/1_1",
      )
    assertEquals(
      "users/***/bookmarks/1_1",
      org.json.JSONObject(jsonOutput).getString("path"),
    )
    assertFalse(jsonOutput.contains("mlwnhlnh@gmail.com"))
    assertFalse(jsonOutput.contains("secretUid123456"))
  }

  @Test
  fun `firebase create maps omit document id and populate free audio hosting fields`() {
    val reciterMap =
      FirebaseReciter(
        id = "ignored_id",
        arabicName = "خالد الجليل",
        styleArabic = "حفص عن عاصم",
        hostingProvider = AudioHostingProvider.GITHUB_RELEASES.id,
        audioBaseUrl = "https://github.com/Buasker/noor-quran-audio/releases/download/khalid_jaleel/",
        published = true,
      ).toCreateMap("admin_uid_1")
    assertFalse("id" in reciterMap)
    assertEquals("admin_uid_1", reciterMap["createdBy"])
    assertEquals("خالد الجليل", reciterMap["arabicName"])
    assertEquals("github_releases", reciterMap["hostingProvider"])

    val trackMap =
      FirebaseRecitationTrack(
        id = "018",
        reciterId = "khalid_jaleel",
        surahNumber = 18L,
        surahArabicName = "سورة الكهف",
        hostingProvider = AudioHostingProvider.GITHUB_RELEASES.id,
        audioUrl = "https://github.com/Buasker/noor-quran-audio/releases/download/khalid_jaleel/018.mp3",
        externalAssetId = "998877",
        fileSizeBytes = 1024000L,
      ).toCreateMap("admin_uid_1")
    assertFalse("id" in trackMap)
    assertEquals("admin_uid_1", trackMap["uploadedBy"])
    assertEquals(18L, trackMap["surahNumber"])
    assertEquals("998877", trackMap["externalAssetId"])
    assertEquals(1024000L, trackMap["fileSizeBytes"])

    val bookmarkMap =
      FirebaseUserBookmark(
        id = "1_1",
        surahNumber = 1L,
        ayahNumber = 1L,
        category = "تدبر",
      ).toCreateMap("user_uid_1")
    assertFalse("id" in bookmarkMap)
    assertEquals("user_uid_1", bookmarkMap["userId"])
  }

  @Test
  fun `room database resolves recitation audio from all 4 sources and works completely offline`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db =
      Room.inMemoryDatabaseBuilder(context, NoorQuranDatabase::class.java)
        .allowMainThreadQueries()
        .build()
    try {
      val dao = db.quranDao()
      // Offline OkHttp client simulating no internet connectivity
      val offlineClient =
        OkHttpClient.Builder()
          .addInterceptor { throw IOException("Offline test mode: network disabled") }
          .build()

      var firestoreUrl: String? = null
      val repository =
        QuranRepository(
          context = context,
          dao = dao,
          api = AlQuranApiService.create(offlineClient),
          mp3QuranApi = Mp3QuranApiService.create(offlineClient),
          okHttpClient = offlineClient,
          resolveCloudHostedTrackUrl = { _, _ -> firestoreUrl },
        )

      // Offline seeding works without network
      repository.ensureInitialDataSeeded()
      assertEquals(114, dao.getSurahCount())
      assertEquals(7, dao.getDhikrCounterCount())

      // Offline surah reading works for embedded fallback surahs (Al-Fatiha & Al-Nas)
      val fatiha = repository.loadSurah(1, "en.sahih").getOrThrow()
      assertEquals(7, fatiha.ayahs.size)
      val nas = repository.loadSurah(114, "en.sahih").getOrThrow()
      assertEquals(6, nas.ayahs.size)

      // Offline search works across local Surahs, Adhkar, and cached Ayahs
      val searchResults = repository.smartSearch("الفاتحة", "ar.muyassar", "en.sahih").getOrThrow()
      assertTrue(searchResults.isNotEmpty())

      // Bookmarks & Khatmah persistence in Room
      dao.insertBookmark(
        BookmarkEntity(
          surahNumber = 1,
          surahEnglishName = "Al-Faatiha",
          surahArabicName = "سُورَةُ ٱلْفَاتِحَةِ",
          ayahNumberInSurah = 5,
          globalAyahNumber = 5,
          arabicText = "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ",
          translationText = "You alone we worship...",
          category = "تدبر",
          note = "آية جامعة",
        )
      )
      assertEquals(1, dao.getAllBookmarksFlow().first().size)

      repository.saveKhatmahPlan(
        KhatmahPlan(
          title = "ختمة رمضان",
          startDateEpochDay = 1L,
          endDateEpochDay = 30L,
          totalPages = 604,
          pagesRead = 20,
        )
      )
      assertEquals(1, repository.khatmahPlansFlow.first().size)

      // Source 1 (GitHub Releases via Firestore)
      firestoreUrl = "https://github.com/Buasker/noor-quran-audio/releases/download/v1/khalid_jaleel_001.mp3"
      assertEquals(firestoreUrl, repository.resolveSurahAudioSource("khalid_jaleel", 1))

      // Source 2 (Internet Archive via Firestore)
      firestoreUrl = "https://archive.org/download/khalid-al-jaleel/001.mp3"
      assertEquals(firestoreUrl, repository.resolveSurahAudioSource("khalid_jaleel", 1))

      // Source 3 (Direct HTTPS CDN override when Firestore has no track)
      firestoreUrl = null
      val directCdn = "https://cdn.jsdelivr.net/gh/Buasker/noor-quran-audio/001.mp3"
      assertEquals(
        directCdn,
        repository.resolveSurahAudioSource(
          reciterId = "khalid_jaleel",
          surahNumber = 1,
          directHttpsUrl = directCdn,
        ),
      )

      // Source 4 (MP3Quran fallback when offline/API unreachable uses reciter.defaultSurahServerUrl)
      val mp3Fallback = repository.resolveSurahAudioSource("khalid_jaleel", 1)
      assertEquals("https://server10.mp3quran.net/jleel/001.mp3", mp3Fallback)

      // Offline Priority 1: Local cached file in Room overrides all 4 remote sources
      val tempAudio = File.createTempFile("surah_001_", ".mp3", context.cacheDir).apply {
        writeBytes(byteArrayOf(1, 2, 3))
      }
      try {
        dao.insertDownloadedAudio(
          DownloadedAudioEntity(
            reciterId = "khalid_jaleel",
            surahNumber = 1,
            localFilePath = tempAudio.absolutePath,
            sizeBytes = tempAudio.length(),
          )
        )
        firestoreUrl = "https://github.com/Buasker/noor-quran-audio/releases/download/v1/khalid_jaleel_001.mp3"
        assertEquals(
          tempAudio.absolutePath,
          repository.resolveSurahAudioSource("khalid_jaleel", 1),
        )
      } finally {
        tempAudio.delete()
      }
    } finally {
      db.close()
    }
  }

  @Test
  fun `voice dhikr counter matches phrases, avoids double counting, and persists counts in Room`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db =
      Room.inMemoryDatabaseBuilder(context, NoorQuranDatabase::class.java)
        .allowMainThreadQueries()
        .build()
    try {
      val dao = db.quranDao()
      dao.insertDhikrCounters(AdhkarSeedData.initialVoiceDhikrCounters)

      val utteranceState = mutableMapOf<String, Int>()
      val partial1 =
        DhikrSpeechMatcher.computeIncrementalDelta(
          "وسبحان الله والحمد لله",
          utteranceState,
        )
      assertEquals(1, partial1["tasbih"])
      assertEquals(1, partial1["hamd"])

      val finalUtterance =
        DhikrSpeechMatcher.computeIncrementalDelta(
          "وسبحان الله والحمد لله والله أكبر الله أكبر",
          utteranceState,
        )
      assertEquals(null, finalUtterance["tasbih"])
      assertEquals(null, finalUtterance["hamd"])
      assertEquals(2, finalUtterance["takbir"])

      for ((id, delta) in partial1) {
        repeat(delta) { dao.incrementDhikrCounter(id) }
      }
      for ((id, delta) in finalUtterance) {
        repeat(delta) { dao.incrementDhikrCounter(id) }
      }

      val persisted = dao.getAllDhikrCountersFlow().first().associateBy { it.id }
      assertEquals(1, persisted["tasbih"]?.count)
      assertEquals(1, persisted["hamd"]?.count)
      assertEquals(2, persisted["takbir"]?.count)

      dao.resetDhikrCounter("takbir")
      assertEquals(0, dao.getAllDhikrCountersFlow().first().first { it.id == "takbir" }.count)
      dao.resetAllDhikrCounters()
      assertTrue(dao.getAllDhikrCountersFlow().first().all { it.count == 0 })
    } finally {
      db.close()
    }
  }

  @Test
  fun `seed data contains all 114 surahs`() {
    assertEquals(114, QuranSeedData.surahs.size)
    assertEquals("سُورَةُ ٱلْفَاتِحَةِ", QuranSeedData.surahs.first().arabicName)
    assertEquals("سُورَةُ النَّاسِ", QuranSeedData.surahs.last().arabicName)
  }

  @Test
  fun `catalog includes all 8 reciters and social handles`() {
    assertEquals(8, QuranCatalog.reciters.size)
    assertTrue(QuranCatalog.reciters.any { it.arabicName == "خالد الجليل" })
    assertTrue(QuranCatalog.reciters.any { it.arabicName == "ماهر المعيقلي" })
    assertTrue(QuranCatalog.reciters.any { it.arabicName == "عبدالرحمن السديس" })
    assertTrue(QuranCatalog.reciters.any { it.arabicName == "علي جابر" })
    assertTrue(QuranCatalog.reciters.any { it.arabicName == "مشاري العفاسي" })
    assertTrue(QuranCatalog.reciters.any { it.arabicName == "عبدالباسط عبدالصمد" })
    assertTrue(QuranCatalog.reciters.any { it.arabicName == "محمود خليل الحصري" })
    assertTrue(QuranCatalog.reciters.any { it.arabicName == "محمد صديق المنشاوي" })

    assertEquals(
      setOf("@buaskerrr", "@bu_askerrr"),
      QuranCatalog.socialAccounts.map { it.handle }.toSet(),
    )
    assertTrue(QuranCatalog.socialAccounts.any { it.url == "https://www.snapchat.com/add/buaskerrr" })
    assertTrue(QuranCatalog.socialAccounts.any { it.url == "https://www.instagram.com/bu_askerrr/" })
    assertTrue(QuranCatalog.socialAccounts.any { it.url == "https://www.tiktok.com/@bu_askerrr" })
  }

  @Test
  fun `adhkar seed covers all 7 categories and 7 voice dhikr phrases`() {
    assertEquals(7, AdhkarSeedData.initialVoiceDhikrCounters.size)
    val categories = AdhkarSeedData.allAdhkar.map { it.category }.toSet()
    assertEquals(AdhkarCategory.entries.toSet(), categories)
  }

  @Test
  fun `voice dhikr matcher counts variants and avoids duplicates across partial and final transcripts`() {
    val result =
      DhikrSpeechMatcher.countOccurrences(
        "سُبْحَانَ اللَّهِ وَالْحَمْدُ لِلَّهِ وَاللَّهُ أَكْبَرُ أَسْتَغْفِرُ اللَّهَ العظيم اللهم صل وسلم على نبينا محمد لا حول ولا قوة إلا بالله"
      )
    assertEquals(1, result["tasbih"])
    assertEquals(1, result["hamd"])
    assertEquals(1, result["takbir"])
    assertEquals(1, result["istighfar"])
    assertEquals(1, result["salawat"])
    assertEquals(1, result["hawqala"])

    val utteranceState = mutableMapOf<String, Int>()
    val delta1 = DhikrSpeechMatcher.computeIncrementalDelta("الحمد لله الحمد لله", utteranceState)
    val delta2 = DhikrSpeechMatcher.computeIncrementalDelta("الحمد لله الحمد لله الحمد لله", utteranceState)
    assertEquals(2, delta1["hamd"])
    assertEquals(1, delta2["hamd"])
  }

  @Test
  fun `repository rejects path traversal reciter IDs, invalid dhikr IDs, and non-HTTPS requests`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val db =
      Room.inMemoryDatabaseBuilder(context, NoorQuranDatabase::class.java)
        .allowMainThreadQueries()
        .build()
    try {
      val dao = db.quranDao()
      val client = AlQuranApiService.createOkHttpClient()
      val repository =
        QuranRepository(
          context = context,
          dao = dao,
          api = AlQuranApiService.create(client),
          mp3QuranApi = Mp3QuranApiService.create(client),
          okHttpClient = client,
        )
      repository.ensureInitialDataSeeded()

      // Path traversal reciter ID blocked in both resolve & download
      var traversalRejected = false
      try {
        repository.resolveSurahAudioSource("../../evil", 1)
      } catch (_: IllegalArgumentException) {
        traversalRejected = true
      }
      assertTrue(traversalRejected)

      val downloadTraversal = repository.downloadSurahAudio("../etc", 1) {}
      assertTrue(downloadTraversal.isFailure)

      // Dhikr counter ignores non-allowlisted IDs
      repository.incrementDhikr("malicious_id")
      assertTrue(repository.dhikrCountersFlow.first().none { it.id == "malicious_id" })

      // AlQuran OkHttp client blocks cleartext HTTP
      val httpResult =
        runCatching {
          client.newCall(okhttp3.Request.Builder().url("http://example.com/test").build()).execute()
        }
      assertTrue(httpResult.isFailure)

      // AlQuranApiService blocks private, link-local, loopback, and CGNAT IP addresses
      assertTrue(AlQuranApiService.isPrivateOrLoopbackAddress(java.net.InetAddress.getByName("127.0.0.1")))
      assertTrue(AlQuranApiService.isPrivateOrLoopbackAddress(java.net.InetAddress.getByName("10.0.0.1")))
      assertTrue(AlQuranApiService.isPrivateOrLoopbackAddress(java.net.InetAddress.getByName("192.168.1.1")))
      assertTrue(AlQuranApiService.isPrivateOrLoopbackAddress(java.net.InetAddress.getByName("169.254.169.254")))
      assertTrue(AlQuranApiService.isPrivateOrLoopbackAddress(java.net.InetAddress.getByName("100.64.0.1")))
      assertFalse(AlQuranApiService.isPrivateOrLoopbackAddress(java.net.InetAddress.getByName("1.1.1.1")))

      // QuranAudioPlayer rejects unsafe URLs and files outside filesDir/audio
      val player = com.example.audio.QuranAudioPlayer(context) { _, _ -> "" }
      assertFalse(player.isAllowedAudioDataSource("http://insecure.example.com/001.mp3"))
      assertFalse(player.isAllowedAudioDataSource("https://127.0.0.1/001.mp3"))
      assertFalse(player.isAllowedAudioDataSource("https://localhost/001.mp3"))
      assertFalse(player.isAllowedAudioDataSource("https://example.com:8443/001.mp3"))
      assertFalse(player.isAllowedAudioDataSource("/data/local/tmp/001.mp3"))
      val safeLocalFile = File(File(context.filesDir, "audio/ar.alafasy"), "001.mp3")
      assertTrue(player.isAllowedAudioDataSource(safeLocalFile.absolutePath))
      assertTrue(player.isAllowedAudioDataSource("https://archive.org/download/reciter/001.mp3"))
      player.release()
    } finally {
      db.close()
    }
  }
}
