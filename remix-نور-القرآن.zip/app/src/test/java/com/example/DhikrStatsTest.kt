package com.example

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AdhkarSeedData
import com.example.data.local.NoorQuranDatabase
import com.example.data.model.DhikrDailyLog
import com.example.data.model.DhikrSourceType
import com.example.data.remote.AlQuranApiService
import com.example.data.remote.Mp3QuranApiService
import com.example.data.repository.QuranRepository
import com.example.dhikr.DhikrDateUtils
import com.example.ui.screens.DhikrStatsScreen
import com.example.ui.theme.NoorQuranTheme
import com.example.ui.viewmodel.DhikrStatsAggregator
import com.example.ui.viewmodel.StatsPeriodMode
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class DhikrStatsTest {

  @get:Rule val composeRule = createComposeRule()

  private fun createInMemoryRepository(context: Context): Pair<NoorQuranDatabase, QuranRepository> {
    val db =
      Room.inMemoryDatabaseBuilder(context, NoorQuranDatabase::class.java)
        .allowMainThreadQueries()
        .build()
    val client = OkHttpClient.Builder().build()
    val repo =
      QuranRepository(
        context = context,
        dao = db.quranDao(),
        api = AlQuranApiService.create(client),
        mp3QuranApi = Mp3QuranApiService.create(client),
        okHttpClient = client,
      )
    return db to repo
  }

  @Test
  fun `aggregator computes daily 7d and weekly 8w rates, streak, growth, and breakdown accurately`() {
    val today = 20_500L
    val logs =
      listOf(
        // Today: 15 voice + 5 adhkar = 20
        DhikrDailyLog(today, "hamd", "الحمد لله", DhikrSourceType.VOICE, 10, 1L),
        DhikrDailyLog(today, "tasbih", "سبحان الله", DhikrSourceType.VOICE, 5, 2L),
        DhikrDailyLog(today, "adhkar_morning", "أذكار الصباح", DhikrSourceType.ADHKAR, 5, 3L),
        // Yesterday: 10
        DhikrDailyLog(today - 1L, "hamd", "الحمد لله", DhikrSourceType.VOICE, 10, 4L),
        // 2 days ago: 8
        DhikrDailyLog(today - 2L, "takbir", "الله أكبر", DhikrSourceType.VOICE, 8, 5L),
        // Gap at today - 3L -> streak should be 3 days!
        // Previous week (today - 10L): 19
        DhikrDailyLog(today - 10L, "istighfar", "أستغفر الله", DhikrSourceType.VOICE, 19, 6L),
      )

    val dailyState =
      DhikrStatsAggregator.buildState(
        logs = logs,
        periodMode = StatsPeriodMode.DAILY,
        dailyWindowDays = 7,
        selectedPointIndex = null,
        todayEpochDay = today,
      )

    assertEquals(7, dailyState.points.size)
    assertEquals(20, dailyState.todayCount)
    assertEquals(38, dailyState.thisWeekCount) // 20 + 10 + 8
    assertEquals(38, dailyState.periodTotalCount)
    assertEquals(3, dailyState.currentStreakDays)
    assertEquals(100, dailyState.weekOverWeekPercent) // (38 - 19) / 19 = +100%
    assertEquals("اليوم", dailyState.points.last().primaryLabel)
    assertEquals(20, dailyState.points.last().totalCount)
    assertEquals(15, dailyState.points.last().voiceCount)
    assertEquals(5, dailyState.points.last().adhkarCount)
    assertEquals("hamd", dailyState.breakdown.first().dhikrId)
    assertEquals(20, dailyState.breakdown.first().count)

    val weeklyState =
      DhikrStatsAggregator.buildState(
        logs = logs,
        periodMode = StatsPeriodMode.WEEKLY,
        dailyWindowDays = 7,
        selectedPointIndex = null,
        todayEpochDay = today,
      )

    assertEquals(8, weeklyState.points.size)
    assertEquals("الحالي", weeklyState.points.last().primaryLabel)
    assertEquals(38, weeklyState.points.last().totalCount)
    assertEquals("الماضي", weeklyState.points[6].primaryLabel)
    assertEquals(19, weeklyState.points[6].totalCount)
    assertEquals(57, weeklyState.periodTotalCount)
  }

  @Test
  fun `repository incrementDhikr and incrementAdhkar record real daily logs in Room`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val (db, repo) = createInMemoryRepository(context)
    try {
      repo.ensureInitialDataSeeded()
      val day1Millis = 1_760_000_000_000L
      val day2Millis = day1Millis + 86_400_000L

      assertTrue(repo.incrementDhikr("hamd", delta = 3, timestampMillis = day1Millis))
      assertTrue(repo.incrementDhikr("hamd", delta = 2, timestampMillis = day1Millis))
      assertTrue(repo.incrementDhikr("takbir", delta = 4, timestampMillis = day2Millis))
      repo.incrementAdhkar("m_1", currentCount = 0, targetCount = 1, timestampMillis = day2Millis)

      val logs = repo.dhikrDailyLogsFlow.first()
      val day1Epoch = DhikrDateUtils.epochDayForMillis(day1Millis)
      val day2Epoch = DhikrDateUtils.epochDayForMillis(day2Millis)

      val day1Hamd = logs.first { it.epochDay == day1Epoch && it.dhikrId == "hamd" }
      assertEquals(5, day1Hamd.count)
      assertEquals(DhikrSourceType.VOICE, day1Hamd.sourceType)

      val day2Takbir = logs.first { it.epochDay == day2Epoch && it.dhikrId == "takbir" }
      assertEquals(4, day2Takbir.count)

      val day2Morning = logs.first { it.epochDay == day2Epoch && it.dhikrId == "adhkar_morning" }
      assertEquals(1, day2Morning.count)
      assertEquals(DhikrSourceType.ADHKAR, day2Morning.sourceType)
    } finally {
      db.close()
    }
  }

  @Test
  fun `ensureInitialDataSeeded backfills pre-existing non-zero voice dhikr counters once`() =
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val (db, repo) = createInMemoryRepository(context)
      try {
        val dao = db.quranDao()
        dao.insertDhikrCounters(AdhkarSeedData.initialVoiceDhikrCounters)
        val ts = 1_760_500_000_000L
        dao.incrementDhikrCounter("tasbih", delta = 12, timestamp = ts)

        repo.ensureInitialDataSeeded()
        val logs = repo.dhikrDailyLogsFlow.first()
        val expectedDay = DhikrDateUtils.epochDayForMillis(ts)
        val tasbihLog = logs.first { it.epochDay == expectedDay && it.dhikrId == "tasbih" }
        assertEquals(12, tasbihLog.count)
      } finally {
        db.close()
      }
    }

  @Test
  fun `DhikrStatsScreen renders empty state and switches between daily and weekly charts interactively`() {
    val today = 20_500L
    val sampleLogs =
      listOf(
        DhikrDailyLog(today, "hamd", "الحمد لله", DhikrSourceType.VOICE, 14, 1L),
        DhikrDailyLog(today - 1L, "tasbih", "سبحان الله", DhikrSourceType.VOICE, 22, 2L),
        DhikrDailyLog(today - 8L, "adhkar_evening", "أذكار المساء", DhikrSourceType.ADHKAR, 9, 3L),
      )

    var showData by mutableStateOf(false)
    var periodMode by mutableStateOf(StatsPeriodMode.DAILY)
    var windowDays by mutableStateOf(7)
    var selectedIdx by mutableStateOf<Int?>(null)
    var openedVoice = false

    composeRule.setContent {
      val state =
        DhikrStatsAggregator.buildState(
          logs = if (showData) sampleLogs else emptyList(),
          periodMode = periodMode,
          dailyWindowDays = windowDays,
          selectedPointIndex = selectedIdx,
          todayEpochDay = today,
        )
      NoorQuranTheme {
        DhikrStatsScreen(
          uiState = state,
          onSelectPeriodMode = {
            periodMode = it
            selectedIdx = null
          },
          onSelectDailyWindowDays = {
            windowDays = it
            selectedIdx = null
          },
          onSelectPoint = { selectedIdx = it },
          onOpenVoiceDhikr = { openedVoice = true },
          onOpenAdhkar = {},
        )
      }
    }

    // Empty state shown when no logs exist
    composeRule
      .onNodeWithTag("dhikr_stats_list")
      .performScrollToNode(hasTestTag("stats_empty_state"))
    composeRule.onNodeWithTag("stats_empty_state").assertIsDisplayed()
    composeRule.onNodeWithTag("stats_empty_voice_cta").performClick()
    assertTrue(openedVoice)

    // Populate real logs and verify charts, metrics, point selection, and breakdown
    composeRule.runOnIdle { showData = true }
    composeRule.waitForIdle()

    composeRule
      .onNodeWithTag("dhikr_stats_list")
      .performScrollToNode(hasTestTag("stats_metric_today"))
    composeRule.onNodeWithTag("stats_metric_today").assertTextContains("14", substring = true)

    composeRule
      .onNodeWithTag("dhikr_stats_list")
      .performScrollToNode(hasTestTag("stats_rate_chart_card"))
    composeRule.onNodeWithTag("stats_bar_trend_canvas").assertIsDisplayed()

    // Tap yesterday's bar slot (index 5 in 7-day window) and verify banner updates to 22
    composeRule.onNodeWithTag("stats_point_5").performClick()
    composeRule.onNodeWithTag("stats_selected_point_banner").assertTextContains("22", substring = true)

    // Switch to Weekly tab and verify weekly range includes previous week
    composeRule
      .onNodeWithTag("dhikr_stats_list")
      .performScrollToNode(hasTestTag("stats_tab_weekly"))
    composeRule.onNodeWithTag("stats_tab_weekly").performClick()
    composeRule
      .onNodeWithTag("dhikr_stats_list")
      .performScrollToNode(hasTestTag("stats_rate_chart_card"))
    composeRule.onNodeWithTag("stats_point_6").performClick()
    composeRule.onNodeWithTag("stats_selected_point_banner").assertTextContains("9", substring = true)

    // Scroll to breakdown card
    composeRule
      .onNodeWithTag("dhikr_stats_list")
      .performScrollToNode(hasTestTag("stats_breakdown_card"))
    composeRule.onNodeWithTag("stats_breakdown_card").assertIsDisplayed()
    composeRule.onNodeWithTag("stats_breakdown_row_tasbih").assertExists()
  }
}
