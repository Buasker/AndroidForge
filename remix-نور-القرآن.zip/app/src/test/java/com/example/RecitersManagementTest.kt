package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.example.audio.AudioPlaybackState
import com.example.audio.QuranAudioPlayer
import com.example.data.firebase.AdminPrivilegeStatus
import com.example.data.firebase.AudioHostingProvider
import com.example.data.firebase.FirebaseRecitationTrack
import com.example.data.firebase.FirebaseReciter
import com.example.data.firebase.FreeAudioHostingService
import com.example.data.local.QuranSeedData
import com.example.data.model.QuranCatalog
import com.example.data.model.ReaderThemeMode
import com.example.data.model.ReciterOption
import com.example.ui.screens.AdminRecitersScreen
import com.example.ui.screens.RecitersScreen
import com.example.ui.theme.NoorQuranTheme
import com.example.ui.viewmodel.ReciterSourceFilter
import com.example.ui.viewmodel.RecitersViewModel
import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class RecitersManagementTest {

  @get:Rule val composeRule = createComposeRule()

  @Test
  fun `mergePublishedAndCatalogReciters orders by sortOrder, enriches catalog, and hides drafts`() {
    val cloud =
      listOf(
        FirebaseReciter(
          id = "draft_reciter",
          arabicName = "قارئ مسودة",
          riwayah = "ورش",
          sortOrder = 0L,
          published = false,
        ),
        FirebaseReciter(
          id = "sheikh_second",
          arabicName = "الشيخ الثاني",
          riwayah = "قالون عن نافع",
          bioArabic = "نبذة الشيخ الثاني",
          photoUrl = "https://example.com/p2.jpg",
          sortOrder = 2L,
          published = true,
        ),
        FirebaseReciter(
          id = "sheikh_first",
          arabicName = "الشيخ الأول",
          riwayah = "حفص عن عاصم",
          bioArabic = "نبذة الشيخ الأول",
          photoUrl = "https://example.com/p1.jpg",
          sortOrder = 1L,
          published = true,
        ),
        FirebaseReciter(
          id = "ar.alafasy",
          arabicName = "مشاري العفاسي (محدث)",
          riwayah = "حفص عن عاصم - رواية مصورة",
          bioArabic = "قارئ من دولة الكويت",
          photoUrl = "https://example.com/alafasy.jpg",
          sortOrder = 3L,
          audioBaseUrl = "",
          published = true,
        ),
      )

    val merged = RecitersViewModel.mergePublishedAndCatalogReciters(cloud)

    assertFalse(merged.any { it.identifier == "draft_reciter" })
    assertEquals("sheikh_first", merged[0].identifier)
    assertEquals("sheikh_second", merged[1].identifier)
    assertEquals("ar.alafasy", merged[2].identifier)
    assertTrue(merged[2].isCloudSynced)
    assertEquals("https://example.com/alafasy.jpg", merged[2].photoUrl)
    assertEquals("قارئ من دولة الكويت", merged[2].bioArabic)
    // Built-in default server URL is preserved when cloud audioBaseUrl is blank
    assertTrue(merged[2].defaultSurahServerUrl.startsWith("https://"))
    assertEquals(QuranCatalog.reciters.size + 2, merged.size)
  }

  @Test
  fun `hosting validator handles optional image urls and blocks unsafe urls`() {
    val service = FreeAudioHostingService(OkHttpClient())

    assertEquals("", service.validatePublicImageUrl("   "))
    assertEquals("", service.validateOptionalPublicHttpsUrl("", "رابط الأساس"))
    assertEquals(
      "https://example.com/avatar.jpg",
      service.validatePublicImageUrl("  https://example.com/avatar.jpg "),
    )

    listOf(
      "http://example.com/avatar.jpg",
      "https://localhost/avatar.jpg",
      "https://127.0.0.1/avatar.jpg",
      "https://169.254.169.254/latest/meta-data/",
      "https://evil@github.com/avatar.jpg",
      "https://example.com:8443/avatar.jpg",
    ).forEach { bad ->
      assertThrows(IllegalArgumentException::class.java) {
        service.validatePublicImageUrl(bad)
      }
    }
  }

  @Test
  fun `reciter and track create maps preserve rich metadata and omit document ids`() {
    val reciterMap =
      FirebaseReciter(
        id = "doc_id_ignored",
        arabicName = "الشيخ عبدالله",
        styleArabic = "مرتل",
        riwayah = "حفص عن عاصم",
        bioArabic = "إمام وخطيب وقارئ للقرآن الكريم",
        photoUrl = "https://example.com/sheikh.jpg",
        sortOrder = 5L,
        hostingProvider = AudioHostingProvider.INTERNET_ARCHIVE.id,
        audioBaseUrl = "",
        published = true,
      ).toCreateMap("owner_uid")

    assertFalse("id" in reciterMap)
    assertEquals("حفص عن عاصم", reciterMap["riwayah"])
    assertEquals("إمام وخطيب وقارئ للقرآن الكريم", reciterMap["bioArabic"])
    assertEquals("https://example.com/sheikh.jpg", reciterMap["photoUrl"])
    assertEquals(5L, reciterMap["sortOrder"])
    assertEquals("owner_uid", reciterMap["createdBy"])

    val trackMap =
      FirebaseRecitationTrack(
        id = "track_018_1",
        reciterId = "sheikh_abdullah",
        surahNumber = 18L,
        surahArabicName = "سورة الكهف",
        description = "تلاوة خاشعة من صلاة التراويح",
        sortOrder = 4L,
        hostingProvider = AudioHostingProvider.GITHUB_RELEASES.id,
        audioUrl = "https://github.com/user/repo/releases/download/v1/018.mp3",
        published = true,
      ).toCreateMap("owner_uid")

    assertFalse("id" in trackMap)
    assertEquals("تلاوة خاشعة من صلاة التراويح", trackMap["description"])
    assertEquals(4L, trackMap["sortOrder"])
    assertEquals(18L, trackMap["surahNumber"])
    assertEquals("owner_uid", trackMap["uploadedBy"])
  }

  @Test
  fun `audio player plays custom recitation with single instance and rejects unsafe urls`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val player = QuranAudioPlayer(context) { _, _ -> "" }
    try {
      player.playCustomRecitation(
        trackId = "track_001_custom",
        surahNumber = 1,
        surahArabicName = "سُورَةُ ٱلْفَاتِحَةِ",
        reciterId = "sheikh_custom",
        reciterDisplayName = "الشيخ المضاف",
        audioUrl = "http://insecure.example.com/001.mp3",
        description = "تسجيل خاص",
      )
      val rejectedState = player.state.value
      assertTrue(rejectedState.isActive)
      assertFalse(rejectedState.isPlaying)
      assertEquals("track_001_custom", rejectedState.trackId)
      assertEquals("تسجيل خاص", rejectedState.trackDescription)
      assertEquals("الشيخ المضاف", rejectedState.reciterName)
      assertTrue(rejectedState.errorMessage?.isNotBlank() == true)

      player.stop()
      assertFalse(player.state.value.isActive)
    } finally {
      player.release()
    }
  }

  @Test
  fun `public RecitersScreen renders directory and detail without any admin controls`() {
    val reciter =
      ReciterOption(
        identifier = "sheikh_ali",
        arabicName = "الشيخ علي",
        styleArabic = "مرتل",
        islamicNetworkId = null,
        everyAyahFolder = null,
        mp3QuranSearchKeywords = emptyList(),
        defaultSurahServerUrl = "",
        riwayah = "حفص عن عاصم",
        bioArabic = "قارئ متقن ومجاز في القراءات",
        photoUrl = "",
        sortOrder = 1,
        isCloudSynced = true,
      )
    val track =
      FirebaseRecitationTrack(
        id = "001",
        reciterId = "sheikh_ali",
        surahNumber = 1L,
        surahArabicName = "سُورَةُ ٱلْفَاتِحَةِ",
        description = "تلاوة فجرية خاشعة",
        sortOrder = 1L,
        hostingProvider = AudioHostingProvider.GITHUB_RELEASES.id,
        audioUrl = "https://github.com/user/repo/releases/download/v1/001.mp3",
        durationSeconds = 95L,
        published = true,
      )

    var openedId: String? = null
    composeRule.setContent {
      NoorQuranTheme(themeMode = ReaderThemeMode.PARCHMENT) {
        RecitersScreen(
          reciters = listOf(reciter),
          selectedReciter = null,
          preferredReciterId = "ar.alafasy",
          searchQuery = "",
          sourceFilter = ReciterSourceFilter.ALL,
          trackSearchQuery = "",
          publishedTracks = listOf(track),
          catalogSurahs = QuranSeedData.surahs.take(2).map {
            com.example.data.model.SurahInfo(
              number = it.number,
              arabicName = it.arabicName,
              englishName = it.englishName,
              englishNameTranslation = it.englishNameTranslation,
              numberOfAyahs = it.numberOfAyahs,
              revelationType = it.revelationType,
            )
          },
          downloadedSurahs = emptySet(),
          downloadProgressMap = emptyMap(),
          audioState = AudioPlaybackState(),
          statusMessage = null,
          onClearMessage = {},
          onSearchQueryChange = {},
          onSourceFilterChange = {},
          onOpenReciter = { openedId = it },
          onBackToRecitersList = {},
          onTrackSearchQueryChange = {},
          onSetPreferredReciter = {},
          onPlayCloudRecitation = { _, _ -> },
          onPlayCatalogSurah = { _, _ -> },
          onTogglePlayPause = {},
          onSeekTo = {},
          onSeekBySeconds = {},
          onStopPlayback = {},
          onDownloadSurah = {},
          onDeleteDownload = {},
        )
      }
    }

    composeRule.onNodeWithTag("reciter_directory_card_sheikh_ali").assertIsDisplayed()
    assertTrue(composeRule.onAllNodesWithTag("admin_add_reciter_fab").fetchSemanticsNodes().isEmpty())
    composeRule.onNodeWithTag("reciter_directory_card_sheikh_ali").performClick()
    assertEquals("sheikh_ali", openedId)
  }

  @Test
  fun `AdminRecitersScreen blocks standard users and allows owner preview before publish`() {
    val ownerReciter =
      FirebaseReciter(
        id = "sheikh_ali",
        arabicName = "الشيخ علي",
        riwayah = "حفص عن عاصم",
        bioArabic = "قارئ ومجود",
        sortOrder = 1L,
        published = false,
      )

    composeRule.setContent {
      NoorQuranTheme(themeMode = ReaderThemeMode.PARCHMENT) {
        AdminRecitersScreen(
          adminStatus =
            AdminPrivilegeStatus(
              isAuthenticated = true,
              email = "regular@gmail.com",
              isEmailVerified = true,
              isVerifiedOwnerEmail = false,
            ),
          isCheckingAuth = false,
          isBusy = false,
          isProbingUrl = false,
          probeResult = null,
          audioState = AudioPlaybackState(),
          reciters = listOf(ownerReciter),
          selectedReciterId = null,
          recitations = emptyList(),
          statusMessage = null,
          onClearMessage = {},
          onClearProbeResult = {},
          onSelectReciter = {},
          onProbeUrl = {},
          onPreviewRecitationAudio = { _, _, _, _, _, _, _ -> },
          onSeekAudio = {},
          onStopPreviewAudio = {},
          onSaveReciter = { _, _, _, _, _, _, _, _, _, _, _, _ -> },
          onMoveReciterOrder = { _, _ -> },
          onDeleteReciter = {},
          onSaveRecitation = { _, _, _, _, _, _, _, _, _, _, _, _ -> },
          onMoveRecitationOrder = { _, _, _ -> },
          onDeleteRecitation = { _, _ -> },
          onBack = {},
        )
      }
    }

    composeRule.onNodeWithTag("admin_access_denied").assertIsDisplayed()
    assertTrue(composeRule.onAllNodesWithTag("owner_verified_banner").fetchSemanticsNodes().isEmpty())
  }

  @Test
  fun `AdminRecitersScreen owner can open pre-publish preview dialog`() {
    val ownerReciter =
      FirebaseReciter(
        id = "sheikh_ali",
        arabicName = "الشيخ علي",
        riwayah = "حفص عن عاصم",
        bioArabic = "قارئ ومجود",
        sortOrder = 1L,
        published = false,
      )

    composeRule.setContent {
      NoorQuranTheme(themeMode = ReaderThemeMode.PARCHMENT) {
        AdminRecitersScreen(
          adminStatus =
            AdminPrivilegeStatus(
              isAuthenticated = true,
              email = "mlwnhlnh@gmail.com",
              isEmailVerified = true,
              isVerifiedOwnerEmail = true,
            ),
          isCheckingAuth = false,
          isBusy = false,
          isProbingUrl = false,
          probeResult = null,
          audioState = AudioPlaybackState(),
          reciters = listOf(ownerReciter),
          selectedReciterId = null,
          recitations = emptyList(),
          statusMessage = null,
          onClearMessage = {},
          onClearProbeResult = {},
          onSelectReciter = {},
          onProbeUrl = {},
          onPreviewRecitationAudio = { _, _, _, _, _, _, _ -> },
          onSeekAudio = {},
          onStopPreviewAudio = {},
          onSaveReciter = { _, _, _, _, _, _, _, _, _, _, _, _ -> },
          onMoveReciterOrder = { _, _ -> },
          onDeleteReciter = {},
          onSaveRecitation = { _, _, _, _, _, _, _, _, _, _, _, _ -> },
          onMoveRecitationOrder = { _, _, _ -> },
          onDeleteRecitation = { _, _ -> },
          onBack = {},
        )
      }
    }

    composeRule.onNodeWithTag("owner_verified_banner").assertIsDisplayed()
    composeRule.onNodeWithTag("admin_preview_reciter_sheikh_ali").performClick()
    composeRule.onNodeWithTag("reciter_preview_card").assertIsDisplayed()
    composeRule.onNodeWithText("اعتماد ونشر").assertIsDisplayed()
  }
}
