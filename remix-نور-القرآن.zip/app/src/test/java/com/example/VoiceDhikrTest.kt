package com.example

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollToNode
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.AdhkarSeedData
import com.example.data.local.NoorQuranDatabase
import com.example.data.model.DhikrPhraseItem
import com.example.dhikr.VoiceDhikrStatus
import com.example.ui.screens.VoiceDhikrScreen
import com.example.ui.theme.NoorQuranTheme
import com.example.data.remote.AlQuranApiService
import com.example.data.remote.Mp3QuranApiService
import com.example.data.repository.QuranRepository
import com.example.dhikr.DhikrSpeechMatcher
import com.example.dhikr.SpeechEngineClient
import com.example.dhikr.VoiceDhikrController
import com.example.dhikr.VoiceDhikrService
import com.example.dhikr.VoiceListeningPhase
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class VoiceDhikrTest {

  @get:Rule val composeRule = createComposeRule()

  private class FakeSpeechEngineClient(
    var available: Boolean = true,
    var onDeviceArabicSupported: Boolean = false,
    var onDeviceLocale: String = "ar-SA",
    var failOnStart: Throwable? = null,
  ) : SpeechEngineClient {
    var startCalls = 0
    var destroyCalls = 0
    var checkOnDeviceCalls = 0
    var lastStartUsedOnDeviceFallback: Boolean? = null
    var lastLanguageTag: String = "ar-SA"
    var activeListener: RecognitionListener? = null
    val listenersHistory = mutableListOf<RecognitionListener>()

    override fun isAvailable(context: Context): Boolean = available

    override fun setPreferredLanguageTag(tag: String) {
      lastLanguageTag = tag
    }

    override fun checkOnDeviceArabicSupport(
      context: Context,
      onResult: (supported: Boolean, preferredLocale: String) -> Unit,
    ) {
      checkOnDeviceCalls++
      onResult(onDeviceArabicSupported, onDeviceLocale)
    }

    override fun startListening(listener: RecognitionListener, useOnDeviceFallback: Boolean) {
      startCalls++
      lastStartUsedOnDeviceFallback = useOnDeviceFallback
      failOnStart?.let { throw it }
      activeListener = listener
      listenersHistory.add(listener)
    }

    override fun stopListening() {}

    override fun cancel() {}

    override fun destroy() {
      destroyCalls++
      activeListener = null
    }

    fun emitReady() {
      activeListener?.onReadyForSpeech(Bundle())
    }

    fun emitBeginningOfSpeech() {
      activeListener?.onBeginningOfSpeech()
    }

    fun emitEndOfSpeech() {
      activeListener?.onEndOfSpeech()
    }

    fun emitPartial(vararg candidates: String) {
      val bundle =
        Bundle().apply {
          putStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION, ArrayList(candidates.toList()))
        }
      activeListener?.onPartialResults(bundle)
    }

    fun emitUnstablePartial(stable: List<String>, unstable: List<String>) {
      val bundle =
        Bundle().apply {
          putStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION, ArrayList(stable))
          putStringArrayList("android.speech.extra.UNSTABLE_TEXT", ArrayList(unstable))
        }
      activeListener?.onPartialResults(bundle)
    }

    fun emitResults(vararg candidates: String) {
      val bundle =
        Bundle().apply {
          putStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION, ArrayList(candidates.toList()))
        }
      activeListener?.onResults(bundle)
    }

    fun emitError(errorCode: Int) {
      activeListener?.onError(errorCode)
    }
  }

  private fun createOfflineRepo(context: Context): Pair<NoorQuranDatabase, QuranRepository> {
    val db =
      Room.inMemoryDatabaseBuilder(context, NoorQuranDatabase::class.java)
        .allowMainThreadQueries()
        .build()
    val offlineClient =
      OkHttpClient.Builder().addInterceptor { throw IOException("Offline test") }.build()
    val repo =
      QuranRepository(
        context = context,
        dao = db.quranDao(),
        api = AlQuranApiService.create(offlineClient),
        mp3QuranApi = Mp3QuranApiService.create(offlineClient),
        okHttpClient = offlineClient,
      )
    return db to repo
  }

  @Test
  fun `matcher recognizes all required adhkar including istighfar and repeated counts without double counting`() {
    val phrases =
      listOf(
        "tasbih" to
          listOf("سُبْحَانَ اللَّهِ", "سبحان اللة", "سبحانالله", "وسبحـان الله", "سبحانه الله"),
        "hamd" to
          listOf("الْحَمْدُ لِلَّهِ", "الحمدلله", "الحمد الله", "والحمد لله", "الحمدله", "الحمد له"),
        "takbir" to
          listOf("اللَّهُ أَكْبَرُ", "الله اكبر", "اللة اكبر", "والله أكبر", "اللهو اكبر"),
        "istighfar" to
          listOf("استغفرالله", "أستغفر الله", "استغفر الله العظيم", "واستغفر الله"),
        "tahlil" to
          listOf(
            "لَا إِلَٰهَ إِلَّا اللَّهُ",
            "لا اله الا الله",
            "لا إلاه إلا اللة",
            "ولا إله إلا الله",
            "لإله إلا الله",
            "لا إله إلا لله",
            "لاالهالاالله",
          ),
        "hawqala" to
          listOf(
            "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ",
            "لاحول ولاقوة الا بالله",
            "لا حول و لا قوة إلا بالله",
            "لا حول ولا قوة",
          ),
        "salawat" to
          listOf(
            "اللَّهُمَّ صَلِّ وَسَلِّمْ عَلَى نَبِيِّنَا مُحَمَّدٍ",
            "اللهم صلي وسلم على نبينا محمد",
            "اللهم صل و سلم على نبينا محمد",
            "اللهم صل وسلم على النبي محمد",
            "اللهم صل وسلم وبارك على سيدنا محمد",
            "صلى الله عليه وسلم",
            "صلى الله عليه و سلم",
            "اللهم صل وسلم علی نبینا محمد",
          ),
      )

    for ((expectedId, variants) in phrases) {
      for (variant in variants) {
        val counts = DhikrSpeechMatcher.countOccurrences(variant)
        assertEquals("Failed to match variant '$variant' for $expectedId", 1, counts[expectedId])
      }
    }

    // Multiple repetitions in a single transcript count accurately without double-counting partial+final
    val tracked = mutableMapOf<String, Int>()
    val firstPartialDelta = DhikrSpeechMatcher.computeIncrementalDelta("سبحان الله", tracked)
    val secondPartialDelta = DhikrSpeechMatcher.computeIncrementalDelta("سبحان الله سبحان الله", tracked)
    val finalDelta = DhikrSpeechMatcher.computeIncrementalDelta("سبحان الله سبحان الله", tracked)
    assertEquals(mapOf("tasbih" to 1), firstPartialDelta)
    assertEquals(mapOf("tasbih" to 1), secondPartialDelta)
    assertTrue(finalDelta.isEmpty())

    // N-best candidate selection picks the matching hypothesis without double counting
    val best =
      DhikrSpeechMatcher.selectBestCandidate(
        listOf("لهم صلي", "اللهم صلي وسلم على نبينا محمد")
      )
    assertEquals("اللهم صلي وسلم على نبينا محمد", best)

    // Diagnostic inspection explains rejection clearly on unrelated Arabic speech
    val rejectedDiag = DhikrSpeechMatcher.diagnoseTranscript("السلام عليكم ورحمة الله")
    assertTrue(rejectedDiag.matchedCounts.isEmpty())
    assertTrue(rejectedDiag.rejectionReason?.contains("لم يطابق") == true)
  }

  @Test
  fun `repository incrementDhikr persists across database close and reopen`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val dbFile = context.getDatabasePath("voice_dhikr_persistence_test.db")
    dbFile.delete()
    val offlineClient =
      OkHttpClient.Builder().addInterceptor { throw IOException("Offline test") }.build()

    fun openRepo(): Pair<NoorQuranDatabase, QuranRepository> {
      val db =
        Room.databaseBuilder(context, NoorQuranDatabase::class.java, dbFile.absolutePath)
          .allowMainThreadQueries()
          .build()
      val repo =
        QuranRepository(
          context = context,
          dao = db.quranDao(),
          api = AlQuranApiService.create(offlineClient),
          mp3QuranApi = Mp3QuranApiService.create(offlineClient),
          okHttpClient = offlineClient,
        )
      return db to repo
    }

    val (db1, repo1) = openRepo()
    try {
      // Auto-seeds and saves all required dhikr increments
      assertTrue(repo1.incrementDhikr("hamd", 2))
      assertTrue(repo1.incrementDhikr("takbir", 1))
      assertTrue(repo1.incrementDhikr("istighfar", 3))
      assertTrue(repo1.incrementDhikr("tasbih", 1))
      assertTrue(repo1.incrementDhikr("hawqala", 1))
      assertTrue(repo1.incrementDhikr("salawat", 1))
      assertFalse(repo1.incrementDhikr("unknown_id", 1))
    } finally {
      db1.close()
    }

    // Reopen DB (simulating app close & reopen) and re-run ensureInitialDataSeeded()
    val (db2, repo2) = openRepo()
    try {
      repo2.ensureInitialDataSeeded()
      val persisted = repo2.dhikrCountersFlow.first().associateBy { it.id }
      assertEquals(2, persisted["hamd"]?.count)
      assertEquals(1, persisted["takbir"]?.count)
      assertEquals(3, persisted["istighfar"]?.count)
      assertEquals(1, persisted["tasbih"]?.count)
      assertEquals(1, persisted["hawqala"]?.count)
      assertEquals(1, persisted["salawat"]?.count)
    } finally {
      db2.close()
      dbFile.delete()
    }
  }

  @Test
  fun `controller enforces RECORD_AUDIO permission and speech availability`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val (db, repo) = createOfflineRepo(context)
    repo.ensureInitialDataSeeded()
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val fakeEngine = FakeSpeechEngineClient(available = true)
    var fgServiceRunning = false

    try {
      val deniedController =
        VoiceDhikrController(
          appContext = context,
          quranRepository = repo,
          speechEngineClient = fakeEngine,
          scope = scope,
          hasRecordAudioPermission = { false },
          onForegroundServiceStateChanged = { fgServiceRunning = it },
        )
      deniedController.startListening()
      assertFalse(deniedController.status.value.isListening)
      assertEquals(VoiceListeningPhase.MICROPHONE_ERROR, deniedController.status.value.phase)
      assertTrue(deniedController.status.value.statusMessage.contains("تعذر تشغيل الميكروفون"))
      assertEquals(0, fakeEngine.startCalls)
      assertFalse(fgServiceRunning)

      fakeEngine.available = false
      val unavailableController =
        VoiceDhikrController(
          appContext = context,
          quranRepository = repo,
          speechEngineClient = fakeEngine,
          scope = scope,
          hasRecordAudioPermission = { true },
          onForegroundServiceStateChanged = { fgServiceRunning = it },
        )
      unavailableController.startListening()
      assertFalse(unavailableController.status.value.isListening)
      assertFalse(unavailableController.status.value.speechAvailable)
      assertEquals(VoiceListeningPhase.MICROPHONE_ERROR, unavailableController.status.value.phase)
    } finally {
      scope.cancel()
      db.close()
    }
  }

  @Test
  fun `controller recognizes all required dhikrs without duplicates, enforces destroy-before-cooldown, and prevents overlap`() =
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val (db, repo) = createOfflineRepo(context)
      repo.ensureInitialDataSeeded()
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
      val fakeEngine = FakeSpeechEngineClient(available = true)
      var fgServiceRunning = false
      var fakeClock = 10_000L

      val controller =
        VoiceDhikrController(
          appContext = context,
          quranRepository = repo,
          speechEngineClient = fakeEngine,
          scope = scope,
          hasRecordAudioPermission = { true },
          onForegroundServiceStateChanged = { fgServiceRunning = it },
          nowMsProvider = { fakeClock },
        )

      try {
        controller.startListening()
        // Calling startListening() again while active must NOT create a second overlapping session
        controller.startListening()
        assertTrue(controller.status.value.isListening)
        assertTrue(fgServiceRunning)
        assertEquals(1, fakeEngine.startCalls)
        val firstSessionListener = fakeEngine.listenersHistory.first()

        // 1. Ready -> LISTENING
        fakeEngine.emitReady()
        assertEquals(VoiceListeningPhase.LISTENING, controller.status.value.phase)
        assertEquals("الميكروفون يعمل ويستمع", controller.status.value.statusMessage)

        // 2. Speech starts -> RECOGNIZING
        fakeEngine.emitBeginningOfSpeech()
        assertEquals(VoiceListeningPhase.RECOGNIZING, controller.status.value.phase)
        assertTrue(controller.status.value.statusMessage.contains("جاري التعرف على الصوت"))

        // 3. Partial + Final + Duplicate Final -> counted ONLY ONCE, old engine destroyed BEFORE cooldown
        val destroysBeforeResult = fakeEngine.destroyCalls
        fakeEngine.emitPartial("سبحان الله")
        fakeEngine.emitPartial("سبحان الله")
        fakeEngine.emitResults("سبحان الله", "سبحان اللة")
        // Old recognizer must already be destroyed immediately upon results, BEFORE cooldown ends
        assertTrue(fakeEngine.destroyCalls > destroysBeforeResult)
        assertEquals(1, fakeEngine.startCalls)
        // Stale callbacks from destroyed session #1 must be ignored
        firstSessionListener.onResults(
          Bundle().apply {
            putStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION, arrayListOf("سبحان الله"))
          }
        )
        firstSessionListener.onError(SpeechRecognizer.ERROR_SERVER_DISCONNECTED)

        val countersAfterFirst =
          withTimeout(3_000) {
            while (true) {
              shadowOf(Looper.getMainLooper()).idle()
              val map = repo.dhikrCountersFlow.first().associateBy { it.id }
              val diag = controller.status.value.diagnostics
              if (map["tasbih"]?.count == 1 && diag.dbSaveStatus.contains("تم حفظ الزيادة")) {
                return@withTimeout map
              }
              delay(20)
            }
            @Suppress("UNREACHABLE_CODE") emptyMap()
          }
        assertEquals(1, countersAfterFirst["tasbih"]?.count)

        // During cooldown (100ms < 350ms), session 2 must NOT start yet
        shadowOf(Looper.getMainLooper()).idleFor(100, TimeUnit.MILLISECONDS)
        assertEquals(1, fakeEngine.startCalls)

        // After 350ms cooldown finishes, session 2 starts cleanly
        shadowOf(Looper.getMainLooper()).idleFor(300, TimeUnit.MILLISECONDS)
        assertEquals(2, fakeEngine.startCalls)

        // 4. All remaining required adhkar including istighfar recognized & persisted
        fakeEngine.emitReady()
        fakeEngine.emitResults(
          "الحمد لله والله أكبر واستغفرالله ولا إله إلا الله ولا حول و لا قوة إلا بالله واللهم صل و سلم على نبينا محمد"
        )

        val expectedIds = setOf("hamd", "takbir", "istighfar", "tahlil", "hawqala", "salawat")
        val countersAfterAll =
          withTimeout(3_000) {
            while (true) {
              shadowOf(Looper.getMainLooper()).idle()
              val map = repo.dhikrCountersFlow.first().associateBy { it.id }
              if (expectedIds.all { (map[it]?.count ?: 0) == 1 }) return@withTimeout map
              delay(20)
            }
            @Suppress("UNREACHABLE_CODE") emptyMap()
          }
        for (id in expectedIds) {
          assertEquals("Expected count 1 for $id", 1, countersAfterAll[id]?.count)
        }

        // 5. ERROR_NO_MATCH -> shows NO_SPEECH_MATCH and restarts after 350ms cooldown
        shadowOf(Looper.getMainLooper()).idleFor(400, TimeUnit.MILLISECONDS)
        assertEquals(3, fakeEngine.startCalls)
        fakeEngine.emitReady()
        fakeEngine.emitError(SpeechRecognizer.ERROR_NO_MATCH)
        assertEquals(VoiceListeningPhase.NO_SPEECH_MATCH, controller.status.value.phase)
        assertEquals("لم يتم التعرف على الكلام", controller.status.value.statusMessage)
        assertTrue(controller.status.value.isListening)

        shadowOf(Looper.getMainLooper()).idleFor(400, TimeUnit.MILLISECONDS)
        assertEquals(4, fakeEngine.startCalls)

        // After NO_MATCH display window expires on next ready, reverts to LISTENING
        fakeClock += 2_000L
        fakeEngine.emitReady()
        shadowOf(Looper.getMainLooper()).idleFor(1500, TimeUnit.MILLISECONDS)
        assertEquals(VoiceListeningPhase.LISTENING, controller.status.value.phase)

        // 6. ERROR_RECOGNIZER_BUSY -> destroys first, waits >= 900ms cooldown, then restarts
        val destroysBeforeBusy = fakeEngine.destroyCalls
        fakeEngine.emitError(SpeechRecognizer.ERROR_RECOGNIZER_BUSY)
        assertTrue(fakeEngine.destroyCalls > destroysBeforeBusy)
        shadowOf(Looper.getMainLooper()).idleFor(400, TimeUnit.MILLISECONDS)
        assertEquals(4, fakeEngine.startCalls) // still in cooldown!
        shadowOf(Looper.getMainLooper()).idleFor(600, TimeUnit.MILLISECONDS)
        assertEquals(5, fakeEngine.startCalls)

        // 7. ERROR_INSUFFICIENT_PERMISSIONS -> MICROPHONE_ERROR & stops foreground service
        fakeEngine.emitError(SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS)
        assertFalse(controller.status.value.isListening)
        assertFalse(fgServiceRunning)
        assertEquals(VoiceListeningPhase.MICROPHONE_ERROR, controller.status.value.phase)
        assertTrue(controller.status.value.statusMessage.contains("تعذر تشغيل الميكروفون"))

        controller.pauseListening()
        assertEquals(VoiceListeningPhase.IDLE, controller.status.value.phase)
      } finally {
        controller.release()
        scope.cancel()
        db.close()
      }
    }

  @Test
  fun `controller falls back to on-device Arabic on ERROR_SERVER_DISCONNECTED and stops loop via circuit breaker`() =
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val (db, repo) = createOfflineRepo(context)
      repo.ensureInitialDataSeeded()
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

      try {
        // Case A: On-device Arabic IS supported -> ERROR_SERVER_DISCONNECTED switches to on-device and succeeds
        val fallbackEngine =
          FakeSpeechEngineClient(
            available = true,
            onDeviceArabicSupported = true,
            onDeviceLocale = "ar-SA",
          )
        val controllerA =
          VoiceDhikrController(
            appContext = context,
            quranRepository = repo,
            speechEngineClient = fallbackEngine,
            scope = scope,
            hasRecordAudioPermission = { true },
            onForegroundServiceStateChanged = {},
          )
        controllerA.startListening()
        assertEquals(false, fallbackEngine.lastStartUsedOnDeviceFallback)
        fallbackEngine.emitReady()
        fallbackEngine.emitBeginningOfSpeech()
        fallbackEngine.emitError(SpeechRecognizer.ERROR_SERVER_DISCONNECTED)
        assertEquals(1, fallbackEngine.checkOnDeviceCalls)

        shadowOf(Looper.getMainLooper()).idleFor(1000, TimeUnit.MILLISECONDS)
        assertEquals(2, fallbackEngine.startCalls)
        assertEquals(true, fallbackEngine.lastStartUsedOnDeviceFallback)

        // On-device session succeeds and increments "hamd"
        fallbackEngine.emitReady()
        fallbackEngine.emitResults("الحمد لله")
        val mapA =
          withTimeout(3_000) {
            while (true) {
              shadowOf(Looper.getMainLooper()).idle()
              val m = repo.dhikrCountersFlow.first().associateBy { it.id }
              if (m["hamd"]?.count == 1) return@withTimeout m
              delay(20)
            }
            @Suppress("UNREACHABLE_CODE") emptyMap()
          }
        assertEquals(1, mapA["hamd"]?.count)
        controllerA.release()

        // Case B: Persistent onReadyForSpeech -> onBeginningOfSpeech -> ERROR_SERVER_DISCONNECTED loop
        // with no on-device Arabic must NOT loop infinitely (circuit breaker stops at 4 attempts)
        val brokenEngine =
          FakeSpeechEngineClient(available = true, onDeviceArabicSupported = false)
        val controllerB =
          VoiceDhikrController(
            appContext = context,
            quranRepository = repo,
            speechEngineClient = brokenEngine,
            scope = scope,
            hasRecordAudioPermission = { true },
            onForegroundServiceStateChanged = {},
          )
        controllerB.startListening()
        repeat(3) { attempt ->
          brokenEngine.emitReady()
          brokenEngine.emitBeginningOfSpeech()
          brokenEngine.emitError(SpeechRecognizer.ERROR_SERVER_DISCONNECTED)
          assertTrue(
            "Should still recover on attempt ${attempt + 1}",
            controllerB.status.value.isListening,
          )
          shadowOf(Looper.getMainLooper()).idleFor(3000, TimeUnit.MILLISECONDS)
        }
        // 4th consecutive disconnect breaks the loop cleanly
        brokenEngine.emitReady()
        brokenEngine.emitBeginningOfSpeech()
        brokenEngine.emitError(SpeechRecognizer.ERROR_SERVER_DISCONNECTED)
        assertFalse(controllerB.status.value.isListening)
        assertEquals(VoiceListeningPhase.MICROPHONE_ERROR, controllerB.status.value.phase)
        assertTrue(
          controllerB.status.value.diagnostics.rejectionReason?.contains("ERROR_SERVER_DISCONNECTED") == true
        )
        // Advancing time further must NOT restart after circuit breaker stopped
        val startsAtStop = brokenEngine.startCalls
        shadowOf(Looper.getMainLooper()).idleFor(5000, TimeUnit.MILLISECONDS)
        assertEquals(startsAtStop, brokenEngine.startCalls)
        controllerB.release()
      } finally {
        scope.cancel()
        db.close()
      }
    }

  @Test
  fun `controller recovers when SpeechRecognizer hangs in recognizing without onResults and reads unstable partials`() =
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val (db, repo) = createOfflineRepo(context)
      repo.ensureInitialDataSeeded()
      val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
      val fakeEngine = FakeSpeechEngineClient(available = true)
      var fakeClock = 20_000L

      val controller =
        VoiceDhikrController(
          appContext = context,
          quranRepository = repo,
          speechEngineClient = fakeEngine,
          scope = scope,
          hasRecordAudioPermission = { true },
          onForegroundServiceStateChanged = {},
          nowMsProvider = { fakeClock },
        )

      try {
        controller.startListening()
        fakeEngine.emitReady()
        fakeEngine.emitBeginningOfSpeech()
        assertEquals(VoiceListeningPhase.RECOGNIZING, controller.status.value.phase)

        // Simulate engine ending speech and hanging without delivering onResults or onError
        fakeEngine.emitEndOfSpeech()
        shadowOf(Looper.getMainLooper()).idleFor(2500, TimeUnit.MILLISECONDS)

        // Watchdog should have exited RECOGNIZING cleanly, logged diagnostic reason, and started cooldown
        assertEquals(VoiceListeningPhase.NO_SPEECH_MATCH, controller.status.value.phase)
        assertTrue(
          controller.status.value.diagnostics.rejectionReason?.contains("دون إرسال نص نهائي") == true
        )
        shadowOf(Looper.getMainLooper()).idleFor(400, TimeUnit.MILLISECONDS)
        assertEquals(2, fakeEngine.startCalls)

        // Next session: unstable partial text (`android.speech.extra.UNSTABLE_TEXT`) combines with prefix
        fakeEngine.emitReady()
        fakeEngine.emitUnstablePartial(stable = listOf("الله"), unstable = listOf("أكبر"))

        val map =
          withTimeout(3_000) {
            while (true) {
              shadowOf(Looper.getMainLooper()).idle()
              val m = repo.dhikrCountersFlow.first().associateBy { it.id }
              if (m["takbir"]?.count == 1) return@withTimeout m
              delay(20)
            }
            @Suppress("UNREACHABLE_CODE") emptyMap()
          }
        assertEquals(1, map["takbir"]?.count)
        fakeEngine.emitResults("الله أكبر")

        // Next fresh session: unmatched final speech logs rejection reason cleanly
        shadowOf(Looper.getMainLooper()).idleFor(400, TimeUnit.MILLISECONDS)
        assertEquals(3, fakeEngine.startCalls)
        fakeEngine.emitReady()
        fakeEngine.emitResults("صباح الخير")
        assertEquals(VoiceListeningPhase.NO_SPEECH_MATCH, controller.status.value.phase)
        assertEquals("صباح الخير", controller.status.value.diagnostics.recognizedText)
        assertTrue(
          controller.status.value.diagnostics.rejectionReason?.contains("لم يطابق") == true
        )
      } finally {
        controller.release()
        scope.cancel()
        db.close()
      }
    }

  @Test
  fun `manifest declares microphone foreground service and RECORD_AUDIO permission`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val pm = context.packageManager
    val pkgInfo = pm.getPackageInfo(context.packageName, PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES)

    val requestedPermissions = pkgInfo.requestedPermissions?.toSet().orEmpty()
    assertTrue(Manifest.permission.RECORD_AUDIO in requestedPermissions)
    assertTrue(Manifest.permission.FOREGROUND_SERVICE in requestedPermissions)
    assertTrue(Manifest.permission.FOREGROUND_SERVICE_MICROPHONE in requestedPermissions)

    val serviceInfo =
      pm.getServiceInfo(ComponentName(context, VoiceDhikrService::class.java), 0)
    assertEquals(
      ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE,
      serviceInfo.foregroundServiceType and ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE,
    )
  }

  @Test
  fun `voice dhikr screen displays all 4 required status phases, diagnostics, and updated dhikr counts`() {
    var statusState by
      mutableStateOf(
        VoiceDhikrStatus(
          isListening = true,
          phase = VoiceListeningPhase.LISTENING,
          statusMessage = "الميكروفون يعمل ويستمع",
        )
      )
    var items by
      mutableStateOf(
        AdhkarSeedData.initialVoiceDhikrCounters.map {
          DhikrPhraseItem(it.id, it.arabicTitle, it.subtitle, it.count, it.lastUpdated)
        }
      )

    composeRule.setContent {
      NoorQuranTheme {
        VoiceDhikrScreen(
          status = statusState,
          counters = items,
          onStartListening = {},
          onPauseListening = {},
          onPermissionDenied = {},
          onResetSingleCounter = {},
          onResetAllCounters = {},
        )
      }
    }

    composeRule.waitForIdle()
    composeRule.onNodeWithTag("voice_status_phase_badge").assertTextContains("الميكروفون يعمل ويستمع")

    for (requiredId in listOf("tasbih", "hamd", "takbir", "istighfar", "tahlil", "hawqala", "salawat")) {
      composeRule
        .onNodeWithTag("voice_dhikr_list")
        .performScrollToNode(hasTestTag("voice_dhikr_card_$requiredId"))
      composeRule.onNodeWithTag("voice_dhikr_card_$requiredId").assertIsDisplayed()
    }
    composeRule
      .onNodeWithTag("voice_dhikr_list")
      .performScrollToNode(hasTestTag("voice_dhikr_card_tahlil"))
    composeRule.onNodeWithText("لا إله إلا الله").assertIsDisplayed()

    // Increment tasbih count in state -> verify UI reflects count immediately and shows diagnostics
    items =
      items.map { if (it.id == "tasbih") it.copy(count = 7) else it }
    statusState =
      statusState.copy(
        lastHeardText = "سبحان الله",
        lastMatchedDhikrId = "tasbih",
        lastMatchedDhikrTitle = "سبحان الله",
        diagnostics =
          com.example.dhikr.VoiceDhikrDiagnostics(
            recognizedText = "سبحان الله",
            normalizedText = "سبحان الله",
            matchedDhikrTitles = listOf("سبحان الله"),
            dbSaveStatus = "تم حفظ الزيادة بنجاح: سبحان الله (+1)",
          ),
      )
    composeRule.waitForIdle()
    composeRule
      .onNodeWithTag("voice_dhikr_list")
      .performScrollToNode(hasTestTag("voice_dhikr_card_tasbih"))
    composeRule.onNodeWithText("7").assertIsDisplayed()

    composeRule
      .onNodeWithTag("voice_dhikr_list")
      .performScrollToNode(hasTestTag("voice_listening_panel"))
    composeRule.onNodeWithTag("voice_diagnostics_panel").assertIsDisplayed()

    statusState =
      statusState.copy(
        phase = VoiceListeningPhase.RECOGNIZING,
        statusMessage = "جاري التعرف على الصوت…",
      )
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("voice_status_phase_badge").assertTextContains("جاري التعرف على الصوت")

    statusState =
      statusState.copy(
        phase = VoiceListeningPhase.NO_SPEECH_MATCH,
        statusMessage = "لم يتم التعرف على الكلام",
      )
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("voice_status_phase_badge").assertTextContains("لم يتم التعرف على الكلام")

    statusState =
      statusState.copy(
        isListening = false,
        phase = VoiceListeningPhase.MICROPHONE_ERROR,
        statusMessage = "تعذر تشغيل الميكروفون",
      )
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("voice_status_phase_badge").assertTextContains("تعذر تشغيل الميكروفون")
  }
}
