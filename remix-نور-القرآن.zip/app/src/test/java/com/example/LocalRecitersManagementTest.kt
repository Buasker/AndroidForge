package com.example

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.audio.AudioPlaybackMode
import com.example.audio.AudioPlaybackState
import com.example.audio.QuranAudioPlayer
import com.example.data.firebase.AudioHostingProvider
import com.example.data.firebase.FirebaseReciter
import com.example.data.firebase.FreeAudioHostingService
import com.example.data.local.NoorQuranDatabase
import com.example.data.local.QuranSeedData
import com.example.data.model.AyahItem
import com.example.data.model.LocalRecitationTrack
import com.example.data.model.LocalReciter
import com.example.data.model.QuranCatalog
import com.example.data.model.ReciterOption
import com.example.data.model.SurahInfo
import com.example.data.remote.AlQuranApiService
import com.example.data.remote.Mp3QuranApiService
import com.example.data.repository.QuranRepository
import com.example.ui.screens.ManageLocalRecitersScreen
import com.example.ui.screens.RecitersScreen
import com.example.ui.theme.NoorQuranTheme
import com.example.ui.viewmodel.ReciterSourceFilter
import com.example.ui.viewmodel.RecitersViewModel
import java.io.File
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LocalRecitersManagementTest {

  @get:Rule val composeRule = createComposeRule()

  private fun createFileBackedRepo(
    context: Context,
    dbName: String,
  ): Pair<NoorQuranDatabase, QuranRepository> {
    val db =
      Room.databaseBuilder(context, NoorQuranDatabase::class.java, dbName)
        .addMigrations(
          NoorQuranDatabase.MIGRATION_2_3,
          NoorQuranDatabase.MIGRATION_3_4,
        )
        .allowMainThreadQueries()
        .build()

    val client = OkHttpClient()
    val repo =
      QuranRepository(
        context = context,
        dao = db.quranDao(),
        api = AlQuranApiService.create(client),
        mp3QuranApi = Mp3QuranApiService.create(client),
        okHttpClient = client,
      )
    return db to repo
  }

  @Test
  fun `local reciters and recitations persist across database close and reopen`() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val dbName = "local_reciters_persist_${System.nanoTime()}.db"
    context.deleteDatabase(dbName)

    val (db1, repo1) = createFileBackedRepo(context, dbName)
    val savedReciter =
      repo1.saveLocalReciter(
        editingId = null,
        arabicName = "الشيخ عبدالولي الأركاني",
        description = "تلاوات خاشعة بصوت ندي",
        riwayah = "حفص عن عاصم",
        photoPathOrUrl = "https://example.com/arkani.jpg",
        fullSurahBaseUrl = "https://server11.mp3quran.net/arkani/",
      ).getOrThrow()

    val savedTrack =
      repo1.saveLocalRecitation(
        reciterId = savedReciter.id,
        surahNumber = 18,
        audioUrl = "https://archive.org/download/arkani/018_custom.mp3",
        notes = "تلاوة سورة الكهف كاملة",
        isEdit = false,
      ).getOrThrow()

    assertEquals("سُورَةُ الكَهۡفِ", savedTrack.surahArabicName)
    db1.close()

    // Reopen the exact same database to verify durable local persistence
    val (db2, repo2) = createFileBackedRepo(context, dbName)
    try {
      val persistedReciters = repo2.localRecitersFlow.first()
      assertEquals(1, persistedReciters.size)
      assertEquals(savedReciter.id, persistedReciters.first().id)
      assertEquals("الشيخ عبدالولي الأركاني", persistedReciters.first().arabicName)
      assertEquals("تلاوات خاشعة بصوت ندي", persistedReciters.first().description)
      assertEquals("https://server11.mp3quran.net/arkani/", persistedReciters.first().fullSurahBaseUrl)

      val persistedTracks = repo2.localRecitationsForReciterFlow(savedReciter.id).first()
      assertEquals(1, persistedTracks.size)
      assertEquals(18, persistedTracks.first().surahNumber)
      assertEquals("https://archive.org/download/arkani/018_custom.mp3", persistedTracks.first().audioUrl)
      assertEquals("تلاوة سورة الكهف كاملة", persistedTracks.first().notes)

      // Priority order: explicit Surah link overrides base server folder, while Surah 2 resolves from base folder
      assertEquals(
        "https://archive.org/download/arkani/018_custom.mp3",
        repo2.resolveSurahAudioSource(savedReciter.id, 18),
      )
      assertEquals(
        "https://server11.mp3quran.net/arkani/002.mp3",
        repo2.resolveSurahAudioSource(savedReciter.id, 2),
      )
    } finally {
      db2.close()
      context.deleteDatabase(dbName)
    }
  }

  @Test
  fun `validation blocks duplicate reciter names, duplicate surahs on create, and unsafe urls`() =
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val dbName = "local_reciters_validation_${System.nanoTime()}.db"
      context.deleteDatabase(dbName)
      val (db, repo) = createFileBackedRepo(context, dbName)
      try {
        val first =
          repo.saveLocalReciter(
            editingId = null,
            arabicName = "الشيخ أحمد النفيس",
            description = "قارئ من الكويت",
            riwayah = "حفص عن عاصم",
            photoPathOrUrl = "",
            fullSurahBaseUrl = "",
          ).getOrThrow()

        // Duplicate name with subtle Hamza variation rejected
        val dupName =
          repo.saveLocalReciter(
            editingId = null,
            arabicName = "الشيخ احمد النفيس",
            description = "",
            riwayah = "",
            photoPathOrUrl = "",
            fullSurahBaseUrl = "",
          )
        assertTrue(dupName.isFailure)

        // Unsafe URL rejected on saveLocalRecitation
        val badUrl =
          repo.saveLocalRecitation(
            reciterId = first.id,
            surahNumber = 1,
            audioUrl = "http://example.com/001.mp3",
            notes = "",
            isEdit = false,
          )
        assertTrue(badUrl.isFailure)

        // Create Surah 1 works
        val created =
          repo.saveLocalRecitation(
            reciterId = first.id,
            surahNumber = 1,
            audioUrl = "https://example.com/audio/001.mp3",
            notes = "نسخة أولى",
            isEdit = false,
          )
        assertTrue(created.isSuccess)

        // Duplicate Surah 1 rejected when isEdit = false
        val duplicateSurah =
          repo.saveLocalRecitation(
            reciterId = first.id,
            surahNumber = 1,
            audioUrl = "https://example.com/audio/001_v2.mp3",
            notes = "نسخة ثانية",
            isEdit = false,
          )
        assertTrue(duplicateSurah.isFailure)

        // Editing Surah 1 succeeds when isEdit = true
        val editedSurah =
          repo.saveLocalRecitation(
            reciterId = first.id,
            surahNumber = 1,
            audioUrl = "https://example.com/audio/001_v2.mp3",
            notes = "محدثة",
            isEdit = true,
          )
        assertTrue(editedSurah.isSuccess)
        assertEquals("https://example.com/audio/001_v2.mp3", editedSurah.getOrThrow().audioUrl)

        // Unlinked Surah throws clear Arabic message when reciter has no fullSurahBaseUrl
        var thrownMessage: String? = null
        try {
          repo.resolveSurahAudioSource(first.id, 36)
        } catch (e: IllegalStateException) {
          thrownMessage = e.message
        }
        assertNotNull(thrownMessage)
        assertTrue(thrownMessage!!.contains("لا يوجد رابط تلاوة"))
      } finally {
        db.close()
        context.deleteDatabase(dbName)
      }
    }

  @Test
  fun `full surah url resolver supports directory base, template, and single mp3 url`() =
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val dbName = "local_reciters_urls_${System.nanoTime()}.db"
      context.deleteDatabase(dbName)
      val (db, repo) = createFileBackedRepo(context, dbName)
      try {
        assertEquals(
          "https://server.mp3quran.net/test/001.mp3",
          repo.resolveUrlFromFullSurahSetting("https://server.mp3quran.net/test", 1),
        )
        assertEquals(
          "https://server.mp3quran.net/test/114.mp3",
          repo.resolveUrlFromFullSurahSetting("https://server.mp3quran.net/test/", 114),
        )
        assertEquals(
          "https://example.com/qari/surah_036.mp3",
          repo.resolveUrlFromFullSurahSetting("https://example.com/qari/surah_{03d}.mp3", 36),
        )
        assertEquals(
          "https://example.com/recitation/single_full.mp3",
          repo.resolveUrlFromFullSurahSetting("https://example.com/recitation/single_full.mp3", 18),
        )
      } finally {
        db.close()
        context.deleteDatabase(dbName)
      }
    }

  @Test
  fun `deleting local recitation and deleting local reciter cleans up tracks and owned photo`() =
    runBlocking {
      val context = ApplicationProvider.getApplicationContext<Context>()
      val dbName = "local_reciters_delete_${System.nanoTime()}.db"
      context.deleteDatabase(dbName)
      val (db, repo) = createFileBackedRepo(context, dbName)

      val photosDir = File(context.filesDir, "reciter_photos").apply { mkdirs() }
      val tempPhoto = File(photosDir, "test_photo_${System.nanoTime()}.jpg").apply {
        writeBytes(byteArrayOf(1, 2, 3, 4))
      }

      try {
        val reciter =
          repo.saveLocalReciter(
            editingId = null,
            arabicName = "الشيخ بدر التركي",
            description = "نبذة",
            riwayah = "حفص عن عاصم",
            photoPathOrUrl = tempPhoto.absolutePath,
            fullSurahBaseUrl = "",
          ).getOrThrow()

        repo.saveLocalRecitation(reciter.id, 1, "https://example.com/001.mp3", "", false).getOrThrow()
        repo.saveLocalRecitation(reciter.id, 2, "https://example.com/002.mp3", "", false).getOrThrow()

        assertEquals(2, repo.localRecitationsForReciterFlow(reciter.id).first().size)
        repo.deleteLocalRecitation(reciter.id, 1)
        val afterSingleDelete = repo.localRecitationsForReciterFlow(reciter.id).first()
        assertEquals(1, afterSingleDelete.size)
        assertEquals(2, afterSingleDelete.first().surahNumber)

        repo.deleteLocalReciter(reciter.id).getOrThrow()
        assertTrue(repo.localRecitersFlow.first().isEmpty())
        assertTrue(repo.localRecitationsForReciterFlow(reciter.id).first().isEmpty())
        assertFalse(tempPhoto.exists())
      } finally {
        tempPhoto.delete()
        db.close()
        context.deleteDatabase(dbName)
      }
    }

  @Test
  fun `mergePublishedAndCatalogReciters merges local reciters with custom flag`() {
    val localReciter =
      LocalReciter(
        id = "local_abc123",
        arabicName = "الشيخ المضاف محلياً",
        description = "وصف مختصر",
        riwayah = "حفص عن عاصم",
        photoPathOrUrl = "",
        fullSurahBaseUrl = "https://example.com/audio/",
      )
    val cloudReciter =
      FirebaseReciter(
        id = "cloud_sheikh",
        arabicName = "قارئ سحابي",
        riwayah = "ورش عن نافع",
        sortOrder = 1L,
        published = true,
      )

    val merged = RecitersViewModel.mergePublishedAndCatalogReciters(listOf(cloudReciter), listOf(localReciter))
    assertEquals(QuranCatalog.reciters.size + 2, merged.size)

    val mergedLocal = merged.first { it.identifier == "local_abc123" }
    assertTrue(mergedLocal.isLocalCustom)
    assertFalse(mergedLocal.isCloudSynced)
    assertEquals("https://example.com/audio/", mergedLocal.defaultSurahServerUrl)
    assertEquals("وصف مختصر", mergedLocal.bioArabic)
  }

  @Test
  fun `audio player routes local reciter playAyah from mushaf to full surah mode and surfaces errors cleanly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val localOption =
      ReciterOption(
        identifier = "local_custom_sheikh",
        arabicName = "الشيخ المضاف",
        styleArabic = "حفص عن عاصم",
        islamicNetworkId = null,
        everyAyahFolder = null,
        mp3QuranSearchKeywords = emptyList(),
        defaultSurahServerUrl = "",
        riwayah = "حفص عن عاصم",
        isLocalCustom = true,
      )
    val player =
      QuranAudioPlayer(context) { reciterId, surahNum ->
        if (reciterId == "local_custom_sheikh" && surahNum == 1) {
          throw IllegalStateException("لا يوجد رابط تلاوة مضاف لهذه السورة عند القارئ المختار.")
        }
        "https://example.com/001.mp3"
      }
    try {
      player.updateKnownReciters(QuranCatalog.reciters + localOption)
      val fatiha =
        SurahInfo(
          number = 1,
          arabicName = "سُورَةُ ٱلْفَاتِحَةِ",
          englishName = "Al-Fatiha",
          englishNameTranslation = "The Opening",
          numberOfAyahs = 7,
          revelationType = "Meccan",
        )
      val ayahs =
        listOf(
          AyahItem(
            globalNumber = 1,
            numberInSurah = 1,
            surahNumber = 1,
            surahArabicName = fatiha.arabicName,
            arabicText = "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ",
            translationText = "In the name of Allah",
            juz = 1,
            page = 1,
          )
        )

      player.playAyah(
        surah = fatiha,
        ayahs = ayahs,
        startAyahInSurah = 1,
        reciterId = localOption.identifier,
      )

      val state = player.state.value
      assertTrue(state.isActive)
      assertEquals(AudioPlaybackMode.FULL_SURAH, state.mode)
      assertEquals("الشيخ المضاف", state.reciterName)
      assertEquals(
        "لا يوجد رابط تلاوة مضاف لهذه السورة عند القارئ المختار.",
        state.errorMessage,
      )
    } finally {
      player.release()
    }
  }

  @Test
  fun `ManageLocalRecitersScreen add, display, and delete with confirmation works cleanly`() {
    var recitersState by mutableStateOf<List<LocalReciter>>(emptyList())
    var selectedReciterState by mutableStateOf<LocalReciter?>(null)
    val surahs =
      QuranSeedData.surahs.take(5).map {
        SurahInfo(
          number = it.number,
          arabicName = it.arabicName,
          englishName = it.englishName,
          englishNameTranslation = it.englishNameTranslation,
          numberOfAyahs = it.numberOfAyahs,
          revelationType = it.revelationType,
        )
      }

    composeRule.setContent {
      NoorQuranTheme {
        ManageLocalRecitersScreen(
          reciters = recitersState,
          trackCountByReciter = emptyMap(),
          selectedReciter = selectedReciterState,
          recitationsForSelected = emptyList(),
          surahs = surahs,
          preferredReciterId = "ar.alafasy",
          searchQuery = "",
          isBusy = false,
          isProbingUrl = false,
          probeResult = null,
          audioState = AudioPlaybackState(),
          statusMessage = null,
          onClearMessage = {},
          onClearProbeResult = {},
          onSearchQueryChange = {},
          onOpenReciter = { id -> selectedReciterState = recitersState.firstOrNull { it.id == id } },
          onBackToList = { selectedReciterState = null },
          onProbeAudioUrl = {},
          onImportPhotoUri = { _, _, _ -> },
          onSaveReciter = { editingId, name, desc, riwayah, photo, baseUrl, onResult ->
            val saved =
              LocalReciter(
                id = editingId ?: "local_ui_1",
                arabicName = name.trim(),
                description = desc.trim(),
                riwayah = riwayah.trim(),
                photoPathOrUrl = photo.trim(),
                fullSurahBaseUrl = baseUrl.trim(),
              )
            recitersState = listOf(saved)
            onResult(Result.success(saved))
          },
          onDeleteReciter = { target ->
            recitersState = recitersState.filterNot { it.id == target.id }
            selectedReciterState = null
          },
          onSaveRecitation = { _, _, _, _, _, _ -> },
          onDeleteRecitation = { _, _ -> },
          onSetPreferredReciter = {},
          onPlayTrack = { _, _ -> },
          onPlayFullSurahSample = { _, _ -> },
          onTogglePlayPause = {},
          onSeekTo = {},
          onSeekBySeconds = {},
          onStopPlayback = {},
        )
      }
    }

    composeRule.onNodeWithTag("local_reciters_empty_state").assertIsDisplayed()
    composeRule.onNodeWithTag("local_add_reciter_button").performClick()

    composeRule.onNodeWithTag("local_reciter_name_input").performTextInput("الشيخ ناصر القطامي")
    composeRule.onNodeWithTag("local_reciter_bio_input").performTextInput("تلاوات مختارة")
    composeRule.onNodeWithTag("save_local_reciter_button").performClick()

    composeRule.waitForIdle()
    composeRule.onNodeWithTag("local_reciter_card_local_ui_1").assertIsDisplayed()
    composeRule.onNodeWithText("الشيخ ناصر القطامي").assertIsDisplayed()

    // Click delete icon -> confirmation dialog MUST appear before deleting
    composeRule.onNodeWithTag("delete_local_reciter_local_ui_1").performScrollTo().performClick()
    composeRule.waitForIdle()
    composeRule.onNodeWithTag("confirm_delete_reciter_dialog").assertIsDisplayed()
    assertEquals(1, recitersState.size)

    // Confirm deletion -> reciter removed and empty state restored
    composeRule.onNodeWithTag("confirm_delete_reciter_button").performClick()
    composeRule.waitForIdle()
    assertEquals(0, recitersState.size)
    composeRule.onNodeWithTag("local_reciters_empty_state").assertIsDisplayed()
  }

  @Test
  fun `RecitersScreen shows local custom badge and plays added local surah tracks`() {
    val localReciter =
      ReciterOption(
        identifier = "local_custom_1",
        arabicName = "الشيخ خالد الغامدي",
        styleArabic = "حفص عن عاصم",
        islamicNetworkId = null,
        everyAyahFolder = null,
        mp3QuranSearchKeywords = emptyList(),
        defaultSurahServerUrl = "",
        riwayah = "حفص عن عاصم",
        bioArabic = "إمام الحرم المكي",
        isLocalCustom = true,
      )
    val localTrack =
      LocalRecitationTrack(
        reciterId = "local_custom_1",
        surahNumber = 18,
        surahArabicName = "سُورَةُ الكَهْفِ",
        audioUrl = "https://example.com/018.mp3",
        notes = "تسجيل متقن",
      )
    var selected by mutableStateOf<ReciterOption?>(null)
    var playedTrack by mutableStateOf<LocalRecitationTrack?>(null)

    composeRule.setContent {
      NoorQuranTheme {
        RecitersScreen(
          reciters = listOf(localReciter),
          selectedReciter = selected,
          preferredReciterId = "ar.alafasy",
          searchQuery = "",
          sourceFilter = ReciterSourceFilter.LOCAL,
          trackSearchQuery = "",
          publishedTracks = emptyList(),
          localTracks = if (selected != null) listOf(localTrack) else emptyList(),
          catalogSurahs = emptyList(),
          downloadedSurahs = emptySet(),
          downloadProgressMap = emptyMap(),
          audioState = AudioPlaybackState(),
          statusMessage = null,
          onClearMessage = {},
          onSearchQueryChange = {},
          onSourceFilterChange = {},
          onOpenReciter = { selected = localReciter },
          onBackToRecitersList = { selected = null },
          onTrackSearchQueryChange = {},
          onSetPreferredReciter = {},
          onPlayCloudRecitation = { _, _ -> },
          onPlayLocalRecitation = { track, _ -> playedTrack = track },
          onPlayCatalogSurah = { _, _ -> },
          onTogglePlayPause = {},
          onSeekTo = {},
          onSeekBySeconds = {},
          onStopPlayback = {},
          onDownloadSurah = {},
          onDeleteDownload = {},
        )
      }
    }

    composeRule.onNodeWithTag("reciter_directory_card_local_custom_1").assertIsDisplayed()
    composeRule.onNodeWithText("مضاف محلياً").assertIsDisplayed()
    composeRule.onNodeWithTag("reciter_directory_card_local_custom_1").performClick()

    composeRule.waitForIdle()
    composeRule.onNodeWithTag("local_track_card_18").performScrollTo().assertIsDisplayed()
    composeRule.onNodeWithTag("play_local_track_18").performScrollTo().performClick()
    composeRule.waitForIdle()
    assertEquals(18, playedTrack?.surahNumber)
    assertTrue(composeRule.onAllNodesWithTag("reciter_no_tracks_empty").fetchSemanticsNodes().isEmpty())
  }
}
