package com.example.share

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.model.AyahItem
import java.io.File
import java.io.FileOutputStream

object DailyPagePosterGenerator {
  fun generatePosterBitmap(
    context: Context,
    pageNumber: Int,
    surahNames: String,
    ayahs: List<AyahItem>,
  ): Bitmap {
    val width = 1080
    val paddingH = 88f
    val maxTextWidth = (width - paddingH * 2).toInt()

    val amiriTypeface =
      ResourcesCompat.getFont(context, R.font.amiri) ?: Typeface.SERIF
    val cairoTypeface =
      ResourcesCompat.getFont(context, R.font.cairo) ?: Typeface.SANS_SERIF

    val combinedArabic =
      ayahs.joinToString("  ") { ayah -> "${ayah.arabicText} ﴿${ayah.numberInSurah}﴾" }

    val quranPaint =
      TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.parseColor("#1B211E")
        textSize = if (combinedArabic.length > 900) 34f else 42f
        typeface = amiriTypeface
      }

    val staticLayout =
      StaticLayout.Builder.obtain(combinedArabic, 0, combinedArabic.length, quranPaint, maxTextWidth)
        .setAlignment(Layout.Alignment.ALIGN_CENTER)
        .setLineSpacing(14f, 1.35f)
        .build()

    val headerHeight = 250f
    val footerHeight = 170f
    val height = (headerHeight + staticLayout.height + footerHeight + 120f).toInt().coerceAtLeast(1350)

    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)

    // Parchment background
    canvas.drawColor(android.graphics.Color.parseColor("#FAF5EA"))

    // Outer emerald frame
    val outerBorderPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.parseColor("#0F5C4D")
        style = Paint.Style.STROKE
        strokeWidth = 10f
      }
    canvas.drawRoundRect(RectF(28f, 28f, width - 28f, height - 28f), 36f, 36f, outerBorderPaint)

    // Inner gold frame
    val innerBorderPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.parseColor("#B8862D")
        style = Paint.Style.STROKE
        strokeWidth = 3f
      }
    canvas.drawRoundRect(RectF(46f, 46f, width - 46f, height - 46f), 26f, 26f, innerBorderPaint)

    // Header pill background
    val headerBgPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.parseColor("#0F5C4D")
      }
    canvas.drawRoundRect(RectF(80f, 78f, width - 80f, 210f), 24f, 24f, headerBgPaint)

    val titlePaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.parseColor("#F6D98D")
        textSize = 44f
        typeface = Typeface.create(amiriTypeface, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
      }
    canvas.drawText(surahNames.ifBlank { "القرآن الكريم" }, width / 2f, 142f, titlePaint)

    val subPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.WHITE
        textSize = 26f
        typeface = cairoTypeface
        textAlign = Paint.Align.CENTER
      }
    canvas.drawText("الصفحة $pageNumber من المصحف الشريف", width / 2f, 188f, subPaint)

    // Draw Quran text
    canvas.save()
    canvas.translate(paddingH, headerHeight + 28f)
    staticLayout.draw(canvas)
    canvas.restore()

    // Footer branding
    val dividerPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.parseColor("#B8862D")
        strokeWidth = 2f
      }
    val footerY = height - 125f
    canvas.drawLine(140f, footerY, width - 140f, footerY, dividerPaint)

    val brandPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = android.graphics.Color.parseColor("#0F5C4D")
        textSize = 34f
        typeface = Typeface.create(cairoTypeface, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
      }
    canvas.drawText("نور القرآن • رفيقك إلى القرآن والطمأنينة", width / 2f, height - 72f, brandPaint)

    return bitmap
  }

  fun saveBitmapToGallery(context: Context, bitmap: Bitmap, pageNumber: Int): Result<Uri> {
    return try {
      val fileName = "NoorQuran_Page_$pageNumber.png"
      val values =
        ContentValues().apply {
          put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
          put(MediaStore.Images.Media.MIME_TYPE, "image/png")
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(
              MediaStore.Images.Media.RELATIVE_PATH,
              "${Environment.DIRECTORY_PICTURES}/NoorQuran",
            )
            put(MediaStore.Images.Media.IS_PENDING, 1)
          }
        }
      val resolver = context.contentResolver
      val uri =
        resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
          ?: return Result.failure(IllegalStateException("تعذر إنشاء ملف الصورة"))

      resolver.openOutputStream(uri)?.use { stream ->
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
      }
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
      }
      Result.success(uri)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  fun sharePoster(
    context: Context,
    bitmap: Bitmap,
    pageNumber: Int,
    targetPackage: String? = null,
  ): Result<Unit> {
    return try {
      val cacheDir = File(context.cacheDir, "shared_pages").apply { mkdirs() }
      val file = File(cacheDir, "noor_quran_page_$pageNumber.png")
      FileOutputStream(file).use { out ->
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
      }
      val uri =
        FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

      val shareIntent =
        Intent(Intent.ACTION_SEND).apply {
          type = "image/png"
          putExtra(Intent.EXTRA_STREAM, uri)
          putExtra(
            Intent.EXTRA_TEXT,
            "صفحة $pageNumber من المصحف الشريف — تطبيق نور القرآن",
          )
          addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
          if (targetPackage != null) {
            setPackage(targetPackage)
          }
        }

      if (targetPackage != null) {
        val canHandle = shareIntent.resolveActivity(context.packageManager) != null
        if (canHandle) {
          context.startActivity(shareIntent)
        } else {
          val fallback = Intent(shareIntent).apply { setPackage(null) }
          context.startActivity(Intent.createChooser(fallback, "مشاركة صفحة القرآن"))
        }
      } else {
        context.startActivity(Intent.createChooser(shareIntent, "مشاركة صفحة القرآن"))
      }
      Result.success(Unit)
    } catch (e: Exception) {
      Result.failure(e)
    }
  }
}
