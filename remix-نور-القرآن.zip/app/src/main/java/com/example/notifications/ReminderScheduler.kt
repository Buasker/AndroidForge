package com.example.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.MainActivity
import com.example.R
import com.example.data.model.ReminderType
import java.util.Calendar
import java.util.concurrent.TimeUnit

object ReminderChannelHelper {
  const val CHANNEL_ID = "noor_quran_reminders"
  const val EXTRA_REMINDER_TYPE = "extra_reminder_type"

  fun ensureChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel =
        NotificationChannel(
            CHANNEL_ID,
            "تذكيرات نور القرآن",
            NotificationManager.IMPORTANCE_DEFAULT,
          )
          .apply { description = "تذكيرات القرآن الكريم والأذكار والختمة والصفحة اليومية" }
      val manager = context.getSystemService(NotificationManager::class.java)
      manager.createNotificationChannel(channel)
    }
  }
}

class ReminderWorker(
  appContext: Context,
  params: WorkerParameters,
) : CoroutineWorker(appContext, params) {

  override suspend fun doWork(): Result {
    val typeId = inputData.getString(ReminderChannelHelper.EXTRA_REMINDER_TYPE) ?: return Result.success()
    val reminderType = ReminderType.entries.firstOrNull { it.id == typeId } ?: return Result.success()

    if (
      Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
        ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) !=
          PackageManager.PERMISSION_GRANTED
    ) {
      return Result.success()
    }

    ReminderChannelHelper.ensureChannel(applicationContext)

    val intent =
      Intent(applicationContext, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        putExtra(ReminderChannelHelper.EXTRA_REMINDER_TYPE, reminderType.id)
      }
    val pendingIntent =
      PendingIntent.getActivity(
        applicationContext,
        reminderType.ordinal + 200,
        intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

    val notification =
      NotificationCompat.Builder(applicationContext, ReminderChannelHelper.CHANNEL_ID)
        .setSmallIcon(R.mipmap.ic_launcher)
        .setContentTitle(reminderType.titleArabic)
        .setContentText(reminderType.bodyArabic)
        .setStyle(NotificationCompat.BigTextStyle().bigText(reminderType.bodyArabic))
        .setPriority(NotificationCompat.PRIORITY_DEFAULT)
        .setContentIntent(pendingIntent)
        .setAutoCancel(true)
        .build()

    NotificationManagerCompat.from(applicationContext)
      .notify(reminderType.ordinal + 1000, notification)

    return Result.success()
  }
}

object ReminderScheduler {
  fun scheduleOrCancel(
    context: Context,
    type: ReminderType,
    enabled: Boolean,
    hour: Int,
    minute: Int,
  ) {
    val workManager = WorkManager.getInstance(context)
    val workName = "noor_reminder_${type.id}"
    if (!enabled) {
      workManager.cancelUniqueWork(workName)
      return
    }

    ReminderChannelHelper.ensureChannel(context)
    val initialDelayMinutes = computeInitialDelayMinutes(hour, minute)
    val request =
      PeriodicWorkRequestBuilder<ReminderWorker>(24, TimeUnit.HOURS)
        .setInitialDelay(initialDelayMinutes, TimeUnit.MINUTES)
        .setInputData(workDataOf(ReminderChannelHelper.EXTRA_REMINDER_TYPE to type.id))
        .build()

    workManager.enqueueUniquePeriodicWork(
      workName,
      ExistingPeriodicWorkPolicy.UPDATE,
      request,
    )
  }

  private fun computeInitialDelayMinutes(targetHour: Int, targetMinute: Int): Long {
    val now = Calendar.getInstance()
    val target =
      Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, targetHour)
        set(Calendar.MINUTE, targetMinute)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
        if (before(now)) {
          add(Calendar.DAY_OF_YEAR, 1)
        }
      }
    val diffMs = target.timeInMillis - now.timeInMillis
    return (diffMs / 60_000L).coerceAtLeast(1L)
  }
}
