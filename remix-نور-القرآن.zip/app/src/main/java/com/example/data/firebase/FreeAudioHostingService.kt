package com.example.data.firebase

import android.net.Uri
import java.net.URI
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

enum class AudioHostingProvider(val id: String, val arabicLabel: String) {
  GITHUB_RELEASES("github_releases", "GitHub Releases (مجاني بالكامل)"),
  INTERNET_ARCHIVE("internet_archive", "Internet Archive (archive.org)"),
  MP3QURAN("mp3quran", "MP3Quran CDN"),
  DIRECT_HTTPS("direct_https", "رابط HTTPS مباشر");

  companion object {
    val validIds: Set<String> = entries.map { it.id }.toSet()

    fun fromId(id: String?): AudioHostingProvider =
      entries.firstOrNull { it.id == id } ?: DIRECT_HTTPS
  }
}

data class ExternalAudioMetadata(
  val audioUrl: String,
  val contentLengthBytes: Long,
  val contentType: String?,
  val reachable: Boolean,
)

/**
 * Free, no-credit-card audio hosting helper for Noor Quran (Spark-plan compatible).
 *
 * Notice: No GitHub Personal Access Tokens or administrative secrets live inside the Android app.
 * Validates all audio URLs strictly against HTTPS-only, non-SSRF public domain rules.
 */
class FreeAudioHostingService(
  private val okHttpClient: OkHttpClient,
) {
  fun validatePublicAudioUrl(url: String): String =
    validatePublicHttpsUrl(url, "رابط التلاوة")

  fun validatePublicImageUrl(url: String): String =
    validateOptionalPublicHttpsUrl(url, "رابط الصورة")

  fun validateOptionalPublicHttpsUrl(url: String, fieldLabel: String = "الرابط"): String {
    val trimmed = url.trim()
    if (trimmed.isEmpty()) return ""
    return validatePublicHttpsUrl(trimmed, fieldLabel)
  }

  private fun validatePublicHttpsUrl(url: String, fieldLabel: String): String {
    val trimmed = url.trim()
    require(trimmed.startsWith("https://") && trimmed.length in 12..1000) {
      "$fieldLabel يجب أن يبدأ بـ https:// ويكون صالحاً."
    }
    require(!trimmed.any { it.isWhitespace() || it.isISOControl() }) {
      "$fieldLabel يحتوي على أحرف أو مسافات غير صالحة."
    }
    require(!trimmed.contains("@")) {
      "$fieldLabel يحتوي على صيغة غير آمنة (@)."
    }

    val uri =
      runCatching { URI(trimmed) }.getOrNull()
        ?: throw IllegalArgumentException("تعذر تحليل $fieldLabel.")
    val scheme = uri.scheme?.lowercase(Locale.US)
    require(scheme == "https") { "يُسمح بروابط HTTPS الآمنة فقط." }
    require(uri.userInfo.isNullOrEmpty()) { "غير مسموح ببيانات اعتماد داخل الرابط." }

    val host =
      (uri.host ?: runCatching { Uri.parse(trimmed).host }.getOrNull())
        ?.trim()
        ?.lowercase(Locale.US)
        .orEmpty()
    require(host.isNotEmpty() && "." in host && !host.startsWith(".") && !host.endsWith(".")) {
      "اسم النطاق في $fieldLabel غير صالح."
    }
    require(!isForbiddenInternalHost(host)) {
      "لا يُسمح بالعناوين المحلية أو الشبكات الخاصة."
    }
    if (uri.port != -1) {
      require(uri.port == 443) { "المنفذ غير مسموح في $fieldLabel." }
    }
    return trimmed
  }

  private fun isForbiddenInternalHost(host: String): Boolean {
    if (
      host == "localhost" ||
        host.endsWith(".localhost") ||
        host.endsWith(".local") ||
        host.endsWith(".internal") ||
        host.endsWith(".arpa") ||
        host == "0.0.0.0" ||
        host.startsWith("127.") ||
        host.startsWith("10.") ||
        host.startsWith("192.168.") ||
        host.startsWith("169.254.") ||
        host.startsWith("[") ||
        host.contains(":")
    ) {
      return true
    }
    val parts = host.split('.')
    if (parts.size == 4 && parts.all { it.toIntOrNull() in 0..255 }) {
      val first = parts[0].toInt()
      val second = parts[1].toInt()
      if (first == 172 && second in 16..31) return true
      if (first == 100 && second in 64..127) return true
    }
    return false
  }

  private fun validatePathSegment(segment: String, label: String): String {
    val clean = segment.trim()
    require(clean.matches(SAFE_SEGMENT_REGEX) && !clean.contains("..")) {
      "$label يحتوي على أحرف غير مسموحة."
    }
    return clean
  }

  fun buildGitHubReleaseDownloadUrl(
    owner: String,
    repo: String,
    tag: String,
    fileName: String,
  ): String =
    validatePublicAudioUrl(
      "https://github.com/${validatePathSegment(owner, "المالك")}/${validatePathSegment(repo, "المستودع")}/releases/download/${validatePathSegment(tag, "الإصدار")}/${validatePathSegment(fileName, "اسم الملف")}"
    )

  fun buildInternetArchiveDownloadUrl(itemIdentifier: String, fileName: String): String =
    validatePublicAudioUrl(
      "https://archive.org/download/${validatePathSegment(itemIdentifier, "معرّف العنصر")}/${validatePathSegment(fileName, "اسم الملف")}"
    )

  fun buildMp3QuranSurahUrl(serverBaseUrl: String, surahNumber: Int): String {
    require(surahNumber in 1..114) { "رقم السورة غير صالح." }
    val cleanBase = validatePublicAudioUrl(serverBaseUrl).let { if (it.endsWith("/")) it else "$it/" }
    val padded = String.format(Locale.US, "%03d", surahNumber)
    return validatePublicAudioUrl("$cleanBase$padded.mp3")
  }

  /**
   * Performs an unauthenticated HTTPS HEAD check with OkHttp to verify an external audio file
   * exists and inspect its content length before streaming or registering metadata.
   */
  suspend fun verifyExternalAudioReachable(audioUrl: String): Result<ExternalAudioMetadata> =
    withContext(Dispatchers.IO) {
      runCatching {
        val safeUrl = validatePublicAudioUrl(audioUrl)
        val headRequest = Request.Builder().url(safeUrl).head().build()
        okHttpClient.newCall(headRequest).execute().use { response ->
          val finalUrl = response.request.url.toString()
          validatePublicAudioUrl(finalUrl)
          if (response.isSuccessful) {
            val contentLength = response.header("Content-Length")?.toLongOrNull() ?: 0L
            val contentType = response.header("Content-Type")
            return@runCatching ExternalAudioMetadata(
              audioUrl = safeUrl,
              contentLengthBytes = contentLength.coerceAtLeast(0L),
              contentType = contentType,
              reachable = true,
            )
          }
          if (response.code != 405 && response.code != 403 && response.code != 501) {
            val contentLength = response.header("Content-Length")?.toLongOrNull() ?: 0L
            return@runCatching ExternalAudioMetadata(
              audioUrl = safeUrl,
              contentLengthBytes = contentLength.coerceAtLeast(0L),
              contentType = response.header("Content-Type"),
              reachable = false,
            )
          }
        }
        // Fallback: tiny byte-range GET for hosts that disallow HEAD
        val rangeRequest =
          Request.Builder().url(safeUrl).get().header("Range", "bytes=0-1").build()
        okHttpClient.newCall(rangeRequest).execute().use { getResponse ->
          val finalUrl = getResponse.request.url.toString()
          validatePublicAudioUrl(finalUrl)
          val contentLength =
            getResponse.header("Content-Range")?.substringAfterLast('/')?.toLongOrNull()
              ?: getResponse.header("Content-Length")?.toLongOrNull()
              ?: 0L
          ExternalAudioMetadata(
            audioUrl = safeUrl,
            contentLengthBytes = contentLength.coerceAtLeast(0L),
            contentType = getResponse.header("Content-Type"),
            reachable = getResponse.isSuccessful || getResponse.code == 206,
          )
        }
      }
    }

  companion object {
    private val SAFE_SEGMENT_REGEX = Regex("^[a-zA-Z0-9_\\-\\.]{1,120}$")
  }
}
