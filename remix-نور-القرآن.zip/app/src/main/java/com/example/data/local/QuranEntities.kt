package com.example.data.local

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "surahs")
data class SurahEntity(
  @PrimaryKey val number: Int,
  val arabicName: String,
  val englishName: String,
  val englishNameTranslation: String,
  val numberOfAyahs: Int,
  val revelationType: String,
)

@Entity(
  tableName = "ayahs",
  primaryKeys = ["surahNumber", "numberInSurah", "translationEdition"],
)
data class AyahEntity(
  val globalNumber: Int,
  val numberInSurah: Int,
  val surahNumber: Int,
  val translationEdition: String,
  val arabicText: String,
  val translationText: String,
  val juz: Int,
  val page: Int,
  val sajda: Boolean,
)

@Entity(
  tableName = "tafsir",
  primaryKeys = ["surahNumber", "numberInSurah", "editionId"],
)
data class TafsirEntity(
  val surahNumber: Int,
  val numberInSurah: Int,
  val globalNumber: Int,
  val editionId: String,
  val surahArabicName: String,
  val quranArabicText: String,
  val tafsirText: String,
)

@Entity(
  tableName = "bookmarks",
  primaryKeys = ["surahNumber", "ayahNumberInSurah"],
)
data class BookmarkEntity(
  val surahNumber: Int,
  val surahEnglishName: String,
  val surahArabicName: String,
  val ayahNumberInSurah: Int,
  val globalAyahNumber: Int,
  val arabicText: String,
  val translationText: String,
  val category: String = "عام",
  val note: String = "",
  val createdAt: Long = System.currentTimeMillis(),
)

@Entity(tableName = "dhikr_counters")
data class DhikrCounterEntity(
  @PrimaryKey val id: String,
  val arabicTitle: String,
  val subtitle: String,
  val count: Int,
  val sortOrder: Int,
  val lastUpdated: Long = System.currentTimeMillis(),
)

@Entity(tableName = "adhkar_progress")
data class AdhkarProgressEntity(
  @PrimaryKey val dhikrId: String,
  val currentCount: Int,
  val lastUpdated: Long = System.currentTimeMillis(),
)

@Entity(
  tableName = "dhikr_daily_logs",
  primaryKeys = ["epochDay", "dhikrId"],
)
data class DhikrDailyLogEntity(
  val epochDay: Long,
  val dhikrId: String,
  val label: String,
  val sourceType: String,
  val count: Int,
  val lastUpdated: Long = System.currentTimeMillis(),
)

@Entity(tableName = "khatmah_plans")
data class KhatmahPlanEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0L,
  val title: String,
  val startDateEpochDay: Long,
  val endDateEpochDay: Long,
  val totalPages: Int = 604,
  val pagesRead: Int = 0,
  val isPaused: Boolean = false,
  val createdAt: Long = System.currentTimeMillis(),
)

@Entity(
  tableName = "downloaded_audio",
  primaryKeys = ["reciterId", "surahNumber"],
)
data class DownloadedAudioEntity(
  val reciterId: String,
  val surahNumber: Int,
  val localFilePath: String,
  val sizeBytes: Long,
  val downloadedAt: Long = System.currentTimeMillis(),
)

@Entity(
  tableName = "local_reciters",
  indices = [Index(value = ["normalizedName"])],
)
data class LocalReciterEntity(
  @PrimaryKey val id: String,
  val arabicName: String,
  val normalizedName: String,
  val description: String = "",
  val riwayah: String = "حفص عن عاصم",
  val photoPathOrUrl: String = "",
  val fullSurahBaseUrl: String = "",
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis(),
)

@Entity(
  tableName = "local_recitations",
  primaryKeys = ["reciterId", "surahNumber"],
  foreignKeys =
    [
      ForeignKey(
        entity = LocalReciterEntity::class,
        parentColumns = ["id"],
        childColumns = ["reciterId"],
        onDelete = ForeignKey.CASCADE,
      )
    ],
)
data class LocalRecitationEntity(
  val reciterId: String,
  val surahNumber: Int,
  val surahArabicName: String,
  val audioUrl: String,
  val notes: String = "",
  val updatedAt: Long = System.currentTimeMillis(),
)
