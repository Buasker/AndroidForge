package com.example.data.local

import com.example.data.model.AdhkarCategory
import com.example.data.model.AdhkarItem

object AdhkarSeedData {
  val initialVoiceDhikrCounters: List<DhikrCounterEntity> =
    listOf(
      DhikrCounterEntity("hamd", "الحمد لله", "شكرٌ لله على نعمه الظاهرة والباطنة", 0, 1),
      DhikrCounterEntity("takbir", "الله أكبر", "تعظيمٌ لله فوق كل شيء", 0, 2),
      DhikrCounterEntity("tasbih", "سبحان الله", "تنزيهٌ لله عن كل نقص", 0, 3),
      DhikrCounterEntity("tahlil", "لا إله إلا الله", "كلمة التوحيد وأفضل الذكر", 0, 4),
      DhikrCounterEntity("hawqala", "لا حول ولا قوة إلا بالله", "كنزٌ من كنوز الجنة", 0, 5),
      DhikrCounterEntity("salawat", "اللهم صل وسلم على نبينا محمد", "صلاةً وسلاماً على رسول الله ﷺ", 0, 6),
      DhikrCounterEntity("istighfar", "أستغفر الله", "مفتاح الفرج ومحو الذنوب", 0, 7),
    )

  val allAdhkar: List<AdhkarItem> =
    listOf(
      // أذكار الصباح
      AdhkarItem(
        id = "m_1",
        category = AdhkarCategory.MORNING,
        textWithTashkeel =
          "أَصْبَحْنَا وَأَصْبَحَ الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.",
        virtue = "رواه مسلم — افتتاح الصباح بتوحيد الله وحمده",
        targetCount = 1,
      ),
      AdhkarItem(
        id = "m_2",
        category = AdhkarCategory.MORNING,
        textWithTashkeel =
          "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ.",
        virtue = "سيد الاستغفار — رواه البخاري",
        targetCount = 1,
      ),
      AdhkarItem(
        id = "m_3",
        category = AdhkarCategory.MORNING,
        textWithTashkeel =
          "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ.",
        virtue = "حفظٌ من كل ضر بإذن الله — ثلاث مرات",
        targetCount = 3,
      ),
      AdhkarItem(
        id = "m_4",
        category = AdhkarCategory.MORNING,
        textWithTashkeel = "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ ﷺ نَبِيًّا.",
        virtue = "حقٌ على الله أن يرضيه — ثلاث مرات",
        targetCount = 3,
      ),
      AdhkarItem(
        id = "m_5",
        category = AdhkarCategory.MORNING,
        textWithTashkeel = "حَسْبِيَ اللَّهُ لَا إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ.",
        virtue = "كفاه الله ما أهمه — سبع مرات",
        targetCount = 7,
      ),

      // أذكار المساء
      AdhkarItem(
        id = "e_1",
        category = AdhkarCategory.EVENING,
        textWithTashkeel =
          "أَمْسَيْنَا وَأَمْسَى الْمُلْكُ لِلَّهِ، وَالْحَمْدُ لِلَّهِ، لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.",
        virtue = "رواه مسلم — شكر الله عند دخول المساء",
        targetCount = 1,
      ),
      AdhkarItem(
        id = "e_2",
        category = AdhkarCategory.EVENING,
        textWithTashkeel = "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.",
        virtue = "حرزٌ وحفظٌ في المساء — ثلاث مرات",
        targetCount = 3,
      ),
      AdhkarItem(
        id = "e_3",
        category = AdhkarCategory.EVENING,
        textWithTashkeel =
          "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ.",
        virtue = "رواه الترمذي",
        targetCount = 1,
      ),
      AdhkarItem(
        id = "e_4",
        category = AdhkarCategory.EVENING,
        textWithTashkeel =
          "يَا حَيُّ يَا قَيُّومُ بِرَحْمَتِكَ أَسْتَغِيثُ، أَصْلِحْ لِي شَأْنِي كُلَّهُ وَلَا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ.",
        virtue = "دعاء عظيم للتفويض والاستعانة بالله",
        targetCount = 1,
      ),

      // أذكار النوم
      AdhkarItem(
        id = "s_1",
        category = AdhkarCategory.SLEEP,
        textWithTashkeel = "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا.",
        virtue = "رواه البخاري — عند أخذ المضجع",
        targetCount = 1,
      ),
      AdhkarItem(
        id = "s_2",
        category = AdhkarCategory.SLEEP,
        textWithTashkeel =
          "اللَّهُمَّ قِنِي عَذَابَكَ يَوْمَ تَبْعَثُ عِبَادَكَ.",
        virtue = "يقال ثلاث مرات عند وضع اليد اليمنى تحت الخد",
        targetCount = 3,
      ),
      AdhkarItem(
        id = "s_3",
        category = AdhkarCategory.SLEEP,
        textWithTashkeel = "سُبْحَانَ اللَّهِ (٣٣) — الْحَمْدُ لِلَّهِ (٣٣) — اللَّهُ أَكْبَرُ (٣٤).",
        virtue = "وصية النبي ﷺ عند النوم",
        targetCount = 33,
      ),

      // أذكار الاستيقاظ
      AdhkarItem(
        id = "w_1",
        category = AdhkarCategory.WAKE_UP,
        textWithTashkeel = "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ.",
        virtue = "رواه البخاري — أول ما يقال عند الاستيقاظ",
        targetCount = 1,
      ),
      AdhkarItem(
        id = "w_2",
        category = AdhkarCategory.WAKE_UP,
        textWithTashkeel =
          "الْحَمْدُ لِلَّهِ الَّذِي عَافَانِي فِي جَسَدِي، وَرَدَّ عَلَيَّ رُوحِي، وَأَذِنَ لِي بِذِكْرِهِ.",
        virtue = "رواه الترمذي",
        targetCount = 1,
      ),

      // أذكار بعد الصلاة
      AdhkarItem(
        id = "p_1",
        category = AdhkarCategory.AFTER_PRAYER,
        textWithTashkeel =
          "أَسْتَغْفِرُ اللَّهَ (ثلاثاً)، اللَّهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ.",
        virtue = "رواه مسلم — مباشرة بعد التسليم",
        targetCount = 3,
      ),
      AdhkarItem(
        id = "p_2",
        category = AdhkarCategory.AFTER_PRAYER,
        textWithTashkeel = "سُبْحَانَ اللَّهِ، وَالْحَمْدُ لِلَّهِ، وَاللَّهُ أَكْبَرُ.",
        virtue = "تُقال ثلاثاً وثلاثين مرة دبر كل صلاة مكتوبة",
        targetCount = 33,
      ),
      AdhkarItem(
        id = "p_3",
        category = AdhkarCategory.AFTER_PRAYER,
        textWithTashkeel =
          "لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ.",
        virtue = "تمام المائة دبر كل صلاة",
        targetCount = 1,
      ),

      // التسبيح والاستغفار
      AdhkarItem(
        id = "t_1",
        category = AdhkarCategory.TASBIH,
        textWithTashkeel = "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ، سُبْحَانَ اللَّهِ الْعَظِيمِ.",
        virtue = "كلمتان خفيفتان على اللسان ثقيلتان في الميزان — متفق عليه",
        targetCount = 100,
      ),
      AdhkarItem(
        id = "t_2",
        category = AdhkarCategory.TASBIH,
        textWithTashkeel = "أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيَّ الْقَيُّومَ وَأَتُوبُ إِلَيْهِ.",
        virtue = "غُفر له وإن كان فرّ من الزحف",
        targetCount = 10,
      ),
      AdhkarItem(
        id = "t_3",
        category = AdhkarCategory.TASBIH,
        textWithTashkeel = "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ.",
        virtue = "كنزٌ من كنوز الجنة — متفق عليه",
        targetCount = 33,
      ),

      // الصلاة على النبي ﷺ
      AdhkarItem(
        id = "sal_1",
        category = AdhkarCategory.SALAWAT,
        textWithTashkeel =
          "اللَّهُمَّ صَلِّ وَسَلِّمْ وَبَارِكْ عَلَى نَبِيِّنَا مُحَمَّدٍ.",
        virtue = "من صلى عليَّ واحدة صلى الله عليه عشراً — رواه مسلم",
        targetCount = 10,
      ),
      AdhkarItem(
        id = "sal_2",
        category = AdhkarCategory.SALAWAT,
        textWithTashkeel =
          "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ، كَمَا صَلَّيْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ، اللَّهُمَّ بَارِكْ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ، كَمَا بَارَكْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ.",
        virtue = "الصلاة الإبراهيمية المباركة",
        targetCount = 10,
      ),
    )
}
