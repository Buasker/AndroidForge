package com.example.data.firebase

import android.util.Log
import com.example.BuildConfig
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import org.json.JSONObject

enum class OperationType(val value: String) {
  CREATE("create"),
  UPDATE("update"),
  DELETE("delete"),
  LIST("list"),
  GET("get"),
  WRITE("write"),
}

internal fun maskEmailForLog(email: String?): String? {
  val trimmed = email?.trim()?.takeIf { it.isNotEmpty() } ?: return null
  val atIdx = trimmed.indexOf('@')
  if (atIdx <= 1) return "***"
  val local = trimmed.substring(0, atIdx)
  val domain = trimmed.substring(atIdx + 1)
  return "${local.first()}***@$domain"
}

internal fun maskUidForLog(uid: String?): String? {
  val trimmed = uid?.trim()?.takeIf { it.isNotEmpty() } ?: return null
  return if (trimmed.length <= 6) "***" else "${trimmed.take(4)}...${trimmed.takeLast(2)}"
}

fun handleFirestoreError(
  exception: Throwable,
  operationType: OperationType,
  path: String?,
): String {
  val causes = generateSequence(exception) { it.cause }
  val rootError =
    causes.firstOrNull { it is FirebaseFirestoreException }
      ?: causes.firstOrNull { it !is CancellationException }
      ?: exception

  val firestoreCode = (rootError as? FirebaseFirestoreException)?.code?.name ?: rootError.javaClass.simpleName
  val sanitizedPath = path?.replace(Regex("users/[^/]+"), "users/***")

  val currentUser = runCatching { Firebase.auth.currentUser }.getOrNull()

  val authInfoJson =
    JSONObject().apply {
      put("authenticated", currentUser != null)
      put("uidMasked", maskUidForLog(currentUser?.uid))
      put("emailVerified", currentUser?.isEmailVerified ?: false)
      if (BuildConfig.DEBUG) {
        put("emailMasked", maskEmailForLog(currentUser?.email))
      }
    }

  val errorInfoJson =
    JSONObject().apply {
      put("errorCode", firestoreCode)
      if (BuildConfig.DEBUG) {
        put("error", rootError.message ?: rootError.toString())
      }
      put("operationType", operationType.value)
      put("path", sanitizedPath)
      put("authInfo", authInfoJson)
    }

  val jsonString = errorInfoJson.toString()
  if (BuildConfig.DEBUG) {
    Log.e("FirestoreError", "Firestore Error: $jsonString")
  } else {
    Log.w("FirestoreError", "Firestore operation=${operationType.value} code=$firestoreCode")
  }
  return jsonString
}
