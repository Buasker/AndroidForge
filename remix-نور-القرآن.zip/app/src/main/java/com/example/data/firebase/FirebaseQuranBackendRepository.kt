package com.example.data.firebase

import android.content.Context
import com.example.R
import com.example.data.local.QuranSeedData
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import java.util.Locale
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import okhttp3.OkHttpClient

class FirebaseQuranBackendRepository(
  private val db: FirebaseFirestore,
  private val auth: FirebaseAuth = Firebase.auth,
  private val authManager: FirebaseAuthManager,
  private val hostingService: FreeAudioHostingService,
) {
  constructor(
    context: Context,
    authManager: FirebaseAuthManager,
    okHttpClient: OkHttpClient,
  ) : this(
    db =
      FirebaseFirestore.getInstance(
        context.applicationContext.getString(R.string.firestore_database_id)
      ),
    auth = Firebase.auth,
    authManager = authManager,
    hostingService = FreeAudioHostingService(okHttpClient),
  )

  private fun requireUserId(): String =
    auth.currentUser?.uid
      ?: throw IllegalStateException("يجب تسجيل الدخول أولاً قبل إجراء هذه العملية.")

  private suspend fun requireSuperAdmin(): AdminPrivilegeStatus {
    val status = authManager.verifyAdminPrivileges(forceRefreshToken = true)
    if (!status.isSuperAdmin) {
      throw SecurityException("هذه الصلاحية مقتصرة على المالك (${FirebaseAuthManager.OWNER_EMAIL}) فقط.")
    }
    return status
  }

  // --- RECITERS & RECITATIONS (Public published reads, Owner exclusive writes) ---

  fun observePublishedReciters(): Flow<List<FirebaseReciter>> =
    db.collection("reciters")
      .whereEqualTo("published", true)
      .snapshots()
      .map { snapshot ->
        snapshot
          .toObjects(
            FirebaseReciter::class.java,
            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
          )
          .sortedWith(compareBy<FirebaseReciter> { it.sortOrder }.thenBy { it.arabicName })
      }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        handleFirestoreError(firestoreError ?: error, OperationType.LIST, "reciters")
        emit(emptyList())
      }

  fun observeAllRecitersAsAdmin(): Flow<List<FirebaseReciter>> = flow {
    requireSuperAdmin()
    emitAll(
      db.collection("reciters")
        .snapshots()
        .map { snapshot ->
          snapshot
            .toObjects(
              FirebaseReciter::class.java,
              DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
            )
            .sortedWith(compareBy<FirebaseReciter> { it.sortOrder }.thenBy { it.arabicName })
        }
        .catch { error ->
          val firestoreError =
            generateSequence(error) { it.cause }
              .filterIsInstance<FirebaseFirestoreException>()
              .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          handleFirestoreError(firestoreError ?: error, OperationType.LIST, "reciters")
          throw error
        }
    )
  }

  fun observePublishedRecitations(reciterId: String): Flow<List<FirebaseRecitationTrack>> {
    if (!reciterId.matches(VALID_ID_REGEX)) {
      return flow { emit(emptyList()) }
    }
    return db.collection("reciters")
      .document(reciterId)
      .collection("recitations")
      .whereEqualTo("published", true)
      .snapshots()
      .map { snapshot ->
        snapshot
          .toObjects(
            FirebaseRecitationTrack::class.java,
            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
          )
          .sortedWith(
            compareBy<FirebaseRecitationTrack> { it.sortOrder }
              .thenBy { it.surahNumber }
              .thenBy { it.id }
          )
      }
      .catch { error ->
        val firestoreError =
          generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        handleFirestoreError(
          firestoreError ?: error,
          OperationType.LIST,
          "reciters/$reciterId/recitations",
        )
        emit(emptyList())
      }
  }

  fun observeAllRecitationsAsAdmin(reciterId: String): Flow<List<FirebaseRecitationTrack>> = flow {
    requireSuperAdmin()
    require(reciterId.matches(VALID_ID_REGEX)) { "معرف القارئ غير صالح" }
    emitAll(
      db.collection("reciters")
        .document(reciterId)
        .collection("recitations")
        .snapshots()
        .map { snapshot ->
          snapshot
            .toObjects(
              FirebaseRecitationTrack::class.java,
              DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
            )
            .sortedWith(
              compareBy<FirebaseRecitationTrack> { it.sortOrder }
                .thenBy { it.surahNumber }
                .thenBy { it.id }
            )
        }
        .catch { error ->
          val firestoreError =
            generateSequence(error) { it.cause }
              .filterIsInstance<FirebaseFirestoreException>()
              .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          handleFirestoreError(
            firestoreError ?: error,
            OperationType.LIST,
            "reciters/$reciterId/recitations",
          )
          throw error
        }
    )
  }

  /**
   * Resolves a published recitation HTTPS audio URL from Cloud Firestore if available.
   */
  suspend fun resolvePublishedTrackUrl(reciterId: String, surahNumber: Int): String? {
    if (!reciterId.matches(VALID_ID_REGEX) || surahNumber !in 1..114) return null
    val surahId = String.format(Locale.US, "%03d", surahNumber)
    return runCatching {
        val recitationsRef =
          db.collection("reciters").document(reciterId).collection("recitations")
        val doc = recitationsRef.document(surahId).get().await()
        if (doc.exists() && doc.getBoolean("published") == true) {
          val directUrl =
            doc.getString("audioUrl")?.let { url ->
              runCatching { hostingService.validatePublicAudioUrl(url) }.getOrNull()
            }
          if (directUrl != null) return@runCatching directUrl
        }
        val querySnap =
          recitationsRef
            .whereEqualTo("published", true)
            .whereEqualTo("surahNumber", surahNumber)
            .get()
            .await()
        querySnap
          .toObjects(
            FirebaseRecitationTrack::class.java,
            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
          )
          .sortedBy { it.sortOrder }
          .firstNotNullOfOrNull { track ->
            runCatching { hostingService.validatePublicAudioUrl(track.audioUrl) }.getOrNull()
          }
      }
      .getOrNull()
  }

  /**
   * Resolves a published reciter's base HTTPS audio URL from Cloud Firestore (used when playing/downloading
   * custom reciters added by the Owner).
   */
  suspend fun resolvePublishedReciterBaseUrl(reciterId: String): String? {
    if (!reciterId.matches(VALID_ID_REGEX)) return null
    return runCatching {
        val doc = db.collection("reciters").document(reciterId).get().await()
        if (!doc.exists() || doc.getBoolean("published") != true) {
          null
        } else {
          val raw = doc.getString("audioBaseUrl")?.trim().orEmpty()
          if (raw.isEmpty()) {
            null
          } else {
            runCatching { hostingService.validatePublicAudioUrl(raw) }
              .getOrNull()
              ?.let { if (it.endsWith("/")) it else "$it/" }
          }
        }
      }
      .getOrNull()
  }

  suspend fun probeAudioUrl(url: String): Result<ExternalAudioMetadata> =
    hostingService.verifyExternalAudioReachable(url)

  suspend fun createReciterAsAdmin(
    reciterId: String,
    arabicName: String,
    styleArabic: String,
    hostingProvider: AudioHostingProvider,
    audioBaseUrl: String,
    published: Boolean = true,
    riwayah: String = styleArabic,
    bioArabic: String = "",
    photoUrl: String = "",
    sortOrder: Long = 0L,
  ): Result<Unit> {
    val cleanId = reciterId.trim()
    val docPath = "reciters/$cleanId"
    return try {
      val admin = requireSuperAdmin()
      val adminUid = admin.uid ?: requireUserId()
      require(cleanId.matches(VALID_ID_REGEX)) { "معرف القارئ غير صالح (أحرف إنجليزية وأرقام و _ فقط)" }
      require(arabicName.trim().length in 2..120) { "اسم القارئ يجب أن يكون بين حرفين و١٢٠ حرفاً" }
      val cleanRiwayah = riwayah.trim().ifBlank { styleArabic.trim() }
      val cleanStyle = styleArabic.trim().ifBlank { cleanRiwayah }
      require(cleanStyle.length in 2..200) { "وصف التلاوة أو الرواية يجب أن يكون بين حرفين و٢٠٠ حرف" }
      require(cleanRiwayah.length <= 120) { "اسم الرواية طويل جداً" }
      require(bioArabic.trim().length <= 600) { "النبذة طويلة جداً (الحد الأقصى ٦٠٠ حرف)" }
      val safePhotoUrl = hostingService.validatePublicImageUrl(photoUrl)
      val safeBaseUrl = hostingService.validateOptionalPublicHttpsUrl(audioBaseUrl, "رابط الصوت الأساسي")

      val model =
        FirebaseReciter(
          arabicName = arabicName.trim(),
          styleArabic = cleanStyle,
          riwayah = cleanRiwayah,
          bioArabic = bioArabic.trim(),
          photoUrl = safePhotoUrl,
          sortOrder = sortOrder.coerceIn(0L, 100_000L),
          hostingProvider = hostingProvider.id,
          audioBaseUrl = safeBaseUrl,
          published = published,
        )
      db.collection("reciters").document(cleanId).set(model.toCreateMap(adminUid)).await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, docPath)
      Result.failure(e)
    }
  }

  suspend fun updateReciterAsAdmin(
    reciterId: String,
    arabicName: String,
    styleArabic: String,
    hostingProvider: AudioHostingProvider,
    audioBaseUrl: String,
    published: Boolean,
    riwayah: String = styleArabic,
    bioArabic: String = "",
    photoUrl: String = "",
    sortOrder: Long = 0L,
  ): Result<Unit> {
    val cleanId = reciterId.trim()
    val docPath = "reciters/$cleanId"
    return try {
      requireSuperAdmin()
      require(cleanId.matches(VALID_ID_REGEX)) { "معرف القارئ غير صالح" }
      require(arabicName.trim().length in 2..120) { "اسم القارئ يجب أن يكون بين حرفين و١٢٠ حرفاً" }
      val cleanRiwayah = riwayah.trim().ifBlank { styleArabic.trim() }
      val cleanStyle = styleArabic.trim().ifBlank { cleanRiwayah }
      require(cleanStyle.length in 2..200) { "وصف التلاوة غير صالح" }
      require(cleanRiwayah.length <= 120) { "اسم الرواية طويل جداً" }
      require(bioArabic.trim().length <= 600) { "النبذة طويلة جداً (الحد الأقصى ٦٠٠ حرف)" }
      val safePhotoUrl = hostingService.validatePublicImageUrl(photoUrl)
      val safeBaseUrl = hostingService.validateOptionalPublicHttpsUrl(audioBaseUrl, "رابط الصوت الأساسي")

      db.collection("reciters")
        .document(cleanId)
        .update(
          mapOf(
            "arabicName" to arabicName.trim(),
            "styleArabic" to cleanStyle,
            "riwayah" to cleanRiwayah,
            "bioArabic" to bioArabic.trim(),
            "photoUrl" to safePhotoUrl,
            "sortOrder" to sortOrder.coerceIn(0L, 100_000L),
            "hostingProvider" to hostingProvider.id,
            "audioBaseUrl" to safeBaseUrl,
            "published" to published,
            "updatedAt" to FieldValue.serverTimestamp(),
          )
        )
        .await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docPath)
      Result.failure(e)
    }
  }

  suspend fun reorderRecitersAsAdmin(orderedReciterIds: List<String>): Result<Unit> {
    return try {
      requireSuperAdmin()
      if (orderedReciterIds.isEmpty()) return Result.success(Unit)
      val batch = db.batch()
      orderedReciterIds.forEachIndexed { index, id ->
        val cleanId = id.trim()
        require(cleanId.matches(VALID_ID_REGEX)) { "معرف القارئ غير صالح" }
        val ref = db.collection("reciters").document(cleanId)
        batch.update(
          ref,
          mapOf(
            "sortOrder" to index.toLong().coerceIn(0L, 100_000L),
            "updatedAt" to FieldValue.serverTimestamp(),
          ),
        )
      }
      batch.commit().await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, "reciters")
      Result.failure(e)
    }
  }

  suspend fun deleteReciterAsAdmin(reciterId: String): Result<Unit> {
    val cleanId = reciterId.trim()
    val docPath = "reciters/$cleanId"
    return try {
      requireSuperAdmin()
      require(cleanId.matches(VALID_ID_REGEX)) { "معرف القارئ غير صالح" }
      // Delete nested recitations first to avoid orphaned subcollection documents
      val tracks =
        db.collection("reciters").document(cleanId).collection("recitations").get().await()
      for (trackDoc in tracks.documents) {
        trackDoc.reference.delete().await()
      }
      db.collection("reciters").document(cleanId).delete().await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docPath)
      Result.failure(e)
    }
  }

  /**
   * Registers or updates a free HTTPS recitation URL in Cloud Firestore under Owner authority.
   * Supports editing existing track IDs and creating multiple recitations for the same Surah.
   */
  suspend fun registerHostedRecitationAsAdmin(
    reciterId: String,
    surahNumber: Int,
    surahArabicName: String,
    hostingProvider: AudioHostingProvider,
    audioUrl: String,
    externalAssetId: String = "",
    fileSizeBytes: Long = 0L,
    durationSeconds: Long = 0L,
    published: Boolean = true,
    trackId: String = "",
    description: String = "",
    sortOrder: Long = surahNumber.toLong(),
  ): Result<FirebaseRecitationTrack> {
    val cleanId = reciterId.trim()
    val defaultSurahId = String.format(Locale.US, "%03d", surahNumber)
    var resolvedDocId = trackId.trim().takeIf { it.matches(VALID_ID_REGEX) } ?: defaultSurahId
    var docPath = "reciters/$cleanId/recitations/$resolvedDocId"
    return try {
      val admin = requireSuperAdmin()
      val adminUid = admin.uid ?: requireUserId()
      require(cleanId.matches(VALID_ID_REGEX)) { "معرف القارئ غير صالح" }
      require(surahNumber in 1..114) { "رقم السورة يجب أن يكون بين ١ و١١٤" }
      val resolvedSurahName =
        surahArabicName.trim().ifBlank {
          QuranSeedData.surahs.firstOrNull { it.number == surahNumber }?.arabicName ?: "سورة $surahNumber"
        }
      require(resolvedSurahName.length in 2..120) { "اسم السورة غير صالح" }
      val cleanDescription = description.trim()
      require(cleanDescription.length <= 500) { "وصف التلاوة طويل جداً (الحد الأقصى ٥٠٠ حرف)" }
      val safeAudioUrl = hostingService.validatePublicAudioUrl(audioUrl)
      val cleanAssetId = externalAssetId.trim().take(200)

      val recitationsCollection =
        db.collection("reciters").document(cleanId).collection("recitations")

      // If creating a brand-new track (trackId blank) and the canonical Surah doc already exists,
      // allocate a unique track ID so multiple recordings of the same Surah can coexist.
      if (trackId.isBlank()) {
        val canonicalSnap = recitationsCollection.document(defaultSurahId).get().await()
        if (canonicalSnap.exists()) {
          resolvedDocId = "track_${defaultSurahId}_${System.currentTimeMillis()}"
          docPath = "reciters/$cleanId/recitations/$resolvedDocId"
        }
      }

      val resolvedFileSize =
        if (fileSizeBytes > 0L) {
          fileSizeBytes
        } else {
          hostingService.verifyExternalAudioReachable(safeAudioUrl).getOrNull()?.contentLengthBytes
            ?: 0L
        }

      val docRef = recitationsCollection.document(resolvedDocId)
      val existing = docRef.get().await()

      val track =
        FirebaseRecitationTrack(
          id = resolvedDocId,
          reciterId = cleanId,
          surahNumber = surahNumber.toLong(),
          surahArabicName = resolvedSurahName,
          description = cleanDescription,
          sortOrder = sortOrder.coerceIn(0L, 100_000L),
          hostingProvider = hostingProvider.id,
          audioUrl = safeAudioUrl,
          externalAssetId = cleanAssetId,
          fileSizeBytes = resolvedFileSize.coerceIn(0L, 2_147_483_648L),
          durationSeconds = durationSeconds.coerceIn(0L, 36_000L),
          published = published,
          uploadedBy = adminUid,
        )

      if (existing.exists()) {
        val updates =
          buildMap<String, Any> {
            put("surahNumber", surahNumber.toLong())
            put("surahArabicName", resolvedSurahName)
            put("description", cleanDescription)
            put("sortOrder", sortOrder.coerceIn(0L, 100_000L))
            put("hostingProvider", hostingProvider.id)
            put("audioUrl", safeAudioUrl)
            if (cleanAssetId.isNotEmpty()) put("externalAssetId", cleanAssetId)
            if (resolvedFileSize > 0L) {
              put("fileSizeBytes", resolvedFileSize.coerceIn(0L, 2_147_483_648L))
            }
            if (durationSeconds > 0L) {
              put("durationSeconds", durationSeconds.coerceIn(0L, 36_000L))
            }
            put("published", published)
            put("updatedAt", FieldValue.serverTimestamp())
          }
        docRef.update(updates).await()
      } else {
        docRef.set(track.toCreateMap(adminUid)).await()
      }
      Result.success(track)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docPath)
      Result.failure(e)
    }
  }

  suspend fun reorderRecitationsAsAdmin(
    reciterId: String,
    orderedTrackIds: List<String>,
  ): Result<Unit> {
    val cleanReciterId = reciterId.trim()
    return try {
      requireSuperAdmin()
      require(cleanReciterId.matches(VALID_ID_REGEX)) { "معرف القارئ غير صالح" }
      if (orderedTrackIds.isEmpty()) return Result.success(Unit)
      val batch = db.batch()
      val recitationsRef =
        db.collection("reciters").document(cleanReciterId).collection("recitations")
      orderedTrackIds.forEachIndexed { index, trackId ->
        val cleanTrackId = trackId.trim()
        require(cleanTrackId.matches(VALID_ID_REGEX)) { "معرف التلاوة غير صالح" }
        batch.update(
          recitationsRef.document(cleanTrackId),
          mapOf(
            "sortOrder" to index.toLong().coerceIn(0L, 100_000L),
            "updatedAt" to FieldValue.serverTimestamp(),
          ),
        )
      }
      batch.commit().await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, "reciters/$cleanReciterId/recitations")
      Result.failure(e)
    }
  }

  suspend fun deleteRecitationByIdAsAdmin(
    reciterId: String,
    trackId: String,
  ): Result<Unit> {
    val cleanId = reciterId.trim()
    val cleanTrackId = trackId.trim()
    val docPath = "reciters/$cleanId/recitations/$cleanTrackId"
    return try {
      requireSuperAdmin()
      require(cleanId.matches(VALID_ID_REGEX)) { "معرف القارئ غير صالح" }
      require(cleanTrackId.matches(VALID_ID_REGEX)) { "معرف التلاوة غير صالح" }

      db.collection("reciters")
        .document(cleanId)
        .collection("recitations")
        .document(cleanTrackId)
        .delete()
        .await()

      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docPath)
      Result.failure(e)
    }
  }

  suspend fun deleteRecitationAsAdmin(
    reciterId: String,
    surahNumber: Int,
  ): Result<Unit> {
    if (surahNumber !in 1..114) {
      return Result.failure(IllegalArgumentException("رقم السورة غير صالح"))
    }
    val surahId = String.format(Locale.US, "%03d", surahNumber)
    return deleteRecitationByIdAsAdmin(reciterId, surahId)
  }

  // --- USER PROFILE & BOOKMARKS (Strict Per-User Isolation, Never Auto-Escalate) ---

  suspend fun syncUserProfileOnSignIn(preferredReciterId: String): Result<Unit> {
    var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}"
    return try {
      val uid = requireUserId()
      val user = auth.currentUser ?: return Result.failure(IllegalStateException("غير مسجل الدخول"))
      val docRef = db.collection("users").document(uid)
      docPath = docRef.path
      val existing = docRef.get().await()
      val safeDisplayName =
        (user.displayName?.trim()?.take(100)?.takeIf { it.isNotEmpty() }) ?: "مستخدم نور القرآن"
      val safeReciter = preferredReciterId.trim().take(80)

      if (existing.exists()) {
        val updates =
          buildMap<String, Any> {
            put("displayName", safeDisplayName)
            if (safeReciter.isNotEmpty()) put("preferredReciterId", safeReciter)
            put("updatedAt", FieldValue.serverTimestamp())
          }
        docRef.update(updates).await()
      } else {
        // New accounts are ALWAYS registered with standard role "user" — never auto-escalated
        val model =
          FirebaseUserProfile(
            userId = uid,
            displayName = safeDisplayName,
            role = "user",
            preferredReciterId = safeReciter,
          )
        docRef.set(model.toCreateMap(uid)).await()
      }
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docPath)
      Result.failure(e)
    }
  }

  fun observeUserBookmarks(): Flow<List<FirebaseUserBookmark>> = flow {
    val uid = requireUserId()
    val path = "users/$uid/bookmarks"
    emitAll(
      db.collection("users")
        .document(uid)
        .collection("bookmarks")
        .snapshots()
        .map { snapshot ->
          snapshot.toObjects(
            FirebaseUserBookmark::class.java,
            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE,
          )
        }
        .catch { error ->
          val firestoreError =
            generateSequence(error) { it.cause }
              .filterIsInstance<FirebaseFirestoreException>()
              .firstOrNull()
          if (firestoreError == null && error is CancellationException) throw error
          val exceptionToLog = firestoreError ?: (error as? Exception)
          if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, OperationType.LIST, path)
          }
          throw error
        }
    )
  }

  suspend fun saveUserBookmark(
    surahNumber: Int,
    ayahNumber: Int,
    category: String,
    note: String,
  ): Result<Unit> {
    var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/bookmarks"
    return try {
      val uid = requireUserId()
      require(surahNumber in 1..114) { "رقم السورة غير صالح" }
      require(ayahNumber in 1..286) { "رقم الآية غير صالح" }
      require(category.length in 1..40) { "التصنيف غير صالح" }
      require(note.length <= 500) { "الملاحظة طويلة جداً" }

      val bookmarkId = "${surahNumber}_$ayahNumber"
      val docRef = db.collection("users").document(uid).collection("bookmarks").document(bookmarkId)
      docPath = docRef.path
      val existing = docRef.get().await()
      if (existing.exists()) {
        docRef
          .update(
            mapOf(
              "category" to category,
              "note" to note,
              "updatedAt" to FieldValue.serverTimestamp(),
            )
          )
          .await()
      } else {
        val model =
          FirebaseUserBookmark(
            surahNumber = surahNumber.toLong(),
            ayahNumber = ayahNumber.toLong(),
            category = category,
            note = note,
          )
        docRef.set(model.toCreateMap(uid)).await()
      }
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docPath)
      Result.failure(e)
    }
  }

  suspend fun deleteUserBookmark(surahNumber: Int, ayahNumber: Int): Result<Unit> {
    var docPath = "users/${auth.currentUser?.uid ?: "unauthenticated"}/bookmarks"
    return try {
      val uid = requireUserId()
      require(surahNumber in 1..114) { "رقم السورة غير صالح" }
      require(ayahNumber in 1..286) { "رقم الآية غير صالح" }
      val bookmarkId = "${surahNumber}_$ayahNumber"
      val docRef = db.collection("users").document(uid).collection("bookmarks").document(bookmarkId)
      docPath = docRef.path
      docRef.delete().await()
      Result.success(Unit)
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docPath)
      Result.failure(e)
    }
  }

  companion object {
    val VALID_ID_REGEX = Regex("^[a-zA-Z0-9_\\-\\.]{1,128}$")
  }
}
