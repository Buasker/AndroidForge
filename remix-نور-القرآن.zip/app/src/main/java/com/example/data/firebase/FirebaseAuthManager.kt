package com.example.data.firebase

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.BuildConfig
import com.example.R
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

/**
 * In-memory progressive rate limiter protecting authentication & privilege verification endpoints
 * against rapid automated retry / brute-force probing on the client.
 */
class AuthRateLimiter(
  private val maxAttemptsBeforeLockout: Int = 5,
  private val windowMs: Long = 120_000L,
  private val baseCooldownMs: Long = 30_000L,
  private val nowProvider: () -> Long = { System.currentTimeMillis() },
) {
  private val failureTimestamps = ArrayDeque<Long>()
  private var lockoutUntilMs: Long = 0L
  private var lockoutStrikes: Int = 0

  @Synchronized
  fun remainingLockoutSeconds(): Long {
    val now = nowProvider()
    val diff = lockoutUntilMs - now
    return if (diff > 0L) ((diff + 999L) / 1000L) else 0L
  }

  @Synchronized
  fun checkAllowed(): Result<Unit> {
    val remaining = remainingLockoutSeconds()
    return if (remaining > 0L) {
      Result.failure(
        IllegalStateException("تم تجاوز الحد المسموح لمحاولات الدخول. يرجى الانتظار $remaining ثانية.")
      )
    } else {
      Result.success(Unit)
    }
  }

  @Synchronized
  fun recordFailure() {
    val now = nowProvider()
    while (failureTimestamps.isNotEmpty() && now - failureTimestamps.first() > windowMs) {
      failureTimestamps.removeFirst()
    }
    failureTimestamps.addLast(now)
    if (failureTimestamps.size >= maxAttemptsBeforeLockout) {
      lockoutStrikes = (lockoutStrikes + 1).coerceAtMost(4)
      val cooldown = baseCooldownMs * (1L shl (lockoutStrikes - 1))
      lockoutUntilMs = now + cooldown
      failureTimestamps.clear()
    }
  }

  @Synchronized
  fun recordSuccess() {
    failureTimestamps.clear()
    lockoutUntilMs = 0L
    lockoutStrikes = 0
  }
}

data class AdminPrivilegeStatus(
  val isAuthenticated: Boolean = false,
  val uid: String? = null,
  val email: String? = null,
  val displayName: String? = null,
  val isEmailVerified: Boolean = false,
  val hasCustomSuperAdminClaim: Boolean = false,
  val hasAdminsDocument: Boolean = false,
  val isVerifiedOwnerEmail: Boolean = false,
) {
  val isSuperAdmin: Boolean
    get() =
      isAuthenticated &&
        isEmailVerified &&
        isVerifiedOwnerEmail
}

class FirebaseAuthManager(
  private val auth: FirebaseAuth = Firebase.auth,
  private val db: FirebaseFirestore,
  private val rateLimiter: AuthRateLimiter = AuthRateLimiter(),
) {
  constructor(context: Context) : this(
    auth = Firebase.auth,
    db =
      FirebaseFirestore.getInstance(
        context.applicationContext.getString(R.string.firestore_database_id)
      ),
  )

  fun currentUser(): FirebaseUser? = auth.currentUser

  fun authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { firebaseAuth -> trySend(firebaseAuth.currentUser) }
    auth.addAuthStateListener(listener)
    awaitClose { auth.removeAuthStateListener(listener) }
  }

  /**
   * Silent startup credential check using GoogleIdOption (single credential option per request).
   */
  suspend fun attemptSilentSignIn(context: Context): Result<FirebaseUser?> {
    auth.currentUser?.let { return Result.success(it) }
    val clientId =
      runCatching { context.getString(R.string.default_web_client_id) }.getOrNull()
        ?: return Result.success(null)

    return try {
      val credentialManager = CredentialManager.create(context)
      val googleIdOption =
        GetGoogleIdOption.Builder()
          .setFilterByAuthorizedAccounts(true)
          .setServerClientId(clientId)
          .setAutoSelectEnabled(true)
          .build()
      val request = GetCredentialRequest.Builder().addCredentialOption(googleIdOption).build()
      val credential = credentialManager.getCredential(context, request).credential
      if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
        val token = GoogleIdTokenCredential.createFrom(credential.data).idToken
        val authResult =
          auth.signInWithCredential(GoogleAuthProvider.getCredential(token, null)).await()
        rateLimiter.recordSuccess()
        Result.success(authResult.user)
      } else {
        Result.success(null)
      }
    } catch (_: Exception) {
      Result.success(null)
    }
  }

  /**
   * Interactive Google Sign-In using Credential Manager (GetSignInWithGoogleOption).
   * Enforces rate-limiting on repeated failures and sanitizes UI error messages.
   */
  suspend fun signInWithGoogle(activity: Activity): Result<FirebaseUser> {
    rateLimiter.checkAllowed().onFailure { return Result.failure(it) }

    val clientId =
      try {
        activity.getString(R.string.default_web_client_id)
      } catch (e: Exception) {
        return Result.failure(
          IllegalStateException("إعداد Google Sign-In غير مكتمل في التطبيق.", e)
        )
      }

    val credentialManager = CredentialManager.create(activity)
    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

    return try {
      val credential = credentialManager.getCredential(activity, request).credential
      if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
        val idToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
        val result =
          auth.signInWithCredential(GoogleAuthProvider.getCredential(idToken, null)).await()
        val user =
          result.user ?: run {
            rateLimiter.recordFailure()
            return Result.failure(IllegalStateException("تعذر قراءة بيانات الحساب."))
          }
        rateLimiter.recordSuccess()
        Result.success(user)
      } else {
        rateLimiter.recordFailure()
        Result.failure(IllegalStateException("نوع بيانات الاعتماد غير متوقع."))
      }
    } catch (e: GetCredentialCancellationException) {
      if (BuildConfig.DEBUG) {
        Log.w(TAG, "Google Sign-In cancelled or dismissed")
      }
      Result.failure(IllegalStateException("تم إلغاء تسجيل الدخول.", e))
    } catch (e: Exception) {
      rateLimiter.recordFailure()
      if (BuildConfig.DEBUG) {
        Log.e(TAG, "Google Sign-In failed: ${e.javaClass.simpleName}")
      }
      Result.failure(IllegalStateException("تعذر تسجيل الدخول حالياً. يرجى المحاولة لاحقاً.", e))
    }
  }

  /**
   * Evaluates Owner / Super Admin authorization cleanly via server-signed ID token & Firestore:
   * 1) Email must be verified (`user.isEmailVerified == true`),
   * 2) Sole Owner email (`OWNER_EMAIL = mlwnhlnh@gmail.com`) OR server-signed Custom Claims OR read-only `/admins/{uid}`.
   */
  suspend fun verifyAdminPrivileges(forceRefreshToken: Boolean = true): AdminPrivilegeStatus {
    val user = auth.currentUser ?: return AdminPrivilegeStatus(isAuthenticated = false)
    val tokenResult =
      runCatching { user.getIdToken(forceRefreshToken).await() }.getOrNull()
        ?: runCatching { user.getIdToken(false).await() }.getOrNull()
    val claims = tokenResult?.claims.orEmpty()
    val tokenEmailVerified = (claims["email_verified"] as? Boolean) ?: user.isEmailVerified
    val tokenEmail = ((claims["email"] as? String) ?: user.email)?.trim()?.lowercase()
    val hasClaim =
      tokenEmailVerified &&
        ((claims["superAdmin"] as? Boolean == true) ||
          (claims["role"] as? String == "super_admin"))

    val isVerifiedOwner = isVerifiedOwnerEmail(tokenEmail, tokenEmailVerified)

    val hasAdminDoc =
      if (tokenEmailVerified) {
        runCatching {
            db.collection("admins").document(user.uid).get().await().exists()
          }
          .getOrDefault(false)
      } else {
        false
      }

    return AdminPrivilegeStatus(
      isAuthenticated = true,
      uid = user.uid,
      email = user.email,
      displayName = user.displayName,
      isEmailVerified = tokenEmailVerified,
      hasCustomSuperAdminClaim = hasClaim,
      hasAdminsDocument = hasAdminDoc,
      isVerifiedOwnerEmail = isVerifiedOwner,
    )
  }

  suspend fun signOut(context: Context) {
    withContext(NonCancellable) {
      try {
        CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
      } catch (_: Exception) {
        if (BuildConfig.DEBUG) {
          Log.w(TAG, "Failed to clear credential state")
        }
      } finally {
        rateLimiter.recordSuccess()
        auth.signOut()
      }
    }
  }

  companion object {
    private const val TAG = "FirebaseAuthManager"
    const val OWNER_EMAIL = "mlwnhlnh@gmail.com"
    val OWNER_EMAIL_NORMALIZED = OWNER_EMAIL.trim().lowercase()

    fun isVerifiedOwnerEmail(email: String?, isEmailVerified: Boolean): Boolean =
      isEmailVerified && email?.trim()?.lowercase() == OWNER_EMAIL_NORMALIZED
  }
}
