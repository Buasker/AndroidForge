package com.example.data.remote

import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path

interface AlQuranApiService {
  @GET("v1/surah")
  suspend fun getSurahs(): SurahListResponseDto

  @GET("v1/surah/{surahNumber}/editions/{editions}")
  suspend fun getSurahEditions(
    @Path("surahNumber") surahNumber: Int,
    @Path("editions") editions: String,
  ): SurahEditionsResponseDto

  @GET("v1/surah/{surahNumber}/{edition}")
  suspend fun getSurahSingleEdition(
    @Path("surahNumber") surahNumber: Int,
    @Path("edition") edition: String,
  ): SingleSurahResponseDto

  @GET("v1/page/{pageNumber}/{edition}")
  suspend fun getPage(
    @Path("pageNumber") pageNumber: Int,
    @Path("edition") edition: String,
  ): PageResponseDto

  @GET("v1/search/{keyword}/all/{edition}")
  suspend fun searchQuran(
    @Path("keyword") keyword: String,
    @Path("edition") edition: String,
  ): SearchResponseDto

  companion object {
    private const val BASE_URL = "https://api.alquran.cloud/"

    fun createOkHttpClient(): OkHttpClient =
      OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .addInterceptor { chain ->
          val request = chain.request()
          if (!request.url.isHttps) {
            throw java.io.IOException("Blocked insecure non-HTTPS request")
          }
          if (request.url.username.isNotEmpty() || request.url.password.isNotEmpty()) {
            throw java.io.IOException("Blocked URL containing embedded credentials")
          }
          if (request.url.port != 443) {
            throw java.io.IOException("Blocked non-HTTPS standard port")
          }
          chain.proceed(request)
        }
        .addNetworkInterceptor { chain ->
          val request = chain.request()
          if (!request.url.isHttps || request.url.port != 443) {
            throw java.io.IOException("Blocked insecure redirect target")
          }
          if (request.url.username.isNotEmpty() || request.url.password.isNotEmpty()) {
            throw java.io.IOException("Blocked redirect target with credentials")
          }
          val peerAddr = chain.connection()?.socket()?.inetAddress
          if (peerAddr != null && isPrivateOrLoopbackAddress(peerAddr)) {
            throw java.io.IOException("Blocked SSRF connection to internal network address")
          }
          chain.proceed(request)
        }
        .build()

    internal fun isPrivateOrLoopbackAddress(address: java.net.InetAddress): Boolean {
      if (
        address.isAnyLocalAddress ||
          address.isLoopbackAddress ||
          address.isLinkLocalAddress ||
          address.isSiteLocalAddress ||
          address.isMulticastAddress
      ) {
        return true
      }
      val bytes = address.address
      if (bytes.size == 4) {
        val b0 = bytes[0].toInt() and 0xFF
        val b1 = bytes[1].toInt() and 0xFF
        // CGNAT 100.64.0.0/10, 0.0.0.0/8, 127.0.0.0/8
        if (b0 == 0 || b0 == 127) return true
        if (b0 == 100 && b1 in 64..127) return true
      }
      return false
    }

    fun create(client: OkHttpClient = createOkHttpClient()): AlQuranApiService {
      val moshi =
        Moshi.Builder()
          .add(SajdaBooleanAdapter())
          .addLast(KotlinJsonAdapterFactory())
          .build()

      return Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(client)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(AlQuranApiService::class.java)
    }
  }
}
