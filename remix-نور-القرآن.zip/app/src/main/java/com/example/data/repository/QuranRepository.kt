package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.firebase.ExternalAudioMetadata
import com.example.data.firebase.FreeAudioHostingService
import com.example.data.local.AdhkarProgressEntity
import com.example.data.local.AdhkarSeedData
import com.example.data.local.AyahEntity
import com.example.data.local.BookmarkEntity
import com.example.data.local.DhikrCounterEntity
import com.example.data.local.DhikrDailyLogEntity
import com.example.data.local.DownloadedAudioEntity
import com.example.data.local.KhatmahPlanEntity
import com.example.data.local.LocalRecitationEntity
import com.example.data.local.LocalReciterEntity
import com.example.data.local.QuranDao
import com.example.data.local.QuranSeedData
import com.example.data.local.SurahEntity
import com.example.data.local.TafsirEntity
import com.example.data.model.AyahItem
import com.example.data.model.BookmarkItem
import com.example.data.model.DhikrDailyLog
import com.example.data.model.DhikrPhraseItem
import com.example.data.model.DhikrSourceType
import com.example.data.model.KhatmahPlan
import com.example.data.model.LocalRecitationTrack
import com.example.data.model.LocalReciter
import com.example.data.model.QuranCatalog
import com.example.data.model.SearchMatchItem
import com.example.data.model.SearchResultType
import com.example.data.model.SurahInfo
import com.example.data.model.TafsirAyahItem
import com.example.data.remote.AlQuranApiService
import com.example.data.remote.Mp3QuranApiService
import com.example.dhikr.DhikrDateUtils
import com.example.dhikr.DhikrSpeechMatcher
import java.io.File
import java.net.URI
import java.net.URLEncoder
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

data class SurahLoadResult(
  val surah: SurahInfo,
  val ayahs: List<AyahItem>,
  val fromCache: Boolean,
)

data class MushafPageLoadResult(
  val pageNumber: Int,
  val ayahs: List<AyahItem>,
  val surahNames: String,
  val fromCache: Boolean,
)

class QuranRepository(
  private val context: Context,
  private val dao: QuranDao,
  private val api: AlQuranApiService,
  private val mp3QuranApi: Mp3QuranApiService,
  private val okHttpClient: OkHttpClient,
  private val resolveCloudHostedTrackUrl: (suspend (String, Int) -> String?)? = null,
  private val resolveCloudReciterBaseUrl: (suspend (String) -> String?)? = null,
) {
  private val dynamicServerCache = mutableMapOf<String, String>()
  private val hostingService = FreeAudioHostingService(okHttpClient)

  val surahsFlow: Flow<List<SurahInfo>> =
    dao.getAllSurahsFlow().map { list -> list.map { it.toDomain() } }

  val bookmarksFlow: Flow<List<BookmarkItem>> =
    dao.getAllBookmarksFlow().map { list -> list.map { it.toDomain() } }

  val dhikrCountersFlow: Flow<List<DhikrPhraseItem>> =
    dao.getAllDhikrCountersFlow().map { list ->
      list.map {
        DhikrPhraseItem(
          id = it.id,
          arabicTitle = it.arabicTitle,
          subtitle = it.subtitle,
          count = it.count,
          lastUpdated = it.lastUpdated,
        )
      }
    }

  val adhkarProgressFlow: Flow<Map<String, Int>> =
    dao.getAllAdhkarProgressFlow().map { list -> list.associate { it.dhikrId to it.currentCount } }

  val dhikrDailyLogsFlow: Flow<List<DhikrDailyLog>> =
    dao.getAllDhikrDailyLogsFlow().map { list -> list.map { it.toDomain() } }

  val khatmahPlansFlow: Flow<List<KhatmahPlan>> =
    dao.getAllKhatmahPlansFlow().map { list -> list.map { it.toDomain() } }

  val localRecitersFlow: Flow<List<LocalReciter>> =
    dao.getAllLocalRecitersFlow().map { list -> list.map { it.toDomain() } }

  val allLocalRecitationsFlow: Flow<List<LocalRecitationTrack>> =
    dao.getAllLocalRecitationsFlow().map { list -> list.map { it.toDomain() } }

  fun localRecitationsForReciterFlow(reciterId: String): Flow<List<LocalRecitationTrack>> =
    dao.getLocalRecitationsForReciterFlow(reciterId).map { list -> list.map { it.toDomain() } }

  fun downloadedSurahsFlow(reciterId: String): Flow<Set<Int>> =
    dao.getDownloadedAudioForReciterFlow(reciterId).map { list ->
      list.filter { File(it.localFilePath).exists() }.map { it.surahNumber }.toSet()
    }

  suspend fun ensureInitialDataSeeded() {
    if (dao.getSurahCount() < 114) {
      dao.insertSurahs(QuranSeedData.surahs)
    }
    if (dao.getDhikrCounterCount() < AdhkarSeedData.initialVoiceDhikrCounters.size) {
      dao.insertDhikrCounters(AdhkarSeedData.initialVoiceDhikrCounters)
    }
    if (dao.getDhikrDailyLogCount() == 0) {
      val existingNonZero = dao.getNonZeroDhikrCounters()
      if (existingNonZero.isNotEmpty()) {
        dao.insertDhikrDailyLogs(
          existingNonZero.map { counter ->
            DhikrDailyLogEntity(
              epochDay = DhikrDateUtils.epochDayForMillis(counter.lastUpdated),
              dhikrId = counter.id,
              label = counter.arabicTitle,
              sourceType = DhikrSourceType.VOICE.id,
              count = counter.count,
              lastUpdated = counter.lastUpdated,
            )
          }
        )
      }
    }
    listOf(1, 112, 113, 114).forEach { surahNum ->
      if (dao.getAyahsForSurah(surahNum, "en.sahih").isEmpty()) {
        val fallback = QuranSeedData.offlineFallbackAyahs(surahNum)
        if (fallback.isNotEmpty()) {
          dao.insertAyahs(fallback)
        }
      }
    }
    runCatching {
      val response = api.getSurahs()
      if (response.code == 200 && response.data.size == 114) {
        dao.insertSurahs(
          response.data.map { dto ->
            SurahEntity(
              number = dto.number,
              arabicName = dto.name,
              englishName = dto.englishName,
              englishNameTranslation = dto.englishNameTranslation,
              numberOfAyahs = dto.numberOfAyahs,
              revelationType = dto.revelationType,
            )
          }
        )
      }
    }
  }

  suspend fun loadSurah(surahNumber: Int, translationEdition: String): Result<SurahLoadResult> {
    if (surahNumber !in 1..114) {
      return Result.failure(IllegalArgumentException("رقم السورة غير صالح"))
    }
    val safeEdition =
      translationEdition.trim().takeIf { it.matches(SAFE_ID_REGEX) } ?: "en.sahih"
    if (dao.getSurahCount() < 114) {
      dao.insertSurahs(QuranSeedData.surahs)
    }
    val surahInfo =
      dao.getSurahByNumber(surahNumber)?.toDomain()
        ?: QuranSeedData.surahs.first { it.number == surahNumber }.toDomain()

    val cached = dao.getAyahsForSurah(surahNumber, safeEdition)
    if (cached.isNotEmpty()) {
      return Result.success(
        SurahLoadResult(
          surah = surahInfo,
          ayahs = cached.map { it.toDomain(surahInfo.arabicName) },
          fromCache = true,
        )
      )
    }

    return try {
      val response = api.getSurahEditions(surahNumber, "quran-uthmani,$safeEdition")
      val arabicSurah = response.data.firstOrNull { it.edition.identifier == "quran-uthmani" }
      val translationSurah = response.data.firstOrNull { it.edition.identifier == safeEdition }
      if (arabicSurah == null || translationSurah == null) {
        return fallbackOrFailure(surahNumber, surahInfo, IllegalStateException("بيانات السورة غير مكتملة"))
      }

      val translationsByNumber = translationSurah.ayahs.associateBy { it.numberInSurah }
      val entities =
        arabicSurah.ayahs.map { arabicAyah ->
          AyahEntity(
            globalNumber = arabicAyah.number,
            numberInSurah = arabicAyah.numberInSurah,
            surahNumber = surahNumber,
            translationEdition = safeEdition,
            arabicText = arabicAyah.text,
            translationText = translationsByNumber[arabicAyah.numberInSurah]?.text ?: "",
            juz = arabicAyah.juz,
            page = arabicAyah.page,
            sajda = arabicAyah.sajda,
          )
        }

      dao.insertAyahs(entities)
      Result.success(
        SurahLoadResult(
          surah = surahInfo,
          ayahs = entities.map { it.toDomain(surahInfo.arabicName) },
          fromCache = false,
        )
      )
    } catch (e: Exception) {
      fallbackOrFailure(surahNumber, surahInfo, e)
    }
  }

  suspend fun loadMushafPage(pageNumber: Int, translationEdition: String): Result<MushafPageLoadResult> {
    val safePage = pageNumber.coerceIn(1, 604)
    val surahMap = QuranSeedData.surahs.associateBy { it.number }

    val cachedPage = dao.getAyahsForPage(safePage, translationEdition)
    if (cachedPage.isNotEmpty()) {
      val names =
        cachedPage
          .mapNotNull { surahMap[it.surahNumber]?.arabicName }
          .distinct()
          .joinToString(" • ")
      return Result.success(
        MushafPageLoadResult(
          pageNumber = safePage,
          ayahs = cachedPage.map { it.toDomain(surahMap[it.surahNumber]?.arabicName ?: "") },
          surahNames = names,
          fromCache = true,
        )
      )
    }

    return try {
      val arabicPage = api.getPage(safePage, "quran-uthmani").data
      val transPage = runCatching { api.getPage(safePage, translationEdition).data }.getOrNull()
      val transMap = transPage?.ayahs?.associateBy { it.number } ?: emptyMap()

      val entities =
        arabicPage.ayahs.map { dto ->
          AyahEntity(
            globalNumber = dto.number,
            numberInSurah = dto.numberInSurah,
            surahNumber = dto.surah.number,
            translationEdition = translationEdition,
            arabicText = dto.text,
            translationText = transMap[dto.number]?.text ?: "",
            juz = dto.juz,
            page = dto.page,
            sajda = dto.sajda,
          )
        }
      dao.insertAyahs(entities)
      val names = arabicPage.ayahs.map { it.surah.name }.distinct().joinToString(" • ")
      Result.success(
        MushafPageLoadResult(
          pageNumber = safePage,
          ayahs = entities.map { it.toDomain(surahMap[it.surahNumber]?.arabicName ?: "") },
          surahNames = names,
          fromCache = false,
        )
      )
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  suspend fun loadSurahTafsir(surahNumber: Int, editionId: String): Result<List<TafsirAyahItem>> {
    if (surahNumber !in 1..114) {
      return Result.failure(IllegalArgumentException("رقم السورة غير صالح"))
    }
    val editionMeta =
      QuranCatalog.tafsirEditions.firstOrNull { it.identifier == editionId }
        ?: QuranCatalog.tafsirEditions.first()
    val safeEditionId = editionMeta.identifier
    val surahMeta = QuranSeedData.surahs.firstOrNull { it.number == surahNumber }

    val cached = dao.getTafsirForSurah(surahNumber, safeEditionId)
    if (cached.isNotEmpty()) {
      return Result.success(
        cached.map {
          TafsirAyahItem(
            surahNumber = it.surahNumber,
            surahArabicName = it.surahArabicName,
            ayahNumberInSurah = it.numberInSurah,
            globalNumber = it.globalNumber,
            quranArabicText = it.quranArabicText,
            tafsirText = it.tafsirText,
            editionId = it.editionId,
            editionName = editionMeta.arabicName,
            sourceAttribution = editionMeta.sourceAttribution,
          )
        }
      )
    }

    return try {
      val response = api.getSurahEditions(surahNumber, "quran-uthmani,$safeEditionId")
      val quranSurah = response.data.firstOrNull { it.edition.identifier == "quran-uthmani" }
      val tafsirSurah = response.data.firstOrNull { it.edition.identifier == safeEditionId }
      if (quranSurah == null || tafsirSurah == null) {
        return Result.failure(IllegalStateException("تعذر جلب التفسير لهذه السورة"))
      }

      val tafsirByAyah = tafsirSurah.ayahs.associateBy { it.numberInSurah }
      val entities =
        quranSurah.ayahs.map { ayah ->
          TafsirEntity(
            surahNumber = surahNumber,
            numberInSurah = ayah.numberInSurah,
            globalNumber = ayah.number,
            editionId = safeEditionId,
            surahArabicName = surahMeta?.arabicName ?: quranSurah.name,
            quranArabicText = ayah.text,
            tafsirText = tafsirByAyah[ayah.numberInSurah]?.text ?: "",
          )
        }
      dao.insertTafsirItems(entities)
      Result.success(
        entities.map {
          TafsirAyahItem(
            surahNumber = it.surahNumber,
            surahArabicName = it.surahArabicName,
            ayahNumberInSurah = it.numberInSurah,
            globalNumber = it.globalNumber,
            quranArabicText = it.quranArabicText,
            tafsirText = it.tafsirText,
            editionId = it.editionId,
            editionName = editionMeta.arabicName,
            sourceAttribution = editionMeta.sourceAttribution,
          )
        }
      )
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  private fun fallbackOrFailure(
    surahNumber: Int,
    surahInfo: SurahInfo,
    error: Exception,
  ): Result<SurahLoadResult> {
    val fallback = QuranSeedData.offlineFallbackAyahs(surahNumber)
    return if (fallback.isNotEmpty()) {
      Result.success(
        SurahLoadResult(
          surah = surahInfo,
          ayahs = fallback.map { it.toDomain(surahInfo.arabicName) },
          fromCache = true,
        )
      )
    } else {
      Result.failure(error)
    }
  }

  // Bookmarks
  suspend fun toggleBookmark(surah: SurahInfo, ayah: AyahItem): Boolean {
    val exists = dao.isBookmarked(surah.number, ayah.numberInSurah)
    return if (exists) {
      dao.deleteBookmark(surah.number, ayah.numberInSurah)
      false
    } else {
      dao.insertBookmark(
        BookmarkEntity(
          surahNumber = surah.number,
          surahEnglishName = surah.englishName,
          surahArabicName = surah.arabicName,
          ayahNumberInSurah = ayah.numberInSurah,
          globalAyahNumber = ayah.globalNumber,
          arabicText = ayah.arabicText,
          translationText = ayah.translationText,
        )
      )
      true
    }
  }

  suspend fun updateBookmarkDetails(
    surahNumber: Int,
    ayahNumber: Int,
    category: String,
    note: String,
  ) {
    dao.updateBookmarkDetails(surahNumber, ayahNumber, category, note)
  }

  suspend fun removeBookmark(surahNumber: Int, ayahNumber: Int) {
    dao.deleteBookmark(surahNumber, ayahNumber)
  }

  // Voice Dhikr
  suspend fun incrementDhikr(
    id: String,
    delta: Int = 1,
    timestampMillis: Long = System.currentTimeMillis(),
  ): Boolean {
    if (id !in VOICE_DHIKR_IDS || delta <= 0) return false
    var updatedRows = dao.incrementDhikrCounter(id, delta = delta, timestamp = timestampMillis)
    if (updatedRows == 0) {
      dao.insertDhikrCounters(AdhkarSeedData.initialVoiceDhikrCounters)
      updatedRows = dao.incrementDhikrCounter(id, delta = delta, timestamp = timestampMillis)
    }
    if (updatedRows > 0) {
      val title =
        AdhkarSeedData.initialVoiceDhikrCounters.firstOrNull { it.id == id }?.arabicTitle ?: id
      recordDailyDhikrLog(
        epochDay = DhikrDateUtils.epochDayForMillis(timestampMillis),
        dhikrId = id,
        label = title,
        sourceType = DhikrSourceType.VOICE,
        delta = delta,
        timestampMillis = timestampMillis,
      )
    }
    return updatedRows > 0
  }

  suspend fun resetDhikr(id: String) {
    if (id !in VOICE_DHIKR_IDS) return
    dao.resetDhikrCounter(id)
  }

  suspend fun resetAllDhikr() = dao.resetAllDhikrCounters()

  // Adhkar
  suspend fun incrementAdhkar(
    dhikrId: String,
    currentCount: Int,
    targetCount: Int,
    timestampMillis: Long = System.currentTimeMillis(),
  ) {
    if (!dhikrId.matches(SAFE_ID_REGEX)) return
    val safeTarget = targetCount.coerceIn(1, 10_000)
    val cleanCurrent = currentCount.coerceAtLeast(0)
    val next = (cleanCurrent + 1).coerceAtMost(safeTarget)
    dao.upsertAdhkarProgress(
      AdhkarProgressEntity(
        dhikrId = dhikrId,
        currentCount = next,
        lastUpdated = timestampMillis,
      )
    )
    if (next > cleanCurrent) {
      val item = AdhkarSeedData.allAdhkar.firstOrNull { it.id == dhikrId }
      val logId = if (item != null) "adhkar_${item.category.id}" else "adhkar_$dhikrId"
      val label = item?.category?.titleArabic ?: "الأذكار اليومية"
      recordDailyDhikrLog(
        epochDay = DhikrDateUtils.epochDayForMillis(timestampMillis),
        dhikrId = logId,
        label = label,
        sourceType = DhikrSourceType.ADHKAR,
        delta = 1,
        timestampMillis = timestampMillis,
      )
    }
  }

  suspend fun resetAdhkarItem(dhikrId: String) {
    if (!dhikrId.matches(SAFE_ID_REGEX)) return
    dao.upsertAdhkarProgress(AdhkarProgressEntity(dhikrId = dhikrId, currentCount = 0))
  }

  suspend fun resetAllAdhkar() = dao.resetAllAdhkarProgress()

  private suspend fun recordDailyDhikrLog(
    epochDay: Long,
    dhikrId: String,
    label: String,
    sourceType: DhikrSourceType,
    delta: Int,
    timestampMillis: Long,
  ) {
    if (delta <= 0) return
    val updated =
      dao.incrementDhikrDailyLog(
        epochDay = epochDay,
        dhikrId = dhikrId,
        label = label,
        delta = delta,
        timestamp = timestampMillis,
      )
    if (updated == 0) {
      dao.insertDhikrDailyLogs(
        listOf(
          DhikrDailyLogEntity(
            epochDay = epochDay,
            dhikrId = dhikrId,
            label = label,
            sourceType = sourceType.id,
            count = delta,
            lastUpdated = timestampMillis,
          )
        )
      )
    }
  }

  // Khatmah
  suspend fun saveKhatmahPlan(plan: KhatmahPlan): Long {
    val cleanTitle = plan.title.trim().take(100).ifBlank { "ختمة القرآن الكريم" }
    val safeTotalPages = plan.totalPages.coerceIn(1, 604)
    val safeEnd = maxOf(plan.endDateEpochDay, plan.startDateEpochDay)
    return dao.upsertKhatmahPlan(
      KhatmahPlanEntity(
        id = plan.id,
        title = cleanTitle,
        startDateEpochDay = plan.startDateEpochDay,
        endDateEpochDay = safeEnd,
        totalPages = safeTotalPages,
        pagesRead = plan.pagesRead.coerceIn(0, safeTotalPages),
        isPaused = plan.isPaused,
        createdAt = plan.createdAt,
      )
    )
  }

  suspend fun deleteKhatmahPlan(id: Long) = dao.deleteKhatmahPlan(id)

  private fun validateSafeReciterId(reciterId: String): String {
    val clean = reciterId.trim()
    require(clean.matches(SAFE_ID_REGEX) && !clean.contains("..")) {
      "معرف القارئ غير صالح"
    }
    return clean
  }

  private fun safeReciterAudioDir(cleanReciterId: String): File {
    val rootDir = File(context.filesDir, "audio").apply { mkdirs() }
    val targetDir = File(rootDir, cleanReciterId)
    val canonicalRoot = rootDir.canonicalPath
    val canonicalTarget = targetDir.canonicalPath
    require(canonicalTarget.startsWith("$canonicalRoot${File.separator}")) {
      "مسار حفظ الصوت غير صالح"
    }
    return targetDir
  }

  private fun safeReciterPhotosDir(): File =
    File(context.filesDir, "reciter_photos").apply { mkdirs() }

  private fun isSafeInternalPhotoPath(path: String): Boolean {
    val clean = path.trim()
    if (clean.isEmpty()) return false
    val photosRoot = safeReciterPhotosDir().canonicalPath
    val file = runCatching { File(clean) }.getOrNull() ?: return false
    val canonical = runCatching { file.canonicalPath }.getOrNull() ?: return false
    return canonical.startsWith("$photosRoot${File.separator}") && file.exists()
  }

  private fun validatePhotoPathOrUrl(raw: String): String {
    val clean = raw.trim()
    if (clean.isEmpty()) return ""
    if (clean.startsWith("https://")) {
      return hostingService.validatePublicImageUrl(clean)
    }
    if (isSafeInternalPhotoPath(clean)) {
      return clean
    }
    throw IllegalArgumentException("صورة القارئ يجب أن تكون رابط HTTPS آمناً أو صورة مختارة من المعرض.")
  }

  private fun deleteInternalPhotoIfOwned(path: String) {
    if (isSafeInternalPhotoPath(path)) {
      runCatching { File(path).delete() }
    }
  }

  suspend fun saveLocalReciterPhotoFromUri(uri: Uri): Result<String> =
    withContext(Dispatchers.IO) {
      runCatching {
        val dir = safeReciterPhotosDir()
        val destFile = File(dir, "reciter_${UUID.randomUUID()}.jpg")
        val tempFile = File(dir, "${destFile.name}.tmp")
        context.contentResolver.openInputStream(uri)?.use { input ->
          tempFile.outputStream().use { output ->
            val buffer = ByteArray(8192)
            var total = 0L
            while (true) {
              val read = input.read(buffer)
              if (read == -1) break
              total += read
              if (total > MAX_RECITER_PHOTO_BYTES) {
                tempFile.delete()
                throw IllegalArgumentException("حجم الصورة يتجاوز الحد المسموح به (8 ميجابايت).")
              }
              output.write(buffer, 0, read)
            }
          }
        } ?: throw IllegalStateException("تعذر قراءة الصورة المختارة من الجهاز.")
        if (!tempFile.renameTo(destFile)) {
          tempFile.delete()
          throw IllegalStateException("تعذر حفظ صورة القارئ محلياً.")
        }
        destFile.absolutePath
      }
    }

  fun validateAudioInputUrl(rawUrl: String): String =
    hostingService.validatePublicAudioUrl(rawUrl)

  fun resolveUrlFromFullSurahSetting(baseOrDirectUrl: String, surahNumber: Int): String {
    require(surahNumber in 1..114) { "رقم السورة غير صالح" }
    val trimmed = baseOrDirectUrl.trim()
    val padded = String.format(Locale.US, "%03d", surahNumber)
    if (trimmed.contains("{03d}") || trimmed.contains("{surah}")) {
      val templated =
        trimmed.replace("{03d}", padded).replace("{surah}", surahNumber.toString())
      return hostingService.validatePublicAudioUrl(templated)
    }
    val validated = hostingService.validatePublicAudioUrl(trimmed)
    val pathLower = runCatching { URI(validated).path?.lowercase(Locale.US) }.getOrNull().orEmpty()
    if (AUDIO_FILE_EXTENSIONS.any { ext -> pathLower.endsWith(ext) }) {
      return validated
    }
    val normalizedBase = if (validated.endsWith("/")) validated else "$validated/"
    return hostingService.validatePublicAudioUrl("$normalizedBase$padded.mp3")
  }

  suspend fun verifyAudioUrlReachable(audioUrl: String): Result<ExternalAudioMetadata> =
    hostingService.verifyExternalAudioReachable(audioUrl)

  suspend fun saveLocalReciter(
    editingId: String?,
    arabicName: String,
    description: String,
    riwayah: String,
    photoPathOrUrl: String,
    fullSurahBaseUrl: String,
  ): Result<LocalReciter> =
    withContext(Dispatchers.IO) {
      runCatching {
        val cleanName = arabicName.trim().take(120)
        require(cleanName.length >= 2) { "يرجى إدخال اسم الشيخ كاملاً (حرفان على الأقل)." }
        val normalizedName =
          DhikrSpeechMatcher.normalizeArabic(cleanName)
            .ifBlank { cleanName }
            .lowercase(Locale.US)

        val cleanEditingId =
          editingId?.trim()?.takeIf { it.isNotEmpty() }?.let { validateSafeReciterId(it) }
        val existingByName = dao.findLocalReciterByNormalizedName(normalizedName)
        if (existingByName != null && existingByName.id != cleanEditingId) {
          throw IllegalArgumentException("يوجد قارئ مضاف مسبقاً بنفس الاسم.")
        }

        val previous = cleanEditingId?.let { dao.getLocalReciterById(it) }
        val finalId =
          cleanEditingId
            ?: "local_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        val validatedPhoto = validatePhotoPathOrUrl(photoPathOrUrl)
        if (
          previous != null &&
            previous.photoPathOrUrl.isNotBlank() &&
            previous.photoPathOrUrl != validatedPhoto
        ) {
          deleteInternalPhotoIfOwned(previous.photoPathOrUrl)
        }

        val cleanBaseInput = fullSurahBaseUrl.trim()
        val validatedBaseUrl =
          if (cleanBaseInput.isEmpty()) {
            ""
          } else if (cleanBaseInput.contains("{03d}") || cleanBaseInput.contains("{surah}")) {
            resolveUrlFromFullSurahSetting(cleanBaseInput, 1)
            cleanBaseInput
          } else {
            hostingService.validateOptionalPublicHttpsUrl(
              cleanBaseInput,
              "رابط السور الكاملة",
            )
          }
        val now = System.currentTimeMillis()
        val entity =
          LocalReciterEntity(
            id = finalId,
            arabicName = cleanName,
            normalizedName = normalizedName,
            description = description.trim().take(400),
            riwayah = riwayah.trim().take(80).ifBlank { "حفص عن عاصم" },
            photoPathOrUrl = validatedPhoto,
            fullSurahBaseUrl = validatedBaseUrl,
            createdAt = previous?.createdAt ?: now,
            updatedAt = now,
          )
        dao.upsertLocalReciter(entity)
        entity.toDomain()
      }
    }

  suspend fun deleteLocalReciter(reciterId: String): Result<Unit> =
    withContext(Dispatchers.IO) {
      runCatching {
        val cleanId = validateSafeReciterId(reciterId)
        val existing = dao.getLocalReciterById(cleanId)
        if (existing != null) {
          deleteInternalPhotoIfOwned(existing.photoPathOrUrl)
        }
        val downloads = dao.getDownloadedAudioListForReciter(cleanId)
        val audioRoot = File(context.filesDir, "audio").canonicalPath
        downloads.forEach { dl ->
          runCatching {
            val file = File(dl.localFilePath)
            if (file.canonicalPath.startsWith("$audioRoot${File.separator}")) {
              file.delete()
            }
          }
        }
        dao.deleteAllDownloadedAudioForReciter(cleanId)
        dao.deleteLocalReciterById(cleanId)
      }
    }

  suspend fun saveLocalRecitation(
    reciterId: String,
    surahNumber: Int,
    audioUrl: String,
    notes: String,
    isEdit: Boolean = false,
  ): Result<LocalRecitationTrack> =
    withContext(Dispatchers.IO) {
      runCatching {
        val cleanReciterId = validateSafeReciterId(reciterId)
        require(surahNumber in 1..114) { "يرجى اختيار رقم سورة صحيح بين 1 و 114." }
        dao.getLocalReciterById(cleanReciterId)
          ?: throw IllegalStateException("القارئ غير موجود في قاعدة البيانات.")
        val validatedAudioUrl = hostingService.validatePublicAudioUrl(audioUrl)
        if (!isEdit && dao.getLocalRecitation(cleanReciterId, surahNumber) != null) {
          throw IllegalArgumentException(
            "توجد تلاوة مسجّلة لهذه السورة بالفعل لهذا القارئ؛ يمكنك تعديلها من القائمة."
          )
        }
        val surahName =
          QuranSeedData.surahs.firstOrNull { it.number == surahNumber }?.arabicName
            ?: "سورة رقم $surahNumber"
        val entity =
          LocalRecitationEntity(
            reciterId = cleanReciterId,
            surahNumber = surahNumber,
            surahArabicName = surahName,
            audioUrl = validatedAudioUrl,
            notes = notes.trim().take(240),
            updatedAt = System.currentTimeMillis(),
          )
        dao.upsertLocalRecitation(entity)
        entity.toDomain()
      }
    }

  suspend fun deleteLocalRecitation(reciterId: String, surahNumber: Int) {
    val cleanId = runCatching { validateSafeReciterId(reciterId) }.getOrNull() ?: return
    if (surahNumber !in 1..114) return
    dao.deleteLocalRecitation(cleanId, surahNumber)
  }

  // Audio URLs & Offline Downloads
  // Playback priority:
  // 1. Local file cached in Room (DownloadedAudioEntity)
  // 2. User-added Local Recitation Track in Room (LocalRecitationEntity)
  // 3. User-added Local Reciter Full-Surah URL/Base in Room (LocalReciterEntity)
  // 4. Published HTTPS URL from Cloud Firestore (GitHub Releases / Archive.org / Direct HTTPS)
  // 5. Direct external HTTPS URL (if validated as safe public HTTPS)
  // 6. Published Cloud Reciter base URL or MP3Quran CDN fallback
  suspend fun resolveSurahAudioSource(
    reciterId: String,
    surahNumber: Int,
    directHttpsUrl: String? = null,
  ): String {
    val cleanReciterId = validateSafeReciterId(reciterId)
    require(surahNumber in 1..114) { "رقم السورة غير صالح" }

    val downloaded = dao.getDownloadedAudio(cleanReciterId, surahNumber)
    if (downloaded != null && File(downloaded.localFilePath).exists()) {
      return downloaded.localFilePath
    }

    dao.getLocalRecitation(cleanReciterId, surahNumber)
      ?.let { track ->
        runCatching { hostingService.validatePublicAudioUrl(track.audioUrl) }.getOrNull()
      }
      ?.let { return it }

    val localReciter = dao.getLocalReciterById(cleanReciterId)
    localReciter
      ?.fullSurahBaseUrl
      ?.takeIf { it.isNotBlank() }
      ?.let { baseOrDirect ->
        runCatching { resolveUrlFromFullSurahSetting(baseOrDirect, surahNumber) }.getOrNull()
      }
      ?.let { return it }

    resolveCloudHostedTrackUrl?.invoke(cleanReciterId, surahNumber)
      ?.let { url -> runCatching { hostingService.validatePublicAudioUrl(url) }.getOrNull() }
      ?.let { return it }

    directHttpsUrl
      ?.let { url -> runCatching { hostingService.validatePublicAudioUrl(url) }.getOrNull() }
      ?.let { return it }

    val padded = String.format(Locale.US, "%03d", surahNumber)
    resolveCloudReciterBaseUrl?.invoke(cleanReciterId)
      ?.let { base ->
        val normalized = if (base.endsWith("/")) base else "$base/"
        runCatching { hostingService.validatePublicAudioUrl("$normalized$padded.mp3") }.getOrNull()
      }
      ?.let { return it }

    val isCatalogReciter = QuranCatalog.reciters.any { it.identifier == cleanReciterId }
    if (!isCatalogReciter) {
      throw IllegalStateException("لا يوجد رابط تلاوة مضاف لهذه السورة عند القارئ المختار.")
    }

    val serverBase = resolveReciterServerBase(cleanReciterId)
    return hostingService.validatePublicAudioUrl("$serverBase$padded.mp3")
  }

  private suspend fun resolveReciterServerBase(reciterId: String): String {
    dynamicServerCache[reciterId]?.let { return it }
    val reciter =
      QuranCatalog.reciters.firstOrNull { it.identifier == reciterId }
        ?: QuranCatalog.reciters.first()

    val fetchedBase =
      runCatching {
          val response = mp3QuranApi.getReciters("ar")
          val match =
            response.reciters.firstOrNull { dto ->
              reciter.mp3QuranSearchKeywords.any { kw -> dto.name.contains(kw) }
            }
          val moshaf =
            match?.moshaf?.maxByOrNull { it.surah_total }
              ?: match?.moshaf?.firstOrNull()
          moshaf?.server
            ?.let { if (it.endsWith("/")) it else "$it/" }
            ?.let { hostingService.validatePublicAudioUrl(it) }
        }
        .getOrNull()

    val resolved = fetchedBase ?: reciter.defaultSurahServerUrl
    dynamicServerCache[reciterId] = resolved
    return resolved
  }

  suspend fun downloadSurahAudio(
    reciterId: String,
    surahNumber: Int,
    directHttpsUrl: String? = null,
    onProgress: (Float) -> Unit,
  ): Result<File> =
    withContext(Dispatchers.IO) {
      try {
        val cleanReciterId = validateSafeReciterId(reciterId)
        require(surahNumber in 1..114) { "رقم السورة غير صالح" }
        val padded = String.format(Locale.US, "%03d", surahNumber)
        val localTrackUrl =
          dao.getLocalRecitation(cleanReciterId, surahNumber)
            ?.let { runCatching { hostingService.validatePublicAudioUrl(it.audioUrl) }.getOrNull() }
        val localBaseResolved =
          dao.getLocalReciterById(cleanReciterId)
            ?.fullSurahBaseUrl
            ?.takeIf { it.isNotBlank() }
            ?.let { runCatching { resolveUrlFromFullSurahSetting(it, surahNumber) }.getOrNull() }
        val isCatalogReciter = QuranCatalog.reciters.any { it.identifier == cleanReciterId }
        val rawUrl =
          localTrackUrl
            ?: localBaseResolved
            ?: resolveCloudHostedTrackUrl?.invoke(cleanReciterId, surahNumber)
              ?.let { runCatching { hostingService.validatePublicAudioUrl(it) }.getOrNull() }
            ?: directHttpsUrl
              ?.let { runCatching { hostingService.validatePublicAudioUrl(it) }.getOrNull() }
            ?: resolveCloudReciterBaseUrl?.invoke(cleanReciterId)
              ?.let { base ->
                val normalized = if (base.endsWith("/")) base else "$base/"
                runCatching { hostingService.validatePublicAudioUrl("$normalized$padded.mp3") }
                  .getOrNull()
              }
            ?: if (isCatalogReciter) {
              "${resolveReciterServerBase(cleanReciterId)}$padded.mp3"
            } else {
              throw IllegalStateException("لا يوجد رابط تلاوة مضاف لهذه السورة عند القارئ المختار.")
            }
        val url = hostingService.validatePublicAudioUrl(rawUrl)

        val dir = safeReciterAudioDir(cleanReciterId).apply { mkdirs() }
        val targetFile = File(dir, "$padded.mp3")
        val tempFile = File(dir, "$padded.mp3.tmp")

        val request = Request.Builder().url(url).build()
        okHttpClient.newCall(request).execute().use { response ->
          val finalUrl = response.request.url.toString()
          hostingService.validatePublicAudioUrl(finalUrl)
          if (!response.isSuccessful) {
            return@withContext Result.failure(
              IllegalStateException("فشل التحميل (${response.code})")
            )
          }
          val body =
            response.body ?: return@withContext Result.failure(IllegalStateException("ملف فارغ"))
          val totalBytes = body.contentLength()
          if (totalBytes > MAX_AUDIO_DOWNLOAD_BYTES) {
            return@withContext Result.failure(
              IllegalStateException("حجم الملف الصوتي يتجاوز الحد المسموح به.")
            )
          }

          body.byteStream().use { input ->
            tempFile.outputStream().use { output ->
              val buffer = ByteArray(8192)
              var downloaded = 0L
              while (true) {
                val read = input.read(buffer)
                if (read == -1) break
                downloaded += read
                if (downloaded > MAX_AUDIO_DOWNLOAD_BYTES) {
                  tempFile.delete()
                  return@withContext Result.failure(
                    IllegalStateException("تجاوز التحميل الحد الأقصى المسموح به للحجم.")
                  )
                }
                output.write(buffer, 0, read)
                if (totalBytes > 0) {
                  onProgress((downloaded.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f))
                }
              }
            }
          }
        }
        if (targetFile.exists()) targetFile.delete()
        if (!tempFile.renameTo(targetFile)) {
          tempFile.delete()
          return@withContext Result.failure(IllegalStateException("تعذر حفظ الملف الصوتي."))
        }

        dao.insertDownloadedAudio(
          DownloadedAudioEntity(
            reciterId = cleanReciterId,
            surahNumber = surahNumber,
            localFilePath = targetFile.absolutePath,
            sizeBytes = targetFile.length(),
          )
        )
        Result.success(targetFile)
      } catch (e: Exception) {
        Result.failure(e)
      }
    }

  suspend fun deleteDownloadedSurah(reciterId: String, surahNumber: Int) {
    val cleanReciterId = runCatching { validateSafeReciterId(reciterId) }.getOrNull() ?: return
    if (surahNumber !in 1..114) return
    val existing = dao.getDownloadedAudio(cleanReciterId, surahNumber)
    if (existing != null) {
      runCatching {
        val file = File(existing.localFilePath)
        val audioRoot = File(context.filesDir, "audio").canonicalPath
        if (file.canonicalPath.startsWith("$audioRoot${File.separator}")) {
          file.delete()
        }
      }
    }
    dao.deleteDownloadedAudio(cleanReciterId, surahNumber)
  }

  // Unified Smart Search
  suspend fun smartSearch(
    query: String,
    tafsirEdition: String,
    translationEdition: String,
  ): Result<List<SearchMatchItem>> {
    val trimmed = query.trim().take(100)
    if (trimmed.length < 2) return Result.success(emptyList())
    val safeTafsirEdition =
      tafsirEdition.trim().takeIf { it.matches(SAFE_ID_REGEX) } ?: "ar.muyassar"
    val safeTranslationEdition =
      translationEdition.trim().takeIf { it.matches(SAFE_ID_REGEX) } ?: "en.sahih"

    val results = mutableListOf<SearchMatchItem>()
    val normalizedQuery = DhikrSpeechMatcher.normalizeArabic(trimmed)

    // 1. Surahs (instant local, supports queries with or without Arabic tashkeel)
    QuranSeedData.surahs
      .filter {
        it.arabicName.contains(trimmed) ||
          (normalizedQuery.isNotEmpty() &&
            DhikrSpeechMatcher.normalizeArabic(it.arabicName).contains(normalizedQuery)) ||
          it.englishName.contains(trimmed, ignoreCase = true) ||
          it.number.toString() == trimmed
      }
      .take(10)
      .forEach { surah ->
        results.add(
          SearchMatchItem(
            globalNumber = surah.number,
            numberInSurah = 1,
            surahNumber = surah.number,
            surahEnglishName = surah.englishName,
            surahArabicName = surah.arabicName,
            text = "${surah.arabicName} — ${surah.numberOfAyahs} آية (${if (surah.revelationType == "Meccan") "مكية" else "مدنية"})",
            matchType = SearchResultType.SURAH,
          )
        )
      }

    // 2. Adhkar (instant local, supports queries with or without Arabic tashkeel)
    AdhkarSeedData.allAdhkar
      .filter {
        it.textWithTashkeel.contains(trimmed) ||
          it.category.titleArabic.contains(trimmed) ||
          (normalizedQuery.isNotEmpty() &&
            (DhikrSpeechMatcher.normalizeArabic(it.textWithTashkeel).contains(normalizedQuery) ||
              DhikrSpeechMatcher.normalizeArabic(it.category.titleArabic).contains(normalizedQuery)))
      }
      .take(10)
      .forEachIndexed { idx, dhikr ->
        results.add(
          SearchMatchItem(
            globalNumber = 90000 + idx,
            numberInSurah = 1,
            surahNumber = 0,
            surahEnglishName = dhikr.category.id,
            surahArabicName = dhikr.category.titleArabic,
            text = dhikr.textWithTashkeel,
            matchType = SearchResultType.ADHKAR,
          )
        )
      }

    // 3. Cached Tafsir (instant local)
    dao.searchTafsir(trimmed, safeTafsirEdition).take(15).forEach { tafsir ->
      results.add(
        SearchMatchItem(
          globalNumber = tafsir.globalNumber,
          numberInSurah = tafsir.numberInSurah,
          surahNumber = tafsir.surahNumber,
          surahEnglishName = tafsir.surahArabicName,
          surahArabicName = tafsir.surahArabicName,
          text = tafsir.tafsirText,
          matchType = SearchResultType.TAFSIR,
        )
      )
    }

    // 4. Quran Ayah search (API first with Arabic clean edition, fallback to local Room cache)
    val isArabicQuery = trimmed.any { it in '\u0600'..'\u06FF' }
    val searchEdition = if (isArabicQuery) "quran-simple-clean" else safeTranslationEdition
    var networkError: Exception? = null
    try {
      val encoded = URLEncoder.encode(trimmed, "UTF-8").replace("+", "%20")
      val response = api.searchQuran(encoded, searchEdition)
      response.data.matches.take(40).forEach { m ->
        results.add(
          SearchMatchItem(
            globalNumber = m.number,
            numberInSurah = m.numberInSurah,
            surahNumber = m.surah.number,
            surahEnglishName = m.surah.englishName,
            surahArabicName = m.surah.name,
            text = m.text,
            matchType = SearchResultType.AYAH,
          )
        )
      }
    } catch (e: Exception) {
      networkError = e
      val surahMap = QuranSeedData.surahs.associateBy { it.number }
      dao.searchCachedAyahs(trimmed, safeTranslationEdition).take(25).forEach { ayah ->
        val surah = surahMap[ayah.surahNumber]
        results.add(
          SearchMatchItem(
            globalNumber = ayah.globalNumber,
            numberInSurah = ayah.numberInSurah,
            surahNumber = ayah.surahNumber,
            surahEnglishName = surah?.englishName ?: "",
            surahArabicName = surah?.arabicName ?: "سورة ${ayah.surahNumber}",
            text = if (isArabicQuery) ayah.arabicText else ayah.translationText,
            matchType = SearchResultType.AYAH,
          )
        )
      }
    }

    return if (results.isNotEmpty() || networkError == null) {
      Result.success(results)
    } else {
      Result.failure(networkError)
    }
  }

  companion object {
    val SAFE_ID_REGEX = Regex("^[a-zA-Z0-9_\\-\\.]{1,128}$")
    val VOICE_DHIKR_IDS =
      setOf("tasbih", "hamd", "takbir", "tahlil", "istighfar", "salawat", "hawqala")
    val AUDIO_FILE_EXTENSIONS = listOf(".mp3", ".m4a", ".aac", ".ogg", ".wav", ".opus")
    const val MAX_AUDIO_DOWNLOAD_BYTES = 250L * 1024L * 1024L
    const val MAX_RECITER_PHOTO_BYTES = 8L * 1024L * 1024L
  }
}

private fun LocalReciterEntity.toDomain() =
  LocalReciter(
    id = id,
    arabicName = arabicName,
    description = description,
    riwayah = riwayah,
    photoPathOrUrl = photoPathOrUrl,
    fullSurahBaseUrl = fullSurahBaseUrl,
    createdAt = createdAt,
    updatedAt = updatedAt,
  )

private fun LocalRecitationEntity.toDomain() =
  LocalRecitationTrack(
    reciterId = reciterId,
    surahNumber = surahNumber,
    surahArabicName = surahArabicName,
    audioUrl = audioUrl,
    notes = notes,
    updatedAt = updatedAt,
  )

private fun SurahEntity.toDomain() =
  SurahInfo(
    number = number,
    arabicName = arabicName,
    englishName = englishName,
    englishNameTranslation = englishNameTranslation,
    numberOfAyahs = numberOfAyahs,
    revelationType = revelationType,
  )

private fun AyahEntity.toDomain(surahArabicName: String) =
  AyahItem(
    globalNumber = globalNumber,
    numberInSurah = numberInSurah,
    surahNumber = surahNumber,
    arabicText = arabicText,
    translationText = translationText,
    juz = juz,
    page = page,
    sajda = sajda,
    surahArabicName = surahArabicName,
  )

private fun BookmarkEntity.toDomain() =
  BookmarkItem(
    surahNumber = surahNumber,
    surahEnglishName = surahEnglishName,
    surahArabicName = surahArabicName,
    ayahNumberInSurah = ayahNumberInSurah,
    globalAyahNumber = globalAyahNumber,
    arabicText = arabicText,
    translationText = translationText,
    category = category,
    note = note,
    createdAt = createdAt,
  )

private fun KhatmahPlanEntity.toDomain() =
  KhatmahPlan(
    id = id,
    title = title,
    startDateEpochDay = startDateEpochDay,
    endDateEpochDay = endDateEpochDay,
    totalPages = totalPages,
    pagesRead = pagesRead,
    isPaused = isPaused,
    createdAt = createdAt,
  )

private fun DhikrDailyLogEntity.toDomain() =
  DhikrDailyLog(
    epochDay = epochDay,
    dhikrId = dhikrId,
    label = label,
    sourceType =
      if (sourceType == DhikrSourceType.ADHKAR.id) DhikrSourceType.ADHKAR
      else DhikrSourceType.VOICE,
    count = count,
    lastUpdated = lastUpdated,
  )
