package com.example.data.remote

import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

@JsonClass(generateAdapter = true)
data class Mp3QuranRecitersResponseDto(
  val reciters: List<Mp3QuranReciterDto>,
)

@JsonClass(generateAdapter = true)
data class Mp3QuranReciterDto(
  val id: Int,
  val name: String,
  val moshaf: List<Mp3QuranMoshafDto>,
)

@JsonClass(generateAdapter = true)
data class Mp3QuranMoshafDto(
  val id: Int,
  val name: String,
  val server: String,
  val surah_total: Int,
  val surah_list: String,
)

interface Mp3QuranApiService {
  @GET("api/v3/reciters")
  suspend fun getReciters(
    @Query("language") language: String = "ar",
  ): Mp3QuranRecitersResponseDto

  companion object {
    private const val BASE_URL = "https://mp3quran.net/"

    fun create(client: OkHttpClient): Mp3QuranApiService {
      val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
      return Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(client)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(Mp3QuranApiService::class.java)
    }
  }
}
