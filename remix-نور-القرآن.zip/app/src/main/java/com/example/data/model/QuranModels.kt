package com.example.data.model

enum class ReaderThemeMode(val label: String) {
  SYSTEM("تلقائي"),
  PARCHMENT("نهاري دافئ"),
  SEPIA("ورقي"),
  MIDNIGHT("داكن"),
}

data class SurahInfo(
  val number: Int,
  val arabicName: String,
  val englishName: String,
  val englishNameTranslation: String,
  val numberOfAyahs: Int,
  val revelationType: String,
) {
  val revelationArabic: String
    get() = if (revelationType.equals("Meccan", ignoreCase = true)) "مكية" else "مدنية"
}

data class AyahItem(
  val globalNumber: Int,
  val numberInSurah: Int,
  val surahNumber: Int,
  val arabicText: String,
  val translationText: String,
  val juz: Int,
  val page: Int,
  val sajda: Boolean = false,
  val surahArabicName: String = "",
)

data class BookmarkItem(
  val surahNumber: Int,
  val surahEnglishName: String,
  val surahArabicName: String,
  val ayahNumberInSurah: Int,
  val globalAyahNumber: Int,
  val arabicText: String,
  val translationText: String,
  val category: String = "عام",
  val note: String = "",
  val createdAt: Long = System.currentTimeMillis(),
)

data class ReadingProgress(
  val surahNumber: Int = 1,
  val surahEnglishName: String = "Al-Faatiha",
  val surahArabicName: String = "سُورَةُ ٱلْفَاتِحَةِ",
  val ayahNumberInSurah: Int = 1,
  val page: Int = 1,
  val totalAyahs: Int = 7,
)

data class SearchMatchItem(
  val globalNumber: Int,
  val numberInSurah: Int,
  val surahNumber: Int,
  val surahEnglishName: String,
  val surahArabicName: String,
  val text: String,
  val matchType: SearchResultType = SearchResultType.AYAH,
)

enum class SearchResultType(val label: String) {
  SURAH("سورة"),
  AYAH("آية"),
  TAFSIR("تفسير"),
  ADHKAR("ذكر"),
}

data class TranslationEdition(
  val identifier: String,
  val name: String,
  val scholar: String,
)

data class TafsirEdition(
  val identifier: String,
  val arabicName: String,
  val sourceAttribution: String,
)

data class TafsirAyahItem(
  val surahNumber: Int,
  val surahArabicName: String,
  val ayahNumberInSurah: Int,
  val globalNumber: Int,
  val quranArabicText: String,
  val tafsirText: String,
  val editionId: String,
  val editionName: String,
  val sourceAttribution: String,
)

data class ReciterOption(
  val identifier: String,
  val arabicName: String,
  val styleArabic: String,
  val islamicNetworkId: String?,
  val everyAyahFolder: String?,
  val mp3QuranSearchKeywords: List<String>,
  val defaultSurahServerUrl: String,
  val photoUrl: String = "",
  val bioArabic: String = "",
  val riwayah: String = "",
  val sortOrder: Int = Int.MAX_VALUE,
  val isCloudSynced: Boolean = false,
  val isLocalCustom: Boolean = false,
)

data class LocalReciter(
  val id: String,
  val arabicName: String,
  val description: String = "",
  val riwayah: String = "حفص عن عاصم",
  val photoPathOrUrl: String = "",
  val fullSurahBaseUrl: String = "",
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis(),
)

data class LocalRecitationTrack(
  val reciterId: String,
  val surahNumber: Int,
  val surahArabicName: String,
  val audioUrl: String,
  val notes: String = "",
  val updatedAt: Long = System.currentTimeMillis(),
)

data class ReaderSettings(
  val arabicFontSize: Float = 28f,
  val tafsirFontSize: Float = 18f,
  val adhkarFontSize: Float = 20f,
  val translationFontSize: Float = 15f,
  val showTranslation: Boolean = false,
  val translationEdition: String = "en.sahih",
  val tafsirEdition: String = "ar.muyassar",
  val reciterIdentifier: String = "ar.alafasy",
  val themeMode: ReaderThemeMode = ReaderThemeMode.PARCHMENT,
  val volumeLevel: Float = 1.0f,
  val dailyPageHour: Int = 9,
  val dailyPageMinute: Int = 0,
  val dailyPageNumber: Int = 1,
  val dailyPageNotificationsEnabled: Boolean = true,
  val voiceDhikrAllowPartialMatch: Boolean = true,
)

enum class ReminderType(
  val id: String,
  val titleArabic: String,
  val bodyArabic: String,
  val defaultHour: Int,
  val defaultMinute: Int,
) {
  QURAN_READING(
    id = "quran_reading",
    titleArabic = "تذكير بقراءة القرآن",
    bodyArabic = "نور يومك بتلاوة آيات من كتاب الله الكريم",
    defaultHour = 20,
    defaultMinute = 0,
  ),
  DAILY_WIRD(
    id = "daily_wird",
    titleArabic = "تذكير بالورد اليومي",
    bodyArabic = "لا تنسَ قراءة وردك اليومي من القرآن الكريم",
    defaultHour = 13,
    defaultMinute = 0,
  ),
  MORNING_ADHKAR(
    id = "morning_adhkar",
    titleArabic = "تذكير بأذكار الصباح",
    bodyArabic = "أصبحنا وأصبح الملك لله — حصّن يومك بأذكار الصباح",
    defaultHour = 6,
    defaultMinute = 0,
  ),
  EVENING_ADHKAR(
    id = "evening_adhkar",
    titleArabic = "تذكير بأذكار المساء",
    bodyArabic = "أمسينا وأمسى الملك لله — طمئن قلبك بأذكار المساء",
    defaultHour = 17,
    defaultMinute = 30,
  ),
  KHATMAH_COMPLETION(
    id = "khatmah_completion",
    titleArabic = "تذكير بإكمال الختمة",
    bodyArabic = "تفقّد تقدمك في ختمة القرآن الكريم وأتمم صفحات اليوم",
    defaultHour = 21,
    defaultMinute = 0,
  ),
  SALAWAT(
    id = "salawat",
    titleArabic = "تذكير بالصلاة على النبي ﷺ",
    bodyArabic = "اللهم صلِّ وسلِّم على نبينا محمد ﷺ",
    defaultHour = 11,
    defaultMinute = 0,
  ),
  DAILY_PAGE(
    id = "daily_page",
    titleArabic = "صفحة القرآن اليومية",
    bodyArabic = "صفحتك اليومية من المصحف الشريف جاهزة للقراءة والمشاركة",
    defaultHour = 9,
    defaultMinute = 0,
  ),
}

data class ReminderPreference(
  val type: ReminderType,
  val enabled: Boolean,
  val hour: Int,
  val minute: Int,
)

data class DhikrPhraseItem(
  val id: String,
  val arabicTitle: String,
  val subtitle: String,
  val count: Int,
  val lastUpdated: Long = 0L,
)

enum class DhikrSourceType(val id: String, val labelArabic: String) {
  VOICE("voice", "الذكر الصوتي"),
  ADHKAR("adhkar", "الأذكار اليومية"),
}

data class DhikrDailyLog(
  val epochDay: Long,
  val dhikrId: String,
  val label: String,
  val sourceType: DhikrSourceType,
  val count: Int,
  val lastUpdated: Long,
)

enum class AdhkarCategory(val id: String, val titleArabic: String, val subtitle: String) {
  MORNING("morning", "أذكار الصباح", "من الفجر إلى الضحى"),
  EVENING("evening", "أذكار المساء", "من العصر إلى المغرب"),
  SLEEP("sleep", "أذكار النوم", "تحصين المسلم قبل النوم"),
  WAKE_UP("wakeup", "أذكار الاستيقاظ", "شكر الله عند بداية اليوم"),
  AFTER_PRAYER("after_prayer", "أذكار بعد الصلاة", "الأذكار المسنونة بعد السلام"),
  TASBIH("tasbih", "التسبيح والاستغفار", "جوامع الذكر والاستغفار"),
  SALAWAT("salawat", "الصلاة على النبي ﷺ", "صيغ الصلاة والسلام المباركة"),
}

data class AdhkarItem(
  val id: String,
  val category: AdhkarCategory,
  val textWithTashkeel: String,
  val virtue: String,
  val targetCount: Int,
  val currentCount: Int = 0,
)

data class KhatmahPlan(
  val id: Long = 0L,
  val title: String,
  val startDateEpochDay: Long,
  val endDateEpochDay: Long,
  val totalPages: Int = 604,
  val pagesRead: Int = 0,
  val isPaused: Boolean = false,
  val createdAt: Long = System.currentTimeMillis(),
)

data class DailyReflection(
  val surahNumber: Int,
  val surahName: String,
  val ayahNumber: Int,
  val arabicText: String,
  val translationText: String,
  val themeTag: String,
)

data class SocialAccount(
  val platformName: String,
  val handle: String,
  val url: String,
  val packageName: String,
)

object QuranCatalog {
  val bookmarkCategories = listOf("عام", "تدبر", "حفظ", "دعاء")

  val socialAccounts =
    listOf(
      SocialAccount(
        platformName = "سناب شات",
        handle = "@buaskerrr",
        url = "https://www.snapchat.com/add/buaskerrr",
        packageName = "com.snapchat.android",
      ),
      SocialAccount(
        platformName = "إنستغرام",
        handle = "@bu_askerrr",
        url = "https://www.instagram.com/bu_askerrr/",
        packageName = "com.instagram.android",
      ),
      SocialAccount(
        platformName = "تيك توك",
        handle = "@bu_askerrr",
        url = "https://www.tiktok.com/@bu_askerrr",
        packageName = "com.zhiliaoapp.musically",
      ),
    )

  val translationEditions =
    listOf(
      TranslationEdition("en.sahih", "صحيح إنترناشونال (English)", "ترجمة إنجليزية معاصرة واضحة"),
      TranslationEdition("en.asad", "محمد أسد (English)", "رسالة القرآن الكريم"),
      TranslationEdition("en.yusufali", "عبدالله يوسف علي (English)", "ترجمة أدبية كلاسيكية"),
      TranslationEdition("en.pickthall", "مارمادوك بيكثال (English)", "ترجمة تقليدية معتمدة"),
    )

  val tafsirEditions =
    listOf(
      TafsirEdition(
        identifier = "ar.muyassar",
        arabicName = "التفسير الميسّر",
        sourceAttribution = "نخبة من العلماء — مجمع الملك فهد لطباعة المصحف الشريف",
      ),
      TafsirEdition(
        identifier = "ar.jalalayn",
        arabicName = "تفسير الجلالين",
        sourceAttribution = "الإمامان جلال الدين المحلي وجلال الدين السيوطي",
      ),
    )

  val reciters =
    listOf(
      ReciterOption(
        identifier = "khalid_jaleel",
        arabicName = "خالد الجليل",
        styleArabic = "حفص عن عاصم • تلاوة خاشعة",
        islamicNetworkId = null,
        everyAyahFolder = null,
        mp3QuranSearchKeywords = listOf("خالد الجليل", "الجليل"),
        defaultSurahServerUrl = "https://server10.mp3quran.net/jleel/",
      ),
      ReciterOption(
        identifier = "ar.mahermuaiqly",
        arabicName = "ماهر المعيقلي",
        styleArabic = "حفص عن عاصم • إمام المسجد الحرام",
        islamicNetworkId = "ar.mahermuaiqly",
        everyAyahFolder = "MaherAlMuaiqly128kbps",
        mp3QuranSearchKeywords = listOf("ماهر المعيقلي", "المعيقلي"),
        defaultSurahServerUrl = "https://server12.mp3quran.net/maher/",
      ),
      ReciterOption(
        identifier = "ar.abdurrahmaansudais",
        arabicName = "عبدالرحمن السديس",
        styleArabic = "حفص عن عاصم • المسجد الحرام",
        islamicNetworkId = "ar.abdurrahmaansudais",
        everyAyahFolder = "Abdurrahmaan_As-Sudais_192kbps",
        mp3QuranSearchKeywords = listOf("عبدالرحمن السديس", "السديس"),
        defaultSurahServerUrl = "https://server11.mp3quran.net/sds/",
      ),
      ReciterOption(
        identifier = "ali_jaber",
        arabicName = "علي جابر",
        styleArabic = "حفص عن عاصم • تلاوة حجازية",
        islamicNetworkId = null,
        everyAyahFolder = "Ali_Jaber_64kbps",
        mp3QuranSearchKeywords = listOf("علي جابر"),
        defaultSurahServerUrl = "https://server11.mp3quran.net/a_jbr/",
      ),
      ReciterOption(
        identifier = "ar.alafasy",
        arabicName = "مشاري العفاسي",
        styleArabic = "حفص عن عاصم • الكويت",
        islamicNetworkId = "ar.alafasy",
        everyAyahFolder = "Alafasy_128kbps",
        mp3QuranSearchKeywords = listOf("مشاري العفاسي", "العفاسي"),
        defaultSurahServerUrl = "https://server8.mp3quran.net/afs/",
      ),
      ReciterOption(
        identifier = "ar.abdulbasitmurattal",
        arabicName = "عبدالباسط عبدالصمد",
        styleArabic = "مرتل • مصر",
        islamicNetworkId = "ar.abdulbasitmurattal",
        everyAyahFolder = "Abdul_Basit_Murattal_192kbps",
        mp3QuranSearchKeywords = listOf("عبدالباسط عبدالصمد"),
        defaultSurahServerUrl = "https://server7.mp3quran.net/basit/",
      ),
      ReciterOption(
        identifier = "ar.husary",
        arabicName = "محمود خليل الحصري",
        styleArabic = "مرتل بالتجويد • مصر",
        islamicNetworkId = "ar.husary",
        everyAyahFolder = "Husary_128kbps",
        mp3QuranSearchKeywords = listOf("محمود خليل الحصري", "الحصري"),
        defaultSurahServerUrl = "https://server13.mp3quran.net/husr/",
      ),
      ReciterOption(
        identifier = "ar.minshawi",
        arabicName = "محمد صديق المنشاوي",
        styleArabic = "مرتل • مصر",
        islamicNetworkId = "ar.minshawi",
        everyAyahFolder = "Minshawy_Murattal_128kbps",
        mp3QuranSearchKeywords = listOf("محمد صديق المنشاوي", "المنشاوي"),
        defaultSurahServerUrl = "https://server10.mp3quran.net/minsh/",
      ),
    )

  val juzStartSurahs =
    listOf(
      1 to Pair(1, 1),
      2 to Pair(2, 142),
      3 to Pair(2, 253),
      4 to Pair(3, 93),
      5 to Pair(4, 24),
      6 to Pair(4, 148),
      7 to Pair(5, 82),
      8 to Pair(6, 111),
      9 to Pair(7, 88),
      10 to Pair(8, 41),
      11 to Pair(9, 93),
      12 to Pair(11, 6),
      13 to Pair(12, 53),
      14 to Pair(15, 1),
      15 to Pair(17, 1),
      16 to Pair(18, 75),
      17 to Pair(21, 1),
      18 to Pair(23, 1),
      19 to Pair(25, 21),
      20 to Pair(27, 56),
      21 to Pair(29, 46),
      22 to Pair(33, 31),
      23 to Pair(36, 28),
      24 to Pair(39, 32),
      25 to Pair(41, 47),
      26 to Pair(46, 1),
      27 to Pair(51, 31),
      28 to Pair(58, 1),
      29 to Pair(67, 1),
      30 to Pair(78, 1),
    )

  val reflections =
    listOf(
      DailyReflection(
        surahNumber = 94,
        surahName = "سورة الشرح",
        ayahNumber = 6,
        arabicText = "إِنَّ مَعَ الْعُسْرِ يُسْرًا",
        translationText = "فإن مع الضيق والشدة فرجاً ويسراً قريباً.",
        themeTag = "الأمل واليقين",
      ),
      DailyReflection(
        surahNumber = 2,
        surahName = "سورة البقرة",
        ayahNumber = 286,
        arabicText = "لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا",
        translationText = "لا يفرض الله على نفس ما لا تطيقه بل يرحمها ويلطف بها.",
        themeTag = "الرحمة والسعة",
      ),
      DailyReflection(
        surahNumber = 13,
        surahName = "سورة الرعد",
        ayahNumber = 28,
        arabicText = "أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ",
        translationText = "بذكر الله وتلاوة كتابه تسكن القلوب وتجد أنسها.",
        themeTag = "الطمأنينة",
      ),
      DailyReflection(
        surahNumber = 24,
        surahName = "سورة النور",
        ayahNumber = 35,
        arabicText = "اللَّهُ نُورُ السَّمَاوَاتِ وَالْأَرْضِ",
        translationText = "نور الله يهدي القلوب الحائرة ويضيء دروب المؤمنين.",
        themeTag = "الهداية والنور",
      ),
      DailyReflection(
        surahNumber = 55,
        surahName = "سورة الرحمن",
        ayahNumber = 13,
        arabicText = "فَبِأَيِّ آلَاءِ رَبِّكُمَا تُكَذِّبَانِ",
        translationText = "تذكير متجدد بنعم الله الظاهرة والباطنة التي تستوجب الشكر.",
        themeTag = "الشكر والامتنان",
      ),
    )
}
