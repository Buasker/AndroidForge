package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
  entities =
    [
      SurahEntity::class,
      AyahEntity::class,
      TafsirEntity::class,
      BookmarkEntity::class,
      DhikrCounterEntity::class,
      AdhkarProgressEntity::class,
      DhikrDailyLogEntity::class,
      KhatmahPlanEntity::class,
      DownloadedAudioEntity::class,
      LocalReciterEntity::class,
      LocalRecitationEntity::class,
    ],
  version = 4,
  exportSchema = false,
)
abstract class NoorQuranDatabase : RoomDatabase() {
  abstract fun quranDao(): QuranDao

  companion object {
    @Volatile private var INSTANCE: NoorQuranDatabase? = null

    val MIGRATION_2_3 =
      object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `dhikr_daily_logs` (
              `epochDay` INTEGER NOT NULL,
              `dhikrId` TEXT NOT NULL,
              `label` TEXT NOT NULL,
              `sourceType` TEXT NOT NULL,
              `count` INTEGER NOT NULL,
              `lastUpdated` INTEGER NOT NULL,
              PRIMARY KEY(`epochDay`, `dhikrId`)
            )
            """.trimIndent()
          )
        }
      }

    val MIGRATION_3_4 =
      object : Migration(3, 4) {
        override fun migrate(db: SupportSQLiteDatabase) {
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `local_reciters` (
              `id` TEXT NOT NULL,
              `arabicName` TEXT NOT NULL,
              `normalizedName` TEXT NOT NULL,
              `description` TEXT NOT NULL,
              `riwayah` TEXT NOT NULL,
              `photoPathOrUrl` TEXT NOT NULL,
              `fullSurahBaseUrl` TEXT NOT NULL,
              `createdAt` INTEGER NOT NULL,
              `updatedAt` INTEGER NOT NULL,
              PRIMARY KEY(`id`)
            )
            """.trimIndent()
          )
          db.execSQL(
            "CREATE INDEX IF NOT EXISTS `index_local_reciters_normalizedName` ON `local_reciters` (`normalizedName`)"
          )
          db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `local_recitations` (
              `reciterId` TEXT NOT NULL,
              `surahNumber` INTEGER NOT NULL,
              `surahArabicName` TEXT NOT NULL,
              `audioUrl` TEXT NOT NULL,
              `notes` TEXT NOT NULL,
              `updatedAt` INTEGER NOT NULL,
              PRIMARY KEY(`reciterId`, `surahNumber`),
              FOREIGN KEY(`reciterId`) REFERENCES `local_reciters`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE
            )
            """.trimIndent()
          )
        }
      }

    fun getInstance(context: Context): NoorQuranDatabase {
      return INSTANCE
        ?: synchronized(this) {
          val instance =
            Room.databaseBuilder(
                context.applicationContext,
                NoorQuranDatabase::class.java,
                "noor_quran.db",
              )
              .addMigrations(MIGRATION_2_3, MIGRATION_3_4)
              .fallbackToDestructiveMigration(dropAllTables = true)
              .build()
          INSTANCE = instance
          instance
        }
    }
  }
}
