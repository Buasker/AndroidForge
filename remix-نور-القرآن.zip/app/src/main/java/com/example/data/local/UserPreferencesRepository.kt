package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.ReaderSettings
import com.example.data.model.ReaderThemeMode
import com.example.data.model.ReadingProgress
import com.example.data.model.ReminderPreference
import com.example.data.model.ReminderType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.noorDataStore: DataStore<Preferences> by preferencesDataStore(name = "noor_prefs")

class UserPreferencesRepository(private val context: Context) {
  private object Keys {
    val ARABIC_FONT_SIZE = floatPreferencesKey("arabic_font_size")
    val TAFSIR_FONT_SIZE = floatPreferencesKey("tafsir_font_size")
    val ADHKAR_FONT_SIZE = floatPreferencesKey("adhkar_font_size")
    val TRANSLATION_FONT_SIZE = floatPreferencesKey("translation_font_size")
    val SHOW_TRANSLATION = booleanPreferencesKey("show_translation")
    val TRANSLATION_EDITION = stringPreferencesKey("translation_edition")
    val TAFSIR_EDITION = stringPreferencesKey("tafsir_edition")
    val RECITER_ID = stringPreferencesKey("reciter_id")
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val VOLUME_LEVEL = floatPreferencesKey("volume_level")
    val DAILY_PAGE_HOUR = intPreferencesKey("daily_page_hour")
    val DAILY_PAGE_MINUTE = intPreferencesKey("daily_page_minute")
    val DAILY_PAGE_NUMBER = intPreferencesKey("daily_page_number")
    val DAILY_PAGE_NOTIF = booleanPreferencesKey("daily_page_notif")
    val VOICE_PARTIAL_MATCH = booleanPreferencesKey("voice_partial_match")

    val LAST_SURAH = intPreferencesKey("last_surah")
    val LAST_SURAH_NAME = stringPreferencesKey("last_surah_name")
    val LAST_SURAH_ARABIC = stringPreferencesKey("last_surah_arabic")
    val LAST_AYAH = intPreferencesKey("last_ayah")
    val LAST_PAGE = intPreferencesKey("last_page")
    val LAST_TOTAL_AYAHS = intPreferencesKey("last_total_ayahs")
  }

  val readerSettingsFlow: Flow<ReaderSettings> =
    context.noorDataStore.data.map { prefs ->
      val themeName = prefs[Keys.THEME_MODE] ?: ReaderThemeMode.PARCHMENT.name
      val themeMode =
        runCatching { ReaderThemeMode.valueOf(themeName) }.getOrDefault(ReaderThemeMode.PARCHMENT)
      ReaderSettings(
        arabicFontSize = prefs[Keys.ARABIC_FONT_SIZE] ?: 28f,
        tafsirFontSize = prefs[Keys.TAFSIR_FONT_SIZE] ?: 18f,
        adhkarFontSize = prefs[Keys.ADHKAR_FONT_SIZE] ?: 20f,
        translationFontSize = prefs[Keys.TRANSLATION_FONT_SIZE] ?: 15f,
        showTranslation = prefs[Keys.SHOW_TRANSLATION] ?: false,
        translationEdition = prefs[Keys.TRANSLATION_EDITION] ?: "en.sahih",
        tafsirEdition = prefs[Keys.TAFSIR_EDITION] ?: "ar.muyassar",
        reciterIdentifier = prefs[Keys.RECITER_ID] ?: "ar.alafasy",
        themeMode = themeMode,
        volumeLevel = prefs[Keys.VOLUME_LEVEL] ?: 1.0f,
        dailyPageHour = prefs[Keys.DAILY_PAGE_HOUR] ?: 9,
        dailyPageMinute = prefs[Keys.DAILY_PAGE_MINUTE] ?: 0,
        dailyPageNumber = prefs[Keys.DAILY_PAGE_NUMBER] ?: 1,
        dailyPageNotificationsEnabled = prefs[Keys.DAILY_PAGE_NOTIF] ?: true,
        voiceDhikrAllowPartialMatch = prefs[Keys.VOICE_PARTIAL_MATCH] ?: true,
      )
    }

  val readingProgressFlow: Flow<ReadingProgress> =
    context.noorDataStore.data.map { prefs ->
      ReadingProgress(
        surahNumber = prefs[Keys.LAST_SURAH] ?: 1,
        surahEnglishName = prefs[Keys.LAST_SURAH_NAME] ?: "Al-Faatiha",
        surahArabicName = prefs[Keys.LAST_SURAH_ARABIC] ?: "سُورَةُ ٱلْفَاتِحَةِ",
        ayahNumberInSurah = prefs[Keys.LAST_AYAH] ?: 1,
        page = prefs[Keys.LAST_PAGE] ?: 1,
        totalAyahs = prefs[Keys.LAST_TOTAL_AYAHS] ?: 7,
      )
    }

  val remindersFlow: Flow<List<ReminderPreference>> =
    context.noorDataStore.data.map { prefs ->
      ReminderType.entries.map { type ->
        val enabledKey = booleanPreferencesKey("rem_enabled_${type.id}")
        val hourKey = intPreferencesKey("rem_hour_${type.id}")
        val minuteKey = intPreferencesKey("rem_min_${type.id}")
        ReminderPreference(
          type = type,
          enabled = prefs[enabledKey] ?: false,
          hour = prefs[hourKey] ?: type.defaultHour,
          minute = prefs[minuteKey] ?: type.defaultMinute,
        )
      }
    }

  suspend fun updateArabicFontSize(size: Float) {
    context.noorDataStore.edit { it[Keys.ARABIC_FONT_SIZE] = size.coerceIn(18f, 52f) }
  }

  suspend fun updateTafsirFontSize(size: Float) {
    context.noorDataStore.edit { it[Keys.TAFSIR_FONT_SIZE] = size.coerceIn(14f, 32f) }
  }

  suspend fun updateAdhkarFontSize(size: Float) {
    context.noorDataStore.edit { it[Keys.ADHKAR_FONT_SIZE] = size.coerceIn(15f, 34f) }
  }

  suspend fun updateTranslationFontSize(size: Float) {
    context.noorDataStore.edit { it[Keys.TRANSLATION_FONT_SIZE] = size.coerceIn(12f, 24f) }
  }

  suspend fun updateShowTranslation(show: Boolean) {
    context.noorDataStore.edit { it[Keys.SHOW_TRANSLATION] = show }
  }

  suspend fun updateTranslationEdition(edition: String) {
    val clean = edition.trim()
    if (!clean.matches(SAFE_ID_REGEX)) return
    context.noorDataStore.edit { it[Keys.TRANSLATION_EDITION] = clean }
  }

  suspend fun updateTafsirEdition(edition: String) {
    val clean = edition.trim()
    if (!clean.matches(SAFE_ID_REGEX)) return
    context.noorDataStore.edit { it[Keys.TAFSIR_EDITION] = clean }
  }

  suspend fun updateReciter(reciterId: String) {
    val clean = reciterId.trim()
    if (!clean.matches(SAFE_ID_REGEX)) return
    context.noorDataStore.edit { it[Keys.RECITER_ID] = clean }
  }

  suspend fun updateThemeMode(mode: ReaderThemeMode) {
    context.noorDataStore.edit { it[Keys.THEME_MODE] = mode.name }
  }

  suspend fun updateVolumeLevel(volume: Float) {
    context.noorDataStore.edit { it[Keys.VOLUME_LEVEL] = volume.coerceIn(0f, 1f) }
  }

  suspend fun updateDailyPageSchedule(hour: Int, minute: Int, enabled: Boolean) {
    context.noorDataStore.edit { prefs ->
      prefs[Keys.DAILY_PAGE_HOUR] = hour.coerceIn(0, 23)
      prefs[Keys.DAILY_PAGE_MINUTE] = minute.coerceIn(0, 59)
      prefs[Keys.DAILY_PAGE_NOTIF] = enabled
    }
  }

  suspend fun updateDailyPageNumber(page: Int) {
    context.noorDataStore.edit { it[Keys.DAILY_PAGE_NUMBER] = page.coerceIn(1, 604) }
  }

  suspend fun updateVoicePartialMatch(allow: Boolean) {
    context.noorDataStore.edit { it[Keys.VOICE_PARTIAL_MATCH] = allow }
  }

  suspend fun updateReminder(type: ReminderType, enabled: Boolean, hour: Int, minute: Int) {
    context.noorDataStore.edit { prefs ->
      prefs[booleanPreferencesKey("rem_enabled_${type.id}")] = enabled
      prefs[intPreferencesKey("rem_hour_${type.id}")] = hour.coerceIn(0, 23)
      prefs[intPreferencesKey("rem_min_${type.id}")] = minute.coerceIn(0, 59)
    }
  }

  suspend fun saveReadingProgress(progress: ReadingProgress) {
    context.noorDataStore.edit { prefs ->
      prefs[Keys.LAST_SURAH] = progress.surahNumber.coerceIn(1, 114)
      prefs[Keys.LAST_SURAH_NAME] = progress.surahEnglishName.trim().take(120)
      prefs[Keys.LAST_SURAH_ARABIC] = progress.surahArabicName.trim().take(120)
      prefs[Keys.LAST_AYAH] = progress.ayahNumberInSurah.coerceAtLeast(1)
      prefs[Keys.LAST_PAGE] = progress.page.coerceIn(1, 604)
      prefs[Keys.LAST_TOTAL_AYAHS] = progress.totalAyahs.coerceIn(1, 286)
    }
  }

  companion object {
    private val SAFE_ID_REGEX = Regex("^[a-zA-Z0-9_\\-\\.]{1,128}$")
  }
}
