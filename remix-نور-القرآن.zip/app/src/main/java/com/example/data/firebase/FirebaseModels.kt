package com.example.data.firebase

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class FirebaseAdminRecord(
  @DocumentId val id: String = "",
  val uid: String = "",
  val email: String = "",
  val role: String = "super_admin",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
)

@Keep
@IgnoreExtraProperties
data class FirebaseReciter(
  @DocumentId val id: String = "",
  val arabicName: String = "",
  val styleArabic: String = "",
  val riwayah: String = "",
  val bioArabic: String = "",
  val photoUrl: String = "",
  val sortOrder: Long = 0L,
  val hostingProvider: String = AudioHostingProvider.GITHUB_RELEASES.id,
  val audioBaseUrl: String = "",
  val published: Boolean = true,
  val createdBy: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  val effectiveRiwayah: String
    get() = riwayah.ifBlank { styleArabic }

  fun toCreateMap(adminUid: String): Map<String, Any> =
    buildMap {
      put("arabicName", arabicName)
      put("styleArabic", styleArabic)
      if (riwayah.isNotBlank()) put("riwayah", riwayah)
      if (bioArabic.isNotBlank()) put("bioArabic", bioArabic)
      if (photoUrl.isNotBlank()) put("photoUrl", photoUrl)
      put("sortOrder", sortOrder)
      put("hostingProvider", hostingProvider)
      put("audioBaseUrl", audioBaseUrl)
      put("published", published)
      put("createdBy", adminUid)
      put("createdAt", FieldValue.serverTimestamp())
      put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class FirebaseRecitationTrack(
  @DocumentId val id: String = "",
  val reciterId: String = "",
  val surahNumber: Long = 1L,
  val surahArabicName: String = "",
  val description: String = "",
  val sortOrder: Long = 0L,
  val hostingProvider: String = AudioHostingProvider.GITHUB_RELEASES.id,
  val audioUrl: String = "",
  val externalAssetId: String = "",
  val fileSizeBytes: Long = 0L,
  val durationSeconds: Long = 0L,
  val published: Boolean = true,
  val uploadedBy: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  fun toCreateMap(adminUid: String): Map<String, Any> =
    buildMap {
      put("reciterId", reciterId)
      put("surahNumber", surahNumber)
      put("surahArabicName", surahArabicName)
      if (description.isNotBlank()) put("description", description)
      put("sortOrder", sortOrder)
      put("hostingProvider", hostingProvider)
      put("audioUrl", audioUrl)
      if (externalAssetId.isNotBlank()) put("externalAssetId", externalAssetId)
      if (fileSizeBytes > 0L) put("fileSizeBytes", fileSizeBytes)
      if (durationSeconds > 0L) put("durationSeconds", durationSeconds)
      put("published", published)
      put("uploadedBy", adminUid)
      put("createdAt", FieldValue.serverTimestamp())
      put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class FirebaseUserProfile(
  @DocumentId val id: String = "",
  val userId: String = "",
  val displayName: String = "",
  val role: String = "user",
  val preferredReciterId: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  fun toCreateMap(uid: String): Map<String, Any> =
    buildMap {
      put("userId", uid)
      put("displayName", displayName)
      put("role", role)
      if (preferredReciterId.isNotBlank()) put("preferredReciterId", preferredReciterId)
      put("createdAt", FieldValue.serverTimestamp())
      put("updatedAt", FieldValue.serverTimestamp())
    }
}

@Keep
@IgnoreExtraProperties
data class FirebaseUserBookmark(
  @DocumentId val id: String = "",
  val userId: String = "",
  val surahNumber: Long = 1L,
  val ayahNumber: Long = 1L,
  val category: String = "عام",
  val note: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null,
) {
  fun toCreateMap(uid: String): Map<String, Any> =
    buildMap {
      put("userId", uid)
      put("surahNumber", surahNumber)
      put("ayahNumber", ayahNumber)
      put("category", category)
      if (note.isNotBlank()) put("note", note)
      put("createdAt", FieldValue.serverTimestamp())
      put("updatedAt", FieldValue.serverTimestamp())
    }
}
