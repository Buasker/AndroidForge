package com.example.data.remote

import com.squareup.moshi.FromJson
import com.squareup.moshi.JsonClass
import com.squareup.moshi.JsonReader
import com.squareup.moshi.JsonWriter
import com.squareup.moshi.ToJson

class SajdaBooleanAdapter {
  @FromJson
  fun fromJson(reader: JsonReader): Boolean {
    return when (reader.peek()) {
      JsonReader.Token.BOOLEAN -> reader.nextBoolean()
      JsonReader.Token.BEGIN_OBJECT -> {
        reader.skipValue()
        true
      }
      else -> {
        reader.skipValue()
        false
      }
    }
  }

  @ToJson
  fun toJson(writer: JsonWriter, value: Boolean) {
    writer.value(value)
  }
}

@JsonClass(generateAdapter = true)
data class SurahListResponseDto(
  val code: Int,
  val status: String,
  val data: List<SurahDto>,
)

@JsonClass(generateAdapter = true)
data class SurahEditionsResponseDto(
  val code: Int,
  val status: String,
  val data: List<SurahWithAyahsDto>,
)

@JsonClass(generateAdapter = true)
data class SingleSurahResponseDto(
  val code: Int,
  val status: String,
  val data: SurahWithAyahsDto,
)

@JsonClass(generateAdapter = true)
data class PageResponseDto(
  val code: Int,
  val status: String,
  val data: PageDataDto,
)

@JsonClass(generateAdapter = true)
data class PageDataDto(
  val number: Int,
  val ayahs: List<PageAyahDto>,
)

@JsonClass(generateAdapter = true)
data class PageAyahDto(
  val number: Int,
  val text: String,
  val surah: SurahDto,
  val numberInSurah: Int,
  val juz: Int,
  val manzil: Int,
  val page: Int,
  val ruku: Int,
  val hizbQuarter: Int,
  val sajda: Boolean = false,
)

@JsonClass(generateAdapter = true)
data class SurahDto(
  val number: Int,
  val name: String,
  val englishName: String,
  val englishNameTranslation: String,
  val numberOfAyahs: Int,
  val revelationType: String,
)

@JsonClass(generateAdapter = true)
data class SurahWithAyahsDto(
  val number: Int,
  val name: String,
  val englishName: String,
  val englishNameTranslation: String,
  val numberOfAyahs: Int,
  val revelationType: String,
  val ayahs: List<AyahDto>,
  val edition: EditionDto,
)

@JsonClass(generateAdapter = true)
data class AyahDto(
  val number: Int,
  val text: String,
  val numberInSurah: Int,
  val juz: Int,
  val manzil: Int,
  val page: Int,
  val ruku: Int,
  val hizbQuarter: Int,
  val sajda: Boolean = false,
)

@JsonClass(generateAdapter = true)
data class EditionDto(
  val identifier: String,
  val language: String,
  val name: String,
  val englishName: String,
  val format: String,
  val type: String,
)

@JsonClass(generateAdapter = true)
data class SearchResponseDto(
  val code: Int,
  val status: String,
  val data: SearchDataDto,
)

@JsonClass(generateAdapter = true)
data class SearchDataDto(
  val count: Int,
  val matches: List<SearchMatchDto>,
)

@JsonClass(generateAdapter = true)
data class SearchMatchDto(
  val number: Int,
  val text: String,
  val numberInSurah: Int,
  val surah: SurahDto,
)
