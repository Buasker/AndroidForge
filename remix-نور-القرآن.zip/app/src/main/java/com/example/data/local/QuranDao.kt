package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface QuranDao {
  // Surahs
  @Query("SELECT * FROM surahs ORDER BY number ASC")
  fun getAllSurahsFlow(): Flow<List<SurahEntity>>

  @Query("SELECT COUNT(*) FROM surahs")
  suspend fun getSurahCount(): Int

  @Query("SELECT * FROM surahs WHERE number = :surahNumber LIMIT 1")
  suspend fun getSurahByNumber(surahNumber: Int): SurahEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertSurahs(surahs: List<SurahEntity>)

  // Ayahs
  @Query(
    "SELECT * FROM ayahs WHERE surahNumber = :surahNumber AND translationEdition = :edition ORDER BY numberInSurah ASC"
  )
  suspend fun getAyahsForSurah(surahNumber: Int, edition: String): List<AyahEntity>

  @Query(
    "SELECT * FROM ayahs WHERE page = :pageNumber AND translationEdition = :edition ORDER BY surahNumber ASC, numberInSurah ASC"
  )
  suspend fun getAyahsForPage(pageNumber: Int, edition: String): List<AyahEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertAyahs(ayahs: List<AyahEntity>)

  @Query(
    """
    SELECT * FROM ayahs
    WHERE translationEdition = :edition
      AND (translationText LIKE '%' || :query || '%' OR arabicText LIKE '%' || :query || '%')
    ORDER BY surahNumber ASC, numberInSurah ASC
    LIMIT 60
    """
  )
  suspend fun searchCachedAyahs(query: String, edition: String): List<AyahEntity>

  // Tafsir
  @Query(
    "SELECT * FROM tafsir WHERE surahNumber = :surahNumber AND editionId = :editionId ORDER BY numberInSurah ASC"
  )
  suspend fun getTafsirForSurah(surahNumber: Int, editionId: String): List<TafsirEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTafsirItems(items: List<TafsirEntity>)

  @Query(
    """
    SELECT * FROM tafsir
    WHERE editionId = :editionId
      AND (tafsirText LIKE '%' || :query || '%' OR quranArabicText LIKE '%' || :query || '%')
    ORDER BY surahNumber ASC, numberInSurah ASC
    LIMIT 50
    """
  )
  suspend fun searchTafsir(query: String, editionId: String): List<TafsirEntity>

  // Bookmarks
  @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
  fun getAllBookmarksFlow(): Flow<List<BookmarkEntity>>

  @Query(
    "SELECT EXISTS(SELECT 1 FROM bookmarks WHERE surahNumber = :surahNumber AND ayahNumberInSurah = :ayahNumber)"
  )
  suspend fun isBookmarked(surahNumber: Int, ayahNumber: Int): Boolean

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertBookmark(bookmark: BookmarkEntity)

  @Query(
    "UPDATE bookmarks SET category = :category, note = :note WHERE surahNumber = :surahNumber AND ayahNumberInSurah = :ayahNumber"
  )
  suspend fun updateBookmarkDetails(
    surahNumber: Int,
    ayahNumber: Int,
    category: String,
    note: String,
  )

  @Query(
    "DELETE FROM bookmarks WHERE surahNumber = :surahNumber AND ayahNumberInSurah = :ayahNumber"
  )
  suspend fun deleteBookmark(surahNumber: Int, ayahNumber: Int)

  // Voice Dhikr Counters
  @Query("SELECT * FROM dhikr_counters ORDER BY sortOrder ASC")
  fun getAllDhikrCountersFlow(): Flow<List<DhikrCounterEntity>>

  @Query("SELECT COUNT(*) FROM dhikr_counters")
  suspend fun getDhikrCounterCount(): Int

  @Insert(onConflict = OnConflictStrategy.IGNORE)
  suspend fun insertDhikrCounters(counters: List<DhikrCounterEntity>)

  @Query(
    "UPDATE dhikr_counters SET count = count + :delta, lastUpdated = :timestamp WHERE id = :id"
  )
  suspend fun incrementDhikrCounter(
    id: String,
    delta: Int = 1,
    timestamp: Long = System.currentTimeMillis(),
  ): Int

  @Query("UPDATE dhikr_counters SET count = 0, lastUpdated = :timestamp WHERE id = :id")
  suspend fun resetDhikrCounter(id: String, timestamp: Long = System.currentTimeMillis())

  @Query("UPDATE dhikr_counters SET count = 0, lastUpdated = :timestamp")
  suspend fun resetAllDhikrCounters(timestamp: Long = System.currentTimeMillis())

  // Adhkar Progress
  @Query("SELECT * FROM adhkar_progress")
  fun getAllAdhkarProgressFlow(): Flow<List<AdhkarProgressEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertAdhkarProgress(progress: AdhkarProgressEntity)

  @Query("DELETE FROM adhkar_progress")
  suspend fun resetAllAdhkarProgress()

  // Dhikr Daily Logs (Statistics)
  @Query("SELECT * FROM dhikr_daily_logs ORDER BY epochDay ASC")
  fun getAllDhikrDailyLogsFlow(): Flow<List<DhikrDailyLogEntity>>

  @Query("SELECT COUNT(*) FROM dhikr_daily_logs")
  suspend fun getDhikrDailyLogCount(): Int

  @Query("SELECT * FROM dhikr_counters WHERE count > 0")
  suspend fun getNonZeroDhikrCounters(): List<DhikrCounterEntity>

  @Query(
    "UPDATE dhikr_daily_logs SET count = count + :delta, label = :label, lastUpdated = :timestamp WHERE epochDay = :epochDay AND dhikrId = :dhikrId"
  )
  suspend fun incrementDhikrDailyLog(
    epochDay: Long,
    dhikrId: String,
    label: String,
    delta: Int,
    timestamp: Long,
  ): Int

  @Insert(onConflict = OnConflictStrategy.IGNORE)
  suspend fun insertDhikrDailyLogs(logs: List<DhikrDailyLogEntity>)

  // Khatmah Plans
  @Query("SELECT * FROM khatmah_plans ORDER BY createdAt DESC")
  fun getAllKhatmahPlansFlow(): Flow<List<KhatmahPlanEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertKhatmahPlan(plan: KhatmahPlanEntity): Long

  @Query("DELETE FROM khatmah_plans WHERE id = :id")
  suspend fun deleteKhatmahPlan(id: Long)

  // Downloaded Audio
  @Query("SELECT * FROM downloaded_audio WHERE reciterId = :reciterId")
  fun getDownloadedAudioForReciterFlow(reciterId: String): Flow<List<DownloadedAudioEntity>>

  @Query(
    "SELECT * FROM downloaded_audio WHERE reciterId = :reciterId AND surahNumber = :surahNumber LIMIT 1"
  )
  suspend fun getDownloadedAudio(reciterId: String, surahNumber: Int): DownloadedAudioEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertDownloadedAudio(item: DownloadedAudioEntity)

  @Query(
    "DELETE FROM downloaded_audio WHERE reciterId = :reciterId AND surahNumber = :surahNumber"
  )
  suspend fun deleteDownloadedAudio(reciterId: String, surahNumber: Int)

  @Query("SELECT * FROM downloaded_audio WHERE reciterId = :reciterId")
  suspend fun getDownloadedAudioListForReciter(reciterId: String): List<DownloadedAudioEntity>

  @Query("DELETE FROM downloaded_audio WHERE reciterId = :reciterId")
  suspend fun deleteAllDownloadedAudioForReciter(reciterId: String)

  // User-managed Local Reciters & Recitations
  @Query("SELECT * FROM local_reciters ORDER BY createdAt DESC")
  fun getAllLocalRecitersFlow(): Flow<List<LocalReciterEntity>>

  @Query("SELECT * FROM local_reciters WHERE id = :id LIMIT 1")
  suspend fun getLocalReciterById(id: String): LocalReciterEntity?

  @Query("SELECT * FROM local_reciters WHERE normalizedName = :normalizedName LIMIT 1")
  suspend fun findLocalReciterByNormalizedName(normalizedName: String): LocalReciterEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertLocalReciter(reciter: LocalReciterEntity)

  @Query("DELETE FROM local_reciters WHERE id = :id")
  suspend fun deleteLocalReciterById(id: String)

  @Query("SELECT * FROM local_recitations ORDER BY reciterId ASC, surahNumber ASC")
  fun getAllLocalRecitationsFlow(): Flow<List<LocalRecitationEntity>>

  @Query("SELECT * FROM local_recitations WHERE reciterId = :reciterId ORDER BY surahNumber ASC")
  fun getLocalRecitationsForReciterFlow(reciterId: String): Flow<List<LocalRecitationEntity>>

  @Query(
    "SELECT * FROM local_recitations WHERE reciterId = :reciterId AND surahNumber = :surahNumber LIMIT 1"
  )
  suspend fun getLocalRecitation(reciterId: String, surahNumber: Int): LocalRecitationEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertLocalRecitation(recitation: LocalRecitationEntity)

  @Query(
    "DELETE FROM local_recitations WHERE reciterId = :reciterId AND surahNumber = :surahNumber"
  )
  suspend fun deleteLocalRecitation(reciterId: String, surahNumber: Int)
}
