package com.example

import android.app.Application
import android.content.Context
import com.example.audio.QuranAudioPlayer
import com.example.data.firebase.FirebaseAuthManager
import com.example.data.firebase.FirebaseQuranBackendRepository
import com.example.data.local.NoorQuranDatabase
import com.example.data.local.UserPreferencesRepository
import com.example.data.remote.AlQuranApiService
import com.example.data.remote.Mp3QuranApiService
import com.example.data.repository.QuranRepository
import com.example.dhikr.VoiceDhikrController

class NoorAppContainer(context: Context) {
  private val okHttpClient = AlQuranApiService.createOkHttpClient()
  private val database = NoorQuranDatabase.getInstance(context)
  private val apiService = AlQuranApiService.create(okHttpClient)
  private val mp3QuranApi = Mp3QuranApiService.create(okHttpClient)

  val firebaseAuthManager by lazy { FirebaseAuthManager(context.applicationContext) }
  val firebaseBackendRepository by lazy {
    FirebaseQuranBackendRepository(
      context = context.applicationContext,
      authManager = firebaseAuthManager,
      okHttpClient = okHttpClient,
    )
  }

  val quranRepository =
    QuranRepository(
      context = context.applicationContext,
      dao = database.quranDao(),
      api = apiService,
      mp3QuranApi = mp3QuranApi,
      okHttpClient = okHttpClient,
      resolveCloudHostedTrackUrl = { reciterId, surahNum ->
        firebaseBackendRepository.resolvePublishedTrackUrl(reciterId, surahNum)
      },
      resolveCloudReciterBaseUrl = { reciterId ->
        firebaseBackendRepository.resolvePublishedReciterBaseUrl(reciterId)
      },
    )
  val preferencesRepository = UserPreferencesRepository(context)
  val audioPlayer =
    QuranAudioPlayer(
      appContext = context.applicationContext,
      resolveSurahSource = { reciterId, surahNum ->
        quranRepository.resolveSurahAudioSource(reciterId, surahNum)
      },
    )
  val voiceDhikrController by lazy {
    VoiceDhikrController(
      appContext = context.applicationContext,
      quranRepository = quranRepository,
    )
  }
}

class NoorApplication : Application() {
  lateinit var container: NoorAppContainer
    private set

  override fun onCreate() {
    super.onCreate()
    container = NoorAppContainer(this)
  }

  override fun onTerminate() {
    super.onTerminate()
    container.audioPlayer.release()
    container.voiceDhikrController.release()
  }
}
