package com.example.dhikr

import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

/**
 * API 24+-safe local-calendar day arithmetic and Arabic date formatting helpers for dhikr logs
 * and daily/weekly statistics charts.
 */
object DhikrDateUtils {
  private const val MILLIS_PER_DAY = 86_400_000L

  fun epochDayForMillis(millis: Long = System.currentTimeMillis()): Long {
    val local = Calendar.getInstance().apply { timeInMillis = millis }
    val utc =
      Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        clear()
        set(local.get(Calendar.YEAR), local.get(Calendar.MONTH), local.get(Calendar.DAY_OF_MONTH))
      }
    return utc.timeInMillis / MILLIS_PER_DAY
  }

  fun calendarForEpochDay(epochDay: Long): Calendar {
    return Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
      clear()
      timeInMillis = epochDay * MILLIS_PER_DAY
    }
  }

  fun arabicShortDayName(epochDay: Long): String {
    return when (calendarForEpochDay(epochDay).get(Calendar.DAY_OF_WEEK)) {
      Calendar.SATURDAY -> "السبت"
      Calendar.SUNDAY -> "الأحد"
      Calendar.MONDAY -> "الإثنين"
      Calendar.TUESDAY -> "الثلاثاء"
      Calendar.WEDNESDAY -> "الأربعاء"
      Calendar.THURSDAY -> "الخميس"
      Calendar.FRIDAY -> "الجمعة"
      else -> ""
    }
  }

  fun dayMonthLabel(epochDay: Long): String {
    val cal = calendarForEpochDay(epochDay)
    val day = cal.get(Calendar.DAY_OF_MONTH)
    val month = cal.get(Calendar.MONTH) + 1
    return String.format(Locale.US, "%d/%d", day, month)
  }

  fun weekRangeLabel(startEpochDay: Long, endEpochDay: Long): String {
    val startCal = calendarForEpochDay(startEpochDay)
    val endCal = calendarForEpochDay(endEpochDay)
    val sDay = startCal.get(Calendar.DAY_OF_MONTH)
    val sMonth = startCal.get(Calendar.MONTH) + 1
    val eDay = endCal.get(Calendar.DAY_OF_MONTH)
    val eMonth = endCal.get(Calendar.MONTH) + 1
    return if (sMonth == eMonth) {
      String.format(Locale.US, "%d–%d/%d", sDay, eDay, eMonth)
    } else {
      String.format(Locale.US, "%d/%d–%d/%d", sDay, sMonth, eDay, eMonth)
    }
  }
}
