package com.example.dhikr

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognitionSupport
import android.speech.RecognitionSupportCallback
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import com.example.BuildConfig
import com.example.data.local.AdhkarSeedData
import com.example.data.repository.QuranRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class VoiceListeningPhase {
  IDLE,
  STARTING,
  LISTENING,
  RECOGNIZING,
  NO_SPEECH_MATCH,
  MICROPHONE_ERROR,
}

data class VoiceDhikrDiagnostics(
  val recognizedText: String = "",
  val normalizedText: String = "",
  val matchedDhikrTitles: List<String> = emptyList(),
  val rejectionReason: String? = null,
  val dbSaveStatus: String = "",
  val eventSummary: String = "",
)

data class VoiceDhikrStatus(
  val isListening: Boolean = false,
  val phase: VoiceListeningPhase = VoiceListeningPhase.IDLE,
  val lastHeardText: String = "",
  val lastMatchedDhikrId: String? = null,
  val lastMatchedDhikrTitle: String? = null,
  val statusMessage: String = "اضغط على «بدء الاستماع الصوتي» واذكر الله بصوتك",
  val speechAvailable: Boolean = true,
  val diagnostics: VoiceDhikrDiagnostics = VoiceDhikrDiagnostics(),
)

interface SpeechEngineClient {
  fun isAvailable(context: Context): Boolean

  fun startListening(listener: RecognitionListener, useOnDeviceFallback: Boolean = false)

  fun setPreferredLanguageTag(tag: String) {}

  fun checkOnDeviceArabicSupport(
    context: Context,
    onResult: (supported: Boolean, preferredLocale: String) -> Unit,
  ) {
    onResult(false, "ar-SA")
  }

  fun stopListening()

  fun cancel()

  fun destroy()
}

class AndroidSpeechEngineClient(private val context: Context) : SpeechEngineClient {
  private val mainHandler = Handler(Looper.getMainLooper())
  private var speechRecognizer: SpeechRecognizer? = null
  private var preferredLanguageTag: String = "ar-SA"

  override fun isAvailable(context: Context): Boolean {
    val standardAvailable = SpeechRecognizer.isRecognitionAvailable(context)
    val onDeviceAvailable =
      Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
        SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
    return standardAvailable || onDeviceAvailable
  }

  override fun setPreferredLanguageTag(tag: String) {
    if (tag.isNotBlank()) {
      preferredLanguageTag = tag
    }
  }

  override fun checkOnDeviceArabicSupport(
    context: Context,
    onResult: (supported: Boolean, preferredLocale: String) -> Unit,
  ) {
    if (
      Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        !SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
    ) {
      onResult(false, "ar-SA")
      return
    }
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
      onResult(true, "ar-SA")
      return
    }
    checkOnDeviceArabicSupportApi33(context, onResult)
  }

  @RequiresApi(Build.VERSION_CODES.TIRAMISU)
  private fun checkOnDeviceArabicSupportApi33(
    context: Context,
    onResult: (supported: Boolean, preferredLocale: String) -> Unit,
  ) {
    var completed = false
    val probeRecognizer =
      runCatching { SpeechRecognizer.createOnDeviceSpeechRecognizer(context) }.getOrNull()
    if (probeRecognizer == null) {
      onResult(false, "ar-SA")
      return
    }

    val timeoutRunnable = Runnable {
      if (!completed) {
        completed = true
        runCatching { probeRecognizer.destroy() }
        onResult(false, "ar-SA")
      }
    }
    mainHandler.postDelayed(timeoutRunnable, 1500L)

    val probeIntent =
      Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-SA")
      }

    runCatching {
        probeRecognizer.checkRecognitionSupport(
          probeIntent,
          ContextCompat.getMainExecutor(context),
          object : RecognitionSupportCallback {
            override fun onSupportResult(recognitionSupport: RecognitionSupport) {
              if (completed) return
              completed = true
              mainHandler.removeCallbacks(timeoutRunnable)
              runCatching { probeRecognizer.destroy() }

              val installed = recognitionSupport.installedOnDeviceLanguages
              val bestLocale =
                installed.firstOrNull { it.equals("ar-SA", ignoreCase = true) }
                  ?: installed.firstOrNull { it.startsWith("ar", ignoreCase = true) }
              if (bestLocale != null) {
                onResult(true, bestLocale)
              } else {
                onResult(false, "ar-SA")
              }
            }

            override fun onError(error: Int) {
              if (completed) return
              completed = true
              mainHandler.removeCallbacks(timeoutRunnable)
              runCatching { probeRecognizer.destroy() }
              onResult(false, "ar-SA")
            }
          },
        )
      }
      .onFailure {
        if (!completed) {
          completed = true
          mainHandler.removeCallbacks(timeoutRunnable)
          runCatching { probeRecognizer.destroy() }
          onResult(false, "ar-SA")
        }
      }
  }

  override fun startListening(listener: RecognitionListener, useOnDeviceFallback: Boolean) {
    // Always destroy any lingering recognizer before creating a fresh instance on Main thread.
    if (speechRecognizer != null) {
      destroy()
    }
    val recognizer = createRecognizer(useOnDeviceFallback)
    speechRecognizer = recognizer
    recognizer.setRecognitionListener(listener)

    val intent =
      Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        putExtra(
          RecognizerIntent.EXTRA_LANGUAGE_MODEL,
          RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
        )
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, preferredLanguageTag)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, preferredLanguageTag)
        putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        if (useOnDeviceFallback) {
          putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
      }
    recognizer.startListening(intent)
  }

  private fun createRecognizer(useOnDeviceFallback: Boolean): SpeechRecognizer {
    if (
      useOnDeviceFallback &&
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
        SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
    ) {
      return SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
    }
    if (SpeechRecognizer.isRecognitionAvailable(context)) {
      return SpeechRecognizer.createSpeechRecognizer(context)
    }
    if (
      Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
        SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
    ) {
      return SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
    }
    throw IllegalStateException("خدمة التعرف الصوتي غير متوفرة على هذا الجهاز")
  }

  override fun stopListening() {
    runCatching { speechRecognizer?.stopListening() }
  }

  override fun cancel() {
    runCatching { speechRecognizer?.cancel() }
  }

  override fun destroy() {
    val current = speechRecognizer ?: return
    speechRecognizer = null
    runCatching { current.setRecognitionListener(null) }
    runCatching { current.cancel() }
    runCatching { current.destroy() }
  }
}

/**
 * Application-scoped continuous Voice Dhikr engine.
 * Survives screen navigation and screen-off (backed by [VoiceDhikrService]), serializes all
 * [SpeechRecognizer] create/start/cancel/destroy calls strictly on the Main Thread with a
 * destroy-before-cooldown pattern and session-token isolation, handles transient engine errors
 * with exponential backoff + on-device Arabic fallback + circuit breaker, deduplicates partial
 * and final results, and persists matched dhikr increments to Room.
 */
class VoiceDhikrController(
  private val appContext: Context,
  private val quranRepository: QuranRepository,
  private val speechEngineClient: SpeechEngineClient = AndroidSpeechEngineClient(appContext),
  private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO),
  private val hasRecordAudioPermission: () -> Boolean = {
    ContextCompat.checkSelfPermission(appContext, Manifest.permission.RECORD_AUDIO) ==
      PackageManager.PERMISSION_GRANTED
  },
  private val onForegroundServiceStateChanged: (Boolean) -> Unit = { active ->
    val serviceIntent = Intent(appContext, VoiceDhikrService::class.java)
    if (active) {
      serviceIntent.action = VoiceDhikrService.ACTION_START
      runCatching { ContextCompat.startForegroundService(appContext, serviceIntent) }
        .onFailure {
          if (BuildConfig.DEBUG) {
            Log.w(TAG, "Unable to start foreground service: ${it.javaClass.simpleName}")
          }
        }
    } else {
      runCatching { appContext.stopService(serviceIntent) }
    }
  },
  private val nowMsProvider: () -> Long = { System.currentTimeMillis() },
) {
  private val mainHandler = Handler(Looper.getMainLooper())
  private val alreadyCountedInUtterance = mutableMapOf<String, Int>()
  private val titleById: Map<String, String> =
    AdhkarSeedData.initialVoiceDhikrCounters.associate { it.id to it.arabicTitle }

  @Volatile var allowPartialMatch: Boolean = true

  private var shouldContinueListening = false
  private var activeSessionId: Long = 0L
  private var isEngineActive = false
  private var isStartInFlight = false
  private var sessionHandledFinalResult = false
  private var sessionIncrementedAny = false
  private var sessionReceivedAnyText = false
  private var consecutiveEngineErrors = 0
  private var preferOnDeviceFallback = false
  private var triedOnDeviceFallback = false
  private var preferredLanguageTag = "ar-SA"
  private var onDeviceArabicUnavailableReason: String? = null
  private var keepNoMatchNoticeUntilMs = 0L

  private var pendingRestartRunnable: Runnable? = null
  private var pendingStatusRevertRunnable: Runnable? = null
  private var pendingStartWatchdogRunnable: Runnable? = null
  private var pendingRecognitionWatchdogRunnable: Runnable? = null

  private val _status =
    MutableStateFlow(
      VoiceDhikrStatus(
        speechAvailable = speechEngineClient.isAvailable(appContext)
      )
    )
  val status: StateFlow<VoiceDhikrStatus> = _status.asStateFlow()

  fun startListening() {
    runOnMain {
      if (!hasRecordAudioPermission()) {
        onPermissionDeniedInternal()
        return@runOnMain
      }
      if (!speechEngineClient.isAvailable(appContext)) {
        shouldContinueListening = false
        teardownEngineOnMain()
        onForegroundServiceStateChanged(false)
        _status.update {
          it.copy(
            isListening = false,
            phase = VoiceListeningPhase.MICROPHONE_ERROR,
            speechAvailable = false,
            statusMessage = "تعذر تشغيل الميكروفون: خدمة التعرف الصوتي غير متوفرة على هذا الجهاز",
            diagnostics =
              it.diagnostics.copy(
                eventSummary = "فشل التشغيل: خدمة التعرف غير متوفرة",
                rejectionReason = "SpeechRecognizer غير متاح على الجهاز",
              ),
          )
        }
        return@runOnMain
      }

      if (shouldContinueListening && (isEngineActive || isStartInFlight || pendingRestartRunnable != null)) {
        logDiag("تجاهل startListening المكرر: جلسة استماع نشطة بالفعل")
        return@runOnMain
      }

      shouldContinueListening = true
      consecutiveEngineErrors = 0
      preferOnDeviceFallback = false
      triedOnDeviceFallback = false
      preferredLanguageTag = "ar-SA"
      onDeviceArabicUnavailableReason = null
      keepNoMatchNoticeUntilMs = 0L
      cancelScheduledRunnables()
      teardownEngineOnMain()

      _status.update {
        it.copy(
          isListening = true,
          speechAvailable = true,
          phase = VoiceListeningPhase.STARTING,
          statusMessage = "جاري تشغيل الميكروفون…",
          diagnostics =
            VoiceDhikrDiagnostics(
              eventSummary = "بدء جلسة الاستماع الصوتي (المحرك الافتراضي $preferredLanguageTag)",
            ),
        )
      }
      logDiag("بدء الاستماع الصوتي")
      onForegroundServiceStateChanged(true)
      beginRecognitionSessionOnMain()
    }
  }

  fun pauseListening() {
    runOnMain {
      shouldContinueListening = false
      keepNoMatchNoticeUntilMs = 0L
      cancelScheduledRunnables()
      alreadyCountedInUtterance.clear()
      teardownEngineOnMain()
      onForegroundServiceStateChanged(false)
      _status.update {
        it.copy(
          isListening = false,
          phase = VoiceListeningPhase.IDLE,
          statusMessage = "تم إيقاف الاستماع مؤقتاً",
          diagnostics = it.diagnostics.copy(eventSummary = "تم إيقاف الاستماع من المستخدم"),
        )
      }
    }
  }

  fun onPermissionDenied() {
    runOnMain { onPermissionDeniedInternal() }
  }

  private fun onPermissionDeniedInternal() {
    shouldContinueListening = false
    keepNoMatchNoticeUntilMs = 0L
    cancelScheduledRunnables()
    teardownEngineOnMain()
    onForegroundServiceStateChanged(false)
    _status.update {
      it.copy(
        isListening = false,
        phase = VoiceListeningPhase.MICROPHONE_ERROR,
        statusMessage = "تعذر تشغيل الميكروفون: يلزم منح صلاحية الميكروفون",
        diagnostics =
          it.diagnostics.copy(
            eventSummary = "صلاحية RECORD_AUDIO مرفوضة",
            rejectionReason = "يلزم منح صلاحية الميكروفون",
          ),
      )
    }
  }

  fun release() {
    pauseListening()
    scope.cancel()
  }

  /**
   * Immediately invalidates the current session token, cancels watchdogs, and destroys any
   * active SpeechRecognizer on the Main Thread BEFORE any cooldown wait for the next session.
   */
  private fun teardownEngineOnMain() {
    activeSessionId++
    cancelWatchdogs()
    isStartInFlight = false
    if (isEngineActive) {
      speechEngineClient.destroy()
      isEngineActive = false
    } else {
      speechEngineClient.destroy()
    }
  }

  private fun beginRecognitionSessionOnMain() {
    if (!shouldContinueListening) return
    if (isEngineActive || isStartInFlight) {
      logDiag("منع تداخل جلسة: المحرك ما زال نشطاً — جاري تحريره أولاً")
      teardownEngineOnMain()
    }
    if (!hasRecordAudioPermission()) {
      onPermissionDeniedInternal()
      return
    }
    cancelRestartRunnableOnly()
    cancelWatchdogs()
    alreadyCountedInUtterance.clear()
    sessionHandledFinalResult = false
    sessionIncrementedAny = false
    sessionReceivedAnyText = false

    val sessionId = ++activeSessionId
    isStartInFlight = true
    isEngineActive = true
    speechEngineClient.setPreferredLanguageTag(preferredLanguageTag)

    val sessionListener = SessionRecognitionListener(sessionId)

    runCatching {
        speechEngineClient.startListening(
          listener = sessionListener,
          useOnDeviceFallback = preferOnDeviceFallback,
        )
        isStartInFlight = false
        scheduleStartWatchdog(sessionId)
      }
      .onFailure { error ->
        isStartInFlight = false
        logDiag("فشل SpeechRecognizer.startListening: ${error.javaClass.simpleName} - ${error.message}")
        teardownEngineOnMain()
        shouldContinueListening = false
        onForegroundServiceStateChanged(false)
        _status.update {
          it.copy(
            isListening = false,
            phase = VoiceListeningPhase.MICROPHONE_ERROR,
            statusMessage = "تعذر تشغيل الميكروفون: ${error.localizedMessage ?: "خطأ غير متوقع"}",
            diagnostics =
              it.diagnostics.copy(
                eventSummary = "استثناء أثناء بدء محرك التعرف",
                rejectionReason = error.localizedMessage ?: error.javaClass.simpleName,
              ),
          )
        }
      }
  }

  /**
   * Schedules the next session AFTER [teardownEngineOnMain] has already released the previous
   * SpeechRecognizer, ensuring a clean cooldown gap between destroy() and create/startListening().
   */
  private fun scheduleNextSessionAfterCooldown(cooldownMs: Long) {
    if (!shouldContinueListening) return
    cancelRestartRunnableOnly()
    val scheduledGeneration = activeSessionId
    val runnable = Runnable {
      pendingRestartRunnable = null
      if (!shouldContinueListening || scheduledGeneration != activeSessionId) return@Runnable
      beginRecognitionSessionOnMain()
    }
    pendingRestartRunnable = runnable
    mainHandler.postDelayed(runnable, cooldownMs)
  }

  private fun scheduleStartWatchdog(sessionId: Long) {
    pendingStartWatchdogRunnable?.let { mainHandler.removeCallbacks(it) }
    val runnable = Runnable {
      if (!shouldContinueListening || sessionId != activeSessionId || sessionHandledFinalResult) {
        return@Runnable
      }
      val phase = _status.value.phase
      if (phase == VoiceListeningPhase.STARTING) {
        logDiag("مهلة بدء محرك الصوت انتهت دون onReadyForSpeech — تدمير المحرك وإعادة المحاولة")
        teardownEngineOnMain()
        _status.update {
          it.copy(
            diagnostics =
              it.diagnostics.copy(
                eventSummary = "تأخر استجابة المحرك عند البدء — إعادة التشغيل بعد تحرير المحرك",
                rejectionReason = "لم يرسل المحرك إشارة الجاهزية (onReadyForSpeech)",
              )
          )
        }
        scheduleNextSessionAfterCooldown(cooldownMs = RECOVERY_COOLDOWN_BASE_MS)
      }
    }
    pendingStartWatchdogRunnable = runnable
    mainHandler.postDelayed(runnable, START_WATCHDOG_MS)
  }

  private fun scheduleRecognitionWatchdog(sessionId: Long, timeoutMs: Long) {
    pendingRecognitionWatchdogRunnable?.let { mainHandler.removeCallbacks(it) }
    val runnable = Runnable {
      if (!shouldContinueListening || sessionId != activeSessionId || sessionHandledFinalResult) {
        return@Runnable
      }
      logDiag("انتهت مهلة انتظار نتيجة التعرف (${timeoutMs}ms) دون وصول onResults — تدمير المحرك وإعادة التشغيل")
      teardownEngineOnMain()
      alreadyCountedInUtterance.clear()
      if (!sessionIncrementedAny) {
        keepNoMatchNoticeUntilMs = nowMsProvider() + NO_MATCH_DISPLAY_MS
        _status.update {
          it.copy(
            isListening = true,
            phase = VoiceListeningPhase.NO_SPEECH_MATCH,
            statusMessage = "لم يتم التعرف على الكلام",
            diagnostics =
              it.diagnostics.copy(
                eventSummary = "تعليق محرك الصوت بدون نتائج نهائية (تم التحرير وإعادة التشغيل)",
                rejectionReason = "توقف المحرك في حالة «جاري التعرف على الصوت» دون إرسال نص نهائي",
                dbSaveStatus = "لم تُنفّذ زيادة",
              ),
          )
        }
      }
      scheduleNextSessionAfterCooldown(cooldownMs = NORMAL_RESTART_COOLDOWN_MS)
    }
    pendingRecognitionWatchdogRunnable = runnable
    mainHandler.postDelayed(runnable, timeoutMs)
  }

  private fun cancelWatchdogs() {
    pendingStartWatchdogRunnable?.let { mainHandler.removeCallbacks(it) }
    pendingStartWatchdogRunnable = null
    pendingRecognitionWatchdogRunnable?.let { mainHandler.removeCallbacks(it) }
    pendingRecognitionWatchdogRunnable = null
  }

  private fun cancelRestartRunnableOnly() {
    pendingRestartRunnable?.let { mainHandler.removeCallbacks(it) }
    pendingRestartRunnable = null
  }

  private fun cancelScheduledRunnables() {
    cancelRestartRunnableOnly()
    cancelWatchdogs()
    pendingStatusRevertRunnable?.let { mainHandler.removeCallbacks(it) }
    pendingStatusRevertRunnable = null
  }

  private fun scheduleRevertToListeningAfterNoMatch() {
    pendingStatusRevertRunnable?.let { mainHandler.removeCallbacks(it) }
    val remaining = (keepNoMatchNoticeUntilMs - nowMsProvider()).coerceAtLeast(100L)
    val runnable = Runnable {
      if (shouldContinueListening && _status.value.phase == VoiceListeningPhase.NO_SPEECH_MATCH) {
        _status.update {
          it.copy(
            phase = VoiceListeningPhase.LISTENING,
            statusMessage = "الميكروفون يعمل ويستمع",
          )
        }
      }
    }
    pendingStatusRevertRunnable = runnable
    mainHandler.postDelayed(runnable, remaining)
  }

  private fun extractCandidates(bundle: Bundle?, includeUnstable: Boolean): List<String> {
    if (bundle == null) return emptyList()
    val stable =
      bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.filter { it.isNotBlank() }
        .orEmpty()
    if (!includeUnstable) return stable

    val unstable =
      bundle.getStringArrayList(EXTRA_UNSTABLE_TEXT)?.filter { it.isNotBlank() }.orEmpty()
    if (unstable.isEmpty()) return stable

    val combined = mutableListOf<String>()
    val stableFirst = stable.firstOrNull().orEmpty()
    val unstableJoined = unstable.joinToString(" ").trim()
    if (stableFirst.isNotBlank() && unstableJoined.isNotBlank()) {
      combined.add("$stableFirst $unstableJoined".trim())
    }
    combined.addAll(stable)
    combined.addAll(unstable)
    return combined.distinct()
  }

  private fun processTranscriptDelta(
    transcript: String,
    diagnostic: DhikrMatchDiagnostic,
    sourceLabel: String,
  ): Pair<Boolean, Map<String, Int>> {
    val deltaMap = DhikrSpeechMatcher.computeIncrementalDelta(transcript, alreadyCountedInUtterance)
    if (deltaMap.isEmpty()) {
      return false to emptyMap()
    }

    val matchedTitles = deltaMap.keys.map { titleById[it] ?: it }
    val lastId = deltaMap.keys.lastOrNull()
    val lastTitle = lastId?.let { titleById[it] }
    sessionIncrementedAny = true

    _status.update {
      it.copy(
        lastMatchedDhikrId = lastId,
        lastMatchedDhikrTitle = lastTitle,
        diagnostics =
          it.diagnostics.copy(
            recognizedText = transcript,
            normalizedText = diagnostic.normalizedText,
            matchedDhikrTitles = matchedTitles,
            rejectionReason = null,
            dbSaveStatus = "جاري حفظ الزيادة في قاعدة البيانات…",
            eventSummary = "تطابق ($sourceLabel): ${matchedTitles.joinToString("، ")}",
          ),
      )
    }

    logDiag(
      "[$sourceLabel] النص=«$transcript» | المطبّع=«${diagnostic.normalizedText}» | " +
        "المطابقة=$deltaMap | جاري تنفيذ incrementDhikr..."
    )

    scope.launch {
      var allSaved = true
      val savedItems = mutableListOf<String>()
      var errorText: String? = null
      try {
        for ((id, countDelta) in deltaMap) {
          val ok = quranRepository.incrementDhikr(id, countDelta)
          val title = titleById[id] ?: id
          if (ok) {
            savedItems.add("$title (+$countDelta)")
          } else {
            allSaved = false
            savedItems.add("فشل صف $title")
          }
        }
      } catch (e: Exception) {
        allSaved = false
        errorText = e.localizedMessage ?: e.javaClass.simpleName
      }

      val saveSummary =
        if (allSaved) {
          "تم حفظ الزيادة بنجاح: ${savedItems.joinToString("، ")}"
        } else {
          "فشل الحفظ: ${errorText ?: savedItems.joinToString("، ")}"
        }
      logDiag("[$sourceLabel] نتيجة حفظ قاعدة البيانات: $saveSummary")
      _status.update {
        it.copy(
          diagnostics = it.diagnostics.copy(dbSaveStatus = saveSummary)
        )
      }
    }
    return true to deltaMap
  }

  private fun failWithMicrophoneError(message: String, reason: String = message) {
    shouldContinueListening = false
    keepNoMatchNoticeUntilMs = 0L
    cancelScheduledRunnables()
    teardownEngineOnMain()
    onForegroundServiceStateChanged(false)
    logDiag("خطأ ميكروفون نهائي: $reason")
    _status.update {
      it.copy(
        isListening = false,
        phase = VoiceListeningPhase.MICROPHONE_ERROR,
        statusMessage = message,
        diagnostics =
          it.diagnostics.copy(
            eventSummary = "توقف الاستماع لحماية المحرك من التكرار اللانهائي",
            rejectionReason = reason,
          ),
      )
    }
  }

  private fun runOnMain(block: () -> Unit) {
    if (Looper.myLooper() == Looper.getMainLooper()) {
      block()
    } else {
      mainHandler.post(block)
    }
  }

  private fun logDiag(message: String) {
    Log.d(DIAG_TAG, message)
  }

  private inner class SessionRecognitionListener(private val sessionId: Long) : RecognitionListener {
    override fun onReadyForSpeech(params: Bundle?) {
      handleReadyForSpeech(sessionId)
    }

    override fun onBeginningOfSpeech() {
      handleBeginningOfSpeech(sessionId)
    }

    override fun onRmsChanged(rmsdB: Float) {}

    override fun onBufferReceived(buffer: ByteArray?) {}

    override fun onEndOfSpeech() {
      handleEndOfSpeech(sessionId)
    }

    override fun onPartialResults(partialResults: Bundle?) {
      handlePartialResults(sessionId, partialResults)
    }

    override fun onResults(results: Bundle?) {
      handleResults(sessionId, results)
    }

    override fun onError(error: Int) {
      handleError(sessionId, error)
    }

    override fun onEvent(eventType: Int, params: Bundle?) {}
  }

  /**
   * Exposed listener delegating to the active session ID for compatibility with test harnesses
   * or external callers; real sessions receive an isolated [SessionRecognitionListener].
   */
  val recognitionListener: RecognitionListener =
    object : RecognitionListener {
      override fun onReadyForSpeech(params: Bundle?) = handleReadyForSpeech(activeSessionId)

      override fun onBeginningOfSpeech() = handleBeginningOfSpeech(activeSessionId)

      override fun onRmsChanged(rmsdB: Float) {}

      override fun onBufferReceived(buffer: ByteArray?) {}

      override fun onEndOfSpeech() = handleEndOfSpeech(activeSessionId)

      override fun onPartialResults(partialResults: Bundle?) =
        handlePartialResults(activeSessionId, partialResults)

      override fun onResults(results: Bundle?) = handleResults(activeSessionId, results)

      override fun onError(error: Int) = handleError(activeSessionId, error)

      override fun onEvent(eventType: Int, params: Bundle?) {}
    }

  private fun handleReadyForSpeech(sessionId: Long) {
    if (!shouldContinueListening || sessionId != activeSessionId) return
    pendingStartWatchdogRunnable?.let { mainHandler.removeCallbacks(it) }
    pendingStartWatchdogRunnable = null
    alreadyCountedInUtterance.clear()
    sessionHandledFinalResult = false
    sessionIncrementedAny = false
    sessionReceivedAnyText = false

    val modeLabel = if (preferOnDeviceFallback) "المحلي" else "الافتراضي"
    if (nowMsProvider() < keepNoMatchNoticeUntilMs) {
      scheduleRevertToListeningAfterNoMatch()
    } else {
      _status.update {
        it.copy(
          isListening = true,
          phase = VoiceListeningPhase.LISTENING,
          statusMessage = "الميكروفون يعمل ويستمع",
          diagnostics =
            it.diagnostics.copy(
              eventSummary = "onReadyForSpeech (#$sessionId - $modeLabel): الميكروفون جاهز ويستمع"
            ),
        )
      }
    }
  }

  private fun handleBeginningOfSpeech(sessionId: Long) {
    if (!shouldContinueListening || sessionId != activeSessionId) return
    pendingStartWatchdogRunnable?.let { mainHandler.removeCallbacks(it) }
    pendingStartWatchdogRunnable = null
    keepNoMatchNoticeUntilMs = 0L
    pendingStatusRevertRunnable?.let { mainHandler.removeCallbacks(it) }
    scheduleRecognitionWatchdog(sessionId, RECOGNITION_WATCHDOG_MS)
    _status.update {
      it.copy(
        isListening = true,
        phase = VoiceListeningPhase.RECOGNIZING,
        statusMessage = "جاري التعرف على الصوت…",
        diagnostics =
          it.diagnostics.copy(
            eventSummary = "onBeginningOfSpeech (#$sessionId): تم رصد صوت، بانتظار النص من المحرك",
          ),
      )
    }
  }

  private fun handleEndOfSpeech(sessionId: Long) {
    if (!shouldContinueListening || sessionId != activeSessionId || sessionHandledFinalResult) return
    scheduleRecognitionWatchdog(sessionId, END_OF_SPEECH_WATCHDOG_MS)
    _status.update {
      it.copy(
        diagnostics =
          it.diagnostics.copy(
            eventSummary =
              if (sessionReceivedAnyText) {
                "onEndOfSpeech (#$sessionId): انتهى الكلام — بانتظار النتيجة النهائية"
              } else {
                "onEndOfSpeech (#$sessionId): انتهى الكلام دون نتائج جزئية — بانتظار النتيجة النهائية"
              }
          )
      )
    }
  }

  private fun handlePartialResults(sessionId: Long, partialResults: Bundle?) {
    if (!shouldContinueListening || sessionId != activeSessionId || sessionHandledFinalResult) return
    val matches = extractCandidates(partialResults, includeUnstable = true)
    val best = DhikrSpeechMatcher.selectBestCandidate(matches)
    if (best.isBlank()) {
      logDiag("[جزئي #$sessionId] استُقبل onPartialResults لكن النص فارغ")
      return
    }

    sessionReceivedAnyText = true
    consecutiveEngineErrors = 0
    scheduleRecognitionWatchdog(sessionId, RECOGNITION_WATCHDOG_MS)
    keepNoMatchNoticeUntilMs = 0L
    pendingStatusRevertRunnable?.let { mainHandler.removeCallbacks(it) }

    val diagnostic = DhikrSpeechMatcher.diagnoseTranscript(best)
    if (!allowPartialMatch) {
      logDiag("[جزئي #$sessionId] النص=«$best» | تم تأجيل الاحتساب حتى onResults (allowPartialMatch=false)")
      _status.update {
        it.copy(
          isListening = true,
          lastHeardText = best,
          phase = VoiceListeningPhase.RECOGNIZING,
          statusMessage = "جاري التعرف على الصوت…",
          diagnostics =
            it.diagnostics.copy(
              recognizedText = best,
              normalizedText = diagnostic.normalizedText,
              matchedDhikrTitles = diagnostic.matchedCounts.keys.map { id -> titleById[id] ?: id },
              rejectionReason = "التعرف الجزئي معطّل — بانتظار النتيجة النهائية",
              dbSaveStatus = "بانتظار onResults",
              eventSummary = "onPartialResults (#$sessionId): وصل نص جزئي «$best»",
            ),
        )
      }
      return
    }

    val (matchedNow, _) = processTranscriptDelta(best, diagnostic, sourceLabel = "جزئي")
    if (!matchedNow) {
      val reason =
        if (diagnostic.matchedCounts.isNotEmpty()) {
          "تم احتساب الذكر مسبقاً في نفس الجملة (منع التكرار)"
        } else {
          diagnostic.rejectionReason
        }
      logDiag("[جزئي #$sessionId] النص=«$best» | المطبّع=«${diagnostic.normalizedText}» | السبب=$reason")
      _status.update {
        it.copy(
          isListening = true,
          lastHeardText = best,
          phase = VoiceListeningPhase.RECOGNIZING,
          statusMessage = "جاري التعرف على الصوت…",
          diagnostics =
            it.diagnostics.copy(
              recognizedText = best,
              normalizedText = diagnostic.normalizedText,
              matchedDhikrTitles =
                diagnostic.matchedCounts.keys.map { id -> titleById[id] ?: id },
              rejectionReason = reason,
              dbSaveStatus =
                if (sessionIncrementedAny) it.diagnostics.dbSaveStatus else "لم تُنفّذ زيادة بعد",
              eventSummary = "onPartialResults (#$sessionId): وصل نص جزئي «$best»",
            ),
        )
      }
    } else {
      _status.update {
        it.copy(
          isListening = true,
          lastHeardText = best,
          phase = VoiceListeningPhase.RECOGNIZING,
          statusMessage = "جاري التعرف على الصوت… تم احتساب الذكر ✓",
        )
      }
    }
  }

  private fun handleResults(sessionId: Long, results: Bundle?) {
    if (!shouldContinueListening || sessionId != activeSessionId || sessionHandledFinalResult) return
    sessionHandledFinalResult = true
    consecutiveEngineErrors = 0

    val matches = extractCandidates(results, includeUnstable = true)
    val best = DhikrSpeechMatcher.selectBestCandidate(matches)

    if (best.isNotBlank()) {
      sessionReceivedAnyText = true
      val diagnostic = DhikrSpeechMatcher.diagnoseTranscript(best)
      val (matchedNow, _) = processTranscriptDelta(best, diagnostic, sourceLabel = "نهائي")
      if (matchedNow || sessionIncrementedAny) {
        keepNoMatchNoticeUntilMs = 0L
        _status.update { current ->
          val title = current.lastMatchedDhikrTitle
          val updatedDiag =
            if (!matchedNow) {
              current.diagnostics.copy(
                recognizedText = best,
                normalizedText = diagnostic.normalizedText,
                matchedDhikrTitles =
                  diagnostic.matchedCounts.keys.map { id -> titleById[id] ?: id },
                rejectionReason =
                  diagnostic.rejectionReason
                    ?: "تم احتساب الذكر مسبقاً من النتيجة الجزئية (منع التكرار)",
                eventSummary = "onResults (#$sessionId): تأكيد النتيجة النهائية دون تكرار",
              )
            } else {
              current.diagnostics
            }
          current.copy(
            isListening = true,
            lastHeardText = best,
            phase = VoiceListeningPhase.LISTENING,
            statusMessage =
              if (!title.isNullOrBlank()) {
                "الميكروفون يعمل ويستمع • تم احتساب «$title» ✓"
              } else {
                "الميكروفون يعمل ويستمع • تم احتساب الذكر ✓"
              },
            diagnostics = updatedDiag,
          )
        }
      } else {
        keepNoMatchNoticeUntilMs = nowMsProvider() + NO_MATCH_DISPLAY_MS
        logDiag(
          "[نهائي #$sessionId] النص=«$best» | المطبّع=«${diagnostic.normalizedText}» | " +
            "سبب الرفض=${diagnostic.rejectionReason} | لم تُنفّذ زيادة"
        )
        _status.update {
          it.copy(
            isListening = true,
            lastHeardText = best,
            phase = VoiceListeningPhase.NO_SPEECH_MATCH,
            statusMessage = "لم يتم التعرف على الكلام",
            diagnostics =
              VoiceDhikrDiagnostics(
                recognizedText = best,
                normalizedText = diagnostic.normalizedText,
                matchedDhikrTitles = emptyList(),
                rejectionReason = diagnostic.rejectionReason,
                dbSaveStatus = "لم تُنفّذ زيادة (النص لا يطابق ذكراً)",
                eventSummary = "onResults (#$sessionId): وصل نص غير مطابق",
              ),
          )
        }
      }
    } else if (!sessionIncrementedAny) {
      keepNoMatchNoticeUntilMs = nowMsProvider() + NO_MATCH_DISPLAY_MS
      logDiag("[نهائي #$sessionId] استُقبل onResults بقائمة نتائج فارغة (matches=$matches)")
      _status.update {
        it.copy(
          isListening = true,
          phase = VoiceListeningPhase.NO_SPEECH_MATCH,
          statusMessage = "لم يتم التعرف على الكلام",
          diagnostics =
            VoiceDhikrDiagnostics(
              recognizedText = "",
              normalizedText = "",
              matchedDhikrTitles = emptyList(),
              rejectionReason = "أرجع محرك الصوت قائمة نتائج فارغة في onResults",
              dbSaveStatus = "لم تُنفّذ زيادة",
              eventSummary = "onResults (#$sessionId): قائمة فارغة",
            ),
        )
      }
    }

    alreadyCountedInUtterance.clear()
    // Two-phase teardown: destroy old recognizer NOW, then wait cooldown before next startListening.
    teardownEngineOnMain()
    scheduleNextSessionAfterCooldown(cooldownMs = NORMAL_RESTART_COOLDOWN_MS)
  }

  private fun handleError(sessionId: Long, error: Int) {
    if (!shouldContinueListening || sessionId != activeSessionId || sessionHandledFinalResult) return
    alreadyCountedInUtterance.clear()
    val errorLabel = errorName(error)
    logDiag("onError(#$sessionId -> $error / $errorLabel, consecutive=$consecutiveEngineErrors, onDevice=$preferOnDeviceFallback)")

    // Always tear down & release the failing SpeechRecognizer BEFORE waiting cooldown or switching.
    teardownEngineOnMain()

    when (error) {
      SpeechRecognizer.ERROR_NO_MATCH,
      SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
        consecutiveEngineErrors = 0
        if (!sessionIncrementedAny) {
          keepNoMatchNoticeUntilMs = nowMsProvider() + NO_MATCH_DISPLAY_MS
          _status.update {
            it.copy(
              isListening = true,
              phase = VoiceListeningPhase.NO_SPEECH_MATCH,
              statusMessage = "لم يتم التعرف على الكلام",
              diagnostics =
                it.diagnostics.copy(
                  rejectionReason = "استجابة محرك الصوت: $errorLabel (لم يتعرف المحرك على كلام واضح)",
                  dbSaveStatus = "لم تُنفّذ زيادة",
                  eventSummary = "onError (#$sessionId): $errorLabel — إعادة التشغيل بعد تحرير المحرك",
                ),
            )
          }
        }
        scheduleNextSessionAfterCooldown(cooldownMs = NORMAL_RESTART_COOLDOWN_MS)
      }
      SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
        failWithMicrophoneError(
          "تعذر تشغيل الميكروفون: يلزم منح صلاحية الميكروفون",
          reason = errorLabel,
        )
      }
      SpeechRecognizer.ERROR_AUDIO -> {
        consecutiveEngineErrors++
        if (consecutiveEngineErrors >= 2) {
          failWithMicrophoneError(
            "تعذر تشغيل الميكروفون: تأكد من عدم استخدام الميكروفون في تطبيق آخر",
            reason = errorLabel,
          )
        } else {
          scheduleNextSessionAfterCooldown(cooldownMs = RECOVERY_COOLDOWN_BASE_MS)
        }
      }
      ERROR_LANGUAGE_NOT_SUPPORTED,
      ERROR_LANGUAGE_UNAVAILABLE -> {
        consecutiveEngineErrors++
        if (preferOnDeviceFallback) {
          preferOnDeviceFallback = false
          onDeviceArabicUnavailableReason = "اللغة العربية ($preferredLanguageTag) غير مثبتة في المحرك المحلي"
          if (consecutiveEngineErrors >= MAX_CONSECUTIVE_ENGINE_ERRORS) {
            failWithMicrophoneError(
              "تعذر تشغيل التعرف الصوتي للغة العربية على هذا الجهاز",
              reason = "$errorLabel ($onDeviceArabicUnavailableReason)",
            )
          } else {
            _status.update {
              it.copy(
                diagnostics =
                  it.diagnostics.copy(
                    eventSummary = "المحرك المحلي لا يدعم العربية — الرجوع للمحرك الافتراضي",
                    rejectionReason = onDeviceArabicUnavailableReason,
                  )
              )
            }
            scheduleNextSessionAfterCooldown(cooldownMs = RECOVERY_COOLDOWN_BASE_MS)
          }
        } else {
          tryFallbackOrRetry(errorLabel)
        }
      }
      SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
      SpeechRecognizer.ERROR_SERVER_DISCONNECTED,
      SpeechRecognizer.ERROR_CLIENT,
      SpeechRecognizer.ERROR_NETWORK,
      SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
      SpeechRecognizer.ERROR_SERVER -> {
        consecutiveEngineErrors++
        if (consecutiveEngineErrors >= MAX_CONSECUTIVE_ENGINE_ERRORS) {
          val extraNote = onDeviceArabicUnavailableReason?.let { " ($it)" }.orEmpty()
          failWithMicrophoneError(
            "تعذر تشغيل الميكروفون: تعذر استقرار محرك التعرف الصوتي ($errorLabel)",
            reason = "توقف بعد $consecutiveEngineErrors محاولات بسبب $errorLabel$extraNote",
          )
        } else {
          tryFallbackOrRetry(errorLabel)
        }
      }
      else -> {
        consecutiveEngineErrors++
        if (consecutiveEngineErrors >= MAX_CONSECUTIVE_ENGINE_ERRORS) {
          failWithMicrophoneError("تعذر تشغيل الميكروفون ($errorLabel)", reason = errorLabel)
        } else {
          val backoffMs = computeBackoffCooldownMs(consecutiveEngineErrors)
          scheduleNextSessionAfterCooldown(cooldownMs = backoffMs)
        }
      }
    }
  }

  private fun tryFallbackOrRetry(errorLabel: String) {
    val backoffMs = computeBackoffCooldownMs(consecutiveEngineErrors)
    val shouldProbeOnDevice = !preferOnDeviceFallback && !triedOnDeviceFallback

    if (shouldProbeOnDevice) {
      triedOnDeviceFallback = true
      val generationAtProbe = activeSessionId
      _status.update {
        it.copy(
          isListening = true,
          phase = VoiceListeningPhase.LISTENING,
          statusMessage = "جاري إعادة تهيئة محرك التعرف الصوتي…",
          diagnostics =
            it.diagnostics.copy(
              eventSummary = "فحص إمكانية التحويل للمحرك المحلي العربي بعد $errorLabel",
              rejectionReason = "خطأ المحرك الافتراضي: $errorLabel",
            ),
        )
      }
      speechEngineClient.checkOnDeviceArabicSupport(appContext) { supported, localeTag ->
        runOnMain {
          if (!shouldContinueListening || generationAtProbe != activeSessionId) return@runOnMain
          if (supported) {
            preferOnDeviceFallback = true
            preferredLanguageTag = localeTag
            logDiag("التحويل إلى المحرك المحلي على الجهاز ($localeTag) بعد $errorLabel")
            _status.update {
              it.copy(
                isListening = true,
                phase = VoiceListeningPhase.LISTENING,
                statusMessage = "الميكروفون يعمل ويستمع (التعرف المحلي)",
                diagnostics =
                  it.diagnostics.copy(
                    eventSummary = "تم التحويل إلى التعرف المحلي ($localeTag) بعد $errorLabel",
                    rejectionReason = null,
                  ),
              )
            }
            scheduleNextSessionAfterCooldown(cooldownMs = RECOVERY_COOLDOWN_BASE_MS)
          } else {
            onDeviceArabicUnavailableReason = "التعرف المحلي غير متوفر أو لا يدعم العربية"
            logDiag("التعرف المحلي غير متاح/لا يدعم العربية — استمرار إعادة المحاولة المحدودة على الافتراضي ($backoffMs ms)")
            _status.update {
              it.copy(
                isListening = true,
                phase = VoiceListeningPhase.LISTENING,
                statusMessage = "الميكروفون يعمل ويستمع",
                diagnostics =
                  it.diagnostics.copy(
                    eventSummary = "تعافٍ بتأخير ${backoffMs}ms بعد $errorLabel (المحرك المحلي غير متاح للعربية)",
                    rejectionReason = "خطأ المحرك: $errorLabel • $onDeviceArabicUnavailableReason",
                  ),
              )
            }
            scheduleNextSessionAfterCooldown(cooldownMs = backoffMs)
          }
        }
      }
      return
    }

    _status.update {
      it.copy(
        isListening = true,
        phase = VoiceListeningPhase.LISTENING,
        statusMessage = "الميكروفون يعمل ويستمع",
        diagnostics =
          it.diagnostics.copy(
            eventSummary = "تعافٍ بتأخير ${backoffMs}ms بعد $errorLabel (محاولة $consecutiveEngineErrors/$MAX_CONSECUTIVE_ENGINE_ERRORS)",
            rejectionReason = "خطأ المحرك: $errorLabel",
          ),
      )
    }
    scheduleNextSessionAfterCooldown(cooldownMs = backoffMs)
  }

  private fun computeBackoffCooldownMs(attempt: Int): Long =
    (RECOVERY_COOLDOWN_BASE_MS * attempt.coerceAtLeast(1)).coerceAtMost(MAX_RECOVERY_COOLDOWN_MS)

  private fun errorName(code: Int): String =
    when (code) {
      SpeechRecognizer.ERROR_AUDIO -> "ERROR_AUDIO"
      SpeechRecognizer.ERROR_CLIENT -> "ERROR_CLIENT"
      SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "ERROR_INSUFFICIENT_PERMISSIONS"
      SpeechRecognizer.ERROR_NETWORK -> "ERROR_NETWORK"
      SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "ERROR_NETWORK_TIMEOUT"
      SpeechRecognizer.ERROR_NO_MATCH -> "ERROR_NO_MATCH"
      SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "ERROR_RECOGNIZER_BUSY"
      SpeechRecognizer.ERROR_SERVER -> "ERROR_SERVER"
      SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "ERROR_SPEECH_TIMEOUT"
      SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> "ERROR_SERVER_DISCONNECTED"
      ERROR_LANGUAGE_NOT_SUPPORTED -> "ERROR_LANGUAGE_NOT_SUPPORTED"
      ERROR_LANGUAGE_UNAVAILABLE -> "ERROR_LANGUAGE_UNAVAILABLE"
      else -> "ERROR_$code"
    }

  companion object {
    private const val TAG = "VoiceDhikrController"
    private const val DIAG_TAG = "VoiceDhikrDiag"
    private const val EXTRA_UNSTABLE_TEXT = "android.speech.extra.UNSTABLE_TEXT"
    private const val ERROR_LANGUAGE_NOT_SUPPORTED = 12
    private const val ERROR_LANGUAGE_UNAVAILABLE = 13
    private const val NO_MATCH_DISPLAY_MS = 1400L
    private const val NORMAL_RESTART_COOLDOWN_MS = 350L
    private const val RECOVERY_COOLDOWN_BASE_MS = 900L
    private const val MAX_RECOVERY_COOLDOWN_MS = 2800L
    private const val START_WATCHDOG_MS = 5000L
    private const val RECOGNITION_WATCHDOG_MS = 6500L
    private const val END_OF_SPEECH_WATCHDOG_MS = 2400L
    private const val MAX_CONSECUTIVE_ENGINE_ERRORS = 4
  }
}
