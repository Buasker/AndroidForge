package com.example.dhikr

data class DhikrMatchDiagnostic(
  val rawText: String,
  val normalizedText: String,
  val matchedCounts: Map<String, Int>,
  val rejectionReason: String?,
)

/**
 * Normalizes Arabic speech transcripts (stripping tashkeel, tatweel, punctuation, unifying alef/hamza/ya/ta marbuta,
 * and handling common Arabic speech-to-text recognition variations) and counts how many times each known dhikr
 * appears in the transcript.
 *
 * Also supports incremental delta calculation between partial and final recognition callbacks so the
 * same spoken repetition is never counted twice.
 */
object DhikrSpeechMatcher {
  private val tashkeelRegex = Regex("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]")
  private val tatweelRegex = Regex("[ـ]+")
  private val nonArabicRegex = Regex("[^\\u0621-\\u064A\\s]")
  private val multiSpaceRegex = Regex("\\s+")

  fun normalizeArabic(input: String): String {
    if (input.isBlank()) return ""
    val stripped =
      input
        .replace(tashkeelRegex, "")
        .replace(tatweelRegex, "")
        .replace('أ', 'ا')
        .replace('إ', 'ا')
        .replace('آ', 'ا')
        .replace('ٱ', 'ا')
        .replace('ى', 'ي')
        .replace('ی', 'ي')
        .replace('ے', 'ي')
        .replace('ک', 'ك')
        .replace('ة', 'ه')
        .replace('ۃ', 'ه')
        .replace('ہ', 'ه')
        .replace('ھ', 'ه')
        .replace('ؤ', 'و')
        .replace('ئ', 'ي')
        .replace(nonArabicRegex, " ")
        .replace(multiSpaceRegex, " ")
        .trim()
    return stripped
  }

  private val phrasePatterns: Map<String, List<Regex>> =
    mapOf(
      "tasbih" to
        listOf(
          Regex("""(?:^|\s)(?:و|ف)?سبحان\s*ا?لله(?:\s+وبحمده|\s+العظيم)?(?=\s|$)"""),
          Regex("""(?:^|\s)(?:و|ف)?سبحانه?\s+ا?لله(?=\s|$)"""),
        ),
      "hamd" to
        listOf(
          Regex("""(?:^|\s)(?:و|ف)?الحمد\s*(?:لله|الله|له)(?:\s+تعالي|\s+رب\s+العالمين)?(?=\s|$)"""),
          Regex("""(?:^|\s)(?:و)?لله\s+الحمد(?=\s|$)"""),
          Regex("""(?:^|\s)(?:و)?الحمدله(?=\s|$)"""),
        ),
      "takbir" to
        listOf(
          Regex("""(?:^|\s)(?:و|ف)?ا?لله(?:و|ا)?\s*اكبر(?:\s+كبيرا)?(?=\s|$)"""),
        ),
      "tahlil" to
        listOf(
          Regex("""(?:^|\s)(?:و|ف)?لا\s*ا?له\s*الا\s*ا?لله(?=\s|$)"""),
          Regex("""(?:^|\s)(?:و|ف)?لا\s+الاه\s+الا\s+ا?لله(?=\s|$)"""),
          Regex("""(?:^|\s)(?:و|ف)?لإله\s+الا\s+ا?لله""".replace('إ', 'ا') + """(?=\s|$)"""),
          Regex("""(?:^|\s)(?:و|ف)?لاله\s*الا\s*ا?لله(?=\s|$)"""),
        ),
      "istighfar" to
        listOf(
          Regex("""(?:^|\s)(?:و|ف)?استغفر\s*ا?لله(?:\s+العظيم)?(?=\s|$)"""),
          Regex("""(?:^|\s)استغفار(?=\s|$)"""),
          Regex("""(?:^|\s)رب\s+اغفر\s+لي(?=\s|$)"""),
          Regex("""(?:^|\s)اغفر\s+لي(?=\s|$)"""),
        ),
      "hawqala" to
        listOf(
          Regex("""(?:^|\s)(?:و|ف)?لا\s*حول\s*(?:و\s*لا|ولا)\s*قوه\s*(?:الا\s*بالله|بالله)?(?=\s|$)"""),
        ),
      "salawat" to
        listOf(
          Regex(
            """(?:^|\s)(?:و|ف)?اللهم\s+صلي?\s+(?:و\s*سلم\s+|وسلم\s+)?(?:و\s*بارك\s+|وبارك\s+)?(?:علي\s+)?(?:(?:نبينا|سيدنا|النبي)\s+)?محمد(?=\s|$)"""
          ),
          Regex("""(?:^|\s)صلي?\s+الله\s+عليه\s*(?:و\s*سلم|وسلم)(?=\s|$)"""),
          Regex("""(?:^|\s)عليه\s+الصلاه\s*(?:و\s*السلام|والسلام)(?=\s|$)"""),
          Regex("""(?:^|\s)اللهم\s+صلي?\s+علي\s+محمد(?=\s|$)"""),
        ),
    )

  /**
   * Returns a map of dhikr ID -> count found in [rawTranscript].
   */
  fun countOccurrences(rawTranscript: String): Map<String, Int> {
    val normalized = normalizeArabic(rawTranscript)
    if (normalized.isBlank()) return emptyMap()

    val counts = mutableMapOf<String, Int>()
    for ((id, patterns) in phrasePatterns) {
      var best = 0
      for (pattern in patterns) {
        val matches = pattern.findAll(normalized).count()
        if (matches > best) {
          best = matches
        }
      }
      if (best > 0) {
        counts[id] = best
      }
    }
    return counts
  }

  /**
   * Selects the strongest N-best transcript candidate returned by [SpeechRecognizer]:
   * prefers any candidate that yields a recognized dhikr match (highest total hits, then longest
   * normalized text), otherwise falls back to the first non-blank hypothesis.
   */
  fun selectBestCandidate(candidates: List<String>): String {
    val cleanCandidates = candidates.map { it.trim() }.filter { it.isNotEmpty() }
    if (cleanCandidates.isEmpty()) return ""
    return cleanCandidates
      .maxWithOrNull(
        compareBy<String>(
          { countOccurrences(it).values.sum() },
          { normalizeArabic(it).length },
        )
      )
      ?: cleanCandidates.first()
  }

  /**
   * Produces full diagnostic details explaining why a transcript matched or did not match any dhikr.
   */
  fun diagnoseTranscript(rawTranscript: String): DhikrMatchDiagnostic {
    val normalized = normalizeArabic(rawTranscript)
    if (rawTranscript.isBlank()) {
      return DhikrMatchDiagnostic(
        rawText = rawTranscript,
        normalizedText = normalized,
        matchedCounts = emptyMap(),
        rejectionReason = "النص المستلم من محرك التعرف فارغ",
      )
    }
    if (normalized.isBlank()) {
      return DhikrMatchDiagnostic(
        rawText = rawTranscript,
        normalizedText = normalized,
        matchedCounts = emptyMap(),
        rejectionReason = "النص المستلم لا يحتوي على حروف عربية صالحة",
      )
    }
    val counts = countOccurrences(rawTranscript)
    val reason =
      if (counts.isEmpty()) {
        "النص المطبّع «$normalized» لم يطابق أياً من صيغ الأذكار السبعة المعتمدة"
      } else {
        null
      }
    return DhikrMatchDiagnostic(
      rawText = rawTranscript,
      normalizedText = normalized,
      matchedCounts = counts,
      rejectionReason = reason,
    )
  }

  /**
   * Given an in-progress utterance state map (`id -> maxCountAlreadyCounted`), calculates only newly
   * spoken repetitions in [rawTranscript] and updates [alreadyCountedInUtterance].
   */
  fun computeIncrementalDelta(
    rawTranscript: String,
    alreadyCountedInUtterance: MutableMap<String, Int>,
  ): Map<String, Int> {
    val currentTotals = countOccurrences(rawTranscript)
    val delta = mutableMapOf<String, Int>()
    for ((id, currentCount) in currentTotals) {
      val prev = alreadyCountedInUtterance[id] ?: 0
      if (currentCount > prev) {
        delta[id] = currentCount - prev
        alreadyCountedInUtterance[id] = currentCount
      }
    }
    return delta
  }

  /**
   * Diagnostic helper.
   */
  fun debugMatch(rawTranscript: String): String {
    val normalized = normalizeArabic(rawTranscript)
    val matches = countOccurrences(rawTranscript)
    return buildString {
      appendLine("النص الأصلي: $rawTranscript")
      appendLine("النص بعد التطبيع: $normalized")
      appendLine("نتائج المطابقة:")
      if (matches.isEmpty()) {
        appendLine("لم يتم العثور على ذكر مطابق")
      } else {
        matches.forEach { (id, count) ->
          appendLine("$id = $count")
        }
      }
    }
  }
}
