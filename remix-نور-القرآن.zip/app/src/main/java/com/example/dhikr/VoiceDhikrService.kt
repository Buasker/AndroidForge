package com.example.dhikr

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.NoorApplication
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Microphone Foreground Service keeping Voice Dhikr listening alive across screen navigation
 * and when the screen is turned off.
 */
class VoiceDhikrService : Service() {

  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private var statusObserverJob: Job? = null
  private var wakeLock: PowerManager.WakeLock? = null

  override fun onCreate() {
    super.onCreate()
    ensureNotificationChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val controller = (application as NoorApplication).container.voiceDhikrController
    if (intent?.action == ACTION_STOP) {
      controller.pauseListening()
      releaseWakeLock()
      stopForeground(STOP_FOREGROUND_REMOVE)
      stopSelf()
      return START_NOT_STICKY
    }

    val hasMicPermission =
      ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED
    if (!hasMicPermission || !controller.status.value.isListening) {
      releaseWakeLock()
      stopForeground(STOP_FOREGROUND_REMOVE)
      stopSelf()
      return START_NOT_STICKY
    }

    acquireWakeLock()

    val foregroundType =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
      } else {
        0
      }

    val started =
      runCatching {
          ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(controller.status.value),
            foregroundType,
          )
        }
        .isSuccess

    if (!started) {
      releaseWakeLock()
      stopSelf()
      return START_NOT_STICKY
    }

    if (statusObserverJob == null) {
      statusObserverJob =
        serviceScope.launch {
          controller.status.collect { latestStatus ->
            if (!latestStatus.isListening) {
              releaseWakeLock()
              stopForeground(STOP_FOREGROUND_REMOVE)
              stopSelf()
            } else {
              val nm = getSystemService(NotificationManager::class.java)
              nm?.notify(NOTIFICATION_ID, buildNotification(latestStatus))
            }
          }
        }
    }

    return START_STICKY
  }

  override fun onDestroy() {
    statusObserverJob?.cancel()
    statusObserverJob = null
    serviceScope.cancel()
    releaseWakeLock()
    super.onDestroy()
  }

  override fun onBind(intent: Intent?): IBinder? = null

  private fun acquireWakeLock() {
    if (wakeLock?.isHeld == true) return
    val pm = getSystemService(PowerManager::class.java) ?: return
    wakeLock =
      pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NoorQuran:VoiceDhikrWakeLock").apply {
        setReferenceCounted(false)
        acquire(MAX_WAKELOCK_MS)
      }
  }

  private fun releaseWakeLock() {
    runCatching {
      if (wakeLock?.isHeld == true) {
        wakeLock?.release()
      }
    }
    wakeLock = null
  }

  private fun buildNotification(status: VoiceDhikrStatus): Notification {
    val openAppIntent =
      Intent(this, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
      }
    val contentPendingIntent =
      PendingIntent.getActivity(
        this,
        10,
        openAppIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

    val stopIntent = Intent(this, VoiceDhikrService::class.java).apply { action = ACTION_STOP }
    val stopPendingIntent =
      PendingIntent.getService(
        this,
        11,
        stopIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentTitle("عداد الذكر الصوتي — نور القرآن")
      .setContentText(status.statusMessage)
      .setContentIntent(contentPendingIntent)
      .setOngoing(true)
      .setSilent(true)
      .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
      .addAction(
        android.R.drawable.ic_media_pause,
        "إيقاف الاستماع",
        stopPendingIntent,
      )
      .build()
  }

  private fun ensureNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel =
        NotificationChannel(
            CHANNEL_ID,
            "عداد الذكر الصوتي",
            NotificationManager.IMPORTANCE_LOW,
          )
          .apply {
            description = "إشعار استمرار الاستماع الصوتي للأذكار في الخلفية وعند إطفاء الشاشة"
            setShowBadge(false)
          }
      getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
    }
  }

  companion object {
    const val CHANNEL_ID = "noor_voice_dhikr"
    const val NOTIFICATION_ID = 7002
    const val ACTION_START = "com.example.action.VOICE_DHIKR_START"
    const val ACTION_STOP = "com.example.action.VOICE_DHIKR_STOP"
    private const val MAX_WAKELOCK_MS = 4L * 60L * 60L * 1000L
  }
}
