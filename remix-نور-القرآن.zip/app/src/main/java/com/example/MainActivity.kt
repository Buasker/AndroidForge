package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ReaderSettings
import com.example.notifications.ReminderChannelHelper
import com.example.ui.navigation.NoorAppRoot
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.NoorQuranTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    val container = (application as NoorApplication).container
    val rawReminderType = intent?.getStringExtra(ReminderChannelHelper.EXTRA_REMINDER_TYPE)
    val initialReminderTypeId =
      com.example.data.model.ReminderType.entries.firstOrNull { it.id == rawReminderType }?.id

    setContent {
      val settings by
        container.preferencesRepository.readerSettingsFlow.collectAsStateWithLifecycle(
          initialValue = ReaderSettings()
        )
      var showSplash by rememberSaveable { mutableStateOf(initialReminderTypeId == null) }

      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        NoorQuranTheme(themeMode = settings.themeMode) {
          if (showSplash) {
            SplashScreen(onFinished = { showSplash = false })
          } else {
            NoorAppRoot(
              appContainer = container,
              currentThemeMode = settings.themeMode,
              initialReminderTypeId = initialReminderTypeId,
            )
          }
        }
      }
    }
  }
}
