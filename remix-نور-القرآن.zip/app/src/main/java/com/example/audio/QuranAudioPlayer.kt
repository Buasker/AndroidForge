package com.example.audio

import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.PowerManager
import com.example.data.firebase.FreeAudioHostingService
import com.example.data.model.AyahItem
import com.example.data.model.QuranCatalog
import com.example.data.model.ReciterOption
import com.example.data.model.SurahInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient

enum class AudioPlaybackMode {
  AYAH_BY_AYAH,
  FULL_SURAH,
}

data class AudioPlaybackState(
  val isActive: Boolean = false,
  val isPlaying: Boolean = false,
  val isBuffering: Boolean = false,
  val mode: AudioPlaybackMode = AudioPlaybackMode.AYAH_BY_AYAH,
  val surahNumber: Int = 0,
  val surahArabicName: String = "",
  val currentAyahInSurah: Int = 0,
  val totalAyahsInSurah: Int = 0,
  val reciterId: String = "ar.alafasy",
  val reciterName: String = "مشاري العفاسي",
  val positionMs: Int = 0,
  val durationMs: Int = 0,
  val volume: Float = 1.0f,
  val trackId: String = "",
  val trackDescription: String = "",
  val errorMessage: String? = null,
)

class QuranAudioPlayer(
  private val appContext: Context,
  private val resolveSurahSource: suspend (reciterId: String, surahNumber: Int) -> String,
) {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
  private var mediaPlayer: MediaPlayer? = null
  private var progressJob: Job? = null

  private var currentPlaylist: List<AyahItem> = emptyList()
  private var currentSurah: SurahInfo? = null
  private var currentIndex: Int = -1
  private var activeReciterId: String = "ar.alafasy"
  private var currentVolume: Float = 1.0f
  private var knownReciters: Map<String, ReciterOption> =
    QuranCatalog.reciters.associateBy { it.identifier }

  private val _state = MutableStateFlow(AudioPlaybackState())
  val state: StateFlow<AudioPlaybackState> = _state.asStateFlow()

  fun updateKnownReciters(reciters: List<ReciterOption>) {
    knownReciters = reciters.associateBy { it.identifier }
  }

  fun setVolume(volume: Float) {
    currentVolume = volume.coerceIn(0f, 1f)
    runCatching { mediaPlayer?.setVolume(currentVolume, currentVolume) }
    _state.update { it.copy(volume = currentVolume) }
  }

  fun playAyah(
    surah: SurahInfo,
    ayahs: List<AyahItem>,
    startAyahInSurah: Int,
    reciterId: String,
  ) {
    val reciter =
      knownReciters[reciterId] ?: QuranCatalog.reciters.firstOrNull { it.identifier == reciterId }
    // If reciter does not have ayah-by-ayah CDN (e.g. Khalid Al-Jaleel or custom local/cloud reciters), gracefully play Full Surah
    if (reciter?.everyAyahFolder == null && reciter?.islamicNetworkId == null) {
      playFullSurah(surah, reciterId, reciter?.arabicName)
      return
    }
    currentSurah = surah
    currentPlaylist = ayahs
    activeReciterId = reciterId
    val idx = ayahs.indexOfFirst { it.numberInSurah == startAyahInSurah }
    if (idx < 0) return
    currentIndex = idx
    playCurrentAyahIndex()
  }

  fun playFullSurah(
    surah: SurahInfo,
    reciterId: String,
    reciterDisplayName: String? = null,
  ) {
    currentSurah = surah
    currentPlaylist = emptyList()
    currentIndex = -1
    activeReciterId = reciterId
    val reciterName =
      reciterDisplayName
        ?: knownReciters[reciterId]?.arabicName
        ?: QuranCatalog.reciters.firstOrNull { it.identifier == reciterId }?.arabicName
        ?: "القارئ"

    releasePlayer()
    _state.value =
      AudioPlaybackState(
        isActive = true,
        isPlaying = false,
        isBuffering = true,
        mode = AudioPlaybackMode.FULL_SURAH,
        surahNumber = surah.number,
        surahArabicName = surah.arabicName,
        currentAyahInSurah = 0,
        totalAyahsInSurah = surah.numberOfAyahs,
        reciterId = reciterId,
        reciterName = reciterName,
        volume = currentVolume,
      )
    syncForegroundService()

    scope.launch {
      val sourceResult = runCatching { resolveSurahSource(reciterId, surah.number) }
      sourceResult
        .onSuccess { source ->
          startMediaPlayer(
            dataSource = source,
            onCompleted = { stop() },
          )
        }
        .onFailure { err ->
          _state.update {
            it.copy(
              isBuffering = false,
              isPlaying = false,
              errorMessage = err.localizedMessage ?: "تعذر العثور على رابط التلاوة لهذه السورة.",
            )
          }
          syncForegroundService()
        }
    }
  }

  fun playCustomRecitation(
    trackId: String,
    surahNumber: Int,
    surahArabicName: String,
    reciterId: String,
    reciterDisplayName: String,
    audioUrl: String,
    description: String = "",
  ) {
    currentSurah =
      QuranCatalog.reciters.let {
        com.example.data.local.QuranSeedData.surahs
          .firstOrNull { s -> s.number == surahNumber }
          ?.let { s ->
            SurahInfo(
              number = s.number,
              arabicName = s.arabicName,
              englishName = s.englishName,
              englishNameTranslation = s.englishNameTranslation,
              numberOfAyahs = s.numberOfAyahs,
              revelationType = s.revelationType,
            )
          }
      }
    currentPlaylist = emptyList()
    currentIndex = -1
    activeReciterId = reciterId

    releasePlayer()
    _state.value =
      AudioPlaybackState(
        isActive = true,
        isPlaying = false,
        isBuffering = true,
        mode = AudioPlaybackMode.FULL_SURAH,
        surahNumber = surahNumber,
        surahArabicName = surahArabicName,
        currentAyahInSurah = 0,
        totalAyahsInSurah = currentSurah?.numberOfAyahs ?: 0,
        reciterId = reciterId,
        reciterName = reciterDisplayName,
        volume = currentVolume,
        trackId = trackId,
        trackDescription = description.trim(),
      )
    syncForegroundService()
    startMediaPlayer(
      dataSource = audioUrl,
      onCompleted = { stop() },
    )
  }

  fun togglePlayPause() {
    val player = mediaPlayer ?: return
    val current = _state.value
    if (!current.isActive || current.isBuffering) return

    if (player.isPlaying) {
      player.pause()
      _state.update { it.copy(isPlaying = false) }
    } else {
      player.start()
      _state.update { it.copy(isPlaying = true) }
    }
    syncForegroundService()
  }

  fun seekTo(positionMs: Int) {
    val player = mediaPlayer ?: return
    val safePos = positionMs.coerceIn(0, _state.value.durationMs.coerceAtLeast(0))
    runCatching { player.seekTo(safePos) }
    _state.update { it.copy(positionMs = safePos) }
  }

  fun seekBySeconds(deltaSeconds: Int) {
    val player = mediaPlayer ?: return
    if (_state.value.isBuffering) return
    val current = runCatching { player.currentPosition }.getOrDefault(0)
    val duration = runCatching { player.duration }.getOrDefault(0)
    val target = (current + deltaSeconds * 1000).coerceIn(0, duration.coerceAtLeast(0))
    runCatching { player.seekTo(target) }
    _state.update { it.copy(positionMs = target) }
  }

  fun playNext() {
    if (_state.value.mode == AudioPlaybackMode.AYAH_BY_AYAH) {
      if (currentIndex + 1 < currentPlaylist.size) {
        currentIndex++
        playCurrentAyahIndex()
      } else {
        stop()
      }
    } else {
      seekBySeconds(10)
    }
  }

  fun playPrevious() {
    if (_state.value.mode == AudioPlaybackMode.AYAH_BY_AYAH) {
      if (currentIndex > 0) {
        currentIndex--
        playCurrentAyahIndex()
      }
    } else {
      seekBySeconds(-10)
    }
  }

  fun updateReciterIfPlaying(newReciterId: String) {
    if (activeReciterId == newReciterId) return
    activeReciterId = newReciterId
    val current = _state.value
    val surah = currentSurah ?: return
    if (!current.isActive) return
    if (current.mode == AudioPlaybackMode.FULL_SURAH) {
      playFullSurah(surah, newReciterId)
    } else if (currentIndex in currentPlaylist.indices) {
      playAyah(surah, currentPlaylist, currentPlaylist[currentIndex].numberInSurah, newReciterId)
    }
  }

  fun stop() {
    releasePlayer()
    currentIndex = -1
    _state.value = AudioPlaybackState(volume = currentVolume)
    runCatching { appContext.stopService(Intent(appContext, QuranAudioService::class.java)) }
  }

  fun release() {
    stop()
  }

  private fun playCurrentAyahIndex() {
    val surah = currentSurah ?: return
    val ayah = currentPlaylist.getOrNull(currentIndex) ?: return
    val reciter =
      knownReciters[activeReciterId]
        ?: QuranCatalog.reciters.firstOrNull { it.identifier == activeReciterId }
    val reciterName = reciter?.arabicName ?: "القارئ"

    val url =
      when {
        reciter?.everyAyahFolder != null -> {
          val s = surah.number.toString().padStart(3, '0')
          val a = ayah.numberInSurah.toString().padStart(3, '0')
          "https://everyayah.com/data/${reciter.everyAyahFolder}/$s$a.mp3"
        }
        reciter?.islamicNetworkId != null -> {
          "https://cdn.islamic.network/quran/audio/128/${reciter.islamicNetworkId}/${ayah.globalNumber}.mp3"
        }
        else -> {
          playFullSurah(surah, activeReciterId, reciter?.arabicName)
          return
        }
      }

    releasePlayer()
    _state.value =
      AudioPlaybackState(
        isActive = true,
        isPlaying = false,
        isBuffering = true,
        mode = AudioPlaybackMode.AYAH_BY_AYAH,
        surahNumber = surah.number,
        surahArabicName = surah.arabicName,
        currentAyahInSurah = ayah.numberInSurah,
        totalAyahsInSurah = surah.numberOfAyahs,
        reciterId = activeReciterId,
        reciterName = reciterName,
        volume = currentVolume,
      )
    syncForegroundService()

    startMediaPlayer(
      dataSource = url,
      onCompleted = {
        if (currentIndex + 1 < currentPlaylist.size) {
          currentIndex++
          playCurrentAyahIndex()
        } else {
          stop()
        }
      },
    )
  }

  private val urlValidator = FreeAudioHostingService(OkHttpClient())

  internal fun isAllowedAudioDataSource(dataSource: String): Boolean {
    if (dataSource.startsWith("https://")) {
      return runCatching { urlValidator.validatePublicAudioUrl(dataSource) }.isSuccess
    }
    val appAudioPrefix = java.io.File(appContext.filesDir, "audio").canonicalPath
    val candidate = runCatching { java.io.File(dataSource).canonicalPath }.getOrNull() ?: return false
    return candidate.startsWith("$appAudioPrefix${java.io.File.separator}")
  }

  private fun startMediaPlayer(
    dataSource: String,
    onCompleted: () -> Unit,
  ) {
    if (!isAllowedAudioDataSource(dataSource)) {
      _state.update {
        it.copy(
          isBuffering = false,
          isPlaying = false,
          errorMessage = "مصدر التلاوة غير آمن أو غير مصرح به.",
        )
      }
      return
    }
    try {
      val mp =
        MediaPlayer().apply {
          setWakeMode(appContext, PowerManager.PARTIAL_WAKE_LOCK)
          setAudioAttributes(
            AudioAttributes.Builder()
              .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
              .setUsage(AudioAttributes.USAGE_MEDIA)
              .build()
          )
          setVolume(currentVolume, currentVolume)
          setDataSource(dataSource)
          setOnPreparedListener { preparedPlayer ->
            preparedPlayer.start()
            val dur = runCatching { preparedPlayer.duration }.getOrDefault(0).coerceAtLeast(0)
            _state.update {
              it.copy(
                isBuffering = false,
                isPlaying = true,
                durationMs = dur,
                positionMs = 0,
                errorMessage = null,
              )
            }
            startProgressTicker()
            syncForegroundService()
          }
          setOnCompletionListener { onCompleted() }
          setOnErrorListener { _, _, _ ->
            _state.update {
              it.copy(
                isBuffering = false,
                isPlaying = false,
                errorMessage = "تعذر تشغيل التلاوة. يرجى التحقق من الاتصال بالإنترنت.",
              )
            }
            syncForegroundService()
            true
          }
          prepareAsync()
        }
      mediaPlayer = mp
    } catch (e: Exception) {
      _state.update {
        it.copy(
          isBuffering = false,
          isPlaying = false,
          errorMessage = e.localizedMessage ?: "خطأ في تشغيل الصوت",
        )
      }
    }
  }

  private fun startProgressTicker() {
    progressJob?.cancel()
    progressJob =
      scope.launch {
        while (isActive) {
          val player = mediaPlayer
          if (player != null && _state.value.isPlaying) {
            val pos = runCatching { player.currentPosition }.getOrDefault(0).coerceAtLeast(0)
            val dur = runCatching { player.duration }.getOrDefault(_state.value.durationMs).coerceAtLeast(0)
            _state.update { it.copy(positionMs = pos, durationMs = dur) }
          }
          delay(500L)
        }
      }
  }

  private fun syncForegroundService() {
    val intent = Intent(appContext, QuranAudioService::class.java)
    runCatching {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        appContext.startForegroundService(intent)
      } else {
        appContext.startService(intent)
      }
    }
  }

  private fun releasePlayer() {
    progressJob?.cancel()
    progressJob = null
    runCatching {
      mediaPlayer?.reset()
      mediaPlayer?.release()
    }
    mediaPlayer = null
  }
}
