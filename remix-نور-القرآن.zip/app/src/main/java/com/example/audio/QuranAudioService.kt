package com.example.audio

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.MainActivity
import com.example.NoorApplication
import com.example.R

class QuranAudioService : Service() {
  companion object {
    const val CHANNEL_ID = "noor_audio_playback"
    const val NOTIFICATION_ID = 7001
    const val ACTION_PLAY_PAUSE = "com.example.action.AUDIO_PLAY_PAUSE"
    const val ACTION_NEXT = "com.example.action.AUDIO_NEXT"
    const val ACTION_PREV = "com.example.action.AUDIO_PREV"
    const val ACTION_STOP = "com.example.action.AUDIO_STOP"
  }

  override fun onCreate() {
    super.onCreate()
    ensureNotificationChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val player = (application as NoorApplication).container.audioPlayer
    when (intent?.action) {
      ACTION_PLAY_PAUSE -> player.togglePlayPause()
      ACTION_NEXT -> player.playNext()
      ACTION_PREV -> player.playPrevious()
      ACTION_STOP -> {
        player.stop()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        return START_NOT_STICKY
      }
    }

    val state = player.state.value
    if (!state.isActive) {
      stopForeground(STOP_FOREGROUND_REMOVE)
      stopSelf()
      return START_NOT_STICKY
    }

    val foregroundType =
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
      } else {
        0
      }
    ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(state), foregroundType)
    return START_STICKY
  }

  override fun onBind(intent: Intent?): IBinder? = null

  private fun buildNotification(state: AudioPlaybackState): Notification {
    val openAppIntent =
      Intent(this, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
      }
    val contentPendingIntent =
      PendingIntent.getActivity(
        this,
        0,
        openAppIntent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )

    fun actionPendingIntent(action: String, code: Int): PendingIntent {
      val i = Intent(this, QuranAudioService::class.java).apply { this.action = action }
      return PendingIntent.getService(
        this,
        code,
        i,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
      )
    }

    val subtitle =
      when {
        state.mode == AudioPlaybackMode.AYAH_BY_AYAH && state.currentAyahInSurah > 0 ->
          "${state.reciterName} • الآية ${state.currentAyahInSurah}"
        state.trackDescription.isNotBlank() ->
          "${state.reciterName} • ${state.trackDescription}"
        else -> "${state.reciterName} • تلاوة السورة كاملة"
      }

    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentTitle(state.surahArabicName.ifBlank { "نور القرآن" })
      .setContentText(subtitle)
      .setContentIntent(contentPendingIntent)
      .setOngoing(state.isPlaying)
      .setSilent(true)
      .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
      .addAction(
        android.R.drawable.ic_media_previous,
        "السابق",
        actionPendingIntent(ACTION_PREV, 1),
      )
      .addAction(
        if (state.isPlaying) android.R.drawable.ic_media_pause
        else android.R.drawable.ic_media_play,
        if (state.isPlaying) "إيقاف" else "تشغيل",
        actionPendingIntent(ACTION_PLAY_PAUSE, 2),
      )
      .addAction(
        android.R.drawable.ic_media_next,
        "التالي",
        actionPendingIntent(ACTION_NEXT, 3),
      )
      .addAction(
        android.R.drawable.ic_menu_close_clear_cancel,
        "إغلاق",
        actionPendingIntent(ACTION_STOP, 4),
      )
      .build()
  }

  private fun ensureNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel =
        NotificationChannel(
            CHANNEL_ID,
            "تشغيل القرآن الكريم",
            NotificationManager.IMPORTANCE_LOW,
          )
          .apply {
            description = "إشعار التحكم في تلاوة القرآن الكريم بالخلفية"
            setShowBadge(false)
          }
      getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
  }
}
