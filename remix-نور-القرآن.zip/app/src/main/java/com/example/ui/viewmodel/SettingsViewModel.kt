package com.example.ui.viewmodel

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.audio.QuranAudioPlayer
import com.example.data.firebase.AdminPrivilegeStatus
import com.example.data.firebase.FirebaseAuthManager
import com.example.data.firebase.FirebaseQuranBackendRepository
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.QuranCatalog
import com.example.data.model.ReaderSettings
import com.example.data.model.ReaderThemeMode
import com.example.data.model.ReciterOption
import com.example.data.model.ReminderPreference
import com.example.data.model.ReminderType
import com.example.data.repository.QuranRepository
import com.example.notifications.ReminderScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
  application: Application,
  private val quranRepository: QuranRepository,
  private val preferencesRepository: UserPreferencesRepository,
  private val audioPlayer: QuranAudioPlayer,
  private val authManager: FirebaseAuthManager,
  private val backendRepository: FirebaseQuranBackendRepository,
) : AndroidViewModel(application) {

  val settings: StateFlow<ReaderSettings> =
    preferencesRepository.readerSettingsFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = ReaderSettings(),
    )

  val reminders: StateFlow<List<ReminderPreference>> =
    preferencesRepository.remindersFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue =
        ReminderType.entries.map { ReminderPreference(it, false, it.defaultHour, it.defaultMinute) },
    )

  val reciters: StateFlow<List<ReciterOption>> =
    combine(
        backendRepository.observePublishedReciters(),
        quranRepository.localRecitersFlow,
      ) { cloudReciters, localReciters ->
        val merged = RecitersViewModel.mergePublishedAndCatalogReciters(cloudReciters, localReciters)
        audioPlayer.updateKnownReciters(merged)
        merged
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = QuranCatalog.reciters,
      )

  private val _adminStatus = MutableStateFlow(AdminPrivilegeStatus())
  val adminStatus: StateFlow<AdminPrivilegeStatus> = _adminStatus.asStateFlow()

  private val _authBusy = MutableStateFlow(false)
  val authBusy: StateFlow<Boolean> = _authBusy.asStateFlow()

  private val _authMessage = MutableStateFlow<String?>(null)
  val authMessage: StateFlow<String?> = _authMessage.asStateFlow()

  init {
    refreshAdminStatus()
    viewModelScope.launch {
      authManager.authStateFlow().collect {
        refreshAdminStatus()
      }
    }
  }

  fun refreshAdminStatus() {
    viewModelScope.launch {
      _adminStatus.value = authManager.verifyAdminPrivileges(forceRefreshToken = false)
    }
  }

  fun signInWithGoogle(activity: Activity) {
    if (_authBusy.value) return
    viewModelScope.launch {
      _authBusy.value = true
      val result = authManager.signInWithGoogle(activity)
      if (result.isSuccess) {
        backendRepository.syncUserProfileOnSignIn(settings.value.reciterIdentifier)
        val status = authManager.verifyAdminPrivileges(forceRefreshToken = true)
        _adminStatus.value = status
        _authMessage.value =
          if (status.isSuperAdmin) "تم تسجيل الدخول بحساب المالك الموثّق"
          else "تم تسجيل الدخول بنجاح"
      } else {
        _authMessage.value =
          result.exceptionOrNull()?.localizedMessage ?: "تعذر تسجيل الدخول حالياً."
      }
      _authBusy.value = false
    }
  }

  fun signOut() {
    if (_authBusy.value) return
    viewModelScope.launch {
      _authBusy.value = true
      authManager.signOut(getApplication())
      _adminStatus.value = AdminPrivilegeStatus(isAuthenticated = false)
      _authMessage.value = "تم تسجيل الخروج"
      _authBusy.value = false
    }
  }

  fun clearAuthMessage() {
    _authMessage.value = null
  }

  fun updateThemeMode(mode: ReaderThemeMode) {
    viewModelScope.launch { preferencesRepository.updateThemeMode(mode) }
  }

  fun updateArabicFontSize(size: Float) {
    viewModelScope.launch { preferencesRepository.updateArabicFontSize(size) }
  }

  fun updateTafsirFontSize(size: Float) {
    viewModelScope.launch { preferencesRepository.updateTafsirFontSize(size) }
  }

  fun updateAdhkarFontSize(size: Float) {
    viewModelScope.launch { preferencesRepository.updateAdhkarFontSize(size) }
  }

  fun updateReciter(reciterId: String) {
    viewModelScope.launch {
      preferencesRepository.updateReciter(reciterId)
      audioPlayer.updateReciterIfPlaying(reciterId)
    }
  }

  fun updateTranslationEdition(edition: String) {
    viewModelScope.launch { preferencesRepository.updateTranslationEdition(edition) }
  }

  fun updateShowTranslation(show: Boolean) {
    viewModelScope.launch { preferencesRepository.updateShowTranslation(show) }
  }

  fun updateVoicePartialMatch(allow: Boolean) {
    viewModelScope.launch { preferencesRepository.updateVoicePartialMatch(allow) }
  }

  fun updateReminder(type: ReminderType, enabled: Boolean, hour: Int, minute: Int) {
    viewModelScope.launch {
      preferencesRepository.updateReminder(type, enabled, hour, minute)
      if (type == ReminderType.DAILY_PAGE) {
        preferencesRepository.updateDailyPageSchedule(hour, minute, enabled)
      }
      ReminderScheduler.scheduleOrCancel(
        context = getApplication(),
        type = type,
        enabled = enabled,
        hour = hour,
        minute = minute,
      )
    }
  }

  companion object {
    fun factory(
      application: Application,
      quranRepository: QuranRepository,
      preferencesRepository: UserPreferencesRepository,
      audioPlayer: QuranAudioPlayer,
      authManager: FirebaseAuthManager,
      backendRepository: FirebaseQuranBackendRepository,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return SettingsViewModel(
            application = application,
            quranRepository = quranRepository,
            preferencesRepository = preferencesRepository,
            audioPlayer = audioPlayer,
            authManager = authManager,
            backendRepository = backendRepository,
          ) as T
        }
      }
  }
}
