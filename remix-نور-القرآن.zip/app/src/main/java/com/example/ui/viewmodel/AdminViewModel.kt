package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioPlaybackState
import com.example.audio.QuranAudioPlayer
import com.example.data.firebase.AdminPrivilegeStatus
import com.example.data.firebase.AudioHostingProvider
import com.example.data.firebase.ExternalAudioMetadata
import com.example.data.firebase.FirebaseAuthManager
import com.example.data.firebase.FirebaseQuranBackendRepository
import com.example.data.firebase.FirebaseRecitationTrack
import com.example.data.firebase.FirebaseReciter
import com.example.data.local.QuranSeedData
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class AdminViewModel(
  private val authManager: FirebaseAuthManager,
  private val backendRepository: FirebaseQuranBackendRepository,
  private val audioPlayer: QuranAudioPlayer,
) : ViewModel() {

  private val _adminStatus = MutableStateFlow(AdminPrivilegeStatus())
  val adminStatus: StateFlow<AdminPrivilegeStatus> = _adminStatus.asStateFlow()

  private val _isCheckingAuth = MutableStateFlow(true)
  val isCheckingAuth: StateFlow<Boolean> = _isCheckingAuth.asStateFlow()

  private val _selectedReciterId = MutableStateFlow<String?>(null)
  val selectedReciterId: StateFlow<String?> = _selectedReciterId.asStateFlow()

  private val _isBusy = MutableStateFlow(false)
  val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

  private val _isProbingUrl = MutableStateFlow(false)
  val isProbingUrl: StateFlow<Boolean> = _isProbingUrl.asStateFlow()

  private val _probeResult = MutableStateFlow<Result<ExternalAudioMetadata>?>(null)
  val probeResult: StateFlow<Result<ExternalAudioMetadata>?> = _probeResult.asStateFlow()

  private val _statusMessage = MutableStateFlow<String?>(null)
  val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

  val audioState: StateFlow<AudioPlaybackState> = audioPlayer.state

  val reciters: StateFlow<List<FirebaseReciter>> =
    _adminStatus
      .flatMapLatest { status ->
        if (!status.isSuperAdmin) {
          flowOf(emptyList())
        } else {
          backendRepository.observeAllRecitersAsAdmin().catch { e ->
            _statusMessage.value = e.localizedMessage ?: "تعذر تحميل قائمة القراء من السحابة."
            emit(emptyList())
          }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  val recitationsForSelectedReciter: StateFlow<List<FirebaseRecitationTrack>> =
    combine(_adminStatus, _selectedReciterId) { status, reciterId -> status to reciterId }
      .flatMapLatest { (status, reciterId) ->
        if (!status.isSuperAdmin || reciterId.isNullOrBlank()) {
          flowOf(emptyList())
        } else {
          backendRepository.observeAllRecitationsAsAdmin(reciterId).catch { e ->
            _statusMessage.value = e.localizedMessage ?: "تعذر تحميل التلاوات."
            emit(emptyList())
          }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  init {
    refreshPrivilegeStatus()
    viewModelScope.launch {
      authManager.authStateFlow().collect {
        refreshPrivilegeStatus()
      }
    }
  }

  fun refreshPrivilegeStatus() {
    viewModelScope.launch {
      _isCheckingAuth.value = true
      val status = authManager.verifyAdminPrivileges(forceRefreshToken = true)
      _adminStatus.value = status
      _isCheckingAuth.value = false
    }
  }

  fun selectReciter(reciterId: String?) {
    _selectedReciterId.value = reciterId
  }

  fun probeAudioUrl(url: String) {
    viewModelScope.launch {
      _isProbingUrl.value = true
      _probeResult.value = backendRepository.probeAudioUrl(url)
      _isProbingUrl.value = false
    }
  }

  fun clearProbeResult() {
    _probeResult.value = null
  }

  fun clearMessage() {
    _statusMessage.value = null
  }

  fun previewRecitationAudio(
    trackId: String,
    surahNumber: Int,
    surahArabicName: String,
    reciterId: String,
    reciterName: String,
    audioUrl: String,
    description: String,
  ) {
    val current = audioPlayer.state.value
    if (current.isActive && current.trackId == trackId && current.reciterId == reciterId) {
      audioPlayer.togglePlayPause()
    } else {
      audioPlayer.playCustomRecitation(
        trackId = trackId,
        surahNumber = surahNumber,
        surahArabicName = surahArabicName,
        reciterId = reciterId,
        reciterDisplayName = reciterName,
        audioUrl = audioUrl,
        description = description,
      )
    }
  }

  fun togglePlayPause() = audioPlayer.togglePlayPause()

  fun seekTo(positionMs: Int) = audioPlayer.seekTo(positionMs)

  fun stopPreviewAudio() = audioPlayer.stop()

  fun saveReciter(
    isEdit: Boolean,
    reciterId: String,
    arabicName: String,
    riwayah: String,
    bioArabic: String,
    photoUrl: String,
    styleArabic: String,
    provider: AudioHostingProvider,
    audioBaseUrl: String,
    sortOrder: Long,
    published: Boolean,
    onSuccess: () -> Unit = {},
  ) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result =
        if (isEdit) {
          backendRepository.updateReciterAsAdmin(
            reciterId = reciterId,
            arabicName = arabicName,
            styleArabic = styleArabic,
            hostingProvider = provider,
            audioBaseUrl = audioBaseUrl,
            published = published,
            riwayah = riwayah,
            bioArabic = bioArabic,
            photoUrl = photoUrl,
            sortOrder = sortOrder,
          )
        } else {
          backendRepository.createReciterAsAdmin(
            reciterId = reciterId,
            arabicName = arabicName,
            styleArabic = styleArabic,
            hostingProvider = provider,
            audioBaseUrl = audioBaseUrl,
            published = published,
            riwayah = riwayah,
            bioArabic = bioArabic,
            photoUrl = photoUrl,
            sortOrder = sortOrder,
          )
        }
      _isBusy.value = false
      result
        .onSuccess {
          _selectedReciterId.value = reciterId.trim()
          _statusMessage.value =
            if (isEdit) "تم تحديث بيانات القارئ بنجاح" else "تمت إضافة القارئ بنجاح"
          onSuccess()
        }
        .onFailure { e ->
          _statusMessage.value = e.localizedMessage ?: "تعذر حفظ بيانات القارئ"
        }
    }
  }

  fun moveReciterOrder(reciterId: String, delta: Int) {
    if (_isBusy.value) return
    val current = reciters.value
    val index = current.indexOfFirst { it.id == reciterId }
    val targetIndex = index + delta
    if (index !in current.indices || targetIndex !in current.indices) return

    val reordered = current.toMutableList()
    val item = reordered.removeAt(index)
    reordered.add(targetIndex, item)

    viewModelScope.launch {
      _isBusy.value = true
      val result = backendRepository.reorderRecitersAsAdmin(reordered.map { it.id })
      _isBusy.value = false
      result
        .onSuccess { _statusMessage.value = "تم تحديث ترتيب القرّاء" }
        .onFailure { e -> _statusMessage.value = e.localizedMessage ?: "تعذر تغيير الترتيب" }
    }
  }

  fun deleteReciter(reciterId: String) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result = backendRepository.deleteReciterAsAdmin(reciterId)
      _isBusy.value = false
      result
        .onSuccess {
          if (_selectedReciterId.value == reciterId) {
            _selectedReciterId.value = null
          }
          _statusMessage.value = "تم حذف القارئ وتلاواته بنجاح"
        }
        .onFailure { e ->
          _statusMessage.value = e.localizedMessage ?: "تعذر حذف القارئ"
        }
    }
  }

  fun saveRecitation(
    reciterId: String,
    trackId: String,
    surahNumber: Int,
    surahArabicName: String,
    description: String,
    sortOrder: Long,
    provider: AudioHostingProvider,
    audioUrl: String,
    externalAssetId: String,
    durationSeconds: Long,
    published: Boolean,
    onSuccess: () -> Unit = {},
  ) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val resolvedName =
        surahArabicName.trim().ifBlank {
          QuranSeedData.surahs.firstOrNull { it.number == surahNumber }?.arabicName
            ?: "سورة $surahNumber"
        }
      val result =
        backendRepository.registerHostedRecitationAsAdmin(
          reciterId = reciterId,
          surahNumber = surahNumber,
          surahArabicName = resolvedName,
          hostingProvider = provider,
          audioUrl = audioUrl,
          externalAssetId = externalAssetId,
          durationSeconds = durationSeconds,
          published = published,
          trackId = trackId,
          description = description,
          sortOrder = sortOrder,
        )
      _isBusy.value = false
      result
        .onSuccess {
          _statusMessage.value = "تم حفظ تلاوة $resolvedName بنجاح"
          onSuccess()
        }
        .onFailure { e ->
          _statusMessage.value = e.localizedMessage ?: "تعذر حفظ التلاوة"
        }
    }
  }

  fun moveRecitationOrder(reciterId: String, trackId: String, delta: Int) {
    if (_isBusy.value) return
    val current = recitationsForSelectedReciter.value
    val index = current.indexOfFirst { it.id == trackId }
    val targetIndex = index + delta
    if (index !in current.indices || targetIndex !in current.indices) return

    val reordered = current.toMutableList()
    val item = reordered.removeAt(index)
    reordered.add(targetIndex, item)

    viewModelScope.launch {
      _isBusy.value = true
      val result =
        backendRepository.reorderRecitationsAsAdmin(reciterId, reordered.map { it.id })
      _isBusy.value = false
      result
        .onSuccess { _statusMessage.value = "تم تحديث ترتيب التلاوات" }
        .onFailure { e -> _statusMessage.value = e.localizedMessage ?: "تعذر تغيير ترتيب التلاوات" }
    }
  }

  fun deleteRecitation(reciterId: String, trackId: String) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result = backendRepository.deleteRecitationByIdAsAdmin(reciterId, trackId)
      _isBusy.value = false
      result
        .onSuccess { _statusMessage.value = "تم حذف التلاوة بنجاح" }
        .onFailure { e -> _statusMessage.value = e.localizedMessage ?: "تعذر حذف التلاوة" }
    }
  }

  companion object {
    fun factory(
      authManager: FirebaseAuthManager,
      backendRepository: FirebaseQuranBackendRepository,
      audioPlayer: QuranAudioPlayer,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return AdminViewModel(authManager, backendRepository, audioPlayer) as T
        }
      }
  }
}
