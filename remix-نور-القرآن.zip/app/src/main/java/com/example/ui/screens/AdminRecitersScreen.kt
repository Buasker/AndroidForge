package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.audio.AudioPlaybackState
import com.example.data.firebase.AdminPrivilegeStatus
import com.example.data.firebase.AudioHostingProvider
import com.example.data.firebase.ExternalAudioMetadata
import com.example.data.firebase.FirebaseAuthManager
import com.example.data.firebase.FirebaseRecitationTrack
import com.example.data.firebase.FirebaseReciter
import com.example.ui.components.OctagonalBadge
import com.example.ui.components.ReciterAvatar

@Composable
fun AdminRecitersScreen(
  adminStatus: AdminPrivilegeStatus,
  isCheckingAuth: Boolean,
  isBusy: Boolean,
  isProbingUrl: Boolean,
  probeResult: Result<ExternalAudioMetadata>?,
  audioState: AudioPlaybackState,
  reciters: List<FirebaseReciter>,
  selectedReciterId: String?,
  recitations: List<FirebaseRecitationTrack>,
  statusMessage: String?,
  onClearMessage: () -> Unit,
  onClearProbeResult: () -> Unit,
  onSelectReciter: (String?) -> Unit,
  onProbeUrl: (String) -> Unit,
  onPreviewRecitationAudio:
    (
      trackId: String,
      surahNumber: Int,
      surahArabicName: String,
      reciterId: String,
      reciterName: String,
      audioUrl: String,
      description: String,
    ) -> Unit,
  onSeekAudio: (Int) -> Unit,
  onStopPreviewAudio: () -> Unit,
  onSaveReciter:
    (
      isEdit: Boolean,
      reciterId: String,
      arabicName: String,
      riwayah: String,
      bioArabic: String,
      photoUrl: String,
      styleArabic: String,
      provider: AudioHostingProvider,
      audioBaseUrl: String,
      sortOrder: Long,
      published: Boolean,
      onSuccess: () -> Unit,
    ) -> Unit,
  onMoveReciterOrder: (reciterId: String, delta: Int) -> Unit,
  onDeleteReciter: (String) -> Unit,
  onSaveRecitation:
    (
      reciterId: String,
      trackId: String,
      surahNumber: Int,
      surahArabicName: String,
      description: String,
      sortOrder: Long,
      provider: AudioHostingProvider,
      audioUrl: String,
      externalAssetId: String,
      durationSeconds: Long,
      published: Boolean,
      onSuccess: () -> Unit,
    ) -> Unit,
  onMoveRecitationOrder: (reciterId: String, trackId: String, delta: Int) -> Unit,
  onDeleteRecitation: (reciterId: String, trackId: String) -> Unit,
  onBack: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val snackbarHostState = remember { SnackbarHostState() }
  var editingReciter by remember { mutableStateOf<FirebaseReciter?>(null) }
  var showReciterDialog by remember { mutableStateOf(false) }
  var previewReciterDraft by remember { mutableStateOf<ReciterDraftPayload?>(null) }
  var previewReciterFromEditor by remember { mutableStateOf(false) }
  var deletingReciter by remember { mutableStateOf<FirebaseReciter?>(null) }

  var editingTrack by remember { mutableStateOf<FirebaseRecitationTrack?>(null) }
  var showTrackDialog by remember { mutableStateOf(false) }
  var previewTrackDraft by remember { mutableStateOf<RecitationDraftPayload?>(null) }
  var previewTrackFromEditor by remember { mutableStateOf(false) }
  var deletingTrack by remember { mutableStateOf<FirebaseRecitationTrack?>(null) }

  BackHandler(enabled = selectedReciterId != null) {
    onSelectReciter(null)
  }

  LaunchedEffect(statusMessage) {
    if (statusMessage != null) {
      snackbarHostState.showSnackbar(statusMessage)
      onClearMessage()
    }
  }

  Scaffold(
    snackbarHost = { SnackbarHost(snackbarHostState) },
    contentWindowInsets = WindowInsets(0.dp),
    floatingActionButton = {
      if (adminStatus.isSuperAdmin && !isCheckingAuth) {
        if (selectedReciterId == null) {
          FloatingActionButton(
            onClick = {
              editingReciter = null
              showReciterDialog = true
            },
            modifier = Modifier.testTag("admin_add_reciter_fab"),
          ) {
            Icon(Icons.Rounded.Add, contentDescription = "إضافة قارئ جديد")
          }
        } else {
          FloatingActionButton(
            onClick = {
              editingTrack = null
              onClearProbeResult()
              showTrackDialog = true
            },
            modifier = Modifier.testTag("admin_add_track_fab"),
          ) {
            Icon(Icons.Rounded.Add, contentDescription = "إضافة تلاوة سورة")
          }
        }
      }
    },
    modifier = modifier.fillMaxSize(),
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      when {
        isCheckingAuth -> {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
          }
        }
        !adminStatus.isSuperAdmin -> {
          Column(
            modifier =
              Modifier.fillMaxSize()
                .widthIn(max = 520.dp)
                .padding(24.dp)
                .testTag("admin_access_denied"),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Surface(
              shape = MaterialTheme.shapes.extraLarge,
              color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.4f)),
            ) {
              Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                Icon(
                  imageVector = Icons.Rounded.Lock,
                  contentDescription = "وصول مقيد للمالك فقط",
                  tint = MaterialTheme.colorScheme.error,
                  modifier = Modifier.size(44.dp),
                )
                Text(
                  text = "غير مصرح بالوصول",
                  style = MaterialTheme.typography.headlineSmall,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.error,
                )
                Text(
                  text =
                    "لوحة إدارة القراء والتلاوات محمية بالكامل ولا يمكن الوصول إليها إلا من حساب المالك الموثّق في خوادم Firebase فقط.",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
                  Text("العودة")
                }
              }
            }
          }
        }
        else -> {
          val selectedReciter = reciters.firstOrNull { it.id == selectedReciterId }
          LazyColumn(
            modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            item {
              Surface(
                shape = MaterialTheme.shapes.large,
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth().testTag("owner_verified_banner"),
              ) {
                Column(
                  modifier = Modifier.padding(16.dp),
                  verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Rounded.VerifiedUser,
                      contentDescription = "مالك موثق",
                      tint = MaterialTheme.colorScheme.primary,
                      modifier = Modifier.size(22.dp),
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                      text = "حساب المالك الموثّق (Super Admin)",
                      style = MaterialTheme.typography.titleMedium,
                      fontWeight = FontWeight.Bold,
                    )
                  }
                  Text(
                    text = "البريد الموثّق: ${adminStatus.email ?: FirebaseAuthManager.OWNER_EMAIL}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                  Text(
                    text = "المزامنة الفورية: كل إضافة أو تعديل أو ترتيب أو حذف ينعكس تلقائياً لدى جميع المستخدمين",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                  )
                }
              }
            }

            if (selectedReciter == null) {
              item {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Text(
                    text = "القراء السحابيون (${reciters.size})",
                    style = MaterialTheme.typography.titleLarge,
                  )
                  OutlinedButton(
                    onClick = {
                      editingReciter = null
                      showReciterDialog = true
                    },
                    modifier = Modifier.testTag("admin_add_reciter_btn"),
                  ) {
                    Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("إضافة قارئ")
                  }
                }
              }

              if (reciters.isEmpty()) {
                item {
                  Surface(
                    shape = MaterialTheme.shapes.large,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth(),
                  ) {
                    Column(
                      modifier = Modifier.padding(24.dp),
                      verticalArrangement = Arrangement.spacedBy(8.dp),
                      horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                      Icon(
                        imageVector = Icons.Rounded.AdminPanelSettings,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp),
                      )
                      Text(
                        text = "لا يوجد قرّاء مضافون في السحابة بعد",
                        style = MaterialTheme.typography.titleMedium,
                      )
                      Text(
                        text = "اضغط «إضافة قارئ» لإضافة قارئ بصورته ونبذته وروايته ومعاينة بطاقته قبل النشر.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                      )
                    }
                  }
                }
              } else {
                itemsIndexed(reciters, key = { _, item -> item.id }) { index, reciter ->
                  Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier =
                      Modifier.fillMaxWidth()
                        .clickable { onSelectReciter(reciter.id) }
                        .testTag("admin_reciter_card_${reciter.id}"),
                  ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        ReciterAvatar(
                          photoUrl = reciter.photoUrl,
                          contentDescription = reciter.arabicName,
                          size = 50.dp,
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                          Text(
                            text = reciter.arabicName,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                          )
                          Text(
                            text =
                              "${reciter.effectiveRiwayah} • ترتيب: ${reciter.sortOrder} • ${AudioHostingProvider.fromId(reciter.hostingProvider).arabicLabel}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                          )
                          if (reciter.bioArabic.isNotBlank()) {
                            Text(
                              text = reciter.bioArabic,
                              style = MaterialTheme.typography.bodySmall,
                              color = MaterialTheme.colorScheme.onSurfaceVariant,
                              maxLines = 1,
                              overflow = TextOverflow.Ellipsis,
                            )
                          }
                          Text(
                            text = if (reciter.published) "منشور للمستخدمين" else "مسودة (مخفي)",
                            style = MaterialTheme.typography.labelSmall,
                            color =
                              if (reciter.published) MaterialTheme.colorScheme.primary
                              else MaterialTheme.colorScheme.error,
                          )
                        }
                      }

                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically,
                      ) {
                        IconButton(
                          onClick = { onMoveReciterOrder(reciter.id, -1) },
                          enabled = !isBusy && index > 0,
                          modifier =
                            Modifier.minimumInteractiveComponentSize()
                              .testTag("admin_reciter_up_${reciter.id}"),
                        ) {
                          Icon(Icons.Rounded.ArrowUpward, contentDescription = "تحريك القارئ لأعلى")
                        }
                        IconButton(
                          onClick = { onMoveReciterOrder(reciter.id, 1) },
                          enabled = !isBusy && index < reciters.lastIndex,
                          modifier =
                            Modifier.minimumInteractiveComponentSize()
                              .testTag("admin_reciter_down_${reciter.id}"),
                        ) {
                          Icon(Icons.Rounded.ArrowDownward, contentDescription = "تحريك القارئ لأسفل")
                        }
                        IconButton(
                          onClick = {
                            previewReciterFromEditor = false
                            previewReciterDraft =
                              ReciterDraftPayload(
                                reciterId = reciter.id,
                                arabicName = reciter.arabicName,
                                riwayah = reciter.effectiveRiwayah,
                                styleArabic = reciter.styleArabic,
                                bioArabic = reciter.bioArabic,
                                photoUrl = reciter.photoUrl,
                                provider = AudioHostingProvider.fromId(reciter.hostingProvider),
                                audioBaseUrl = reciter.audioBaseUrl,
                                sortOrder = reciter.sortOrder,
                                published = reciter.published,
                              )
                          },
                          modifier =
                            Modifier.minimumInteractiveComponentSize()
                              .testTag("admin_preview_reciter_${reciter.id}"),
                        ) {
                          Icon(Icons.Rounded.Visibility, contentDescription = "معاينة القارئ")
                        }
                        IconButton(
                          onClick = {
                            editingReciter = reciter
                            showReciterDialog = true
                          },
                          modifier =
                            Modifier.minimumInteractiveComponentSize()
                              .testTag("admin_edit_reciter_${reciter.id}"),
                        ) {
                          Icon(Icons.Rounded.Edit, contentDescription = "تعديل القارئ")
                        }
                        IconButton(
                          onClick = { deletingReciter = reciter },
                          modifier =
                            Modifier.minimumInteractiveComponentSize()
                              .testTag("admin_delete_reciter_${reciter.id}"),
                        ) {
                          Icon(
                            Icons.Rounded.DeleteOutline,
                            contentDescription = "حذف القارئ",
                            tint = MaterialTheme.colorScheme.error,
                          )
                        }
                      }
                    }
                  }
                }
              }
            } else {
              item {
                Surface(
                  shape = MaterialTheme.shapes.large,
                  color = MaterialTheme.colorScheme.surface,
                  border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                  modifier = Modifier.fillMaxWidth(),
                ) {
                  Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                  ) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                      ) {
                        ReciterAvatar(
                          photoUrl = selectedReciter.photoUrl,
                          contentDescription = selectedReciter.arabicName,
                          size = 44.dp,
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                          Text(
                            text = "تلاوات: ${selectedReciter.arabicName}",
                            style = MaterialTheme.typography.titleLarge,
                          )
                          Text(
                            text = selectedReciter.effectiveRiwayah,
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                          )
                        }
                      }
                      TextButton(
                        onClick = { onSelectReciter(null) },
                        modifier = Modifier.testTag("admin_back_to_all_reciters"),
                      ) {
                        Text("جميع القراء")
                      }
                    }
                    Button(
                      onClick = {
                        editingTrack = null
                        onClearProbeResult()
                        showTrackDialog = true
                      },
                      modifier = Modifier.fillMaxWidth().testTag("admin_add_track_btn"),
                    ) {
                      Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                      Spacer(modifier = Modifier.width(6.dp))
                      Text("إضافة تلاوة جديدة")
                    }
                  }
                }
              }

              if (recitations.isEmpty()) {
                item {
                  Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth(),
                  ) {
                    Text(
                      text = "لا توجد تلاوات مسجلة بعد لهذا القارئ. يمكنك إضافة تلاوة ومعاينتها صوتياً قبل النشر.",
                      style = MaterialTheme.typography.bodyMedium,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      modifier = Modifier.padding(16.dp),
                    )
                  }
                }
              } else {
                itemsIndexed(recitations, key = { _, item -> item.id }) { index, track ->
                  val isPlayingThisTrack =
                    audioState.isActive &&
                      audioState.trackId == track.id &&
                      audioState.reciterId == selectedReciter.id

                  Surface(
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth().testTag("admin_track_${track.id}"),
                  ) {
                    Column(
                      modifier = Modifier.padding(12.dp),
                      verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        OctagonalBadge(
                          number = track.surahNumber.toInt().coerceIn(1, 114),
                          size = 38.dp,
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                          Text(
                            text = "${track.surahNumber}. ${track.surahArabicName}",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                          )
                          if (track.description.isNotBlank()) {
                            Text(
                              text = track.description,
                              style = MaterialTheme.typography.bodySmall,
                              color = MaterialTheme.colorScheme.onSurfaceVariant,
                              maxLines = 2,
                              overflow = TextOverflow.Ellipsis,
                            )
                          }
                          Text(
                            text =
                              "ترتيب: ${track.sortOrder} • ${AudioHostingProvider.fromId(track.hostingProvider).arabicLabel} • ${if (track.published) "منشور" else "مسودة"}",
                            style = MaterialTheme.typography.labelSmall,
                            color =
                              if (track.published) MaterialTheme.colorScheme.primary
                              else MaterialTheme.colorScheme.error,
                          )
                        }
                      }

                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically,
                      ) {
                        IconButton(
                          onClick = {
                            onPreviewRecitationAudio(
                              track.id,
                              track.surahNumber.toInt().coerceIn(1, 114),
                              track.surahArabicName,
                              selectedReciter.id,
                              selectedReciter.arabicName,
                              track.audioUrl,
                              track.description,
                            )
                          },
                          modifier =
                            Modifier.minimumInteractiveComponentSize()
                              .testTag("admin_play_track_${track.id}"),
                        ) {
                          Icon(
                            imageVector =
                              if (isPlayingThisTrack && audioState.isPlaying) Icons.Rounded.Pause
                              else Icons.Rounded.PlayArrow,
                            contentDescription = "تشغيل ومعاينة الصوت",
                            tint = MaterialTheme.colorScheme.primary,
                          )
                        }
                        IconButton(
                          onClick = { onMoveRecitationOrder(selectedReciter.id, track.id, -1) },
                          enabled = !isBusy && index > 0,
                          modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                          Icon(Icons.Rounded.ArrowUpward, contentDescription = "تحريك التلاوة لأعلى")
                        }
                        IconButton(
                          onClick = { onMoveRecitationOrder(selectedReciter.id, track.id, 1) },
                          enabled = !isBusy && index < recitations.lastIndex,
                          modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                          Icon(Icons.Rounded.ArrowDownward, contentDescription = "تحريك التلاوة لأسفل")
                        }
                        IconButton(
                          onClick = {
                            previewTrackFromEditor = false
                            previewTrackDraft =
                              RecitationDraftPayload(
                                trackId = track.id,
                                reciterId = selectedReciter.id,
                                reciterName = selectedReciter.arabicName,
                                surahNumber = track.surahNumber.toInt().coerceIn(1, 114),
                                surahArabicName = track.surahArabicName,
                                description = track.description,
                                sortOrder = track.sortOrder,
                                provider = AudioHostingProvider.fromId(track.hostingProvider),
                                audioUrl = track.audioUrl,
                                externalAssetId = track.externalAssetId,
                                durationSeconds = track.durationSeconds,
                                published = track.published,
                              )
                          },
                          modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                          Icon(Icons.Rounded.Visibility, contentDescription = "معاينة بطاقة التلاوة")
                        }
                        IconButton(
                          onClick = {
                            editingTrack = track
                            onClearProbeResult()
                            showTrackDialog = true
                          },
                          modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                          Icon(Icons.Rounded.Edit, contentDescription = "تعديل التلاوة")
                        }
                        IconButton(
                          onClick = { deletingTrack = track },
                          modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                          Icon(
                            Icons.Rounded.DeleteOutline,
                            contentDescription = "حذف التلاوة",
                            tint = MaterialTheme.colorScheme.error,
                          )
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  fun commitReciterDraft(draft: ReciterDraftPayload, overridePublished: Boolean? = null) {
    onSaveReciter(
      editingReciter != null,
      draft.reciterId,
      draft.arabicName,
      draft.riwayah,
      draft.bioArabic,
      draft.photoUrl,
      draft.styleArabic,
      draft.provider,
      draft.audioBaseUrl,
      draft.sortOrder,
      overridePublished ?: draft.published,
    ) {
      showReciterDialog = false
      previewReciterDraft = null
    }
  }

  if (showReciterDialog) {
    val nextSort = (reciters.maxOfOrNull { it.sortOrder } ?: 0L) + 1L
    ReciterEditorDialog(
      existing = editingReciter,
      defaultSortOrder = nextSort,
      isBusy = isBusy,
      onDismiss = { showReciterDialog = false },
      onPreview = { draft ->
        previewReciterFromEditor = true
        previewReciterDraft = draft
      },
      onSave = { draft -> commitReciterDraft(draft) },
    )
  }

  previewReciterDraft?.let { draft ->
    ReciterPreviewDialog(
      draft = draft,
      isBusy = isBusy,
      onBackToEdit =
        if (previewReciterFromEditor) {
          { previewReciterDraft = null }
        } else {
          {
            editingReciter = reciters.firstOrNull { it.id == draft.reciterId }
            previewReciterDraft = null
            showReciterDialog = true
          }
        },
      onSaveDraft = { commitReciterDraft(draft, overridePublished = false) },
      onPublishNow = { commitReciterDraft(draft, overridePublished = true) },
      onDismiss = { previewReciterDraft = null },
    )
  }

  deletingReciter?.let { target ->
    AlertDialog(
      onDismissRequest = { deletingReciter = null },
      title = { Text("تأكيد حذف القارئ") },
      text = {
        Text("سيتم حذف القارئ «${target.arabicName}» وجميع تلاواته المسجلة في السحابة نهائياً.")
      },
      confirmButton = {
        Button(
          onClick = {
            onDeleteReciter(target.id)
            deletingReciter = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
        ) {
          Text("حذف نهائي")
        }
      },
      dismissButton = {
        TextButton(onClick = { deletingReciter = null }) { Text("إلغاء") }
      },
    )
  }

  fun commitTrackDraft(draft: RecitationDraftPayload, overridePublished: Boolean? = null) {
    onSaveRecitation(
      draft.reciterId,
      draft.trackId,
      draft.surahNumber,
      draft.surahArabicName,
      draft.description,
      draft.sortOrder,
      draft.provider,
      draft.audioUrl,
      draft.externalAssetId,
      draft.durationSeconds,
      overridePublished ?: draft.published,
    ) {
      showTrackDialog = false
      previewTrackDraft = null
    }
  }

  val activeReciterForTrack = reciters.firstOrNull { it.id == selectedReciterId }
  if (showTrackDialog && selectedReciterId != null) {
    val nextTrackSort = (recitations.maxOfOrNull { it.sortOrder } ?: 0L) + 1L
    RecitationTrackEditorDialog(
      reciterId = selectedReciterId,
      reciterName = activeReciterForTrack?.arabicName ?: selectedReciterId,
      existing = editingTrack,
      defaultSortOrder = nextTrackSort,
      isBusy = isBusy,
      isProbingUrl = isProbingUrl,
      probeResult = probeResult,
      onProbeUrl = onProbeUrl,
      onDismiss = { showTrackDialog = false },
      onPreview = { draft ->
        previewTrackFromEditor = true
        previewTrackDraft = draft
      },
      onSave = { draft -> commitTrackDraft(draft) },
    )
  }

  previewTrackDraft?.let { draft ->
    RecitationPreviewDialog(
      draft = draft,
      audioState = audioState,
      isBusy = isBusy,
      onPlayPreviewAudio = { payload ->
        onPreviewRecitationAudio(
          payload.trackId,
          payload.surahNumber,
          payload.surahArabicName,
          payload.reciterId,
          payload.reciterName,
          payload.audioUrl,
          payload.description,
        )
      },
      onSeekAudio = onSeekAudio,
      onStopAudio = onStopPreviewAudio,
      onBackToEdit =
        if (previewTrackFromEditor) {
          { previewTrackDraft = null }
        } else {
          {
            editingTrack = recitations.firstOrNull { it.id == draft.trackId }
            previewTrackDraft = null
            onClearProbeResult()
            showTrackDialog = true
          }
        },
      onSaveDraft = { commitTrackDraft(draft, overridePublished = false) },
      onPublishNow = { commitTrackDraft(draft, overridePublished = true) },
      onDismiss = { previewTrackDraft = null },
    )
  }

  deletingTrack?.let { target ->
    AlertDialog(
      onDismissRequest = { deletingTrack = null },
      title = { Text("تأكيد حذف التلاوة") },
      text = { Text("هل تريد حذف تلاوة «${target.surahArabicName}» من السحابة؟") },
      confirmButton = {
        Button(
          onClick = {
            if (selectedReciterId != null) {
              onDeleteRecitation(selectedReciterId, target.id)
            }
            deletingTrack = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
        ) {
          Text("حذف")
        }
      },
      dismissButton = {
        TextButton(onClick = { deletingTrack = null }) { Text("إلغاء") }
      },
    )
  }
}
