package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioPlaybackState
import com.example.audio.QuranAudioPlayer
import com.example.data.firebase.FirebaseQuranBackendRepository
import com.example.data.local.QuranSeedData
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.AyahItem
import com.example.data.model.QuranCatalog
import com.example.data.model.ReaderSettings
import com.example.data.model.ReaderThemeMode
import com.example.data.model.ReadingProgress
import com.example.data.model.ReciterOption
import com.example.data.model.SurahInfo
import com.example.data.repository.QuranRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface SurahReaderUiState {
  data object Loading : SurahReaderUiState

  data class SurahSuccess(
    val surah: SurahInfo,
    val ayahs: List<AyahItem>,
    val isOfflineCached: Boolean,
  ) : SurahReaderUiState

  data class PageSuccess(
    val pageNumber: Int,
    val surahNames: String,
    val ayahs: List<AyahItem>,
    val isOfflineCached: Boolean,
  ) : SurahReaderUiState

  data class Error(val message: String) : SurahReaderUiState
}

class SurahReaderViewModel(
  private val initialSurahNumber: Int,
  private val initialPageNumber: Int,
  private val quranRepository: QuranRepository,
  private val preferencesRepository: UserPreferencesRepository,
  private val audioPlayer: QuranAudioPlayer,
  backendRepository: FirebaseQuranBackendRepository? = null,
) : ViewModel() {

  private val _uiState = MutableStateFlow<SurahReaderUiState>(SurahReaderUiState.Loading)
  val uiState: StateFlow<SurahReaderUiState> = _uiState.asStateFlow()

  private val _isPageMode = MutableStateFlow(initialPageNumber > 0)
  val isPageMode: StateFlow<Boolean> = _isPageMode.asStateFlow()

  private val _activePage = MutableStateFlow(if (initialPageNumber > 0) initialPageNumber else 1)
  val activePage: StateFlow<Int> = _activePage.asStateFlow()

  val readerSettings: StateFlow<ReaderSettings> =
    preferencesRepository.readerSettingsFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = ReaderSettings(),
    )

  val reciters: StateFlow<List<ReciterOption>> =
    combine(
        backendRepository?.observePublishedReciters() ?: flowOf(emptyList()),
        quranRepository.localRecitersFlow,
      ) { cloudReciters, localReciters ->
        val merged = RecitersViewModel.mergePublishedAndCatalogReciters(cloudReciters, localReciters)
        audioPlayer.updateKnownReciters(merged)
        merged
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = QuranCatalog.reciters,
      )

  val bookmarkedKeys: StateFlow<Set<String>> =
    quranRepository.bookmarksFlow
      .map { bookmarks -> bookmarks.map { "${it.surahNumber}_${it.ayahNumberInSurah}" }.toSet() }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptySet(),
      )

  val audioState: StateFlow<AudioPlaybackState> = audioPlayer.state

  private var loadedEdition: String? = null

  init {
    viewModelScope.launch {
      preferencesRepository.readerSettingsFlow
        .map { it.translationEdition }
        .distinctUntilChanged()
        .collect { edition ->
          loadedEdition = edition
          loadContent(edition)
        }
    }
  }

  fun retry() {
    val edition = loadedEdition ?: readerSettings.value.translationEdition
    viewModelScope.launch { loadContent(edition) }
  }

  fun switchToPage(pageNumber: Int) {
    _isPageMode.value = true
    _activePage.value = pageNumber.coerceIn(1, 604)
    val edition = loadedEdition ?: readerSettings.value.translationEdition
    viewModelScope.launch { loadContent(edition) }
  }

  fun switchToSurahMode() {
    _isPageMode.value = false
    val edition = loadedEdition ?: readerSettings.value.translationEdition
    viewModelScope.launch { loadContent(edition) }
  }

  private suspend fun loadContent(edition: String) {
    _uiState.value = SurahReaderUiState.Loading
    if (_isPageMode.value) {
      val result = quranRepository.loadMushafPage(_activePage.value, edition)
      _uiState.value =
        result.fold(
          onSuccess = { loaded ->
            SurahReaderUiState.PageSuccess(
              pageNumber = loaded.pageNumber,
              surahNames = loaded.surahNames,
              ayahs = loaded.ayahs,
              isOfflineCached = loaded.fromCache,
            )
          },
          onFailure = { err ->
            SurahReaderUiState.Error(
              err.localizedMessage ?: "تعذر تحميل الصفحة. تأكد من الاتصال بالإنترنت."
            )
          },
        )
    } else {
      val result = quranRepository.loadSurah(initialSurahNumber, edition)
      _uiState.value =
        result.fold(
          onSuccess = { loaded ->
            loaded.ayahs.firstOrNull()?.let { _activePage.value = it.page }
            SurahReaderUiState.SurahSuccess(
              surah = loaded.surah,
              ayahs = loaded.ayahs,
              isOfflineCached = loaded.fromCache,
            )
          },
          onFailure = { err ->
            SurahReaderUiState.Error(
              err.localizedMessage ?: "تعذر تحميل السورة. تأكد من الاتصال بالإنترنت."
            )
          },
        )
    }
  }

  fun toggleBookmark(ayah: AyahItem) {
    val surah = resolveSurahForAyah(ayah.surahNumber) ?: return
    viewModelScope.launch { quranRepository.toggleBookmark(surah, ayah) }
  }

  fun recordReadingProgress(ayah: AyahItem) {
    val surah = resolveSurahForAyah(ayah.surahNumber) ?: return
    viewModelScope.launch {
      preferencesRepository.saveReadingProgress(
        ReadingProgress(
          surahNumber = surah.number,
          surahEnglishName = surah.englishName,
          surahArabicName = surah.arabicName,
          ayahNumberInSurah = ayah.numberInSurah.coerceIn(1, surah.numberOfAyahs),
          page = ayah.page,
          totalAyahs = surah.numberOfAyahs,
        )
      )
    }
  }

  private fun resolveSurahForAyah(surahNumber: Int): SurahInfo? {
    val state = _uiState.value
    if (state is SurahReaderUiState.SurahSuccess && state.surah.number == surahNumber) {
      return state.surah
    }
    return QuranSeedData.surahs.firstOrNull { it.number == surahNumber }?.let {
      SurahInfo(
        number = it.number,
        arabicName = it.arabicName,
        englishName = it.englishName,
        englishNameTranslation = it.englishNameTranslation,
        numberOfAyahs = it.numberOfAyahs,
        revelationType = it.revelationType,
      )
    }
  }

  fun playAyah(ayah: AyahItem) {
    val surah = resolveSurahForAyah(ayah.surahNumber) ?: return
    val ayahs =
      when (val st = _uiState.value) {
        is SurahReaderUiState.SurahSuccess -> st.ayahs
        is SurahReaderUiState.PageSuccess -> st.ayahs.filter { it.surahNumber == ayah.surahNumber }
        else -> return
      }
    val reciter = readerSettings.value.reciterIdentifier
    val currentAudio = audioPlayer.state.value
    if (
      currentAudio.isActive &&
        currentAudio.surahNumber == ayah.surahNumber &&
        currentAudio.currentAyahInSurah == ayah.numberInSurah
    ) {
      audioPlayer.togglePlayPause()
    } else {
      audioPlayer.playAyah(
        surah = surah,
        ayahs = ayahs,
        startAyahInSurah = ayah.numberInSurah,
        reciterId = reciter,
      )
    }
  }

  fun playSurahFromStart() {
    val state = _uiState.value
    if (state is SurahReaderUiState.SurahSuccess) {
      val firstAyah = state.ayahs.firstOrNull()?.numberInSurah ?: 1
      audioPlayer.playAyah(
        surah = state.surah,
        ayahs = state.ayahs,
        startAyahInSurah = firstAyah,
        reciterId = readerSettings.value.reciterIdentifier,
      )
    } else if (state is SurahReaderUiState.PageSuccess) {
      val first = state.ayahs.firstOrNull() ?: return
      playAyah(first)
    }
  }

  fun zoomInQuranText() {
    updateArabicFontSize(readerSettings.value.arabicFontSize + 2f)
  }

  fun zoomOutQuranText() {
    updateArabicFontSize(readerSettings.value.arabicFontSize - 2f)
  }

  fun resetQuranFontSize() {
    updateArabicFontSize(28f)
  }

  fun updateArabicFontSize(size: Float) {
    viewModelScope.launch { preferencesRepository.updateArabicFontSize(size) }
  }

  fun updateTranslationFontSize(size: Float) {
    viewModelScope.launch { preferencesRepository.updateTranslationFontSize(size) }
  }

  fun updateShowTranslation(show: Boolean) {
    viewModelScope.launch { preferencesRepository.updateShowTranslation(show) }
  }

  fun updateTranslationEdition(edition: String) {
    viewModelScope.launch { preferencesRepository.updateTranslationEdition(edition) }
  }

  fun updateReciter(reciterId: String) {
    viewModelScope.launch {
      preferencesRepository.updateReciter(reciterId)
      audioPlayer.updateReciterIfPlaying(reciterId)
    }
  }

  fun updateThemeMode(mode: ReaderThemeMode) {
    viewModelScope.launch { preferencesRepository.updateThemeMode(mode) }
  }

  fun updateVolume(volume: Float) {
    audioPlayer.setVolume(volume)
    viewModelScope.launch { preferencesRepository.updateVolumeLevel(volume) }
  }

  companion object {
    fun factory(
      surahNumber: Int,
      pageNumber: Int,
      quranRepository: QuranRepository,
      preferencesRepository: UserPreferencesRepository,
      audioPlayer: QuranAudioPlayer,
      backendRepository: FirebaseQuranBackendRepository? = null,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return SurahReaderViewModel(
            initialSurahNumber = surahNumber,
            initialPageNumber = pageNumber,
            quranRepository = quranRepository,
            preferencesRepository = preferencesRepository,
            audioPlayer = audioPlayer,
            backendRepository = backendRepository,
          )
            as T
        }
      }
  }
}
