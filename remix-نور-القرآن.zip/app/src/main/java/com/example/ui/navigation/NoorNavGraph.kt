package com.example.ui.navigation

import android.app.Application
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.MenuBook
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.NoorAppContainer
import com.example.data.model.AdhkarCategory
import com.example.data.model.ReaderThemeMode
import com.example.data.model.ReminderType
import com.example.data.model.SearchResultType
import com.example.ui.components.MiniAudioPlayerBar
import com.example.ui.screens.AdhkarScreen
import com.example.ui.screens.AdminRecitersScreen
import com.example.ui.screens.AudioLibraryScreen
import com.example.ui.screens.BookmarksScreen
import com.example.ui.screens.DailyPageScreen
import com.example.ui.screens.DhikrStatsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.KhatmahScreen
import com.example.ui.screens.ManageLocalRecitersScreen
import com.example.ui.screens.MoreScreen
import com.example.ui.screens.RecitersScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SocialScreen
import com.example.ui.screens.SurahListScreen
import com.example.ui.screens.SurahReaderScreen
import com.example.ui.screens.TafsirScreen
import com.example.ui.screens.VoiceDhikrScreen
import com.example.ui.viewmodel.AdhkarViewModel
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.AudioLibraryViewModel
import com.example.ui.viewmodel.BookmarksViewModel
import com.example.ui.viewmodel.DailyPageViewModel
import com.example.ui.viewmodel.DhikrStatsViewModel
import com.example.ui.viewmodel.HomeViewModel
import com.example.ui.viewmodel.KhatmahViewModel
import com.example.ui.viewmodel.ManageLocalRecitersViewModel
import com.example.ui.viewmodel.RecitersViewModel
import com.example.ui.viewmodel.SearchViewModel
import com.example.ui.viewmodel.SettingsViewModel
import com.example.ui.viewmodel.SurahListViewModel
import com.example.ui.viewmodel.SurahReaderViewModel
import com.example.ui.viewmodel.TafsirViewModel
import com.example.ui.viewmodel.VoiceDhikrViewModel
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

@Serializable object HomeRoute

@Serializable object SurahsRoute

@Serializable data class TafsirRoute(val surahNumber: Int = 1, val ayahNumber: Int = 0)

@Serializable data class AdhkarRoute(val categoryId: String = AdhkarCategory.MORNING.id)

@Serializable object MoreRoute

@Serializable
data class ReaderRoute(
  val surahNumber: Int = 1,
  val scrollToAyah: Int = 1,
  val pageNumber: Int = 0,
)

@Serializable object AudioRoute

@Serializable data class RecitersRoute(val initialReciterId: String? = null)

@Serializable object ManageLocalRecitersRoute

@Serializable object VoiceDhikrRoute

@Serializable object DhikrStatsRoute

@Serializable object KhatmahRoute

@Serializable object DailyPageRoute

@Serializable object BookmarksRoute

@Serializable object SearchRoute

@Serializable object SettingsRoute

@Serializable object AdminRoute

@Serializable object SocialRoute

private data class TopLevelTab(
  val label: String,
  val route: Any,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val testTag: String,
)

private val topLevelTabs =
  listOf(
    TopLevelTab(
      label = "الرئيسية",
      route = HomeRoute,
      selectedIcon = Icons.Rounded.Home,
      unselectedIcon = Icons.Outlined.Home,
      testTag = "nav_home",
    ),
    TopLevelTab(
      label = "المصحف",
      route = SurahsRoute,
      selectedIcon = Icons.AutoMirrored.Rounded.MenuBook,
      unselectedIcon = Icons.AutoMirrored.Outlined.MenuBook,
      testTag = "nav_surahs",
    ),
    TopLevelTab(
      label = "التفسير",
      route = TafsirRoute(),
      selectedIcon = Icons.AutoMirrored.Rounded.MenuBook,
      unselectedIcon = Icons.AutoMirrored.Outlined.MenuBook,
      testTag = "nav_tafsir",
    ),
    TopLevelTab(
      label = "الأذكار",
      route = AdhkarRoute(),
      selectedIcon = Icons.Rounded.AutoAwesome,
      unselectedIcon = Icons.Outlined.AutoAwesome,
      testTag = "nav_adhkar",
    ),
    TopLevelTab(
      label = "المزيد",
      route = MoreRoute,
      selectedIcon = Icons.Rounded.GridView,
      unselectedIcon = Icons.Outlined.GridView,
      testTag = "nav_more",
    ),
  )

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoorAppRoot(
  appContainer: NoorAppContainer,
  currentThemeMode: ReaderThemeMode,
  initialReminderTypeId: String? = null,
) {
  val navController = rememberNavController()
  val backStackEntry by navController.currentBackStackEntryAsState()
  val currentDestination = backStackEntry?.destination
  val isReaderScreen = currentDestination?.hasRoute<ReaderRoute>() == true
  val isTopLevel =
    currentDestination?.hasRoute<HomeRoute>() == true ||
      currentDestination?.hasRoute<SurahsRoute>() == true ||
      currentDestination?.hasRoute<TafsirRoute>() == true ||
      currentDestination?.hasRoute<AdhkarRoute>() == true ||
      currentDestination?.hasRoute<MoreRoute>() == true

  val secondaryTitle =
    when {
      currentDestination?.hasRoute<AudioRoute>() == true -> "المكتبة الصوتية"
      currentDestination?.hasRoute<RecitersRoute>() == true -> "القرّاء والتلاوات"
      currentDestination?.hasRoute<ManageLocalRecitersRoute>() == true -> "إدارة القرّاء"
      currentDestination?.hasRoute<VoiceDhikrRoute>() == true -> "عداد الذكر الصوتي"
      currentDestination?.hasRoute<DhikrStatsRoute>() == true -> "إحصائيات الأذكار"
      currentDestination?.hasRoute<KhatmahRoute>() == true -> "ختمة القرآن الكريم"
      currentDestination?.hasRoute<DailyPageRoute>() == true -> "صفحة القرآن اليومية"
      currentDestination?.hasRoute<BookmarksRoute>() == true -> "المفضلة والإشارات"
      currentDestination?.hasRoute<SearchRoute>() == true -> "البحث الذكي"
      currentDestination?.hasRoute<SettingsRoute>() == true -> "الإعدادات"
      currentDestination?.hasRoute<AdminRoute>() == true -> "لوحة إدارة المالك"
      currentDestination?.hasRoute<SocialRoute>() == true -> "تواصل معي"
      else -> null
    }

  val audioState by appContainer.audioPlayer.state.collectAsStateWithLifecycle()
  val scope = rememberCoroutineScope()
  val application = LocalContext.current.applicationContext as Application

  fun navigateTopLevel(route: Any) {
    navController.navigate(route) {
      popUpTo(navController.graph.findStartDestination().id) { saveState = true }
      launchSingleTop = true
      restoreState = true
    }
  }

  fun openReader(surahNumber: Int = 1, ayahNumber: Int = 1, pageNumber: Int = 0) {
    navController.navigate(
      ReaderRoute(surahNumber = surahNumber, scrollToAyah = ayahNumber, pageNumber = pageNumber)
    ) {
      launchSingleTop = true
    }
  }

  LaunchedEffect(initialReminderTypeId) {
    val type = ReminderType.entries.firstOrNull { it.id == initialReminderTypeId } ?: return@LaunchedEffect
    when (type) {
      ReminderType.MORNING_ADHKAR -> navigateTopLevel(AdhkarRoute(AdhkarCategory.MORNING.id))
      ReminderType.EVENING_ADHKAR -> navigateTopLevel(AdhkarRoute(AdhkarCategory.EVENING.id))
      ReminderType.SALAWAT -> navigateTopLevel(AdhkarRoute(AdhkarCategory.SALAWAT.id))
      ReminderType.KHATMAH_COMPLETION -> navController.navigate(KhatmahRoute)
      ReminderType.DAILY_PAGE -> navController.navigate(DailyPageRoute)
      ReminderType.QURAN_READING,
      ReminderType.DAILY_WIRD -> navigateTopLevel(SurahsRoute)
    }
  }

  BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
    val useNavRail = maxWidth >= 600.dp

    Row(modifier = Modifier.fillMaxSize()) {
      if (useNavRail && isTopLevel) {
        NavigationRail(
          containerColor = MaterialTheme.colorScheme.surface,
          modifier = Modifier.fillMaxHeight(),
        ) {
          topLevelTabs.forEach { tab ->
            val selected =
              when (tab.route) {
                is HomeRoute -> currentDestination?.hasRoute<HomeRoute>() == true
                is SurahsRoute -> currentDestination?.hasRoute<SurahsRoute>() == true
                is TafsirRoute -> currentDestination?.hasRoute<TafsirRoute>() == true
                is AdhkarRoute -> currentDestination?.hasRoute<AdhkarRoute>() == true
                is MoreRoute -> currentDestination?.hasRoute<MoreRoute>() == true
                else -> false
              }
            NavigationRailItem(
              selected = selected,
              onClick = { navigateTopLevel(tab.route) },
              icon = {
                Icon(
                  imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                  contentDescription = tab.label,
                )
              },
              label = { Text(tab.label) },
              modifier = Modifier.testTag(tab.testTag),
            )
          }
        }
      }

      Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
          if (!isTopLevel && !isReaderScreen && secondaryTitle != null) {
            TopAppBar(
              title = { Text(secondaryTitle, style = MaterialTheme.typography.titleLarge) },
              navigationIcon = {
                IconButton(
                  onClick = { navController.popBackStack() },
                  modifier = Modifier.minimumInteractiveComponentSize().testTag("secondary_back_button"),
                ) {
                  Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "رجوع",
                  )
                }
              },
              colors =
                TopAppBarDefaults.topAppBarColors(
                  containerColor = MaterialTheme.colorScheme.surface,
                  titleContentColor = MaterialTheme.colorScheme.onSurface,
                ),
            )
          }
        },
        bottomBar = {
          if (!isReaderScreen) {
            Column {
              MiniAudioPlayerBar(
                audioState = audioState,
                onTogglePlayPause = { appContainer.audioPlayer.togglePlayPause() },
                onPrevious = { appContainer.audioPlayer.playPrevious() },
                onNext = { appContainer.audioPlayer.playNext() },
                onStop = { appContainer.audioPlayer.stop() },
                onOpenTarget = {
                  if (audioState.trackId.isNotBlank() && audioState.reciterId.isNotBlank()) {
                    navController.navigate(RecitersRoute(initialReciterId = audioState.reciterId)) {
                      launchSingleTop = true
                    }
                  } else if (audioState.surahNumber > 0) {
                    openReader(
                      surahNumber = audioState.surahNumber,
                      ayahNumber = audioState.currentAyahInSurah.coerceAtLeast(1),
                    )
                  } else {
                    navController.navigate(AudioRoute)
                  }
                },
              )
              if (isTopLevel && !useNavRail) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                  topLevelTabs.forEach { tab ->
                    val selected =
                      when (tab.route) {
                        is HomeRoute -> currentDestination?.hasRoute<HomeRoute>() == true
                        is SurahsRoute -> currentDestination?.hasRoute<SurahsRoute>() == true
                        is TafsirRoute -> currentDestination?.hasRoute<TafsirRoute>() == true
                        is AdhkarRoute -> currentDestination?.hasRoute<AdhkarRoute>() == true
                        is MoreRoute -> currentDestination?.hasRoute<MoreRoute>() == true
                        else -> false
                      }
                    NavigationBarItem(
                      selected = selected,
                      onClick = { navigateTopLevel(tab.route) },
                      icon = {
                        Icon(
                          imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                          contentDescription = tab.label,
                        )
                      },
                      label = { Text(tab.label) },
                      modifier = Modifier.testTag(tab.testTag),
                    )
                  }
                }
              }
            }
          }
        },
      ) { innerPadding ->
        Box(
          modifier =
            Modifier.fillMaxSize().then(
              if (!isReaderScreen) Modifier.padding(innerPadding) else Modifier
            )
        ) {
          NavHost(navController = navController, startDestination = HomeRoute) {
            composable<HomeRoute> {
              val homeVm: HomeViewModel =
                viewModel(
                  factory =
                    HomeViewModel.factory(
                      appContainer.quranRepository,
                      appContainer.preferencesRepository,
                    )
                )
              val progress by homeVm.readingProgress.collectAsStateWithLifecycle()
              val featured by homeVm.featuredSurahs.collectAsStateWithLifecycle()
              val bookmarksCount by homeVm.bookmarksCount.collectAsStateWithLifecycle()
              val activeKhatmah by homeVm.activeKhatmah.collectAsStateWithLifecycle()
              val totalVoiceDhikrCount by homeVm.totalVoiceDhikrCount.collectAsStateWithLifecycle()

              HomeScreen(
                readingProgress = progress,
                dailyReflection = homeVm.dailyReflection,
                featuredSurahs = featured,
                bookmarksCount = bookmarksCount,
                activeKhatmah = activeKhatmah,
                totalVoiceDhikrCount = totalVoiceDhikrCount,
                currentThemeMode = currentThemeMode,
                onToggleTheme = {
                  val nextMode =
                    when (currentThemeMode) {
                      ReaderThemeMode.MIDNIGHT -> ReaderThemeMode.PARCHMENT
                      else -> ReaderThemeMode.MIDNIGHT
                    }
                  scope.launch { appContainer.preferencesRepository.updateThemeMode(nextMode) }
                },
                onOpenSurah = { surahNum, ayahNum -> openReader(surahNum, ayahNum) },
                onOpenAllSurahs = { navigateTopLevel(SurahsRoute) },
                onOpenTafsir = { navigateTopLevel(TafsirRoute()) },
                onOpenAudioLibrary = { navController.navigate(AudioRoute) },
                onOpenVoiceDhikr = { navController.navigate(VoiceDhikrRoute) },
                onOpenAdhkar = { navigateTopLevel(AdhkarRoute()) },
                onOpenKhatmah = { navController.navigate(KhatmahRoute) },
                onOpenDailyPage = { navController.navigate(DailyPageRoute) },
                onOpenBookmarks = { navController.navigate(BookmarksRoute) },
                onOpenSearch = { navController.navigate(SearchRoute) },
                onOpenSettings = { navController.navigate(SettingsRoute) },
                onOpenSocial = { navController.navigate(SocialRoute) },
                onOpenDhikrStats = { navController.navigate(DhikrStatsRoute) },
                onOpenReciters = { navController.navigate(RecitersRoute()) },
                onOpenManageLocalReciters = { navController.navigate(ManageLocalRecitersRoute) },
              )
            }

            composable<SurahsRoute> {
              val listVm: SurahListViewModel =
                viewModel(factory = SurahListViewModel.factory(appContainer.quranRepository))
              val surahs by listVm.filteredSurahs.collectAsStateWithLifecycle()
              val query by listVm.searchQuery.collectAsStateWithLifecycle()
              val filter by listVm.revelationFilter.collectAsStateWithLifecycle()
              val browseTab by listVm.browseTab.collectAsStateWithLifecycle()

              SurahListScreen(
                surahs = surahs,
                searchQuery = query,
                revelationFilter = filter,
                browseTab = browseTab,
                onSearchQueryChange = listVm::onSearchQueryChange,
                onRevelationFilterChange = listVm::onRevelationFilterChange,
                onBrowseTabChange = listVm::onBrowseTabChange,
                onOpenSurah = { surahNum, ayahNum -> openReader(surahNum, ayahNum) },
                onOpenPage = { pageNum -> openReader(surahNumber = 1, ayahNumber = 1, pageNumber = pageNum) },
              )
            }

            composable<TafsirRoute> { entry ->
              val route = entry.toRoute<TafsirRoute>()
              val tafsirVm: TafsirViewModel =
                viewModel(
                  key = "tafsir_${route.surahNumber}_${route.ayahNumber}",
                  factory =
                    TafsirViewModel.factory(
                      initialSurah = route.surahNumber,
                      initialAyah = route.ayahNumber,
                      quranRepository = appContainer.quranRepository,
                      preferencesRepository = appContainer.preferencesRepository,
                    ),
                )
              val surahs by tafsirVm.surahs.collectAsStateWithLifecycle()
              val selectedSurah by tafsirVm.selectedSurahNumber.collectAsStateWithLifecycle()
              val selectedAyah by tafsirVm.selectedAyahFilter.collectAsStateWithLifecycle()
              val editionId by tafsirVm.tafsirEditionId.collectAsStateWithLifecycle()
              val fontSize by tafsirVm.tafsirFontSize.collectAsStateWithLifecycle()
              val query by tafsirVm.searchQuery.collectAsStateWithLifecycle()
              val uiState by tafsirVm.uiState.collectAsStateWithLifecycle()

              TafsirScreen(
                surahs = surahs,
                selectedSurahNumber = selectedSurah,
                selectedAyahFilter = selectedAyah,
                tafsirEditionId = editionId,
                tafsirFontSize = fontSize,
                searchQuery = query,
                uiState = uiState,
                onSelectSurah = tafsirVm::selectSurah,
                onSelectAyah = tafsirVm::selectAyahFilter,
                onSelectEdition = tafsirVm::selectEdition,
                onFontSizeChange = tafsirVm::updateTafsirFontSize,
                onSearchQueryChange = tafsirVm::onSearchQueryChange,
                onRetry = tafsirVm::retry,
                onOpenInMushaf = { sNum, aNum -> openReader(surahNumber = sNum, ayahNumber = aNum) },
              )
            }

            composable<AdhkarRoute> { entry ->
              val route = entry.toRoute<AdhkarRoute>()
              val initialCategory =
                AdhkarCategory.entries.firstOrNull { it.id == route.categoryId }
                  ?: AdhkarCategory.MORNING
              val adhkarVm: AdhkarViewModel =
                viewModel(
                  key = "adhkar_${route.categoryId}",
                  factory =
                    AdhkarViewModel.factory(
                      initialCategory = initialCategory,
                      quranRepository = appContainer.quranRepository,
                      preferencesRepository = appContainer.preferencesRepository,
                    ),
                )
              val selectedCategory by adhkarVm.selectedCategory.collectAsStateWithLifecycle()
              val items by adhkarVm.itemsForCategory.collectAsStateWithLifecycle()
              val fontSize by adhkarVm.adhkarFontSize.collectAsStateWithLifecycle()

              AdhkarScreen(
                selectedCategory = selectedCategory,
                items = items,
                fontSize = fontSize,
                onSelectCategory = adhkarVm::selectCategory,
                onIncrementItem = adhkarVm::incrementItem,
                onResetItem = adhkarVm::resetItem,
                onResetAll = adhkarVm::resetAllAdhkar,
                onFontSizeChange = adhkarVm::updateFontSize,
                onOpenReminders = { navController.navigate(SettingsRoute) },
                onOpenStats = { navController.navigate(DhikrStatsRoute) },
              )
            }

            composable<MoreRoute> {
              MoreScreen(
                onOpenAudioLibrary = { navController.navigate(AudioRoute) },
                onOpenVoiceDhikr = { navController.navigate(VoiceDhikrRoute) },
                onOpenDhikrStats = { navController.navigate(DhikrStatsRoute) },
                onOpenKhatmah = { navController.navigate(KhatmahRoute) },
                onOpenDailyPage = { navController.navigate(DailyPageRoute) },
                onOpenBookmarks = { navController.navigate(BookmarksRoute) },
                onOpenSearch = { navController.navigate(SearchRoute) },
                onOpenSocial = { navController.navigate(SocialRoute) },
                onOpenSettings = { navController.navigate(SettingsRoute) },
                onOpenReciters = { navController.navigate(RecitersRoute()) },
                onOpenManageLocalReciters = { navController.navigate(ManageLocalRecitersRoute) },
              )
            }

            composable<AudioRoute> {
              val audioVm: AudioLibraryViewModel =
                viewModel(
                  factory =
                    AudioLibraryViewModel.factory(
                      quranRepository = appContainer.quranRepository,
                      preferencesRepository = appContainer.preferencesRepository,
                      audioPlayer = appContainer.audioPlayer,
                      backendRepository = appContainer.firebaseBackendRepository,
                    )
                )
              val surahs by audioVm.filteredSurahs.collectAsStateWithLifecycle()
              val reciters by audioVm.reciters.collectAsStateWithLifecycle()
              val reciterId by audioVm.selectedReciterId.collectAsStateWithLifecycle()
              val downloaded by audioVm.downloadedSurahs.collectAsStateWithLifecycle()
              val downloadProgress by audioVm.downloadProgressMap.collectAsStateWithLifecycle()
              val libAudioState by audioVm.audioState.collectAsStateWithLifecycle()
              val volume by audioVm.volumeLevel.collectAsStateWithLifecycle()
              val query by audioVm.searchQuery.collectAsStateWithLifecycle()
              val message by audioVm.message.collectAsStateWithLifecycle()

              AudioLibraryScreen(
                surahs = surahs,
                selectedReciterId = reciterId,
                downloadedSurahs = downloaded,
                downloadProgressMap = downloadProgress,
                audioState = libAudioState,
                volumeLevel = volume,
                searchQuery = query,
                statusMessage = message,
                reciters = reciters,
                onClearMessage = audioVm::clearMessage,
                onSelectReciter = audioVm::selectReciter,
                onSearchQueryChange = audioVm::onSearchQueryChange,
                onPlaySurah = audioVm::playSurah,
                onTogglePlayPause = audioVm::togglePlayPause,
                onSeekTo = audioVm::seekTo,
                onSeekBySeconds = audioVm::seekBySeconds,
                onStopPlayback = audioVm::stopPlayback,
                onVolumeChange = audioVm::setVolume,
                onDownloadSurah = audioVm::downloadSurah,
                onDeleteDownload = audioVm::deleteDownload,
                onOpenReciters = { navController.navigate(RecitersRoute(reciterId)) },
                onOpenManageLocalReciters = { navController.navigate(ManageLocalRecitersRoute) },
              )
            }

            composable<RecitersRoute> { entry ->
              val route = entry.toRoute<RecitersRoute>()
              val recitersVm: RecitersViewModel =
                viewModel(
                  key = "reciters_${route.initialReciterId ?: "directory"}",
                  factory =
                    RecitersViewModel.factory(
                      initialReciterId = route.initialReciterId,
                      quranRepository = appContainer.quranRepository,
                      preferencesRepository = appContainer.preferencesRepository,
                      audioPlayer = appContainer.audioPlayer,
                      backendRepository = appContainer.firebaseBackendRepository,
                    ),
                )
              val reciters by recitersVm.filteredReciters.collectAsStateWithLifecycle()
              val selectedReciter by recitersVm.selectedReciter.collectAsStateWithLifecycle()
              val preferredReciterId by recitersVm.preferredReciterId.collectAsStateWithLifecycle()
              val searchQuery by recitersVm.searchQuery.collectAsStateWithLifecycle()
              val sourceFilter by recitersVm.sourceFilter.collectAsStateWithLifecycle()
              val trackSearchQuery by recitersVm.trackSearchQuery.collectAsStateWithLifecycle()
              val publishedTracks by recitersVm.filteredTracksForSelected.collectAsStateWithLifecycle()
              val localTracks by recitersVm.filteredLocalTracksForSelected.collectAsStateWithLifecycle()
              val catalogSurahs by recitersVm.filteredCatalogSurahs.collectAsStateWithLifecycle()
              val downloadedSurahs by recitersVm.downloadedSurahs.collectAsStateWithLifecycle()
              val downloadProgress by recitersVm.downloadProgressMap.collectAsStateWithLifecycle()
              val reciterAudioState by recitersVm.audioState.collectAsStateWithLifecycle()
              val message by recitersVm.message.collectAsStateWithLifecycle()

              RecitersScreen(
                reciters = reciters,
                selectedReciter = selectedReciter,
                preferredReciterId = preferredReciterId,
                searchQuery = searchQuery,
                sourceFilter = sourceFilter,
                trackSearchQuery = trackSearchQuery,
                publishedTracks = publishedTracks,
                localTracks = localTracks,
                catalogSurahs = catalogSurahs,
                downloadedSurahs = downloadedSurahs,
                downloadProgressMap = downloadProgress,
                audioState = reciterAudioState,
                statusMessage = message,
                onClearMessage = recitersVm::clearMessage,
                onSearchQueryChange = recitersVm::onSearchQueryChange,
                onSourceFilterChange = recitersVm::onSourceFilterChange,
                onOpenReciter = recitersVm::openReciter,
                onBackToRecitersList = recitersVm::closeReciterDetail,
                onTrackSearchQueryChange = recitersVm::onTrackSearchQueryChange,
                onSetPreferredReciter = recitersVm::setPreferredReciter,
                onPlayCloudRecitation = recitersVm::playCloudRecitation,
                onPlayLocalRecitation = recitersVm::playLocalRecitation,
                onPlayCatalogSurah = recitersVm::playCatalogSurah,
                onTogglePlayPause = recitersVm::togglePlayPause,
                onSeekTo = recitersVm::seekTo,
                onSeekBySeconds = recitersVm::seekBySeconds,
                onStopPlayback = recitersVm::stopPlayback,
                onDownloadSurah = recitersVm::downloadSurah,
                onDeleteDownload = recitersVm::deleteDownload,
                onOpenManageLocalReciters = { navController.navigate(ManageLocalRecitersRoute) },
              )
            }

            composable<ManageLocalRecitersRoute> {
              val manageVm: ManageLocalRecitersViewModel =
                viewModel(
                  factory =
                    ManageLocalRecitersViewModel.factory(
                      quranRepository = appContainer.quranRepository,
                      preferencesRepository = appContainer.preferencesRepository,
                      audioPlayer = appContainer.audioPlayer,
                    )
                )
              val reciters by manageVm.filteredLocalReciters.collectAsStateWithLifecycle()
              val trackCountByReciter by manageVm.trackCountByReciter.collectAsStateWithLifecycle()
              val selectedReciter by manageVm.selectedReciter.collectAsStateWithLifecycle()
              val recitationsForSelected by manageVm.recitationsForSelected.collectAsStateWithLifecycle()
              val surahs by manageVm.surahs.collectAsStateWithLifecycle()
              val preferredReciterId by manageVm.preferredReciterId.collectAsStateWithLifecycle()
              val searchQuery by manageVm.searchQuery.collectAsStateWithLifecycle()
              val isBusy by manageVm.isBusy.collectAsStateWithLifecycle()
              val isProbingUrl by manageVm.isProbingUrl.collectAsStateWithLifecycle()
              val probeResult by manageVm.probeResult.collectAsStateWithLifecycle()
              val manageAudioState by manageVm.audioState.collectAsStateWithLifecycle()
              val statusMessage by manageVm.statusMessage.collectAsStateWithLifecycle()

              ManageLocalRecitersScreen(
                reciters = reciters,
                trackCountByReciter = trackCountByReciter,
                selectedReciter = selectedReciter,
                recitationsForSelected = recitationsForSelected,
                surahs = surahs,
                preferredReciterId = preferredReciterId,
                searchQuery = searchQuery,
                isBusy = isBusy,
                isProbingUrl = isProbingUrl,
                probeResult = probeResult,
                audioState = manageAudioState,
                statusMessage = statusMessage,
                onClearMessage = manageVm::clearMessage,
                onClearProbeResult = manageVm::clearProbeResult,
                onSearchQueryChange = manageVm::onSearchQueryChange,
                onOpenReciter = manageVm::openReciter,
                onBackToList = manageVm::closeReciterDetail,
                onProbeAudioUrl = manageVm::probeAudioUrl,
                onImportPhotoUri = manageVm::importPhotoFromUri,
                onSaveReciter = manageVm::saveReciter,
                onDeleteReciter = manageVm::deleteReciter,
                onSaveRecitation = manageVm::saveRecitation,
                onDeleteRecitation = manageVm::deleteRecitation,
                onSetPreferredReciter = manageVm::setPreferredReciter,
                onPlayTrack = manageVm::playLocalTrack,
                onPlayFullSurahSample = manageVm::playFullSurahSample,
                onTogglePlayPause = manageVm::togglePlayPause,
                onSeekTo = manageVm::seekTo,
                onSeekBySeconds = manageVm::seekBySeconds,
                onStopPlayback = manageVm::stopPlayback,
              )
            }

            composable<VoiceDhikrRoute> {
              val dhikrVm: VoiceDhikrViewModel =
                viewModel(
                  factory =
                    VoiceDhikrViewModel.factory(
                      quranRepository = appContainer.quranRepository,
                      preferencesRepository = appContainer.preferencesRepository,
                      controller = appContainer.voiceDhikrController,
                    )
                )
              val status by dhikrVm.status.collectAsStateWithLifecycle()
              val counters by dhikrVm.counters.collectAsStateWithLifecycle()

              VoiceDhikrScreen(
                status = status,
                counters = counters,
                onStartListening = dhikrVm::startListening,
                onPauseListening = dhikrVm::pauseListening,
                onPermissionDenied = dhikrVm::onPermissionDenied,
                onResetSingleCounter = dhikrVm::resetSingleCounter,
                onResetAllCounters = dhikrVm::resetAllCounters,
                onOpenStats = { navController.navigate(DhikrStatsRoute) },
              )
            }

            composable<DhikrStatsRoute> {
              val statsVm: DhikrStatsViewModel =
                viewModel(factory = DhikrStatsViewModel.factory(appContainer.quranRepository))
              val uiState by statsVm.uiState.collectAsStateWithLifecycle()

              DhikrStatsScreen(
                uiState = uiState,
                onSelectPeriodMode = statsVm::selectPeriodMode,
                onSelectDailyWindowDays = statsVm::selectDailyWindowDays,
                onSelectPoint = statsVm::selectPoint,
                onOpenVoiceDhikr = { navController.navigate(VoiceDhikrRoute) },
                onOpenAdhkar = { navigateTopLevel(AdhkarRoute()) },
              )
            }

            composable<KhatmahRoute> {
              val khatmahVm: KhatmahViewModel =
                viewModel(factory = KhatmahViewModel.factory(appContainer.quranRepository))
              val plans by khatmahVm.plans.collectAsStateWithLifecycle()

              KhatmahScreen(
                plans = plans,
                todayEpochDay = khatmahVm.todayEpochDay(),
                onCreatePlan = khatmahVm::createPlan,
                onUpdateSchedule = khatmahVm::updateSchedule,
                onMarkPagesRead = khatmahVm::markPagesRead,
                onTogglePause = khatmahVm::togglePause,
                onDeletePlan = khatmahVm::deletePlan,
                onOpenMushafPage = { page -> openReader(pageNumber = page) },
              )
            }

            composable<DailyPageRoute> {
              val dailyVm: DailyPageViewModel =
                viewModel(
                  factory =
                    DailyPageViewModel.factory(
                      application = application,
                      quranRepository = appContainer.quranRepository,
                      preferencesRepository = appContainer.preferencesRepository,
                    )
                )
              val uiState by dailyVm.uiState.collectAsStateWithLifecycle()
              val settings by dailyVm.settings.collectAsStateWithLifecycle()

              DailyPageScreen(
                uiState = uiState,
                settings = settings,
                onPreviousPage = dailyVm::previousPage,
                onNextPage = dailyVm::nextPage,
                onRetry = dailyVm::retry,
                onUpdateSchedule = dailyVm::updateSchedule,
                onOpenInMushaf = { page -> openReader(pageNumber = page) },
              )
            }

            composable<BookmarksRoute> {
              val bookmarksVm: BookmarksViewModel =
                viewModel(factory = BookmarksViewModel.factory(appContainer.quranRepository))
              val bookmarks by bookmarksVm.bookmarks.collectAsStateWithLifecycle()
              val selectedCategory by bookmarksVm.selectedCategory.collectAsStateWithLifecycle()

              BookmarksScreen(
                bookmarks = bookmarks,
                selectedCategory = selectedCategory,
                onSelectCategory = bookmarksVm::selectCategory,
                onOpenAyah = { surahNum, ayahNum -> openReader(surahNum, ayahNum) },
                onUpdateBookmarkDetails = bookmarksVm::updateBookmarkDetails,
                onRemoveBookmark = bookmarksVm::removeBookmark,
                onExploreSurahs = { navigateTopLevel(SurahsRoute) },
              )
            }

            composable<SearchRoute> {
              val searchVm: SearchViewModel =
                viewModel(
                  factory =
                    SearchViewModel.factory(
                      appContainer.quranRepository,
                      appContainer.preferencesRepository,
                    )
                )
              val query by searchVm.query.collectAsStateWithLifecycle()
              val selectedType by searchVm.selectedTypeFilter.collectAsStateWithLifecycle()
              val uiState by searchVm.uiState.collectAsStateWithLifecycle()

              SearchScreen(
                query = query,
                selectedTypeFilter = selectedType,
                uiState = uiState,
                suggestedTopics = searchVm.suggestedTopics,
                onQueryChange = searchVm::onQueryChange,
                onSelectTopic = searchVm::selectTopic,
                onSelectTypeFilter = searchVm::selectTypeFilter,
                onRetry = searchVm::retry,
                onOpenMatch = { match ->
                  when (match.matchType) {
                    SearchResultType.SURAH,
                    SearchResultType.AYAH ->
                      openReader(
                        surahNumber = match.surahNumber,
                        ayahNumber = match.numberInSurah.coerceAtLeast(1),
                      )
                    SearchResultType.TAFSIR ->
                      navigateTopLevel(
                        TafsirRoute(
                          surahNumber = match.surahNumber.coerceIn(1, 114),
                          ayahNumber = match.numberInSurah,
                        )
                      )
                    SearchResultType.ADHKAR -> navigateTopLevel(AdhkarRoute())
                  }
                },
              )
            }

            composable<SettingsRoute> {
              val settingsVm: SettingsViewModel =
                viewModel(
                  factory =
                    SettingsViewModel.factory(
                      application = application,
                      quranRepository = appContainer.quranRepository,
                      preferencesRepository = appContainer.preferencesRepository,
                      audioPlayer = appContainer.audioPlayer,
                      authManager = appContainer.firebaseAuthManager,
                      backendRepository = appContainer.firebaseBackendRepository,
                    )
                )
              val settings by settingsVm.settings.collectAsStateWithLifecycle()
              val reminders by settingsVm.reminders.collectAsStateWithLifecycle()
              val adminStatus by settingsVm.adminStatus.collectAsStateWithLifecycle()
              val authBusy by settingsVm.authBusy.collectAsStateWithLifecycle()
              val authMessage by settingsVm.authMessage.collectAsStateWithLifecycle()
              val reciters by settingsVm.reciters.collectAsStateWithLifecycle()

              SettingsScreen(
                settings = settings,
                reminders = reminders,
                adminStatus = adminStatus,
                authBusy = authBusy,
                authMessage = authMessage,
                reciters = reciters,
                onClearAuthMessage = settingsVm::clearAuthMessage,
                onGoogleSignIn = settingsVm::signInWithGoogle,
                onSignOut = settingsVm::signOut,
                onOpenOwnerAdmin = {
                  if (adminStatus.isSuperAdmin) {
                    navController.navigate(AdminRoute)
                  }
                },
                onThemeModeChange = settingsVm::updateThemeMode,
                onArabicFontSizeChange = settingsVm::updateArabicFontSize,
                onTafsirFontSizeChange = settingsVm::updateTafsirFontSize,
                onAdhkarFontSizeChange = settingsVm::updateAdhkarFontSize,
                onReciterChange = settingsVm::updateReciter,
                onShowTranslationChange = settingsVm::updateShowTranslation,
                onTranslationEditionChange = settingsVm::updateTranslationEdition,
                onVoicePartialMatchChange = settingsVm::updateVoicePartialMatch,
                onReminderChange = settingsVm::updateReminder,
                onOpenKhatmah = { navController.navigate(KhatmahRoute) },
                onOpenDailyPage = { navController.navigate(DailyPageRoute) },
              )
            }

            composable<AdminRoute> {
              val adminVm: AdminViewModel =
                viewModel(
                  factory =
                    AdminViewModel.factory(
                      authManager = appContainer.firebaseAuthManager,
                      backendRepository = appContainer.firebaseBackendRepository,
                      audioPlayer = appContainer.audioPlayer,
                    )
                )
              val adminStatus by adminVm.adminStatus.collectAsStateWithLifecycle()
              val isCheckingAuth by adminVm.isCheckingAuth.collectAsStateWithLifecycle()
              val isBusy by adminVm.isBusy.collectAsStateWithLifecycle()
              val isProbingUrl by adminVm.isProbingUrl.collectAsStateWithLifecycle()
              val probeResult by adminVm.probeResult.collectAsStateWithLifecycle()
              val adminAudioState by adminVm.audioState.collectAsStateWithLifecycle()
              val reciters by adminVm.reciters.collectAsStateWithLifecycle()
              val selectedReciterId by adminVm.selectedReciterId.collectAsStateWithLifecycle()
              val recitations by adminVm.recitationsForSelectedReciter.collectAsStateWithLifecycle()
              val statusMessage by adminVm.statusMessage.collectAsStateWithLifecycle()

              AdminRecitersScreen(
                adminStatus = adminStatus,
                isCheckingAuth = isCheckingAuth,
                isBusy = isBusy,
                isProbingUrl = isProbingUrl,
                probeResult = probeResult,
                audioState = adminAudioState,
                reciters = reciters,
                selectedReciterId = selectedReciterId,
                recitations = recitations,
                statusMessage = statusMessage,
                onClearMessage = adminVm::clearMessage,
                onClearProbeResult = adminVm::clearProbeResult,
                onSelectReciter = adminVm::selectReciter,
                onProbeUrl = adminVm::probeAudioUrl,
                onPreviewRecitationAudio = adminVm::previewRecitationAudio,
                onSeekAudio = adminVm::seekTo,
                onStopPreviewAudio = adminVm::stopPreviewAudio,
                onSaveReciter = adminVm::saveReciter,
                onMoveReciterOrder = adminVm::moveReciterOrder,
                onDeleteReciter = adminVm::deleteReciter,
                onSaveRecitation = adminVm::saveRecitation,
                onMoveRecitationOrder = adminVm::moveRecitationOrder,
                onDeleteRecitation = adminVm::deleteRecitation,
                onBack = { navController.popBackStack() },
              )
            }

            composable<SocialRoute> { SocialScreen() }

            composable<ReaderRoute> { entry ->
              val route = entry.toRoute<ReaderRoute>()
              val readerVm: SurahReaderViewModel =
                viewModel(
                  key = "reader_${route.surahNumber}_${route.pageNumber}",
                  factory =
                    SurahReaderViewModel.factory(
                      surahNumber = route.surahNumber,
                      pageNumber = route.pageNumber,
                      quranRepository = appContainer.quranRepository,
                      preferencesRepository = appContainer.preferencesRepository,
                      audioPlayer = appContainer.audioPlayer,
                      backendRepository = appContainer.firebaseBackendRepository,
                    ),
                )
              val uiState by readerVm.uiState.collectAsStateWithLifecycle()
              val settings by readerVm.readerSettings.collectAsStateWithLifecycle()
              val bookmarkedKeys by readerVm.bookmarkedKeys.collectAsStateWithLifecycle()
              val readerAudioState by readerVm.audioState.collectAsStateWithLifecycle()
              val isPageMode by readerVm.isPageMode.collectAsStateWithLifecycle()
              val activePage by readerVm.activePage.collectAsStateWithLifecycle()
              val readerReciters by readerVm.reciters.collectAsStateWithLifecycle()

              SurahReaderScreen(
                uiState = uiState,
                readerSettings = settings,
                bookmarkedKeys = bookmarkedKeys,
                audioState = readerAudioState,
                scrollToAyah = route.scrollToAyah,
                isPageMode = isPageMode,
                activePage = activePage,
                onBack = { navController.popBackStack() },
                onRetry = readerVm::retry,
                onNavigateToSurah = { nextSurah ->
                  navController.navigate(
                    ReaderRoute(surahNumber = nextSurah, scrollToAyah = 1, pageNumber = 0)
                  ) {
                    popUpTo<ReaderRoute> { inclusive = true }
                  }
                },
                onSwitchToPage = readerVm::switchToPage,
                onSwitchToSurahMode = readerVm::switchToSurahMode,
                onOpenTafsir = { surahNum, ayahNum ->
                  navController.navigate(TafsirRoute(surahNumber = surahNum, ayahNumber = ayahNum))
                },
                onToggleBookmark = readerVm::toggleBookmark,
                onRecordProgress = readerVm::recordReadingProgress,
                onPlayAyah = readerVm::playAyah,
                onPlaySurahFromStart = readerVm::playSurahFromStart,
                onTogglePlayPause = { appContainer.audioPlayer.togglePlayPause() },
                onAudioPrevious = { appContainer.audioPlayer.playPrevious() },
                onAudioNext = { appContainer.audioPlayer.playNext() },
                onAudioStop = { appContainer.audioPlayer.stop() },
                onZoomIn = readerVm::zoomInQuranText,
                onZoomOut = readerVm::zoomOutQuranText,
                onResetFontSize = readerVm::resetQuranFontSize,
                onArabicFontSizeChange = readerVm::updateArabicFontSize,
                onTranslationFontSizeChange = readerVm::updateTranslationFontSize,
                onShowTranslationChange = readerVm::updateShowTranslation,
                onTranslationEditionChange = readerVm::updateTranslationEdition,
                onReciterChange = readerVm::updateReciter,
                onThemeModeChange = readerVm::updateThemeMode,
                onVolumeChange = readerVm::updateVolume,
                reciters = readerReciters,
                onOpenManageReciters = { navController.navigate(ManageLocalRecitersRoute) },
              )
            }
          }
        }
      }
    }
  }
}
