package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioPlaybackState
import com.example.audio.QuranAudioPlayer
import com.example.data.firebase.FirebaseQuranBackendRepository
import com.example.data.firebase.FirebaseRecitationTrack
import com.example.data.firebase.FirebaseReciter
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.LocalRecitationTrack
import com.example.data.model.LocalReciter
import com.example.data.model.QuranCatalog
import com.example.data.model.ReciterOption
import com.example.data.model.SurahInfo
import com.example.data.repository.QuranRepository
import com.example.dhikr.DhikrSpeechMatcher
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class ReciterSourceFilter(val label: String) {
  ALL("الجميع"),
  LOCAL("قرّائي المضافون"),
  CLOUD("قرّاء المنصة المضافون"),
  CATALOG("القرّاء الأساسيون"),
}

@OptIn(ExperimentalCoroutinesApi::class)
class RecitersViewModel(
  initialReciterId: String? = null,
  private val quranRepository: QuranRepository,
  private val preferencesRepository: UserPreferencesRepository,
  private val audioPlayer: QuranAudioPlayer,
  private val backendRepository: FirebaseQuranBackendRepository,
) : ViewModel() {

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _trackSearchQuery = MutableStateFlow("")
  val trackSearchQuery: StateFlow<String> = _trackSearchQuery.asStateFlow()

  private val _sourceFilter = MutableStateFlow(ReciterSourceFilter.ALL)
  val sourceFilter: StateFlow<ReciterSourceFilter> = _sourceFilter.asStateFlow()

  private val _selectedReciterId = MutableStateFlow(initialReciterId)
  val selectedReciterId: StateFlow<String?> = _selectedReciterId.asStateFlow()

  private val _downloadProgressMap = MutableStateFlow<Map<Int, Float>>(emptyMap())
  val downloadProgressMap: StateFlow<Map<Int, Float>> = _downloadProgressMap.asStateFlow()

  private val _message = MutableStateFlow<String?>(null)
  val message: StateFlow<String?> = _message.asStateFlow()

  val preferredReciterId: StateFlow<String> =
    preferencesRepository.readerSettingsFlow
      .map { it.reciterIdentifier }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "ar.alafasy",
      )

  val allReciters: StateFlow<List<ReciterOption>> =
    combine(
        backendRepository.observePublishedReciters(),
        quranRepository.localRecitersFlow,
      ) { cloudReciters, localReciters ->
        val merged = mergePublishedAndCatalogReciters(cloudReciters, localReciters)
        audioPlayer.updateKnownReciters(merged)
        merged
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = QuranCatalog.reciters,
      )

  val filteredReciters: StateFlow<List<ReciterOption>> =
    combine(allReciters, _searchQuery, _sourceFilter) { reciters, query, filter ->
        val bySource =
          when (filter) {
            ReciterSourceFilter.ALL -> reciters
            ReciterSourceFilter.LOCAL -> reciters.filter { it.isLocalCustom }
            ReciterSourceFilter.CLOUD -> reciters.filter { it.isCloudSynced }
            ReciterSourceFilter.CATALOG -> reciters.filter { !it.isCloudSynced && !it.isLocalCustom }
          }
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty()) {
          bySource
        } else {
          val normalizedQuery = DhikrSpeechMatcher.normalizeArabic(cleanQuery)
          bySource.filter { reciter ->
            reciter.arabicName.contains(cleanQuery, ignoreCase = true) ||
              reciter.riwayah.contains(cleanQuery, ignoreCase = true) ||
              reciter.styleArabic.contains(cleanQuery, ignoreCase = true) ||
              reciter.bioArabic.contains(cleanQuery, ignoreCase = true) ||
              (normalizedQuery.isNotEmpty() &&
                (DhikrSpeechMatcher.normalizeArabic(reciter.arabicName).contains(normalizedQuery) ||
                  DhikrSpeechMatcher.normalizeArabic(reciter.riwayah).contains(normalizedQuery) ||
                  DhikrSpeechMatcher.normalizeArabic(reciter.styleArabic).contains(normalizedQuery) ||
                  DhikrSpeechMatcher.normalizeArabic(reciter.bioArabic).contains(normalizedQuery)))
          }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = QuranCatalog.reciters,
      )

  val selectedReciter: StateFlow<ReciterOption?> =
    combine(allReciters, _selectedReciterId) { list, id ->
        if (id.isNullOrBlank()) null else list.firstOrNull { it.identifier == id }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null,
      )

  val publishedTracksForSelected: StateFlow<List<FirebaseRecitationTrack>> =
    _selectedReciterId
      .flatMapLatest { id ->
        if (id.isNullOrBlank()) flowOf(emptyList())
        else backendRepository.observePublishedRecitations(id)
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  val localTracksForSelected: StateFlow<List<LocalRecitationTrack>> =
    _selectedReciterId
      .flatMapLatest { id ->
        if (id.isNullOrBlank()) flowOf(emptyList())
        else quranRepository.localRecitationsForReciterFlow(id)
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  val filteredLocalTracksForSelected: StateFlow<List<LocalRecitationTrack>> =
    combine(localTracksForSelected, _trackSearchQuery) { tracks, query ->
        val clean = query.trim()
        if (clean.isEmpty()) {
          tracks
        } else {
          val norm = DhikrSpeechMatcher.normalizeArabic(clean)
          tracks.filter { track ->
            track.surahArabicName.contains(clean) ||
              track.notes.contains(clean) ||
              track.surahNumber.toString() == clean ||
              (norm.isNotEmpty() &&
                (DhikrSpeechMatcher.normalizeArabic(track.surahArabicName).contains(norm) ||
                  DhikrSpeechMatcher.normalizeArabic(track.notes).contains(norm)))
          }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  val filteredTracksForSelected: StateFlow<List<FirebaseRecitationTrack>> =
    combine(publishedTracksForSelected, _trackSearchQuery) { tracks, query ->
        val clean = query.trim()
        if (clean.isEmpty()) {
          tracks
        } else {
          val norm = DhikrSpeechMatcher.normalizeArabic(clean)
          tracks.filter { track ->
            track.surahArabicName.contains(clean) ||
              track.description.contains(clean) ||
              track.surahNumber.toString() == clean ||
              (norm.isNotEmpty() &&
                (DhikrSpeechMatcher.normalizeArabic(track.surahArabicName).contains(norm) ||
                  DhikrSpeechMatcher.normalizeArabic(track.description).contains(norm)))
          }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  val filteredCatalogSurahs: StateFlow<List<SurahInfo>> =
    combine(quranRepository.surahsFlow, _trackSearchQuery) { surahs, query ->
        val clean = query.trim()
        if (clean.isEmpty()) {
          surahs
        } else {
          val norm = DhikrSpeechMatcher.normalizeArabic(clean)
          surahs.filter {
            it.arabicName.contains(clean) ||
              it.englishName.contains(clean, ignoreCase = true) ||
              it.number.toString() == clean ||
              (norm.isNotEmpty() && DhikrSpeechMatcher.normalizeArabic(it.arabicName).contains(norm))
          }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  val downloadedSurahs: StateFlow<Set<Int>> =
    _selectedReciterId
      .flatMapLatest { reciterId ->
        if (reciterId.isNullOrBlank()) flowOf(emptySet())
        else quranRepository.downloadedSurahsFlow(reciterId)
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptySet(),
      )

  val audioState: StateFlow<AudioPlaybackState> = audioPlayer.state

  init {
    viewModelScope.launch { quranRepository.ensureInitialDataSeeded() }
  }

  fun onSearchQueryChange(query: String) {
    _searchQuery.value = query
  }

  fun onTrackSearchQueryChange(query: String) {
    _trackSearchQuery.value = query
  }

  fun onSourceFilterChange(filter: ReciterSourceFilter) {
    _sourceFilter.value = filter
  }

  fun openReciter(reciterId: String) {
    _selectedReciterId.value = reciterId
    _trackSearchQuery.value = ""
  }

  fun closeReciterDetail() {
    _selectedReciterId.value = null
    _trackSearchQuery.value = ""
  }

  fun setPreferredReciter(reciterId: String) {
    viewModelScope.launch {
      preferencesRepository.updateReciter(reciterId)
      _message.value = "تم تعيين القارئ كمفضّل للتلاوة"
    }
  }

  fun playCloudRecitation(track: FirebaseRecitationTrack, reciter: ReciterOption) {
    val current = audioPlayer.state.value
    if (
      current.isActive &&
        current.trackId == track.id &&
        current.reciterId == reciter.identifier
    ) {
      audioPlayer.togglePlayPause()
    } else {
      audioPlayer.playCustomRecitation(
        trackId = track.id,
        surahNumber = track.surahNumber.toInt().coerceIn(1, 114),
        surahArabicName = track.surahArabicName,
        reciterId = reciter.identifier,
        reciterDisplayName = reciter.arabicName,
        audioUrl = track.audioUrl,
        description = track.description,
      )
    }
  }

  fun playLocalRecitation(track: LocalRecitationTrack, reciter: ReciterOption) {
    val trackId = "local_${track.reciterId}_${track.surahNumber}"
    val current = audioPlayer.state.value
    if (
      current.isActive &&
        current.trackId == trackId &&
        current.reciterId == reciter.identifier
    ) {
      audioPlayer.togglePlayPause()
    } else {
      audioPlayer.playCustomRecitation(
        trackId = trackId,
        surahNumber = track.surahNumber.coerceIn(1, 114),
        surahArabicName = track.surahArabicName,
        reciterId = reciter.identifier,
        reciterDisplayName = reciter.arabicName,
        audioUrl = track.audioUrl,
        description = track.notes,
      )
    }
  }

  fun playCatalogSurah(surah: SurahInfo, reciter: ReciterOption) {
    val current = audioPlayer.state.value
    if (
      current.isActive &&
        current.trackId.isEmpty() &&
        current.surahNumber == surah.number &&
        current.reciterId == reciter.identifier
    ) {
      audioPlayer.togglePlayPause()
    } else {
      audioPlayer.playFullSurah(surah, reciter.identifier, reciter.arabicName)
    }
  }

  fun togglePlayPause() = audioPlayer.togglePlayPause()

  fun seekTo(ms: Int) = audioPlayer.seekTo(ms)

  fun seekBySeconds(sec: Int) = audioPlayer.seekBySeconds(sec)

  fun stopPlayback() = audioPlayer.stop()

  fun downloadSurah(surah: SurahInfo) {
    val reciterId = _selectedReciterId.value ?: return
    if (_downloadProgressMap.value.containsKey(surah.number)) return
    viewModelScope.launch {
      _downloadProgressMap.update { it + (surah.number to 0.01f) }
      val result =
        quranRepository.downloadSurahAudio(reciterId, surah.number) { progress ->
          _downloadProgressMap.update { it + (surah.number to progress) }
        }
      _downloadProgressMap.update { it - surah.number }
      result
        .onSuccess { _message.value = "تم تحميل ${surah.arabicName} للاستماع دون إنترنت" }
        .onFailure { _message.value = "تعذر التحميل: ${it.localizedMessage ?: "تحقق من الإنترنت"}" }
    }
  }

  fun deleteDownload(surahNumber: Int) {
    val reciterId = _selectedReciterId.value ?: return
    viewModelScope.launch {
      quranRepository.deleteDownloadedSurah(reciterId, surahNumber)
      _message.value = "تم حذف الملف المحفوظ"
    }
  }

  fun clearMessage() {
    _message.value = null
  }

  companion object {
    fun mergePublishedAndCatalogReciters(
      cloudReciters: List<FirebaseReciter>,
      localReciters: List<LocalReciter> = emptyList(),
    ): List<ReciterOption> {
      val localOptions =
        localReciters.map { local ->
          ReciterOption(
            identifier = local.id,
            arabicName = local.arabicName,
            styleArabic =
              if (local.fullSurahBaseUrl.isNotBlank()) {
                "${local.riwayah} • مضاف محلياً"
              } else {
                "${local.riwayah} • تلاوات مضافة"
              },
            islamicNetworkId = null,
            everyAyahFolder = null,
            mp3QuranSearchKeywords = emptyList(),
            defaultSurahServerUrl = local.fullSurahBaseUrl.trim(),
            photoUrl = local.photoPathOrUrl,
            bioArabic = local.description,
            riwayah = local.riwayah,
            sortOrder = -1000,
            isCloudSynced = false,
            isLocalCustom = true,
          )
        }

      val publishedCloud = cloudReciters.filter { it.published && it.id.isNotBlank() }
      val cloudById = publishedCloud.associateBy { it.id }

      val builtInsEnriched =
        QuranCatalog.reciters.map { builtIn ->
          val cloudOverride = cloudById[builtIn.identifier]
          if (cloudOverride == null) {
            builtIn
          } else {
            val normalizedBase =
              cloudOverride.audioBaseUrl
                .trim()
                .takeIf { it.isNotEmpty() }
                ?.let { if (it.endsWith("/")) it else "$it/" }
                ?: builtIn.defaultSurahServerUrl
            builtIn.copy(
              arabicName = cloudOverride.arabicName.ifBlank { builtIn.arabicName },
              styleArabic = cloudOverride.styleArabic.ifBlank { builtIn.styleArabic },
              riwayah = cloudOverride.effectiveRiwayah.ifBlank { builtIn.styleArabic },
              bioArabic = cloudOverride.bioArabic,
              photoUrl = cloudOverride.photoUrl,
              sortOrder = cloudOverride.sortOrder.toInt(),
              defaultSurahServerUrl = normalizedBase,
              isCloudSynced = true,
            )
          }
        }

      val builtInIds = QuranCatalog.reciters.map { it.identifier }.toSet()
      val extraCloud =
        publishedCloud
          .filter { it.id !in builtInIds }
          .map { cloud ->
            val normalizedBase =
              cloud.audioBaseUrl
                .trim()
                .takeIf { it.isNotEmpty() }
                ?.let { if (it.endsWith("/")) it else "$it/" }
                ?: ""
            ReciterOption(
              identifier = cloud.id,
              arabicName = cloud.arabicName,
              styleArabic = cloud.styleArabic,
              islamicNetworkId = null,
              everyAyahFolder = null,
              mp3QuranSearchKeywords = emptyList(),
              defaultSurahServerUrl = normalizedBase,
              photoUrl = cloud.photoUrl,
              bioArabic = cloud.bioArabic,
              riwayah = cloud.effectiveRiwayah,
              sortOrder = cloud.sortOrder.toInt(),
              isCloudSynced = true,
            )
          }
          .sortedWith(compareBy<ReciterOption> { it.sortOrder }.thenBy { it.arabicName })

      val cloudBuiltIns =
        builtInsEnriched
          .filter { it.isCloudSynced }
          .sortedWith(compareBy<ReciterOption> { it.sortOrder }.thenBy { it.arabicName })
      val localBuiltIns = builtInsEnriched.filter { !it.isCloudSynced }

      return localOptions +
        (extraCloud + cloudBuiltIns)
          .sortedWith(compareBy<ReciterOption> { it.sortOrder }.thenBy { it.arabicName }) +
        localBuiltIns
    }

    fun factory(
      initialReciterId: String? = null,
      quranRepository: QuranRepository,
      preferencesRepository: UserPreferencesRepository,
      audioPlayer: QuranAudioPlayer,
      backendRepository: FirebaseQuranBackendRepository,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return RecitersViewModel(
            initialReciterId = initialReciterId,
            quranRepository = quranRepository,
            preferencesRepository = preferencesRepository,
            audioPlayer = audioPlayer,
            backendRepository = backendRepository,
          ) as T
        }
      }
  }
}
