package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.AyahItem
import com.example.data.model.ReaderSettings
import com.example.data.model.ReminderType
import com.example.data.repository.QuranRepository
import com.example.notifications.ReminderScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface DailyPageUiState {
  data object Loading : DailyPageUiState

  data class Ready(
    val pageNumber: Int,
    val surahNames: String,
    val ayahs: List<AyahItem>,
  ) : DailyPageUiState

  data class Error(val message: String) : DailyPageUiState
}

class DailyPageViewModel(
  application: Application,
  private val quranRepository: QuranRepository,
  private val preferencesRepository: UserPreferencesRepository,
) : AndroidViewModel(application) {

  private val _uiState = MutableStateFlow<DailyPageUiState>(DailyPageUiState.Loading)
  val uiState: StateFlow<DailyPageUiState> = _uiState.asStateFlow()

  val settings: StateFlow<ReaderSettings> =
    preferencesRepository.readerSettingsFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = ReaderSettings(),
    )

  init {
    viewModelScope.launch {
      // Sync initial daily page with active Khatmah if available, otherwise use stored page
      val activeKhatmah =
        quranRepository.khatmahPlansFlow.first().firstOrNull { !it.isPaused }
      if (activeKhatmah != null) {
        val targetPage = (activeKhatmah.pagesRead + 1).coerceIn(1, 604)
        preferencesRepository.updateDailyPageNumber(targetPage)
      }

      preferencesRepository.readerSettingsFlow
        .map { it.dailyPageNumber }
        .distinctUntilChanged()
        .collect { page -> loadPage(page) }
    }
  }

  fun nextPage() {
    val next = ((settings.value.dailyPageNumber) % 604) + 1
    viewModelScope.launch { preferencesRepository.updateDailyPageNumber(next) }
  }

  fun previousPage() {
    val prev = if (settings.value.dailyPageNumber <= 1) 604 else settings.value.dailyPageNumber - 1
    viewModelScope.launch { preferencesRepository.updateDailyPageNumber(prev) }
  }

  fun retry() {
    viewModelScope.launch { loadPage(settings.value.dailyPageNumber) }
  }

  fun updateSchedule(hour: Int, minute: Int, enabled: Boolean) {
    viewModelScope.launch {
      preferencesRepository.updateDailyPageSchedule(hour, minute, enabled)
      preferencesRepository.updateReminder(ReminderType.DAILY_PAGE, enabled, hour, minute)
      ReminderScheduler.scheduleOrCancel(
        context = getApplication(),
        type = ReminderType.DAILY_PAGE,
        enabled = enabled,
        hour = hour,
        minute = minute,
      )
    }
  }

  private suspend fun loadPage(page: Int) {
    _uiState.value = DailyPageUiState.Loading
    val edition = settings.value.translationEdition
    val result = quranRepository.loadMushafPage(page, edition)
    _uiState.value =
      result.fold(
        onSuccess = { loaded ->
          DailyPageUiState.Ready(
            pageNumber = loaded.pageNumber,
            surahNames = loaded.surahNames,
            ayahs = loaded.ayahs,
          )
        },
        onFailure = { err ->
          DailyPageUiState.Error(
            err.localizedMessage ?: "تعذر تحميل صفحة اليوم. يرجى التحقق من الإنترنت."
          )
        },
      )
  }

  companion object {
    fun factory(
      application: Application,
      quranRepository: QuranRepository,
      preferencesRepository: UserPreferencesRepository,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return DailyPageViewModel(application, quranRepository, preferencesRepository) as T
        }
      }
  }
}
