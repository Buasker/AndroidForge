package com.example.ui.screens

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Login
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.data.firebase.AdminPrivilegeStatus
import com.example.data.model.QuranCatalog
import com.example.data.model.ReaderSettings
import com.example.data.model.ReaderThemeMode
import com.example.data.model.ReciterOption
import com.example.data.model.ReminderPreference
import com.example.data.model.ReminderType
import com.example.ui.components.SocialAccountsSection
import java.util.Locale
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SettingsScreen(
  settings: ReaderSettings,
  reminders: List<ReminderPreference>,
  adminStatus: AdminPrivilegeStatus = AdminPrivilegeStatus(),
  authBusy: Boolean = false,
  authMessage: String? = null,
  reciters: List<ReciterOption> = QuranCatalog.reciters,
  onClearAuthMessage: () -> Unit = {},
  onGoogleSignIn: (Activity) -> Unit = {},
  onSignOut: () -> Unit = {},
  onOpenOwnerAdmin: () -> Unit = {},
  onThemeModeChange: (ReaderThemeMode) -> Unit,
  onArabicFontSizeChange: (Float) -> Unit,
  onTafsirFontSizeChange: (Float) -> Unit,
  onAdhkarFontSizeChange: (Float) -> Unit,
  onReciterChange: (String) -> Unit,
  onShowTranslationChange: (Boolean) -> Unit,
  onTranslationEditionChange: (String) -> Unit,
  onVoicePartialMatchChange: (Boolean) -> Unit,
  onReminderChange: (type: ReminderType, enabled: Boolean, hour: Int, minute: Int) -> Unit,
  onOpenKhatmah: () -> Unit,
  onOpenDailyPage: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }
  var pendingPermissionReminder by remember { mutableStateOf<ReminderPreference?>(null) }
  var editingTimeReminder by remember { mutableStateOf<ReminderPreference?>(null) }

  LaunchedEffect(authMessage) {
    if (authMessage != null) {
      snackbarHostState.showSnackbar(authMessage)
      onClearAuthMessage()
    }
  }

  val notificationPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      val pending = pendingPermissionReminder
      pendingPermissionReminder = null
      if (granted && pending != null) {
        onReminderChange(pending.type, true, pending.hour, pending.minute)
      } else if (!granted) {
        scope.launch {
          snackbarHostState.showSnackbar("يرجى منح إذن الإشعارات لتفعيل التذكيرات")
        }
      }
    }

  fun handleReminderToggle(pref: ReminderPreference, enabled: Boolean) {
    if (!enabled) {
      onReminderChange(pref.type, false, pref.hour, pref.minute)
      return
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val granted =
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      if (!granted) {
        pendingPermissionReminder = pref
        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        return
      }
    }
    onReminderChange(pref.type, true, pref.hour, pref.minute)
  }

  Scaffold(
    snackbarHost = { SnackbarHost(snackbarHostState) },
    contentWindowInsets = WindowInsets(0.dp),
    modifier = modifier.fillMaxSize(),
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier =
          Modifier.fillMaxSize()
            .widthIn(max = 720.dp)
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text(
            text = "الإعدادات والتخصيص",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text = "خصّص مظهر القراءة، أحجام الخطوط، القارئ المفضل، والتنبيهات اليومية",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        // Account & Owner Administration Section
        SettingsSectionCard(
          icon = Icons.Rounded.VerifiedUser,
          title = "الحساب والمزامنة السحابية",
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (!adminStatus.isAuthenticated) {
              Text(
                text = "يمكنك استخدام جميع ميزات القرآن والأذكار والختمة دون تسجيل دخول، أو تسجيل الدخول عبر Google لحفظ الإشارات المرجعية سحابياً.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Button(
                onClick = { context.findActivity()?.let(onGoogleSignIn) },
                enabled = !authBusy,
                modifier = Modifier.fillMaxWidth().testTag("google_sign_in_button"),
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Rounded.Login,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (authBusy) "جارٍ تسجيل الدخول…" else "تسجيل الدخول عبر Google")
              }
            } else {
              Text(
                text = adminStatus.displayName?.takeIf { it.isNotBlank() } ?: "مستخدم نور القرآن",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text =
                  (adminStatus.email ?: "") +
                    if (adminStatus.isEmailVerified) " • موثّق" else " • غير موثّق",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              if (adminStatus.isSuperAdmin) {
                Surface(
                  shape = MaterialTheme.shapes.medium,
                  color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                  border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                  modifier = Modifier.fillMaxWidth().testTag("owner_role_badge"),
                ) {
                  Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                  ) {
                    Text(
                      text = "صلاحيات المالك (Super Admin) مفعّلة",
                      style = MaterialTheme.typography.labelLarge,
                      color = MaterialTheme.colorScheme.primary,
                      fontWeight = FontWeight.Bold,
                    )
                    Button(
                      onClick = onOpenOwnerAdmin,
                      modifier = Modifier.fillMaxWidth().testTag("open_owner_admin_button"),
                    ) {
                      Icon(
                        imageVector = Icons.Rounded.AdminPanelSettings,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                      )
                      Spacer(modifier = Modifier.width(8.dp))
                      Text("لوحة إدارة القراء والتلاوات")
                    }
                  }
                }
              }
              OutlinedButton(
                onClick = onSignOut,
                enabled = !authBusy,
                modifier = Modifier.fillMaxWidth().testTag("sign_out_button"),
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Rounded.Logout,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("تسجيل الخروج")
              }
            }
          }
        }

        // Theme Section
        SettingsSectionCard(
          icon = Icons.Rounded.Palette,
          title = "المظهر والألوان",
        ) {
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            ReaderThemeMode.entries.forEach { mode ->
              FilterChip(
                selected = settings.themeMode == mode,
                onClick = { onThemeModeChange(mode) },
                label = { Text(mode.label) },
                modifier = Modifier.testTag("theme_chip_${mode.name.lowercase()}"),
              )
            }
          }
        }

        // Fonts & Reader Section
        SettingsSectionCard(
          icon = Icons.Rounded.TextFields,
          title = "أحجام الخطوط والقراءة",
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "خط المصحف الشريف (${settings.arabicFontSize.toInt()})",
                style = MaterialTheme.typography.titleMedium,
              )
              TextButton(onClick = { onArabicFontSizeChange(28f) }) {
                Text("الافتراضي")
              }
            }
            Slider(
              value = settings.arabicFontSize,
              onValueChange = onArabicFontSizeChange,
              valueRange = 18f..48f,
            )

            Text(
              text = "خط التفسير (${settings.tafsirFontSize.toInt()})",
              style = MaterialTheme.typography.titleMedium,
            )
            Slider(
              value = settings.tafsirFontSize,
              onValueChange = onTafsirFontSizeChange,
              valueRange = 14f..32f,
            )

            Text(
              text = "خط الأذكار (${settings.adhkarFontSize.toInt()})",
              style = MaterialTheme.typography.titleMedium,
            )
            Slider(
              value = settings.adhkarFontSize,
              onValueChange = onAdhkarFontSizeChange,
              valueRange = 15f..34f,
            )

            HorizontalDivider()

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "إظهار الترجمة الإنجليزية أثناء القراءة",
                style = MaterialTheme.typography.bodyLarge,
                modifier = Modifier.weight(1f),
              )
              Switch(
                checked = settings.showTranslation,
                onCheckedChange = onShowTranslationChange,
              )
            }

            if (settings.showTranslation) {
              FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                QuranCatalog.translationEditions.forEach { edition ->
                  FilterChip(
                    selected = settings.translationEdition == edition.identifier,
                    onClick = { onTranslationEditionChange(edition.identifier) },
                    label = { Text(edition.name) },
                  )
                }
              }
            }
          }
        }

        // Default Reciter
        SettingsSectionCard(
          icon = Icons.Rounded.RecordVoiceOver,
          title = "القارئ المفضل (${reciters.size} قراء)",
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            reciters.forEach { reciter ->
              val selected = settings.reciterIdentifier == reciter.identifier
              Surface(
                modifier =
                  Modifier.fillMaxWidth().clickable { onReciterChange(reciter.identifier) },
                shape = MaterialTheme.shapes.small,
                color =
                  if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                  else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = reciter.arabicName,
                      style = MaterialTheme.typography.titleMedium,
                    )
                    Text(
                      text = reciter.styleArabic,
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                  if (selected) {
                    Icon(
                      Icons.Rounded.Check,
                      contentDescription = "مختار",
                      tint = MaterialTheme.colorScheme.primary,
                    )
                  }
                }
              }
            }
          }
        }

        // Voice Dhikr Counter Setting
        SettingsSectionCard(
          icon = Icons.Rounded.RecordVoiceOver,
          title = "عداد الذكر الصوتي التلقائي",
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "احتساب النتائج الفورية أثناء التحدث",
                style = MaterialTheme.typography.titleMedium,
              )
              Text(
                text = "يعمل على احتساب الذكر تلقائياً بمجرد نطقه دون انتظار انتهاء الجملة",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Switch(
              checked = settings.voiceDhikrAllowPartialMatch,
              onCheckedChange = onVoicePartialMatchChange,
            )
          }
        }

        // All 7 Notifications & Reminders
        SettingsSectionCard(
          icon = Icons.Rounded.NotificationsActive,
          title = "الإشعارات والتذكيرات اليومية",
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            reminders.forEachIndexed { index, pref ->
              val formattedTime = String.format(Locale.US, "%02d:%02d", pref.hour, pref.minute)
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = pref.type.titleArabic,
                    style = MaterialTheme.typography.titleMedium,
                  )
                  TextButton(
                    onClick = { editingTimeReminder = pref },
                    contentPadding = PaddingValues(0.dp),
                  ) {
                    Icon(
                      Icons.Rounded.Schedule,
                      contentDescription = null,
                      modifier = Modifier.size(16.dp),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("الوقت: $formattedTime (تعديل)")
                  }
                }
                Switch(
                  checked = pref.enabled,
                  onCheckedChange = { checked -> handleReminderToggle(pref, checked) },
                  modifier = Modifier.testTag("reminder_switch_${pref.type.id}"),
                )
              }
              if (index < reminders.lastIndex) {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
              }
            }
          }
        }

        // Khatmah & Daily Page Shortcuts
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          OutlinedButton(
            onClick = onOpenKhatmah,
            modifier = Modifier.weight(1f),
          ) {
            Icon(Icons.Rounded.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("إدارة الختمة")
          }
          OutlinedButton(
            onClick = onOpenDailyPage,
            modifier = Modifier.weight(1f),
          ) {
            Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("الصفحة اليومية")
          }
        }

        // Official Social Accounts inside Settings
        SocialAccountsSection(title = "حساباتي الاجتماعية")
      }
    }
  }

  val targetReminder = editingTimeReminder
  if (targetReminder != null) {
    val pickerState =
      rememberTimePickerState(
        initialHour = targetReminder.hour,
        initialMinute = targetReminder.minute,
        is24Hour = true,
      )
    AlertDialog(
      onDismissRequest = { editingTimeReminder = null },
      title = { Text(targetReminder.type.titleArabic) },
      text = { TimePicker(state = pickerState) },
      confirmButton = {
        Button(
          onClick = {
            onReminderChange(
              targetReminder.type,
              true,
              pickerState.hour,
              pickerState.minute,
            )
            editingTimeReminder = null
          }
        ) {
          Text("حفظ وتفعيل")
        }
      },
      dismissButton = {
        TextButton(onClick = { editingTimeReminder = null }) { Text("إلغاء") }
      },
    )
  }
}

@Composable
private fun SettingsSectionCard(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  title: String,
  content: @Composable () -> Unit,
) {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = MaterialTheme.shapes.large,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = title,
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onSurface,
        )
      }
      content()
    }
  }
}

private tailrec fun Context.findActivity(): Activity? =
  when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
  }
