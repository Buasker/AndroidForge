package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioPlaybackState
import com.example.data.model.QuranCatalog
import com.example.data.model.ReciterOption
import com.example.data.model.SurahInfo
import com.example.ui.components.OctagonalBadge
import com.example.ui.theme.AmiriFontFamily

@Composable
fun AudioLibraryScreen(
  surahs: List<SurahInfo>,
  selectedReciterId: String,
  downloadedSurahs: Set<Int>,
  downloadProgressMap: Map<Int, Float>,
  audioState: AudioPlaybackState,
  volumeLevel: Float,
  searchQuery: String,
  statusMessage: String?,
  reciters: List<ReciterOption> = QuranCatalog.reciters,
  onClearMessage: () -> Unit,
  onSelectReciter: (String) -> Unit,
  onSearchQueryChange: (String) -> Unit,
  onPlaySurah: (SurahInfo) -> Unit,
  onTogglePlayPause: () -> Unit,
  onSeekTo: (Int) -> Unit,
  onSeekBySeconds: (Int) -> Unit,
  onStopPlayback: () -> Unit,
  onVolumeChange: (Float) -> Unit,
  onDownloadSurah: (SurahInfo) -> Unit,
  onDeleteDownload: (Int) -> Unit,
  onOpenReciters: () -> Unit = {},
  onOpenManageLocalReciters: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(statusMessage) {
    if (statusMessage != null) {
      snackbarHostState.showSnackbar(statusMessage)
      onClearMessage()
    }
  }

  Scaffold(
    snackbarHost = { SnackbarHost(snackbarHostState) },
    contentWindowInsets = WindowInsets(0.dp),
    modifier = modifier.fillMaxSize(),
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(modifier = Modifier.fillMaxSize().widthIn(max = 720.dp)) {
        Column(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Text(
            text = "المكتبة الصوتية",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text = "تلاوات خاشعة بصوت ${reciters.size} من قرّاء العالم الإسلامي مع التشغيل بالخلفية والتحميل دون إنترنت",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )

          OutlinedButton(
            onClick = onOpenReciters,
            modifier = Modifier.fillMaxWidth().testTag("audio_open_reciters_button"),
          ) {
            Icon(
              imageVector = Icons.Rounded.RecordVoiceOver,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("تصفح ملفات القرّاء والتلاوات المنشورة")
          }

          FilledTonalButton(
            onClick = onOpenManageLocalReciters,
            modifier = Modifier.fillMaxWidth().testTag("audio_manage_reciters_button"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.QueueMusic,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("إدارة القرّاء والتلاوات")
          }

          // Reciters Selector
          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(reciters, key = { it.identifier }) { reciter ->
              val selected = reciter.identifier == selectedReciterId
              Surface(
                modifier =
                  Modifier.testTag("reciter_chip_${reciter.identifier}")
                    .clickable { onSelectReciter(reciter.identifier) },
                shape = MaterialTheme.shapes.medium,
                color =
                  if (selected) MaterialTheme.colorScheme.primary
                  else MaterialTheme.colorScheme.surface,
                border =
                  BorderStroke(
                    1.dp,
                    if (selected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.outlineVariant,
                  ),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    imageVector = Icons.Rounded.RecordVoiceOver,
                    contentDescription = null,
                    tint =
                      if (selected) MaterialTheme.colorScheme.onPrimary
                      else MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp),
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text(
                      text = reciter.arabicName,
                      style = MaterialTheme.typography.labelLarge,
                      color =
                        if (selected) MaterialTheme.colorScheme.onPrimary
                        else MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                      text = reciter.styleArabic,
                      style = MaterialTheme.typography.labelSmall,
                      color =
                        if (selected) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }
              }
            }
          }

          // Expanded Player & Volume Controller when active
          if (audioState.isActive) {
            Surface(
              shape = MaterialTheme.shapes.large,
              color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
              modifier = Modifier.fillMaxWidth().testTag("audio_library_player_card"),
            ) {
              Column(modifier = Modifier.padding(14.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = audioState.surahArabicName,
                      fontFamily = AmiriFontFamily,
                      fontSize = 22.sp,
                      fontWeight = FontWeight.Bold,
                      color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                      text =
                        audioState.errorMessage
                          ?: buildString {
                            append(audioState.reciterName)
                            if (audioState.trackDescription.isNotBlank()) {
                              append(" • ")
                              append(audioState.trackDescription)
                            }
                            append(" • ")
                            append(if (audioState.isBuffering) "جارٍ التحميل…" else "قيد التشغيل")
                          },
                      style = MaterialTheme.typography.bodyMedium,
                      color = MaterialTheme.colorScheme.primary,
                    )
                  }
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                      onClick = { onSeekBySeconds(-10) },
                      modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                      Icon(Icons.Rounded.Replay10, contentDescription = "تأخير ١٠ ثوانٍ")
                    }
                    Surface(
                      shape = CircleShape,
                      color = MaterialTheme.colorScheme.primary,
                      modifier = Modifier.size(48.dp),
                    ) {
                      IconButton(onClick = onTogglePlayPause) {
                        if (audioState.isBuffering) {
                          CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = MaterialTheme.colorScheme.onPrimary,
                            strokeWidth = 2.dp,
                          )
                        } else {
                          Icon(
                            imageVector =
                              if (audioState.isPlaying) Icons.Rounded.Pause
                              else Icons.Rounded.PlayArrow,
                            contentDescription = "تشغيل أو إيقاف",
                            tint = MaterialTheme.colorScheme.onPrimary,
                          )
                        }
                      }
                    }
                    IconButton(
                      onClick = { onSeekBySeconds(10) },
                      modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                      Icon(Icons.Rounded.Forward10, contentDescription = "تقديم ١٠ ثوانٍ")
                    }
                    IconButton(
                      onClick = onStopPlayback,
                      modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                      Icon(Icons.Rounded.Stop, contentDescription = "إيقاف")
                    }
                  }
                }

                if (audioState.durationMs > 0) {
                  Slider(
                    value = audioState.positionMs.toFloat().coerceIn(0f, audioState.durationMs.toFloat()),
                    onValueChange = { onSeekTo(it.toInt()) },
                    valueRange = 0f..audioState.durationMs.toFloat().coerceAtLeast(1f),
                  )
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                  ) {
                    Text(
                      text = formatMs(audioState.positionMs),
                      style = MaterialTheme.typography.labelSmall,
                    )
                    Text(
                      text = formatMs(audioState.durationMs),
                      style = MaterialTheme.typography.labelSmall,
                    )
                  }
                }

                // Volume Control
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    imageVector = Icons.AutoMirrored.Rounded.VolumeUp,
                    contentDescription = "مستوى الصوت",
                    modifier = Modifier.size(20.dp),
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Slider(
                    value = volumeLevel,
                    onValueChange = onVolumeChange,
                    valueRange = 0f..1f,
                    modifier = Modifier.weight(1f),
                  )
                  Text(
                    text = "${(volumeLevel * 100).toInt()}%",
                    style = MaterialTheme.typography.labelSmall,
                  )
                }
              }
            }
          }

          OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("ابحث عن سورة للاستماع أو التحميل…") },
            leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
            trailingIcon = {
              if (searchQuery.isNotEmpty()) {
                IconButton(onClick = { onSearchQueryChange("") }) {
                  Icon(Icons.Rounded.Clear, contentDescription = "مسح")
                }
              }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors =
              OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
              ),
            modifier = Modifier.fillMaxWidth().testTag("audio_search_input"),
          )
        }

        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
          verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          items(surahs, key = { it.number }) { surah ->
            val isThisSurahPlaying =
              audioState.isActive &&
                audioState.surahNumber == surah.number &&
                audioState.reciterId == selectedReciterId
            val isDownloaded = surah.number in downloadedSurahs
            val progress = downloadProgressMap[surah.number]

            Surface(
              modifier = Modifier.fillMaxWidth().testTag("audio_surah_${surah.number}"),
              shape = MaterialTheme.shapes.medium,
              color =
                if (isThisSurahPlaying) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                else MaterialTheme.colorScheme.surface,
              border =
                BorderStroke(
                  1.dp,
                  if (isThisSurahPlaying) MaterialTheme.colorScheme.primary
                  else MaterialTheme.colorScheme.outlineVariant,
                ),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                OctagonalBadge(number = surah.number, size = 38.dp)
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = surah.arabicName,
                    fontFamily = AmiriFontFamily,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  Text(
                    text =
                      if (isDownloaded) "${surah.numberOfAyahs} آية • محفوظ دون إنترنت"
                      else "${surah.revelationArabic} • ${surah.numberOfAyahs} آية",
                    style = MaterialTheme.typography.labelSmall,
                    color =
                      if (isDownloaded) MaterialTheme.colorScheme.primary
                      else MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }

                if (progress != null) {
                  Box(
                    modifier = Modifier.size(48.dp),
                    contentAlignment = Alignment.Center,
                  ) {
                    CircularProgressIndicator(
                      progress = { progress },
                      modifier = Modifier.size(26.dp),
                      strokeWidth = 2.5.dp,
                    )
                  }
                } else if (isDownloaded) {
                  IconButton(
                    onClick = { onDeleteDownload(surah.number) },
                    modifier = Modifier.minimumInteractiveComponentSize(),
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.CheckCircle,
                      contentDescription = "محمل دون إنترنت - اضغط للحذف",
                      tint = MaterialTheme.colorScheme.primary,
                    )
                  }
                } else {
                  IconButton(
                    onClick = { onDownloadSurah(surah) },
                    modifier =
                      Modifier.minimumInteractiveComponentSize()
                        .testTag("download_surah_${surah.number}"),
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.Download,
                      contentDescription = "تحميل السورة",
                      tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }

                IconButton(
                  onClick = { onPlaySurah(surah) },
                  modifier =
                    Modifier.minimumInteractiveComponentSize()
                      .testTag("play_audio_surah_${surah.number}"),
                ) {
                  Icon(
                    imageVector =
                      if (isThisSurahPlaying && audioState.isPlaying) Icons.Rounded.Pause
                      else Icons.Rounded.PlayArrow,
                    contentDescription = "تشغيل السورة",
                    tint = MaterialTheme.colorScheme.primary,
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

private fun formatMs(ms: Int): String {
  val totalSeconds = (ms / 1000).coerceAtLeast(0)
  val hours = totalSeconds / 3600
  val minutes = (totalSeconds % 3600) / 60
  val seconds = totalSeconds % 60
  return if (hours > 0) String.format("%d:%02d:%02d", hours, minutes, seconds)
  else String.format("%02d:%02d", minutes, seconds)
}
