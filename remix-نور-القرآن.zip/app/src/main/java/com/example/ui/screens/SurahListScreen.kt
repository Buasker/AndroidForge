package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.QuranCatalog
import com.example.data.model.SurahInfo
import com.example.ui.components.OctagonalBadge
import com.example.ui.components.SurahRowCard
import com.example.ui.viewmodel.BrowseTab
import com.example.ui.viewmodel.RevelationFilter

@Composable
fun SurahListScreen(
  surahs: List<SurahInfo>,
  searchQuery: String,
  revelationFilter: RevelationFilter,
  browseTab: BrowseTab,
  onSearchQueryChange: (String) -> Unit,
  onRevelationFilterChange: (RevelationFilter) -> Unit,
  onBrowseTabChange: (BrowseTab) -> Unit,
  onOpenSurah: (surahNumber: Int, ayahNumber: Int) -> Unit,
  onOpenPage: (pageNumber: Int) -> Unit,
  modifier: Modifier = Modifier,
) {
  val surahLookup = surahs.associateBy { it.number }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(modifier = Modifier.fillMaxSize().widthIn(max = 720.dp)) {
      Column(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text(
          text = "المصحف الشريف",
          style = MaterialTheme.typography.headlineLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )

        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
          BrowseTab.entries.forEachIndexed { index, tab ->
            SegmentedButton(
              selected = browseTab == tab,
              onClick = { onBrowseTabChange(tab) },
              shape = SegmentedButtonDefaults.itemShape(index = index, count = BrowseTab.entries.size),
              modifier = Modifier.testTag("browse_tab_${tab.name.lowercase()}"),
            ) {
              Text(tab.label, style = MaterialTheme.typography.labelLarge)
            }
          }
        }

        if (browseTab == BrowseTab.SURAHS) {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            placeholder = { Text("ابحث باسم السورة أو رقمها…") },
            leadingIcon = { Icon(imageVector = Icons.Rounded.Search, contentDescription = null) },
            trailingIcon = {
              if (searchQuery.isNotEmpty()) {
                IconButton(onClick = { onSearchQueryChange("") }) {
                  Icon(imageVector = Icons.Rounded.Clear, contentDescription = "مسح")
                }
              }
            },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors =
              OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
              ),
            modifier = Modifier.fillMaxWidth().testTag("surah_filter_input"),
          )

          LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(RevelationFilter.entries) { filter ->
              FilterChip(
                selected = revelationFilter == filter,
                onClick = { onRevelationFilterChange(filter) },
                label = { Text(filter.label) },
                colors =
                  FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                  ),
                modifier = Modifier.testTag("filter_${filter.name.lowercase()}"),
              )
            }
          }
        }
      }

      when (browseTab) {
        BrowseTab.SURAHS -> {
          if (surahs.isEmpty()) {
            Box(
              modifier = Modifier.fillMaxSize().padding(32.dp),
              contentAlignment = Alignment.Center,
            ) {
              Text(
                text = "لا توجد سور مطابقة لـ \"$searchQuery\"",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          } else {
            LazyColumn(
              modifier = Modifier.fillMaxSize(),
              contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              items(surahs, key = { it.number }) { surah ->
                SurahRowCard(
                  surah = surah,
                  onClick = { onOpenSurah(surah.number, 1) },
                )
              }
            }
          }
        }

        BrowseTab.JUZ -> {
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            items(QuranCatalog.juzStartSurahs, key = { it.first }) { (juzNum, startPair) ->
              val (startSurahNum, startAyahNum) = startPair
              val startSurah = surahLookup[startSurahNum]
              Surface(
                modifier =
                  Modifier.fillMaxWidth()
                    .testTag("juz_card_$juzNum")
                    .clickable { onOpenSurah(startSurahNum, startAyahNum) },
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  OctagonalBadge(number = juzNum, size = 42.dp)
                  Spacer(modifier = Modifier.width(14.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = "الجزء $juzNum",
                      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                      color = MaterialTheme.colorScheme.onSurface,
                    )
                    val startLabel =
                      startSurah?.let { "${it.arabicName} • الآية $startAyahNum" }
                        ?: "سورة $startSurahNum • آية $startAyahNum"
                    Text(
                      text = "يبدأ عند $startLabel",
                      style = MaterialTheme.typography.bodyMedium,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                  Text(
                    text = "قراءة ←",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                  )
                }
              }
            }
          }
        }

        BrowseTab.PAGES -> {
          val pages = (1..604).toList()
          LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 84.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            items(pages, key = { it }) { page ->
              Surface(
                modifier =
                  Modifier.testTag("page_tile_$page").clickable { onOpenPage(page) },
                shape = MaterialTheme.shapes.small,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
              ) {
                Column(
                  modifier = Modifier.padding(vertical = 12.dp, horizontal = 6.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                  Text(
                    text = page.toString(),
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center,
                  )
                  Text(
                    text = "صفحة",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}
