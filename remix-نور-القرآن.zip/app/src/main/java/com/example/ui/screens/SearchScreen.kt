package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SearchMatchItem
import com.example.data.model.SearchResultType
import com.example.ui.components.OctagonalBadge
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.viewmodel.SearchUiState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(
  query: String,
  selectedTypeFilter: SearchResultType?,
  uiState: SearchUiState,
  suggestedTopics: List<String>,
  onQueryChange: (String) -> Unit,
  onSelectTopic: (String) -> Unit,
  onSelectTypeFilter: (SearchResultType?) -> Unit,
  onRetry: () -> Unit,
  onOpenMatch: (SearchMatchItem) -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(modifier = Modifier.fillMaxSize().widthIn(max = 720.dp)) {
      Column(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Text(
          text = "البحث الذكي",
          style = MaterialTheme.typography.headlineLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )
        OutlinedTextField(
          value = query,
          onValueChange = onQueryChange,
          placeholder = { Text("ابحث في السور والآيات والتفسير والأذكار…") },
          leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
          trailingIcon = {
            if (query.isNotEmpty()) {
              IconButton(onClick = { onQueryChange("") }) {
                Icon(Icons.Rounded.Clear, contentDescription = "مسح البحث")
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(16.dp),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedContainerColor = MaterialTheme.colorScheme.surface,
              unfocusedContainerColor = MaterialTheme.colorScheme.surface,
            ),
          modifier = Modifier.fillMaxWidth().testTag("quran_search_input"),
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          item {
            FilterChip(
              selected = selectedTypeFilter == null,
              onClick = { onSelectTypeFilter(null) },
              label = { Text("الكل") },
            )
          }
          items(SearchResultType.entries) { type ->
            FilterChip(
              selected = selectedTypeFilter == type,
              onClick = { onSelectTypeFilter(type) },
              label = { Text(type.label) },
            )
          }
        }
      }

      when (uiState) {
        is SearchUiState.Idle -> {
          Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Text(
              text = "موضوعات مقترحة للبحث",
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            FlowRow(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              suggestedTopics.forEach { topic ->
                AssistChip(
                  onClick = { onSelectTopic(topic) },
                  label = { Text(topic) },
                  modifier = Modifier.testTag("topic_chip_$topic"),
                )
              }
            }
          }
        }

        is SearchUiState.Searching -> {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "جارٍ البحث في المصحف والتفسير والأذكار…",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }

        is SearchUiState.Error -> {
          Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Text(
              text = "تعذر إتمام البحث",
              style = MaterialTheme.typography.headlineMedium,
              color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = uiState.message,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center,
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onRetry) { Text("إعادة المحاولة") }
          }
        }

        is SearchUiState.Results -> {
          val filteredMatches =
            if (selectedTypeFilter == null) uiState.matches
            else uiState.matches.filter { it.matchType == selectedTypeFilter }

          if (filteredMatches.isEmpty()) {
            Box(
              modifier = Modifier.fillMaxSize().padding(32.dp),
              contentAlignment = Alignment.Center,
            ) {
              Text(
                text = "لم يتم العثور على نتائج مطابقة لـ «${uiState.query}».",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
              )
            }
          } else {
            LazyColumn(
              modifier = Modifier.fillMaxSize(),
              contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              item {
                Text(
                  text = "عرض ${filteredMatches.size} نتيجة للبحث عن «${uiState.query}»",
                  style = MaterialTheme.typography.labelLarge,
                  color = MaterialTheme.colorScheme.primary,
                )
              }
              items(
                filteredMatches,
                key = { "${it.matchType.name}_${it.surahNumber}_${it.numberInSurah}_${it.globalNumber}_${it.text.hashCode()}" },
              ) { match ->
                Surface(
                  modifier =
                    Modifier.fillMaxWidth()
                      .testTag("search_match_${match.matchType.name}_${match.surahNumber}_${match.numberInSurah}")
                      .clickable { onOpenMatch(match) },
                  shape = MaterialTheme.shapes.medium,
                  color = MaterialTheme.colorScheme.surface,
                  border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                  Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                      ) {
                        if (match.numberInSurah > 0) {
                          OctagonalBadge(number = match.numberInSurah, size = 34.dp)
                          Spacer(modifier = Modifier.width(10.dp))
                        }
                        Column {
                          Text(
                            text = match.surahArabicName.ifBlank { match.surahEnglishName },
                            fontFamily = AmiriFontFamily,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                          )
                          if (match.numberInSurah > 0 && match.surahNumber > 0) {
                            Text(
                              text = "سورة رقم ${match.surahNumber} • آية ${match.numberInSurah}",
                              style = MaterialTheme.typography.labelMedium,
                              color = MaterialTheme.colorScheme.primary,
                            )
                          }
                        }
                      }
                      Surface(
                        shape = RoundedCornerShape(50),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                      ) {
                        Text(
                          text = match.matchType.label,
                          style = MaterialTheme.typography.labelSmall,
                          color = MaterialTheme.colorScheme.onSecondaryContainer,
                          modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        )
                      }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                      text = match.text,
                      fontFamily =
                        if (match.matchType == SearchResultType.AYAH) AmiriFontFamily
                        else MaterialTheme.typography.bodyLarge.fontFamily,
                      fontSize = if (match.matchType == SearchResultType.AYAH) 20.sp else 15.sp,
                      lineHeight = if (match.matchType == SearchResultType.AYAH) 36.sp else 24.sp,
                      color = MaterialTheme.colorScheme.onSurface,
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
