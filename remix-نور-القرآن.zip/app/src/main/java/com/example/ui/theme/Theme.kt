package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import com.example.data.model.ReaderThemeMode

private val ParchmentColorScheme =
  lightColorScheme(
    primary = EmeraldPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldPrimaryContainer,
    onPrimaryContainer = EmeraldOnPrimaryContainer,
    secondary = GoldSecondary,
    onSecondary = Color.White,
    secondaryContainer = GoldSecondaryContainer,
    onSecondaryContainer = GoldOnSecondaryContainer,
    tertiary = TealTertiary,
    onTertiary = Color.White,
    tertiaryContainer = TealTertiaryContainer,
    background = ParchmentBackground,
    onBackground = InkOnSurface,
    surface = ParchmentSurface,
    onSurface = InkOnSurface,
    surfaceVariant = ParchmentSurfaceVariant,
    onSurfaceVariant = InkMuted,
    surfaceContainerLow = ParchmentSurface,
    surfaceContainer = ParchmentSurfaceVariant,
    surfaceContainerHigh = ParchmentSurfaceHigh,
    outline = ParchmentOutline,
    outlineVariant = ParchmentOutline.copy(alpha = 0.6f),
  )

private val SepiaColorScheme =
  lightColorScheme(
    primary = SepiaPrimary,
    onPrimary = Color.White,
    primaryContainer = EmeraldPrimaryContainer,
    onPrimaryContainer = EmeraldOnPrimaryContainer,
    secondary = GoldSecondary,
    onSecondary = Color.White,
    secondaryContainer = GoldSecondaryContainer,
    onSecondaryContainer = GoldOnSecondaryContainer,
    tertiary = TealTertiary,
    onTertiary = Color.White,
    background = SepiaBackground,
    onBackground = InkOnSurface,
    surface = SepiaSurface,
    onSurface = InkOnSurface,
    surfaceVariant = SepiaSurfaceVariant,
    onSurfaceVariant = InkMuted,
    surfaceContainerLow = SepiaSurface,
    surfaceContainer = SepiaSurfaceVariant,
    surfaceContainerHigh = SepiaSurfaceHigh,
    outline = SepiaOutline,
    outlineVariant = SepiaOutline.copy(alpha = 0.65f),
  )

private val MidnightColorScheme =
  darkColorScheme(
    primary = JadePrimary,
    onPrimary = JadeOnPrimary,
    primaryContainer = JadePrimaryContainer,
    onPrimaryContainer = JadeOnPrimaryContainer,
    secondary = LuminousGold,
    onSecondary = LuminousGoldOnSecondary,
    secondaryContainer = LuminousGoldContainer,
    onSecondaryContainer = LuminousGoldOnContainer,
    tertiary = TealTertiaryContainer,
    onTertiary = MidnightBackground,
    background = MidnightBackground,
    onBackground = MidnightInk,
    surface = MidnightSurface,
    onSurface = MidnightInk,
    surfaceVariant = MidnightSurfaceVariant,
    onSurfaceVariant = MidnightInkMuted,
    surfaceContainerLow = MidnightSurface,
    surfaceContainer = MidnightSurfaceVariant,
    surfaceContainerHigh = MidnightSurfaceHigh,
    outline = MidnightOutline,
    outlineVariant = MidnightOutline.copy(alpha = 0.7f),
  )

val NoorShapes =
  Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(28.dp),
  )

@Composable
fun NoorQuranTheme(
  themeMode: ReaderThemeMode = ReaderThemeMode.SYSTEM,
  content: @Composable () -> Unit,
) {
  val systemDark = isSystemInDarkTheme()
  val isDark =
    when (themeMode) {
      ReaderThemeMode.SYSTEM -> systemDark
      ReaderThemeMode.MIDNIGHT -> true
      ReaderThemeMode.PARCHMENT,
      ReaderThemeMode.SEPIA -> false
    }

  val colorScheme =
    when (themeMode) {
      ReaderThemeMode.SYSTEM -> if (systemDark) MidnightColorScheme else ParchmentColorScheme
      ReaderThemeMode.PARCHMENT -> ParchmentColorScheme
      ReaderThemeMode.SEPIA -> SepiaColorScheme
      ReaderThemeMode.MIDNIGHT -> MidnightColorScheme
    }

  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as? Activity)?.window
      if (window != null) {
        val insetsController = WindowCompat.getInsetsController(window, view)
        insetsController.isAppearanceLightStatusBars = !isDark
        insetsController.isAppearanceLightNavigationBars = !isDark
      }
    }
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = NoorTypography,
    shapes = NoorShapes,
    content = content,
  )
}
