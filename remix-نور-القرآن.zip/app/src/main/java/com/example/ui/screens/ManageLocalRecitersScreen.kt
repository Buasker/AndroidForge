package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Audiotrack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioPlaybackState
import com.example.data.firebase.ExternalAudioMetadata
import com.example.data.model.LocalRecitationTrack
import com.example.data.model.LocalReciter
import com.example.data.model.SurahInfo
import com.example.ui.components.OctagonalBadge
import com.example.ui.components.ReciterAvatar
import com.example.ui.theme.AmiriFontFamily
import java.util.Locale

@Composable
fun ManageLocalRecitersScreen(
  reciters: List<LocalReciter>,
  trackCountByReciter: Map<String, Int>,
  selectedReciter: LocalReciter?,
  recitationsForSelected: List<LocalRecitationTrack>,
  surahs: List<SurahInfo>,
  preferredReciterId: String,
  searchQuery: String,
  isBusy: Boolean,
  isProbingUrl: Boolean,
  probeResult: Result<ExternalAudioMetadata>?,
  audioState: AudioPlaybackState,
  statusMessage: String?,
  onClearMessage: () -> Unit,
  onClearProbeResult: () -> Unit,
  onSearchQueryChange: (String) -> Unit,
  onOpenReciter: (String) -> Unit,
  onBackToList: () -> Unit,
  onProbeAudioUrl: (String) -> Unit,
  onImportPhotoUri: (uri: Uri, onImported: (String) -> Unit, onError: (String) -> Unit) -> Unit,
  onSaveReciter: (
    editingId: String?,
    arabicName: String,
    description: String,
    riwayah: String,
    photoPathOrUrl: String,
    fullSurahBaseUrl: String,
    onResult: (Result<LocalReciter>) -> Unit,
  ) -> Unit,
  onDeleteReciter: (LocalReciter) -> Unit,
  onSaveRecitation: (
    reciterId: String,
    surahNumber: Int,
    audioUrl: String,
    notes: String,
    isEdit: Boolean,
    onResult: (Result<LocalRecitationTrack>) -> Unit,
  ) -> Unit,
  onDeleteRecitation: (reciterId: String, LocalRecitationTrack) -> Unit,
  onSetPreferredReciter: (String) -> Unit,
  onPlayTrack: (LocalReciter, LocalRecitationTrack) -> Unit,
  onPlayFullSurahSample: (LocalReciter, Int) -> Unit,
  onTogglePlayPause: () -> Unit,
  onSeekTo: (Int) -> Unit,
  onSeekBySeconds: (Int) -> Unit,
  onStopPlayback: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val snackbarHostState = remember { SnackbarHostState() }
  var showReciterDialog by remember { mutableStateOf(false) }
  var editingReciter by remember { mutableStateOf<LocalReciter?>(null) }
  var pendingDeleteReciter by remember { mutableStateOf<LocalReciter?>(null) }

  var showRecitationDialog by remember { mutableStateOf(false) }
  var editingRecitation by remember { mutableStateOf<LocalRecitationTrack?>(null) }
  var pendingDeleteRecitation by remember { mutableStateOf<LocalRecitationTrack?>(null) }

  LaunchedEffect(statusMessage) {
    if (statusMessage != null) {
      snackbarHostState.showSnackbar(statusMessage)
      onClearMessage()
    }
  }

  BackHandler(enabled = selectedReciter != null) {
    onBackToList()
  }

  Scaffold(
    snackbarHost = { SnackbarHost(snackbarHostState) },
    contentWindowInsets = WindowInsets(0.dp),
    modifier = modifier.fillMaxSize(),
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      if (selectedReciter == null) {
        LocalRecitersListContent(
          reciters = reciters,
          trackCountByReciter = trackCountByReciter,
          preferredReciterId = preferredReciterId,
          searchQuery = searchQuery,
          onSearchQueryChange = onSearchQueryChange,
          onOpenAddDialog = {
            editingReciter = null
            onClearProbeResult()
            showReciterDialog = true
          },
          onOpenReciter = onOpenReciter,
          onEditReciter = { reciter ->
            editingReciter = reciter
            onClearProbeResult()
            showReciterDialog = true
          },
          onRequestDeleteReciter = { pendingDeleteReciter = it },
        )
      } else {
        LocalReciterDetailContent(
          reciter = selectedReciter,
          recitations = recitationsForSelected,
          isPreferred = selectedReciter.id == preferredReciterId,
          audioState = audioState,
          onBackToList = onBackToList,
          onEditReciter = {
            editingReciter = selectedReciter
            onClearProbeResult()
            showReciterDialog = true
          },
          onRequestDeleteReciter = { pendingDeleteReciter = selectedReciter },
          onSetPreferred = { onSetPreferredReciter(selectedReciter.id) },
          onOpenAddRecitation = {
            editingRecitation = null
            onClearProbeResult()
            showRecitationDialog = true
          },
          onEditRecitation = { track ->
            editingRecitation = track
            onClearProbeResult()
            showRecitationDialog = true
          },
          onRequestDeleteRecitation = { pendingDeleteRecitation = it },
          onPlayTrack = { track -> onPlayTrack(selectedReciter, track) },
          onPlayFullSurahSample = { surahNum -> onPlayFullSurahSample(selectedReciter, surahNum) },
          onTogglePlayPause = onTogglePlayPause,
          onSeekTo = onSeekTo,
          onSeekBySeconds = onSeekBySeconds,
          onStopPlayback = onStopPlayback,
        )
      }
    }
  }

  if (showReciterDialog) {
    LocalReciterEditorDialog(
      initial = editingReciter,
      isBusy = isBusy,
      isProbingUrl = isProbingUrl,
      probeResult = probeResult,
      onProbeAudioUrl = onProbeAudioUrl,
      onImportPhotoUri = onImportPhotoUri,
      onDismiss = {
        showReciterDialog = false
        onClearProbeResult()
      },
      onSave = { name, desc, riwayah, photo, fullUrl, onError ->
        onSaveReciter(editingReciter?.id, name, desc, riwayah, photo, fullUrl) { result ->
          result
            .onSuccess {
              showReciterDialog = false
              onClearProbeResult()
            }
            .onFailure { err ->
              onError(err.localizedMessage ?: "يرجى التحقق من البيانات المدخلة.")
            }
        }
      },
    )
  }

  if (showRecitationDialog && selectedReciter != null) {
    LocalRecitationEditorDialog(
      reciter = selectedReciter,
      surahs = surahs,
      existingSurahNumbers = recitationsForSelected.map { it.surahNumber }.toSet(),
      initial = editingRecitation,
      isBusy = isBusy,
      isProbingUrl = isProbingUrl,
      probeResult = probeResult,
      onProbeAudioUrl = onProbeAudioUrl,
      onDismiss = {
        showRecitationDialog = false
        onClearProbeResult()
      },
      onSave = { surahNumber, audioUrl, notes, onError ->
        onSaveRecitation(
          selectedReciter.id,
          surahNumber,
          audioUrl,
          notes,
          editingRecitation != null,
        ) { result ->
          result
            .onSuccess {
              showRecitationDialog = false
              onClearProbeResult()
            }
            .onFailure { err ->
              onError(err.localizedMessage ?: "تعذر حفظ رابط التلاوة.")
            }
        }
      },
    )
  }

  pendingDeleteReciter?.let { target ->
    AlertDialog(
      onDismissRequest = { pendingDeleteReciter = null },
      title = { Text("تأكيد حذف القارئ") },
      text = {
        Text(
          "هل أنت متأكد من حذف الشيخ «${target.arabicName}»؟ سيتم حذف جميع روابط التلاوات المرتبطة به نهائياً من الجهاز."
        )
      },
      confirmButton = {
        Button(
          onClick = {
            onDeleteReciter(target)
            pendingDeleteReciter = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
          modifier = Modifier.testTag("confirm_delete_reciter_button"),
        ) {
          Text("حذف نهائي")
        }
      },
      dismissButton = {
        TextButton(onClick = { pendingDeleteReciter = null }) {
          Text("إلغاء")
        }
      },
      modifier = Modifier.testTag("confirm_delete_reciter_dialog"),
    )
  }

  pendingDeleteRecitation?.let { target ->
    val activeReciter = selectedReciter
    AlertDialog(
      onDismissRequest = { pendingDeleteRecitation = null },
      title = { Text("حذف تلاوة السورة") },
      text = {
        Text("هل تريد حذف رابط تلاوة ${target.surahArabicName}؟")
      },
      confirmButton = {
        Button(
          onClick = {
            if (activeReciter != null) {
              onDeleteRecitation(activeReciter.id, target)
            }
            pendingDeleteRecitation = null
          },
          colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
          modifier = Modifier.testTag("confirm_delete_recitation_button"),
        ) {
          Text("حذف")
        }
      },
      dismissButton = {
        TextButton(onClick = { pendingDeleteRecitation = null }) {
          Text("إلغاء")
        }
      },
      modifier = Modifier.testTag("confirm_delete_recitation_dialog"),
    )
  }
}

@Composable
private fun LocalRecitersListContent(
  reciters: List<LocalReciter>,
  trackCountByReciter: Map<String, Int>,
  preferredReciterId: String,
  searchQuery: String,
  onSearchQueryChange: (String) -> Unit,
  onOpenAddDialog: () -> Unit,
  onOpenReciter: (String) -> Unit,
  onEditReciter: (LocalReciter) -> Unit,
  onRequestDeleteReciter: (LocalReciter) -> Unit,
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 104.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item {
      Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = "إدارة القرّاء والتلاوات",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text = "أضف القرّاء وروابط تلاواتهم ليظهروا في المصحف والمكتبة الصوتية مع الحفظ على جهازك.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
          Button(
            onClick = onOpenAddDialog,
            modifier = Modifier.fillMaxWidth().testTag("local_add_reciter_button"),
          ) {
            Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("إضافة قارئ جديد")
          }
        }
      }
    }

    item {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = onSearchQueryChange,
        placeholder = { Text("ابحث في قرّائك المضافين…") },
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
        trailingIcon = {
          if (searchQuery.isNotEmpty()) {
            IconButton(
              onClick = { onSearchQueryChange("") },
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
              Icon(Icons.Rounded.Clear, contentDescription = "مسح البحث")
            }
          }
        },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors =
          OutlinedTextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
          ),
        modifier = Modifier.fillMaxWidth().testTag("local_reciters_search_input"),
      )
    }

    if (reciters.isEmpty()) {
      item {
        Surface(
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          modifier = Modifier.fillMaxWidth().testTag("local_reciters_empty_state"),
        ) {
          Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(
              imageVector = Icons.Rounded.RecordVoiceOver,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(40.dp),
            )
            Text(
              text =
                if (searchQuery.isBlank()) "لم تضف قرّاء بعد"
                else "لا توجد نتائج مطابقة للبحث",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
            )
            Text(
              text =
                if (searchQuery.isBlank()) {
                  "اضغط على «إضافة قارئ جديد» لإدخال اسم الشيخ وصورته وروابط التلاوات بصيغة MP3 أو HTTPS."
                } else {
                  "جرّب البحث باسم آخر أو مسح حقل البحث."
                },
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    } else {
      items(reciters, key = { it.id }) { reciter ->
        val trackCount = trackCountByReciter[reciter.id] ?: 0
        val isPreferred = reciter.id == preferredReciterId
        Surface(
          modifier =
            Modifier.fillMaxWidth()
              .clickable { onOpenReciter(reciter.id) }
              .testTag("local_reciter_card_${reciter.id}"),
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.surface,
          border =
            BorderStroke(
              1.dp,
              if (isPreferred) MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
              else MaterialTheme.colorScheme.outlineVariant,
            ),
          tonalElevation = 1.dp,
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              ReciterAvatar(
                photoUrl = reciter.photoPathOrUrl,
                contentDescription = reciter.arabicName,
                size = 56.dp,
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(
                  text = reciter.arabicName,
                  fontFamily = AmiriFontFamily,
                  fontSize = 21.sp,
                  fontWeight = FontWeight.Bold,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Text(
                  text = reciter.riwayah,
                  style = MaterialTheme.typography.labelMedium,
                  color = MaterialTheme.colorScheme.primary,
                )
                if (reciter.description.isNotBlank()) {
                  Text(
                    text = reciter.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
              }
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              val summary =
                buildList {
                  add("$trackCount سورة مضافة")
                  if (reciter.fullSurahBaseUrl.isNotBlank()) add("رابط سور كاملة مفعّل")
                }.joinToString(" • ")
              Text(
                text = summary,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.weight(1f),
              )

              Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(
                  onClick = { onOpenReciter(reciter.id) },
                  modifier = Modifier.testTag("manage_tracks_${reciter.id}"),
                ) {
                  Text("التلاوات")
                }
                IconButton(
                  onClick = { onEditReciter(reciter) },
                  modifier =
                    Modifier.minimumInteractiveComponentSize()
                      .testTag("edit_local_reciter_${reciter.id}"),
                ) {
                  Icon(
                    imageVector = Icons.Rounded.Edit,
                    contentDescription = "تعديل بيانات القارئ",
                    tint = MaterialTheme.colorScheme.primary,
                  )
                }
                IconButton(
                  onClick = { onRequestDeleteReciter(reciter) },
                  modifier =
                    Modifier.minimumInteractiveComponentSize()
                      .testTag("delete_local_reciter_${reciter.id}"),
                ) {
                  Icon(
                    imageVector = Icons.Rounded.DeleteOutline,
                    contentDescription = "حذف القارئ",
                    tint = MaterialTheme.colorScheme.error,
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun LocalReciterDetailContent(
  reciter: LocalReciter,
  recitations: List<LocalRecitationTrack>,
  isPreferred: Boolean,
  audioState: AudioPlaybackState,
  onBackToList: () -> Unit,
  onEditReciter: () -> Unit,
  onRequestDeleteReciter: () -> Unit,
  onSetPreferred: () -> Unit,
  onOpenAddRecitation: () -> Unit,
  onEditRecitation: (LocalRecitationTrack) -> Unit,
  onRequestDeleteRecitation: (LocalRecitationTrack) -> Unit,
  onPlayTrack: (LocalRecitationTrack) -> Unit,
  onPlayFullSurahSample: (Int) -> Unit,
  onTogglePlayPause: () -> Unit,
  onSeekTo: (Int) -> Unit,
  onSeekBySeconds: (Int) -> Unit,
  onStopPlayback: () -> Unit,
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 104.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        TextButton(
          onClick = onBackToList,
          modifier = Modifier.testTag("local_reciter_back_to_list"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text("جميع القرّاء المضافين")
        }
        Row {
          IconButton(
            onClick = onEditReciter,
            modifier = Modifier.minimumInteractiveComponentSize().testTag("detail_edit_reciter_btn"),
          ) {
            Icon(Icons.Rounded.Edit, contentDescription = "تعديل القارئ")
          }
          IconButton(
            onClick = onRequestDeleteReciter,
            modifier =
              Modifier.minimumInteractiveComponentSize().testTag("detail_delete_reciter_btn"),
          ) {
            Icon(
              Icons.Rounded.DeleteOutline,
              contentDescription = "حذف القارئ",
              tint = MaterialTheme.colorScheme.error,
            )
          }
        }
      }
    }

    item {
      Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            ReciterAvatar(
              photoUrl = reciter.photoPathOrUrl,
              contentDescription = reciter.arabicName,
              size = 68.dp,
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(
                text = reciter.arabicName,
                fontFamily = AmiriFontFamily,
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold,
              )
              Text(
                text = reciter.riwayah,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
              )
              if (reciter.description.isNotBlank()) {
                Text(
                  text = reciter.description,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }

          if (reciter.fullSurahBaseUrl.isNotBlank()) {
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Row(
                modifier = Modifier.padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = "مصدر السور الكاملة:",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                  )
                  Text(
                    text = reciter.fullSurahBaseUrl,
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
                TextButton(
                  onClick = { onPlayFullSurahSample(1) },
                  modifier = Modifier.testTag("play_full_surah_sample_button"),
                ) {
                  Icon(Icons.Rounded.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                  Text("تشغيل الفاتحة")
                }
              }
            }
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            OutlinedButton(
              onClick = onSetPreferred,
              enabled = !isPreferred,
              modifier = Modifier.weight(1f).testTag("local_set_preferred_btn"),
            ) {
              Icon(
                imageVector = if (isPreferred) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(if (isPreferred) "المفضّل بالمصحف" else "تعيين للمصحف")
            }

            Button(
              onClick = onOpenAddRecitation,
              modifier = Modifier.weight(1f).testTag("local_add_recitation_button"),
            ) {
              Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("إضافة سورة")
            }
          }
        }
      }
    }

    if (audioState.isActive) {
      item {
        Surface(
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
          modifier = Modifier.fillMaxWidth().testTag("local_manage_inline_player"),
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = audioState.surahArabicName,
                  fontFamily = AmiriFontFamily,
                  fontSize = 21.sp,
                  fontWeight = FontWeight.Bold,
                )
                Text(
                  text =
                    audioState.errorMessage
                      ?: "${audioState.reciterName} • ${if (audioState.isBuffering) "جارٍ التحميل…" else if (audioState.isPlaying) "قيد التشغيل" else "متوقف مؤقتاً"}",
                  style = MaterialTheme.typography.bodySmall,
                  color =
                    if (audioState.errorMessage != null) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary,
                )
              }
              Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                  onClick = { onSeekBySeconds(-10) },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(Icons.Rounded.Replay10, contentDescription = "تأخير ١٠ ثوانٍ")
                }
                Surface(
                  shape = CircleShape,
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(48.dp),
                ) {
                  IconButton(onClick = onTogglePlayPause) {
                    if (audioState.isBuffering) {
                      CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp,
                      )
                    } else {
                      Icon(
                        imageVector =
                          if (audioState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = "تشغيل أو إيقاف",
                        tint = MaterialTheme.colorScheme.onPrimary,
                      )
                    }
                  }
                }
                IconButton(
                  onClick = { onSeekBySeconds(10) },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(Icons.Rounded.Forward10, contentDescription = "تقديم ١٠ ثوانٍ")
                }
                IconButton(
                  onClick = onStopPlayback,
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(Icons.Rounded.Stop, contentDescription = "إيقاف")
                }
              }
            }
            if (audioState.durationMs > 0) {
              Slider(
                value = audioState.positionMs.toFloat().coerceIn(0f, audioState.durationMs.toFloat()),
                onValueChange = { onSeekTo(it.toInt()) },
                valueRange = 0f..audioState.durationMs.toFloat().coerceAtLeast(1f),
              )
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatLocalReciterMs(audioState.positionMs), style = MaterialTheme.typography.labelSmall)
                Text(formatLocalReciterMs(audioState.durationMs), style = MaterialTheme.typography.labelSmall)
              }
            }
          }
        }
      }
    }

    item {
      Text(
        text = "التلاوات المضافة لكل سورة (${recitations.size})",
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onBackground,
      )
    }

    if (recitations.isEmpty()) {
      item {
        Surface(
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          modifier = Modifier.fillMaxWidth().testTag("local_recitations_empty"),
        ) {
          Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(
              imageVector = Icons.Rounded.Audiotrack,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(34.dp),
            )
            Text(
              text = "لا توجد روابط سور مضافة بشكل منفرد",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
            )
            Text(
              text =
                if (reciter.fullSurahBaseUrl.isNotBlank()) {
                  "يعمل القارئ حالياً برابط السور الكاملة؛ ويمكنك إضافة رابط مخصص لأي سورة لتقديمه في التشغيل."
                } else {
                  "اضغط على «إضافة سورة» لربط رابط MP3 أو بث مباشر بالسورة المناسبة."
                },
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    } else {
      items(recitations, key = { "${it.reciterId}_${it.surahNumber}" }) { track ->
        val trackId = "local_${track.reciterId}_${track.surahNumber}"
        val isThisActive =
          audioState.isActive &&
            audioState.trackId == trackId &&
            audioState.reciterId == reciter.id

        Surface(
          modifier =
            Modifier.fillMaxWidth()
              .clickable { onPlayTrack(track) }
              .testTag("local_recitation_card_${track.surahNumber}"),
          shape = MaterialTheme.shapes.medium,
          color =
            if (isThisActive) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
            else MaterialTheme.colorScheme.surface,
          border =
            BorderStroke(
              1.dp,
              if (isThisActive) MaterialTheme.colorScheme.primary
              else MaterialTheme.colorScheme.outlineVariant,
            ),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            OctagonalBadge(number = track.surahNumber, size = 40.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
              Text(
                text = track.surahArabicName,
                fontFamily = AmiriFontFamily,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              if (track.notes.isNotBlank()) {
                Text(
                  text = track.notes,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
              Text(
                text = track.audioUrl,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            IconButton(
              onClick = { onPlayTrack(track) },
              modifier =
                Modifier.minimumInteractiveComponentSize()
                  .testTag("play_local_recitation_${track.surahNumber}"),
            ) {
              Icon(
                imageVector =
                  if (isThisActive && audioState.isPlaying) Icons.Rounded.Pause
                  else Icons.Rounded.PlayArrow,
                contentDescription = "تشغيل أو إيقاف",
                tint = MaterialTheme.colorScheme.primary,
              )
            }
            IconButton(
              onClick = { onEditRecitation(track) },
              modifier =
                Modifier.minimumInteractiveComponentSize()
                  .testTag("edit_local_recitation_${track.surahNumber}"),
            ) {
              Icon(
                imageVector = Icons.Rounded.Edit,
                contentDescription = "تعديل الرابط",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            IconButton(
              onClick = { onRequestDeleteRecitation(track) },
              modifier =
                Modifier.minimumInteractiveComponentSize()
                  .testTag("delete_local_recitation_${track.surahNumber}"),
            ) {
              Icon(
                imageVector = Icons.Rounded.DeleteOutline,
                contentDescription = "حذف التلاوة",
                tint = MaterialTheme.colorScheme.error,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun LocalReciterEditorDialog(
  initial: LocalReciter?,
  isBusy: Boolean,
  isProbingUrl: Boolean,
  probeResult: Result<ExternalAudioMetadata>?,
  onProbeAudioUrl: (String) -> Unit,
  onImportPhotoUri: (uri: Uri, onImported: (String) -> Unit, onError: (String) -> Unit) -> Unit,
  onDismiss: () -> Unit,
  onSave: (
    arabicName: String,
    description: String,
    riwayah: String,
    photoPathOrUrl: String,
    fullSurahBaseUrl: String,
    onError: (String) -> Unit,
  ) -> Unit,
) {
  var name by remember(initial) { mutableStateOf(initial?.arabicName ?: "") }
  var riwayah by remember(initial) { mutableStateOf(initial?.riwayah ?: "حفص عن عاصم") }
  var description by remember(initial) { mutableStateOf(initial?.description ?: "") }
  var photoPathOrUrl by remember(initial) { mutableStateOf(initial?.photoPathOrUrl ?: "") }
  var fullSurahUrl by remember(initial) { mutableStateOf(initial?.fullSurahBaseUrl ?: "") }
  var validationError by remember { mutableStateOf<String?>(null) }

  val photoPickerLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
      if (uri != null) {
        onImportPhotoUri(
          uri,
          { savedPath ->
            photoPathOrUrl = savedPath
            validationError = null
          },
          { err -> validationError = err },
        )
      }
    }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(if (initial == null) "إضافة قارئ جديد" else "تعديل بيانات القارئ")
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = {
            name = it
            validationError = null
          },
          label = { Text("اسم الشيخ (مطلوب)") },
          placeholder = { Text("مثال: الشيخ عبدالولي الأركاني") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("local_reciter_name_input"),
        )

        OutlinedTextField(
          value = riwayah,
          onValueChange = { riwayah = it },
          label = { Text("الرواية") },
          placeholder = { Text("حفص عن عاصم") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("local_reciter_riwayah_input"),
        )

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("وصف مختصر (اختياري)") },
          placeholder = { Text("نبذة عن القارئ أو أسلوب التلاوة") },
          minLines = 2,
          maxLines = 3,
          modifier = Modifier.fillMaxWidth().testTag("local_reciter_bio_input"),
        )

        HorizontalDivider()

        Text(
          text = "صورة القارئ (اختياري)",
          style = MaterialTheme.typography.labelLarge,
        )
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          ReciterAvatar(
            photoUrl = photoPathOrUrl,
            contentDescription = "معاينة صورة القارئ",
            size = 48.dp,
          )
          OutlinedButton(
            onClick = {
              photoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
              )
            },
            modifier = Modifier.weight(1f).testTag("pick_reciter_photo_button"),
          ) {
            Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("صورة من المعرض")
          }
          if (photoPathOrUrl.isNotBlank()) {
            IconButton(
              onClick = { photoPathOrUrl = "" },
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
              Icon(Icons.Rounded.Clear, contentDescription = "إزالة الصورة")
            }
          }
        }

        OutlinedTextField(
          value = if (photoPathOrUrl.startsWith("/")) "" else photoPathOrUrl,
          onValueChange = {
            photoPathOrUrl = it
            validationError = null
          },
          label = { Text("أو رابط صورة مباشر HTTPS (اختياري)") },
          placeholder = { Text("https://example.com/sheikh.jpg") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("local_reciter_photo_url_input"),
        )

        HorizontalDivider()

        OutlinedTextField(
          value = fullSurahUrl,
          onValueChange = {
            fullSurahUrl = it
            validationError = null
          },
          label = { Text("رابط السور الكاملة أو الخادم (اختياري)") },
          placeholder = { Text("https://server.mp3quran.net/folder/ أو رابط MP3") },
          supportingText = {
            Text(
              "إذا أدخلت مجلد خادم مثل .../folder/ فسيقرأ السور 001.mp3 إلى 114.mp3، أو يمكنك إضافة كل سورة منفردة لاحقاً."
            )
          },
          singleLine = true,
          leadingIcon = { Icon(Icons.Rounded.Link, contentDescription = null) },
          modifier = Modifier.fillMaxWidth().testTag("local_reciter_base_url_input"),
        )

        if (fullSurahUrl.isNotBlank()) {
          OutlinedButton(
            onClick = { onProbeAudioUrl(fullSurahUrl) },
            enabled = !isProbingUrl,
            modifier = Modifier.fillMaxWidth().testTag("probe_reciter_base_url_btn"),
          ) {
            if (isProbingUrl) {
              CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
              Spacer(modifier = Modifier.width(8.dp))
            }
            Text("فحص صلاحية الرابط")
          }
          ProbeStatusBanner(probeResult)
        }

        if (validationError != null) {
          Text(
            text = validationError!!,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error,
            modifier = Modifier.testTag("local_reciter_dialog_error"),
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(name, description, riwayah, photoPathOrUrl, fullSurahUrl) { err ->
            validationError = err
          }
        },
        enabled = !isBusy,
        modifier = Modifier.testTag("save_local_reciter_button"),
      ) {
        Text(if (isBusy) "جارٍ الحفظ…" else "حفظ القارئ")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("إلغاء") }
    },
  )
}

@Composable
private fun LocalRecitationEditorDialog(
  reciter: LocalReciter,
  surahs: List<SurahInfo>,
  existingSurahNumbers: Set<Int>,
  initial: LocalRecitationTrack?,
  isBusy: Boolean,
  isProbingUrl: Boolean,
  probeResult: Result<ExternalAudioMetadata>?,
  onProbeAudioUrl: (String) -> Unit,
  onDismiss: () -> Unit,
  onSave: (
    surahNumber: Int,
    audioUrl: String,
    notes: String,
    onError: (String) -> Unit,
  ) -> Unit,
) {
  val defaultSurah =
    initial?.surahNumber
      ?: surahs.firstOrNull { it.number !in existingSurahNumbers }?.number
      ?: 1
  var selectedSurahNumber by remember(initial) { mutableIntStateOf(defaultSurah) }
  var surahFilter by remember { mutableStateOf("") }
  var showSurahPicker by remember { mutableStateOf(false) }
  var audioUrl by remember(initial) { mutableStateOf(initial?.audioUrl ?: "") }
  var notes by remember(initial) { mutableStateOf(initial?.notes ?: "") }
  var validationError by remember { mutableStateOf<String?>(null) }

  val selectedSurah = surahs.firstOrNull { it.number == selectedSurahNumber }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text(
        if (initial == null) "إضافة تلاوة للشيخ ${reciter.arabicName}"
        else "تعديل تلاوة ${initial.surahArabicName}"
      )
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = MaterialTheme.colorScheme.surfaceContainer,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          modifier =
            Modifier.fillMaxWidth()
              .clickable(enabled = initial == null) { showSurahPicker = !showSurahPicker }
              .testTag("select_surah_dropdown_trigger"),
        ) {
          Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              OctagonalBadge(number = selectedSurahNumber, size = 34.dp)
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = selectedSurah?.arabicName ?: "سورة رقم $selectedSurahNumber",
                  fontFamily = AmiriFontFamily,
                  fontSize = 18.sp,
                  fontWeight = FontWeight.Bold,
                )
                Text(
                  text =
                    if (initial == null) "اضغط لتغيير السورة (١ - ١١٤)"
                    else "رقم السورة: $selectedSurahNumber",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        }

        if (showSurahPicker && initial == null) {
          OutlinedTextField(
            value = surahFilter,
            onValueChange = { surahFilter = it },
            placeholder = { Text("ابحث باسم السورة أو رقمها…") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("surah_picker_search_input"),
          )
          val filtered =
            remember(surahs, surahFilter) {
              val q = surahFilter.trim()
              if (q.isEmpty()) surahs
              else surahs.filter {
                it.arabicName.contains(q) ||
                  it.englishName.contains(q, ignoreCase = true) ||
                  it.number.toString() == q
              }
            }
          Column(
            modifier =
              Modifier.fillMaxWidth()
                .heightIn(max = 200.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            filtered.forEach { surah ->
              val alreadyAdded = surah.number in existingSurahNumbers
              Surface(
                modifier =
                  Modifier.fillMaxWidth()
                    .clickable(enabled = !alreadyAdded) {
                      selectedSurahNumber = surah.number
                      showSurahPicker = false
                      validationError = null
                    }
                    .testTag("pick_surah_option_${surah.number}"),
                shape = RoundedCornerShape(10.dp),
                color =
                  when {
                    selectedSurahNumber == surah.number ->
                      MaterialTheme.colorScheme.primaryContainer
                    alreadyAdded -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    else -> MaterialTheme.colorScheme.surface
                  },
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Text(
                    text = "${surah.number}. ${surah.arabicName}",
                    style = MaterialTheme.typography.bodyMedium,
                  )
                  if (alreadyAdded) {
                    Text(
                      text = "مضافة",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.primary,
                    )
                  }
                }
              }
            }
          }
        }

        OutlinedTextField(
          value = audioUrl,
          onValueChange = {
            audioUrl = it
            validationError = null
          },
          label = { Text("رابط التلاوة المباشر (MP3 / HTTPS)") },
          placeholder = { Text("https://example.com/018.mp3") },
          singleLine = true,
          leadingIcon = { Icon(Icons.Rounded.Link, contentDescription = null) },
          modifier = Modifier.fillMaxWidth().testTag("local_recitation_url_input"),
        )

        OutlinedButton(
          onClick = { onProbeAudioUrl(audioUrl) },
          enabled = !isProbingUrl && audioUrl.isNotBlank(),
          modifier = Modifier.fillMaxWidth().testTag("probe_recitation_url_button"),
        ) {
          if (isProbingUrl) {
            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
            Spacer(modifier = Modifier.width(8.dp))
          }
          Text("فحص توفر الرابط قبل الحفظ")
        }

        ProbeStatusBanner(probeResult)

        OutlinedTextField(
          value = notes,
          onValueChange = { notes = it },
          label = { Text("وصف أو ملاحظة (اختياري)") },
          placeholder = { Text("مثال: تلاوة من صلاة الفجر - جودة عالية") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("local_recitation_notes_input"),
        )

        if (validationError != null) {
          Text(
            text = validationError!!,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.error,
            modifier = Modifier.testTag("local_recitation_dialog_error"),
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onSave(selectedSurahNumber, audioUrl, notes) { err ->
            validationError = err
          }
        },
        enabled = !isBusy,
        modifier = Modifier.testTag("save_local_recitation_button"),
      ) {
        Text(if (isBusy) "جارٍ الحفظ…" else "حفظ التلاوة")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("إلغاء") }
    },
  )
}

@Composable
private fun ProbeStatusBanner(probeResult: Result<ExternalAudioMetadata>?) {
  probeResult ?: return
  val isSuccess = probeResult.isSuccess && probeResult.getOrNull()?.reachable == true
  Surface(
    shape = RoundedCornerShape(10.dp),
    color =
      if (isSuccess) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
      else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
    modifier = Modifier.fillMaxWidth().testTag("url_probe_status_banner"),
  ) {
    Row(
      modifier = Modifier.padding(10.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Icon(
        imageVector = if (isSuccess) Icons.Rounded.Verified else Icons.Rounded.WarningAmber,
        contentDescription = null,
        tint =
          if (isSuccess) MaterialTheme.colorScheme.primary
          else MaterialTheme.colorScheme.error,
        modifier = Modifier.size(20.dp),
      )
      val meta = probeResult.getOrNull()
      val message =
        when {
          isSuccess && meta != null -> {
            val sizeText =
              if (meta.contentLengthBytes > 0L) {
                " (${String.format(Locale.US, "%.2f", meta.contentLengthBytes / (1024f * 1024f))} MB)"
              } else ""
            "الرابط صالح ومتاح للتشغيل$sizeText"
          }
          probeResult.isSuccess -> "الرابط متاح بصيغة HTTPS لكن تعذر تأكيد الملف (قد يقيّد الخادم الفحص السريع)."
          else -> probeResult.exceptionOrNull()?.localizedMessage ?: "تعذر التحقق من الرابط (تحقق من الصيغة أو الإنترنت)."
        }
      Text(
        text = message,
        style = MaterialTheme.typography.bodySmall,
        color =
          if (isSuccess) MaterialTheme.colorScheme.onPrimaryContainer
          else MaterialTheme.colorScheme.onErrorContainer,
      )
    }
  }
}

private fun formatLocalReciterMs(ms: Int): String {
  val totalSeconds = (ms / 1000).coerceAtLeast(0)
  val hours = totalSeconds / 3600
  val minutes = (totalSeconds % 3600) / 60
  val seconds = totalSeconds % 60
  return if (hours > 0) String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
  else String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
