package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BookmarkItem
import com.example.data.model.QuranCatalog
import com.example.ui.components.OctagonalBadge
import com.example.ui.theme.AmiriFontFamily

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BookmarksScreen(
  bookmarks: List<BookmarkItem>,
  selectedCategory: String,
  onSelectCategory: (String) -> Unit,
  onOpenAyah: (surahNumber: Int, ayahNumber: Int) -> Unit,
  onUpdateBookmarkDetails: (surahNumber: Int, ayahNumber: Int, category: String, note: String) -> Unit,
  onRemoveBookmark: (surahNumber: Int, ayahNumber: Int) -> Unit,
  onExploreSurahs: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val categories = listOf("الكل") + QuranCatalog.bookmarkCategories
  var editingBookmark by remember { mutableStateOf<BookmarkItem?>(null) }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(modifier = Modifier.fillMaxSize().widthIn(max = 720.dp)) {
      Column(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Text(
          text = "المفضلة والإشارات المرجعية",
          style = MaterialTheme.typography.headlineLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
          text =
            if (bookmarks.isEmpty()) "احفظ آياتك المفضلة مع ملاحظات التدبر والحفظ"
            else "${bookmarks.size} آية محفوظة",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(categories) { category ->
            FilterChip(
              selected = selectedCategory == category,
              onClick = { onSelectCategory(category) },
              label = { Text(category) },
              modifier = Modifier.testTag("bookmark_cat_$category"),
            )
          }
        }
      }

      if (bookmarks.isEmpty()) {
        Column(
          modifier = Modifier.fillMaxSize().padding(32.dp),
          verticalArrangement = Arrangement.Center,
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.secondaryContainer,
            modifier = Modifier.size(72.dp),
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Rounded.BookmarkBorder,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(34.dp),
              )
            }
          }
          Spacer(modifier = Modifier.height(16.dp))
          Text(
            text = "لا توجد آيات محفوظة في هذا التصنيف",
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "اضغط على علامة الحفظ بجانب أي آية أثناء القراءة لإضافتها إلى مفضلتك.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
          )
          Spacer(modifier = Modifier.height(20.dp))
          Button(
            onClick = onExploreSurahs,
            modifier = Modifier.testTag("bookmarks_explore_button"),
          ) {
            Text("تصفح المصحف الشريف")
          }
        }
      } else {
        LazyColumn(
          modifier = Modifier.fillMaxSize(),
          contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          items(bookmarks, key = { "${it.surahNumber}_${it.ayahNumberInSurah}" }) { item ->
            Surface(
              modifier =
                Modifier.fillMaxWidth()
                  .testTag("bookmark_card_${item.surahNumber}_${item.ayahNumberInSurah}")
                  .clickable { onOpenAyah(item.surahNumber, item.ayahNumberInSurah) },
              shape = MaterialTheme.shapes.medium,
              color = MaterialTheme.colorScheme.surface,
              border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            ) {
              Column(modifier = Modifier.padding(16.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    OctagonalBadge(number = item.ayahNumberInSurah, size = 34.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                      Text(
                        text = item.surahArabicName.ifBlank { item.surahEnglishName },
                        fontFamily = AmiriFontFamily,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                      )
                      Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                      ) {
                        Text(
                          text = "آية ${item.ayahNumberInSurah}",
                          style = MaterialTheme.typography.labelMedium,
                          color = MaterialTheme.colorScheme.primary,
                        )
                        Surface(
                          shape = MaterialTheme.shapes.small,
                          color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f),
                        ) {
                          Text(
                            text = item.category,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                          )
                        }
                      }
                    }
                  }

                  Row {
                    IconButton(
                      onClick = { editingBookmark = item },
                      modifier = Modifier.minimumInteractiveComponentSize(),
                    ) {
                      Icon(
                        imageVector = Icons.Rounded.EditNote,
                        contentDescription = "تعديل التصنيف والملاحظة",
                        tint = MaterialTheme.colorScheme.primary,
                      )
                    }
                    IconButton(
                      onClick = { onRemoveBookmark(item.surahNumber, item.ayahNumberInSurah) },
                      modifier =
                        Modifier.minimumInteractiveComponentSize()
                          .testTag("remove_bookmark_${item.surahNumber}_${item.ayahNumberInSurah}"),
                    ) {
                      Icon(
                        imageVector = Icons.Rounded.DeleteOutline,
                        contentDescription = "إزالة من المفضلة",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                      )
                    }
                  }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                  text = item.arabicText,
                  fontFamily = AmiriFontFamily,
                  fontSize = 22.sp,
                  lineHeight = 38.sp,
                  color = MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.fillMaxWidth(),
                  maxLines = 4,
                  overflow = TextOverflow.Ellipsis,
                )
                if (item.note.isNotBlank()) {
                  Spacer(modifier = Modifier.height(8.dp))
                  Surface(
                    shape = MaterialTheme.shapes.small,
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth(),
                  ) {
                    Text(
                      text = "ملاحظة: ${item.note}",
                      style = MaterialTheme.typography.bodyMedium,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                      modifier = Modifier.padding(10.dp),
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  val target = editingBookmark
  if (target != null) {
    var category by remember(target) { mutableStateOf(target.category) }
    var note by remember(target) { mutableStateOf(target.note) }
    AlertDialog(
      onDismissRequest = { editingBookmark = null },
      title = { Text("تعديل المفضلة") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text("التصنيف:", style = MaterialTheme.typography.labelLarge)
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            QuranCatalog.bookmarkCategories.forEach { cat ->
              FilterChip(
                selected = category == cat,
                onClick = { category = cat },
                label = { Text(cat) },
              )
            }
          }
          OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("ملاحظة شخصية أو تدبر") },
            minLines = 2,
            maxLines = 4,
            modifier = Modifier.fillMaxWidth(),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            onUpdateBookmarkDetails(
              target.surahNumber,
              target.ayahNumberInSurah,
              category,
              note,
            )
            editingBookmark = null
          }
        ) {
          Text("حفظ")
        }
      },
      dismissButton = {
        TextButton(onClick = { editingBookmark = null }) { Text("إلغاء") }
      },
    )
  }
}
