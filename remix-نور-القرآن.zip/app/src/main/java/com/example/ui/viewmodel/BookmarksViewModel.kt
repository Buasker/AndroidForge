package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.BookmarkItem
import com.example.data.repository.QuranRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BookmarksViewModel(
  private val quranRepository: QuranRepository,
) : ViewModel() {

  private val _selectedCategory = MutableStateFlow("الكل")
  val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

  val bookmarks: StateFlow<List<BookmarkItem>> =
    combine(quranRepository.bookmarksFlow, _selectedCategory) { list, cat ->
        if (cat == "الكل") list else list.filter { it.category == cat }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  fun selectCategory(category: String) {
    _selectedCategory.value = category
  }

  fun updateBookmarkDetails(
    surahNumber: Int,
    ayahNumber: Int,
    category: String,
    note: String,
  ) {
    viewModelScope.launch {
      quranRepository.updateBookmarkDetails(surahNumber, ayahNumber, category, note)
    }
  }

  fun removeBookmark(surahNumber: Int, ayahNumber: Int) {
    viewModelScope.launch { quranRepository.removeBookmark(surahNumber, ayahNumber) }
  }

  companion object {
    fun factory(quranRepository: QuranRepository): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return BookmarksViewModel(quranRepository) as T
        }
      }
  }
}
