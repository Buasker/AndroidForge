package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AdhkarCategory
import com.example.data.model.AdhkarItem
import com.example.ui.theme.AmiriFontFamily
import kotlinx.coroutines.launch

@Composable
fun AdhkarScreen(
  selectedCategory: AdhkarCategory,
  items: List<AdhkarItem>,
  fontSize: Float,
  onSelectCategory: (AdhkarCategory) -> Unit,
  onIncrementItem: (AdhkarItem) -> Unit,
  onResetItem: (AdhkarItem) -> Unit,
  onResetAll: () -> Unit,
  onFontSizeChange: (Float) -> Unit,
  onOpenReminders: () -> Unit,
  onOpenStats: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val listState = rememberLazyListState()
  val scope = rememberCoroutineScope()

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(modifier = Modifier.fillMaxSize().widthIn(max = 720.dp)) {
      Column(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column {
            Text(
              text = "الأذكار اليومية",
              style = MaterialTheme.typography.headlineLarge,
              color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
              text = selectedCategory.subtitle,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = { onFontSizeChange(fontSize + 2f) },
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
              Icon(Icons.Rounded.ZoomIn, contentDescription = "تكبير الخط")
            }
            IconButton(
              onClick = { onFontSizeChange(fontSize - 2f) },
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
              Icon(Icons.Rounded.ZoomOut, contentDescription = "تصغير الخط")
            }
            IconButton(
              onClick = onOpenReminders,
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
              Icon(Icons.Rounded.NotificationsActive, contentDescription = "تنبيهات الأذكار")
            }
            IconButton(
              onClick = onOpenStats,
              modifier =
                Modifier.minimumInteractiveComponentSize().testTag("adhkar_open_stats_button"),
            ) {
              Icon(Icons.Rounded.BarChart, contentDescription = "إحصائيات الأذكار")
            }
          }
        }

        // 7 Categories Tabs
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(AdhkarCategory.entries.size) { index ->
            val category = AdhkarCategory.entries[index]
            FilterChip(
              selected = selectedCategory == category,
              onClick = {
                onSelectCategory(category)
                scope.launch { listState.scrollToItem(0) }
              },
              label = { Text(category.titleArabic) },
              modifier = Modifier.testTag("adhkar_cat_${category.id}"),
            )
          }
        }

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          val completedCount = items.count { it.currentCount >= it.targetCount }
          Text(
            text = "أُنجز $completedCount من ${items.size}",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
          )
          TextButton(onClick = onResetAll) {
            Icon(Icons.Rounded.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("إعادة البدء")
          }
        }
      }

      LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        itemsIndexed(items, key = { _, item -> item.id }) { index, item ->
          val isDone = item.currentCount >= item.targetCount
          val fraction =
            if (item.targetCount > 0) (item.currentCount.toFloat() / item.targetCount.toFloat())
            else 1f

          Surface(
            modifier =
              Modifier.fillMaxWidth()
                .testTag("adhkar_item_${item.id}")
                .clickable {
                  onIncrementItem(item)
                  if (item.currentCount + 1 >= item.targetCount && index + 1 < items.size) {
                    scope.launch { listState.animateScrollToItem(index + 1) }
                  }
                },
            shape = MaterialTheme.shapes.medium,
            color =
              if (isDone) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
              else MaterialTheme.colorScheme.surface,
            border =
              BorderStroke(
                1.dp,
                if (isDone) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.outlineVariant,
              ),
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = item.textWithTashkeel,
                fontFamily = AmiriFontFamily,
                fontSize = fontSize.sp,
                lineHeight = (fontSize * 1.8f).sp,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.fillMaxWidth(),
              )
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = item.virtue,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.secondary,
              )
              Spacer(modifier = Modifier.height(12.dp))
              LinearProgressIndicator(
                progress = { fraction.coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
              )
              Spacer(modifier = Modifier.height(10.dp))
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Surface(
                    shape = CircleShape,
                    color =
                      if (isDone) MaterialTheme.colorScheme.primary
                      else MaterialTheme.colorScheme.secondaryContainer,
                  ) {
                    Row(
                      modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      if (isDone) {
                        Icon(
                          imageVector = Icons.Rounded.CheckCircle,
                          contentDescription = "مكتمل",
                          tint = MaterialTheme.colorScheme.onPrimary,
                          modifier = Modifier.size(16.dp),
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                      }
                      Text(
                        text = "${item.currentCount} / ${item.targetCount}",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                        color =
                          if (isDone) MaterialTheme.colorScheme.onPrimary
                          else MaterialTheme.colorScheme.onSecondaryContainer,
                      )
                    }
                  }
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = if (isDone) "تم الذكر ✓" else "اضغط للتسبيح",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                }

                Row {
                  IconButton(
                    onClick = { onResetItem(item) },
                    modifier = Modifier.minimumInteractiveComponentSize(),
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.Refresh,
                      contentDescription = "إعادة عداد الذكر",
                      tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                  IconButton(
                    onClick = {
                      val shareText =
                        "${item.textWithTashkeel}\n\n${item.virtue}\n— تطبيق نور القرآن"
                      val intent =
                        Intent(Intent.ACTION_SEND).apply {
                          type = "text/plain"
                          putExtra(Intent.EXTRA_TEXT, shareText)
                        }
                      context.startActivity(Intent.createChooser(intent, "مشاركة الذكر"))
                    },
                    modifier = Modifier.minimumInteractiveComponentSize(),
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.Share,
                      contentDescription = "مشاركة الذكر",
                      tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
