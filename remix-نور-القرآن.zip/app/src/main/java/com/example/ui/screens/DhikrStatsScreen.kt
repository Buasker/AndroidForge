package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.TrendingUp
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.CalendarToday
import androidx.compose.material.icons.rounded.DateRange
import androidx.compose.material.icons.rounded.LocalFireDepartment
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DhikrSourceType
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.viewmodel.DhikrBreakdownItem
import com.example.ui.viewmodel.DhikrStatsUiState
import com.example.ui.viewmodel.StatsChartPoint
import com.example.ui.viewmodel.StatsPeriodMode
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun DhikrStatsScreen(
  uiState: DhikrStatsUiState,
  onSelectPeriodMode: (StatsPeriodMode) -> Unit,
  onSelectDailyWindowDays: (Int) -> Unit,
  onSelectPoint: (Int) -> Unit,
  onOpenVoiceDhikr: () -> Unit,
  onOpenAdhkar: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().widthIn(max = 720.dp).testTag("dhikr_stats_list"),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      // Header
      item {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text(
            text = "معدل تكرار الأذكار",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text =
              "متابعة بصرية لعدد التسبيحات والأذكار المسجّلة يومياً وأسبوعياً عبر الذكر الصوتي والأذكار اليومية",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      // Period Switcher (Daily vs Weekly) + Daily Window Selector
      item {
        Surface(
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              PeriodModeTab(
                label = "المعدل اليومي",
                selected = uiState.periodMode == StatsPeriodMode.DAILY,
                onClick = { onSelectPeriodMode(StatsPeriodMode.DAILY) },
                testTag = "stats_tab_daily",
                modifier = Modifier.weight(1f),
              )
              PeriodModeTab(
                label = "المعدل الأسبوعي",
                selected = uiState.periodMode == StatsPeriodMode.WEEKLY,
                onClick = { onSelectPeriodMode(StatsPeriodMode.WEEKLY) },
                testTag = "stats_tab_weekly",
                modifier = Modifier.weight(1f),
              )
            }

            AnimatedVisibility(visible = uiState.periodMode == StatsPeriodMode.DAILY) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text = "النطاق:",
                  style = MaterialTheme.typography.labelLarge,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                FilterChip(
                  selected = uiState.dailyWindowDays == 7,
                  onClick = { onSelectDailyWindowDays(7) },
                  label = { Text("آخر ٧ أيام") },
                  modifier = Modifier.testTag("stats_window_7"),
                )
                FilterChip(
                  selected = uiState.dailyWindowDays == 14,
                  onClick = { onSelectDailyWindowDays(14) },
                  label = { Text("آخر ١٤ يوماً") },
                  modifier = Modifier.testTag("stats_window_14"),
                )
              }
            }
          }
        }
      }

      // Empty State Callout (shown above the fold when no dhikr has ever been logged yet)
      if (!uiState.hasAnyData) {
        item {
          Surface(
            shape = MaterialTheme.shapes.large,
            color = MaterialTheme.colorScheme.surfaceContainerLow,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            modifier = Modifier.fillMaxWidth().testTag("stats_empty_state"),
          ) {
            Column(
              modifier = Modifier.padding(18.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(50.dp),
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Icon(
                    imageVector = Icons.Rounded.BarChart,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(26.dp),
                  )
                }
              }
              Text(
                text = "لا توجد أذكار مسجّلة بعد",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
              )
              Text(
                text =
                  "بمجرد التسبيح عبر عداد الذكر الصوتي أو إتمام أذكار الصباح والمساء، ستظهر هنا الرسوم البيانية اليومية والأسبوعية لمعدلك الفعلي.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
              )
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Button(
                  onClick = onOpenVoiceDhikr,
                  modifier = Modifier.weight(1f).testTag("stats_empty_voice_cta"),
                ) {
                  Icon(
                    imageVector = Icons.Rounded.Mic,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("الذكر الصوتي")
                }
                OutlinedButton(
                  onClick = onOpenAdhkar,
                  modifier = Modifier.weight(1f).testTag("stats_empty_adhkar_cta"),
                ) {
                  Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("الأذكار اليومية")
                }
              }
            }
          }
        }
      }

      // KPI Summary Grid (2x2)
      item {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            StatsMetricCard(
              title = "ذكر اليوم",
              value = uiState.todayCount.toString(),
              subtitle = "تسبيحة وذكر",
              icon = Icons.Rounded.CalendarToday,
              accent = MaterialTheme.colorScheme.primary,
              testTag = "stats_metric_today",
              modifier = Modifier.weight(1f),
            )
            StatsMetricCard(
              title = "إجمالي الأسبوع",
              value = uiState.thisWeekCount.toString(),
              subtitle =
                uiState.weekOverWeekPercent?.let { pct ->
                  if (pct >= 0) "+$pct% عن الأسبوع الماضي" else "$pct% عن الأسبوع الماضي"
                } ?: "آخر ٧ أيام",
              icon = Icons.Rounded.DateRange,
              accent = MaterialTheme.colorScheme.secondary,
              testTag = "stats_metric_week",
              modifier = Modifier.weight(1f),
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            StatsMetricCard(
              title =
                if (uiState.periodMode == StatsPeriodMode.DAILY) "المتوسط اليومي"
                else "المتوسط الأسبوعي",
              value = formatRate(uiState.averageRate),
              subtitle =
                if (uiState.periodMode == StatsPeriodMode.DAILY) {
                  "خلال ${uiState.dailyWindowDays} أيام"
                } else {
                  "خلال ٨ أسابيع"
                },
              icon = Icons.AutoMirrored.Rounded.TrendingUp,
              accent = MaterialTheme.colorScheme.tertiary,
              testTag = "stats_metric_average",
              modifier = Modifier.weight(1f),
            )
            StatsMetricCard(
              title = "سلسلة الالتزام",
              value = "${uiState.currentStreakDays} يوم",
              subtitle =
                if (uiState.peakPointCount > 0) "الذروة: ${uiState.peakPointCount}"
                else "ابدأ اليوم",
              icon = Icons.Rounded.LocalFireDepartment,
              accent = MaterialTheme.colorScheme.secondary,
              testTag = "stats_metric_streak",
              modifier = Modifier.weight(1f),
            )
          }
        }
      }

      // Main Interactive Bar + Trend Line Chart Card
      item {
        DhikrRateChartCard(
          uiState = uiState,
          onSelectPoint = onSelectPoint,
        )
      }

      // Source Split + Breakdown Chart by Dhikr Phrase
      if (uiState.periodTotalCount > 0) {
        item {
          DhikrBreakdownCard(uiState = uiState)
        }
      }
    }
  }
}

@Composable
private fun PeriodModeTab(
  label: String,
  selected: Boolean,
  onClick: () -> Unit,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier =
      modifier
        .minimumInteractiveComponentSize()
        .testTag(testTag)
        .clip(MaterialTheme.shapes.medium)
        .clickable(onClick = onClick),
    shape = MaterialTheme.shapes.medium,
    color =
      if (selected) MaterialTheme.colorScheme.primary
      else MaterialTheme.colorScheme.surfaceContainer,
    border =
      BorderStroke(
        1.dp,
        if (selected) MaterialTheme.colorScheme.primary
        else MaterialTheme.colorScheme.outlineVariant,
      ),
  ) {
    Box(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 12.dp),
      contentAlignment = Alignment.Center,
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.titleMedium,
        color =
          if (selected) MaterialTheme.colorScheme.onPrimary
          else MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
      )
    }
  }
}

@Composable
private fun StatsMetricCard(
  title: String,
  value: String,
  subtitle: String,
  icon: ImageVector,
  accent: Color,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  Surface(
    shape = MaterialTheme.shapes.medium,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    tonalElevation = 1.dp,
    modifier = modifier.semantics(mergeDescendants = true) {}.testTag(testTag),
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = title,
          style = MaterialTheme.typography.labelLarge,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Surface(
          shape = CircleShape,
          color = accent.copy(alpha = 0.14f),
          modifier = Modifier.size(30.dp),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = icon,
              contentDescription = null,
              tint = accent,
              modifier = Modifier.size(16.dp),
            )
          }
        }
      }
      Text(
        text = value,
        style = MaterialTheme.typography.headlineLarge,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
      )
      Text(
        text = subtitle,
        style = MaterialTheme.typography.labelSmall,
        color = accent,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun DhikrRateChartCard(
  uiState: DhikrStatsUiState,
  onSelectPoint: (Int) -> Unit,
) {
  val points = uiState.points
  val maxValue = (points.maxOfOrNull { it.totalCount } ?: 0).coerceAtLeast(4)
  val niceCeil = computeNiceCeiling(maxValue)
  val selectedPoint = uiState.selectedPoint

  val animationProgress by
    animateFloatAsState(
      targetValue = 1f,
      animationSpec = tween(durationMillis = 480, easing = FastOutSlowInEasing),
      label = "chartReveal",
    )

  val primaryColor = MaterialTheme.colorScheme.primary
  val secondaryColor = MaterialTheme.colorScheme.secondary
  val gridColor = MaterialTheme.colorScheme.outlineVariant
  val surfaceColor = MaterialTheme.colorScheme.surface
  val selectedHighlight = MaterialTheme.colorScheme.primaryContainer

  Surface(
    shape = MaterialTheme.shapes.large,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    tonalElevation = 1.dp,
    modifier = Modifier.fillMaxWidth().testTag("stats_rate_chart_card"),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text =
              if (uiState.periodMode == StatsPeriodMode.DAILY) {
                "الرسم البياني اليومي للأذكار"
              } else {
                "الرسم البياني الأسبوعي للأذكار"
              },
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = "إجمالي الفترة: ${uiState.periodTotalCount} • اضغط على أي عمود للتفاصيل",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      // Interactive Selected Point Detail Banner
      if (selectedPoint != null) {
        Surface(
          shape = MaterialTheme.shapes.medium,
          color = MaterialTheme.colorScheme.surfaceContainer,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
          modifier =
            Modifier.fillMaxWidth()
              .semantics(mergeDescendants = true) {}
              .testTag("stats_selected_point_banner"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "${selectedPoint.primaryLabel} (${selectedPoint.secondaryLabel})",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
              )
              val topText =
                selectedPoint.topDhikrLabel?.let { "الأكثر: $it" }
                  ?: "لم يُسجّل ذكر في هذه الفترة"
              Text(
                text = topText,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = "${selectedPoint.totalCount}",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.primary,
              )
              Text(
                text = "صوتي ${selectedPoint.voiceCount} • يومي ${selectedPoint.adhkarCount}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      }

      // Chart Canvas + Y-axis labels + X-axis labels locked to LTR so canvas bars align 1:1
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.Top,
        ) {
          // Y-Axis Ticks
          Column(
            modifier = Modifier.width(34.dp).height(190.dp).padding(vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.End,
          ) {
            Text(
              text = niceCeil.toString(),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
              text = (niceCeil / 2).toString(),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
              text = "0",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          Spacer(modifier = Modifier.width(6.dp))

          Column(modifier = Modifier.weight(1f)) {
            Canvas(
              modifier =
                Modifier.fillMaxWidth()
                  .height(190.dp)
                  .testTag("stats_bar_trend_canvas")
                  .pointerInput(points) {
                    detectTapGestures { offset ->
                      if (points.isNotEmpty() && size.width > 0) {
                        val slotWidth = size.width.toFloat() / points.size.toFloat()
                        val idx = (offset.x / slotWidth).toInt().coerceIn(0, points.lastIndex)
                        onSelectPoint(idx)
                      }
                    }
                  }
            ) {
              if (points.isEmpty()) return@Canvas

              val topPad = 14.dp.toPx()
              val bottomPad = 10.dp.toPx()
              val chartHeight = (size.height - topPad - bottomPad).coerceAtLeast(1f)
              val baselineY = topPad + chartHeight
              val slotWidth = size.width / points.size.toFloat()
              val barWidth = (slotWidth * 0.46f).coerceIn(8.dp.toPx(), 28.dp.toPx())
              val dashEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f), 0f)

              // Horizontal reference grid lines (0%, 50%, 100%)
              listOf(0f, 0.5f, 1f).forEach { ratio ->
                val y = baselineY - chartHeight * ratio
                drawLine(
                  color = gridColor.copy(alpha = if (ratio == 0f) 0.9f else 0.5f),
                  start = Offset(0f, y),
                  end = Offset(size.width, y),
                  strokeWidth = if (ratio == 0f) 1.5.dp.toPx() else 1.dp.toPx(),
                  pathEffect = if (ratio == 0f) null else dashEffect,
                )
              }

              val trendCenters = mutableListOf<Offset>()

              points.forEachIndexed { index, point ->
                val centerX = slotWidth * index + slotWidth / 2f
                val isSelected = index == uiState.selectedPointIndex

                if (isSelected) {
                  drawRoundRect(
                    color = selectedHighlight.copy(alpha = 0.35f),
                    topLeft = Offset(slotWidth * index + slotWidth * 0.1f, topPad - 4.dp.toPx()),
                    size = Size(slotWidth * 0.8f, chartHeight + 8.dp.toPx()),
                    cornerRadius = CornerRadius(10.dp.toPx(), 10.dp.toPx()),
                  )
                }

                val totalRatio =
                  (point.totalCount.toFloat() / niceCeil.toFloat()).coerceIn(0f, 1f) *
                    animationProgress
                val voiceRatio =
                  (point.voiceCount.toFloat() / niceCeil.toFloat()).coerceIn(0f, 1f) *
                    animationProgress
                val totalBarH = chartHeight * totalRatio
                val voiceBarH = chartHeight * voiceRatio
                val adhkarBarH = (totalBarH - voiceBarH).coerceAtLeast(0f)

                val barLeft = centerX - barWidth / 2f
                val totalTopY = baselineY - totalBarH
                val corner = CornerRadius(6.dp.toPx(), 6.dp.toPx())

                if (totalBarH > 1f) {
                  // Total / Adhkar segment (secondary tint)
                  if (adhkarBarH > 0.5f) {
                    drawRoundRect(
                      brush =
                        Brush.verticalGradient(
                          colors = listOf(secondaryColor, secondaryColor.copy(alpha = 0.72f)),
                          startY = totalTopY,
                          endY = totalTopY + adhkarBarH,
                        ),
                      topLeft = Offset(barLeft, totalTopY),
                      size = Size(barWidth, totalBarH),
                      cornerRadius = corner,
                    )
                  }
                  // Voice Dhikr segment (primary gradient) anchored at bottom
                  if (voiceBarH > 0.5f) {
                    val voiceTopY = baselineY - voiceBarH
                    drawRoundRect(
                      brush =
                        Brush.verticalGradient(
                          colors = listOf(primaryColor, primaryColor.copy(alpha = 0.72f)),
                          startY = voiceTopY,
                          endY = baselineY,
                        ),
                      topLeft = Offset(barLeft, voiceTopY),
                      size = Size(barWidth, voiceBarH),
                      cornerRadius = corner,
                    )
                  }
                } else {
                  // Subtle baseline marker for zero days (never fake tall bars)
                  drawRoundRect(
                    color = gridColor.copy(alpha = 0.7f),
                    topLeft = Offset(barLeft, baselineY - 2.5.dp.toPx()),
                    size = Size(barWidth, 2.5.dp.toPx()),
                    cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx()),
                  )
                }

                trendCenters.add(Offset(centerX, totalTopY))
              }

              // Smooth Bezier trend curve + subtle area fill
              if (trendCenters.size >= 2 && uiState.periodTotalCount > 0) {
                val linePath = Path().apply {
                  moveTo(trendCenters.first().x, trendCenters.first().y)
                  for (i in 0 until trendCenters.lastIndex) {
                    val p0 = trendCenters[i]
                    val p1 = trendCenters[i + 1]
                    val midX = (p0.x + p1.x) / 2f
                    cubicTo(midX, p0.y, midX, p1.y, p1.x, p1.y)
                  }
                }
                val areaPath =
                  Path().apply {
                    addPath(linePath)
                    lineTo(trendCenters.last().x, baselineY)
                    lineTo(trendCenters.first().x, baselineY)
                    close()
                  }
                drawPath(
                  path = areaPath,
                  brush =
                    Brush.verticalGradient(
                      colors = listOf(secondaryColor.copy(alpha = 0.22f), Color.Transparent),
                      startY = topPad,
                      endY = baselineY,
                    ),
                )
                drawPath(
                  path = linePath,
                  color = secondaryColor,
                  style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round),
                )
              }

              // Data node dots on the trend line
              trendCenters.forEachIndexed { idx, center ->
                val isSelected = idx == uiState.selectedPointIndex
                val dotRadius = if (isSelected) 5.dp.toPx() else 3.2.dp.toPx()
                if (isSelected) {
                  drawCircle(
                    color = secondaryColor.copy(alpha = 0.28f),
                    radius = 9.dp.toPx(),
                    center = center,
                  )
                }
                drawCircle(
                  color = surfaceColor,
                  radius = dotRadius + 1.4.dp.toPx(),
                  center = center,
                )
                drawCircle(
                  color = if (isSelected) secondaryColor else primaryColor,
                  radius = dotRadius,
                  center = center,
                )
              }
            }

            // Interactive X-Axis Labels aligned 1:1 with canvas slots
            Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp)) {
              points.forEachIndexed { index, point ->
                val isSelected = index == uiState.selectedPointIndex
                val showFullLabel = points.size <= 8 || index % 2 == 0 || isSelected
                Column(
                  modifier =
                    Modifier.weight(1f)
                      .clip(RoundedCornerShape(8.dp))
                      .clickable { onSelectPoint(index) }
                      .padding(vertical = 4.dp)
                      .testTag("stats_point_$index"),
                  horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                  Text(
                    text = if (showFullLabel) point.primaryLabel else "•",
                    style =
                      MaterialTheme.typography.labelSmall.copy(
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                      ),
                    color =
                      if (isSelected) MaterialTheme.colorScheme.primary
                      else MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Clip,
                    textAlign = TextAlign.Center,
                  )
                  if (points.size <= 8 || isSelected) {
                    Text(
                      text = point.secondaryLabel,
                      style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                      color =
                        if (isSelected) MaterialTheme.colorScheme.secondary
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
                      maxLines = 1,
                      overflow = TextOverflow.Clip,
                      textAlign = TextAlign.Center,
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Legend
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        ChartLegendItem(color = primaryColor, label = "الذكر الصوتي")
        ChartLegendItem(color = secondaryColor, label = "الأذكار اليومية ومنحنى المعدل")
      }
    }
  }
}

@Composable
private fun ChartLegendItem(color: Color, label: String) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(color))
    Spacer(modifier = Modifier.width(6.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
  }
}

@Composable
private fun DhikrBreakdownCard(uiState: DhikrStatsUiState) {
  val total = uiState.periodTotalCount.coerceAtLeast(1)
  val voiceShare = (uiState.voiceTotalInPeriod.toFloat() / total.toFloat()).coerceIn(0f, 1f)

  Surface(
    shape = MaterialTheme.shapes.large,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    tonalElevation = 1.dp,
    modifier = Modifier.fillMaxWidth().testTag("stats_breakdown_card"),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Text(
        text = "توزيع الأذكار الأكثر تكراراً",
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onSurface,
      )

      // Voice vs Daily Adhkar Proportion Strip
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = "الذكر الصوتي: ${uiState.voiceTotalInPeriod}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary,
          )
          Text(
            text = "الأذكار اليومية: ${uiState.adhkarTotalInPeriod}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.secondary,
          )
        }
        Row(
          modifier =
            Modifier.fillMaxWidth()
              .height(10.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.85f))
        ) {
          if (voiceShare > 0f) {
            Box(
              modifier =
                Modifier.fillMaxWidth(voiceShare)
                  .fillMaxHeight()
                  .background(MaterialTheme.colorScheme.primary)
            )
          }
        }
      }

      // Per-Dhikr Horizontal Bar Chart
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        uiState.breakdown.forEach { item ->
          DhikrBreakdownRow(item = item)
        }
      }
    }
  }
}

@Composable
private fun DhikrBreakdownRow(item: DhikrBreakdownItem) {
  val animatedFraction by
    animateFloatAsState(
      targetValue = item.shareFraction.coerceIn(0.03f, 1f),
      animationSpec = tween(durationMillis = 450, easing = FastOutSlowInEasing),
      label = "breakdownBar",
    )
  val barColor =
    if (item.sourceType == DhikrSourceType.VOICE) MaterialTheme.colorScheme.primary
    else MaterialTheme.colorScheme.secondary
  val percent = (item.shareFraction * 100f).roundToInt()

  Column(
    modifier = Modifier.fillMaxWidth().testTag("stats_breakdown_row_${item.dhikrId}"),
    verticalArrangement = Arrangement.spacedBy(4.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Text(
          text = item.label,
          fontFamily = AmiriFontFamily,
          fontSize = 19.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Surface(
          shape = RoundedCornerShape(50),
          color = barColor.copy(alpha = 0.14f),
        ) {
          Text(
            text = item.sourceType.labelArabic,
            style = MaterialTheme.typography.labelSmall,
            color = barColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
          )
        }
      }
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "${item.count} ($percent%)",
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurface,
      )
    }

    Box(
      modifier =
        Modifier.fillMaxWidth()
          .height(9.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.surfaceContainerHigh)
    ) {
      Box(
        modifier =
          Modifier.fillMaxWidth(animatedFraction)
            .fillMaxHeight()
            .clip(CircleShape)
            .background(
              Brush.horizontalGradient(
                colors = listOf(barColor, barColor.copy(alpha = 0.72f))
              )
            )
      )
    }
  }
}

private fun formatRate(rate: Float): String {
  if (rate <= 0f) return "0"
  return if (rate >= 10f || rate % 1f == 0f) {
    rate.roundToInt().toString()
  } else {
    String.format(Locale.US, "%.1f", rate)
  }
}

private fun computeNiceCeiling(rawMax: Int): Int {
  val safe = rawMax.coerceAtLeast(4)
  return when {
    safe <= 10 -> ((safe + 1) / 2) * 2
    safe <= 50 -> ((safe + 9) / 10) * 10
    safe <= 200 -> ((safe + 24) / 25) * 25
    else -> ((safe + 49) / 50) * 50
  }
}
