package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioPlaybackState
import com.example.audio.QuranAudioPlayer
import com.example.data.firebase.FirebaseQuranBackendRepository
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.QuranCatalog
import com.example.data.model.ReciterOption
import com.example.data.model.SurahInfo
import com.example.data.repository.QuranRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class AudioLibraryViewModel(
  private val quranRepository: QuranRepository,
  private val preferencesRepository: UserPreferencesRepository,
  private val audioPlayer: QuranAudioPlayer,
  private val backendRepository: FirebaseQuranBackendRepository,
) : ViewModel() {

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _downloadProgressMap = MutableStateFlow<Map<Int, Float>>(emptyMap())
  val downloadProgressMap: StateFlow<Map<Int, Float>> = _downloadProgressMap.asStateFlow()

  private val _message = MutableStateFlow<String?>(null)
  val message: StateFlow<String?> = _message.asStateFlow()

  val reciters: StateFlow<List<ReciterOption>> =
    combine(
        backendRepository.observePublishedReciters(),
        quranRepository.localRecitersFlow,
      ) { cloudReciters, localReciters ->
        val merged = RecitersViewModel.mergePublishedAndCatalogReciters(cloudReciters, localReciters)
        audioPlayer.updateKnownReciters(merged)
        merged
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = QuranCatalog.reciters,
      )

  val selectedReciterId: StateFlow<String> =
    preferencesRepository.readerSettingsFlow
      .map { it.reciterIdentifier }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "ar.alafasy",
      )

  val volumeLevel: StateFlow<Float> =
    preferencesRepository.readerSettingsFlow
      .map { it.volumeLevel }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 1.0f,
      )

  val filteredSurahs: StateFlow<List<SurahInfo>> =
    combine(quranRepository.surahsFlow, _searchQuery) { surahs, query ->
        val q = query.trim()
        if (q.isEmpty()) surahs
        else {
          surahs.filter {
            it.arabicName.contains(q) ||
              it.englishName.contains(q, ignoreCase = true) ||
              it.number.toString() == q
          }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  val downloadedSurahs: StateFlow<Set<Int>> =
    selectedReciterId
      .flatMapLatest { reciter -> quranRepository.downloadedSurahsFlow(reciter) }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptySet(),
      )

  val audioState: StateFlow<AudioPlaybackState> = audioPlayer.state

  init {
    viewModelScope.launch { quranRepository.ensureInitialDataSeeded() }
  }

  fun onSearchQueryChange(query: String) {
    _searchQuery.value = query
  }

  fun selectReciter(reciterId: String) {
    viewModelScope.launch {
      preferencesRepository.updateReciter(reciterId)
      audioPlayer.updateReciterIfPlaying(reciterId)
    }
  }

  fun playSurah(surah: SurahInfo) {
    val current = audioPlayer.state.value
    val activeReciterId = selectedReciterId.value
    if (
      current.isActive &&
        current.surahNumber == surah.number &&
        current.reciterId == activeReciterId
    ) {
      audioPlayer.togglePlayPause()
    } else {
      val displayName = reciters.value.firstOrNull { it.identifier == activeReciterId }?.arabicName
      audioPlayer.playFullSurah(surah, activeReciterId, displayName)
    }
  }

  fun togglePlayPause() = audioPlayer.togglePlayPause()

  fun seekTo(ms: Int) = audioPlayer.seekTo(ms)

  fun seekBySeconds(sec: Int) = audioPlayer.seekBySeconds(sec)

  fun stopPlayback() = audioPlayer.stop()

  fun setVolume(volume: Float) {
    audioPlayer.setVolume(volume)
    viewModelScope.launch { preferencesRepository.updateVolumeLevel(volume) }
  }

  fun downloadSurah(surah: SurahInfo) {
    val reciter = selectedReciterId.value
    if (_downloadProgressMap.value.containsKey(surah.number)) return
    viewModelScope.launch {
      _downloadProgressMap.update { it + (surah.number to 0.01f) }
      val result =
        quranRepository.downloadSurahAudio(reciter, surah.number) { progress ->
          _downloadProgressMap.update { it + (surah.number to progress) }
        }
      _downloadProgressMap.update { it - surah.number }
      result.onSuccess {
        _message.value = "تم تحميل ${surah.arabicName} للاستماع دون إنترنت"
      }.onFailure {
        _message.value = "تعذر التحميل: ${it.localizedMessage ?: "تحقق من الإنترنت"}"
      }
    }
  }

  fun deleteDownload(surahNumber: Int) {
    val reciter = selectedReciterId.value
    viewModelScope.launch {
      quranRepository.deleteDownloadedSurah(reciter, surahNumber)
      _message.value = "تم حذف الملف المحفوظ"
    }
  }

  fun clearMessage() {
    _message.value = null
  }

  companion object {
    fun factory(
      quranRepository: QuranRepository,
      preferencesRepository: UserPreferencesRepository,
      audioPlayer: QuranAudioPlayer,
      backendRepository: FirebaseQuranBackendRepository,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return AudioLibraryViewModel(
            quranRepository = quranRepository,
            preferencesRepository = preferencesRepository,
            audioPlayer = audioPlayer,
            backendRepository = backendRepository,
          ) as T
        }
      }
  }
}
