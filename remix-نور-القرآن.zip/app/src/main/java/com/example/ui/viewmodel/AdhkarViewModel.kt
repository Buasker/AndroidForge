package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AdhkarSeedData
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.AdhkarCategory
import com.example.data.model.AdhkarItem
import com.example.data.repository.QuranRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AdhkarViewModel(
  initialCategory: AdhkarCategory,
  private val quranRepository: QuranRepository,
  private val preferencesRepository: UserPreferencesRepository,
) : ViewModel() {

  private val _selectedCategory = MutableStateFlow(initialCategory)
  val selectedCategory: StateFlow<AdhkarCategory> = _selectedCategory.asStateFlow()

  val adhkarFontSize: StateFlow<Float> =
    preferencesRepository.readerSettingsFlow
      .map { it.adhkarFontSize }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 20f,
      )

  val itemsForCategory: StateFlow<List<AdhkarItem>> =
    combine(_selectedCategory, quranRepository.adhkarProgressFlow) { category, progressMap ->
        AdhkarSeedData.allAdhkar
          .filter { it.category == category }
          .map { item -> item.copy(currentCount = progressMap[item.id] ?: 0) }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  fun selectCategory(category: AdhkarCategory) {
    _selectedCategory.value = category
  }

  fun incrementItem(item: AdhkarItem) {
    viewModelScope.launch {
      quranRepository.incrementAdhkar(item.id, item.currentCount, item.targetCount)
    }
  }

  fun resetItem(item: AdhkarItem) {
    viewModelScope.launch { quranRepository.resetAdhkarItem(item.id) }
  }

  fun resetAllAdhkar() {
    viewModelScope.launch { quranRepository.resetAllAdhkar() }
  }

  fun updateFontSize(newSize: Float) {
    viewModelScope.launch { preferencesRepository.updateAdhkarFontSize(newSize) }
  }

  companion object {
    fun factory(
      initialCategory: AdhkarCategory,
      quranRepository: QuranRepository,
      preferencesRepository: UserPreferencesRepository,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return AdhkarViewModel(initialCategory, quranRepository, preferencesRepository) as T
        }
      }
  }
}
