package com.example.ui.components

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.CameraAlt
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import com.example.audio.AudioPlaybackMode
import com.example.audio.AudioPlaybackState
import com.example.data.model.QuranCatalog
import com.example.data.model.SocialAccount
import com.example.data.model.SurahInfo
import com.example.ui.theme.AmiriFontFamily

@Composable
fun OctagonalBadge(
  number: Int,
  modifier: Modifier = Modifier,
  size: Dp = 40.dp,
  strokeColor: Color = MaterialTheme.colorScheme.secondary,
  fillColor: Color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f),
  textColor: Color = MaterialTheme.colorScheme.onSurface,
) {
  Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val side = this.size.minDimension * 0.68f
      val topLeft = Offset((this.size.width - side) / 2f, (this.size.height - side) / 2f)
      val squareSize = Size(side, side)
      val stroke = Stroke(width = 1.6.dp.toPx())

      drawRect(color = fillColor, topLeft = topLeft, size = squareSize)
      drawRect(color = strokeColor, topLeft = topLeft, size = squareSize, style = stroke)

      rotate(degrees = 45f) {
        drawRect(color = fillColor, topLeft = topLeft, size = squareSize)
        drawRect(color = strokeColor, topLeft = topLeft, size = squareSize, style = stroke)
      }
    }
    Text(
      text = number.toString(),
      style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
      color = textColor,
      maxLines = 1,
    )
  }
}

@Composable
fun ReciterAvatar(
  photoUrl: String,
  contentDescription: String,
  size: Dp = 52.dp,
  modifier: Modifier = Modifier,
) {
  val cleanUrl = photoUrl.trim()
  val localFile =
    if (cleanUrl.startsWith("/")) {
      java.io.File(cleanUrl).takeIf { it.exists() }
    } else null
  val imageModel: Any? =
    when {
      cleanUrl.startsWith("https://") -> cleanUrl
      localFile != null -> localFile
      else -> null
    }
  Surface(
    modifier = modifier.size(size),
    shape = CircleShape,
    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
  ) {
    if (imageModel != null) {
      SubcomposeAsyncImage(
        model = imageModel,
        contentDescription = contentDescription,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize().clip(CircleShape),
        loading = {
          Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Icon(
              imageVector = Icons.Rounded.RecordVoiceOver,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(size * 0.48f),
            )
          }
        },
        error = {
          Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
            Icon(
              imageVector = Icons.Rounded.RecordVoiceOver,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(size * 0.48f),
            )
          }
        },
      )
    } else {
      Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
        Icon(
          imageVector = Icons.Rounded.RecordVoiceOver,
          contentDescription = contentDescription,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(size * 0.48f),
        )
      }
    }
  }
}

@Composable
fun SurahRowCard(
  surah: SurahInfo,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier =
      modifier
        .fillMaxWidth()
        .testTag("surah_card_${surah.number}")
        .clickable(onClick = onClick),
    shape = MaterialTheme.shapes.medium,
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 1.dp,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      OctagonalBadge(number = surah.number, size = 42.dp)
      Spacer(modifier = Modifier.width(14.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = surah.arabicName,
          fontFamily = AmiriFontFamily,
          fontSize = 22.sp,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = "${surah.revelationArabic} • ${surah.numberOfAyahs} آية • ${surah.englishName}",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
      Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
      ) {
        Text(
          text = surah.revelationArabic,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
        )
      }
    }
  }
}

@Composable
fun MiniAudioPlayerBar(
  audioState: AudioPlaybackState,
  onTogglePlayPause: () -> Unit,
  onPrevious: () -> Unit,
  onNext: () -> Unit,
  onStop: () -> Unit,
  onOpenTarget: () -> Unit,
  modifier: Modifier = Modifier,
) {
  AnimatedVisibility(
    visible = audioState.isActive,
    enter = slideInVertically { it } + fadeIn(),
    exit = slideOutVertically { it } + fadeOut(),
    modifier = modifier,
  ) {
    Surface(
      modifier =
        Modifier.fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 6.dp)
          .testTag("mini_audio_player"),
      shape = RoundedCornerShape(20.dp),
      color = MaterialTheme.colorScheme.primary,
      contentColor = MaterialTheme.colorScheme.onPrimary,
      shadowElevation = 6.dp,
    ) {
      Column {
        Row(
          modifier =
            Modifier.fillMaxWidth()
              .clickable(onClick = onOpenTarget)
              .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.16f),
            modifier = Modifier.size(38.dp),
          ) {
            Box(contentAlignment = Alignment.Center) {
              if (audioState.isBuffering) {
                CircularProgressIndicator(
                  modifier = Modifier.size(20.dp),
                  strokeWidth = 2.dp,
                  color = MaterialTheme.colorScheme.onPrimary,
                )
              } else {
                Icon(
                  imageVector = Icons.Rounded.GraphicEq,
                  contentDescription = "تشغيل الصوت",
                  tint = MaterialTheme.colorScheme.onPrimary,
                  modifier = Modifier.size(20.dp),
                )
              }
            }
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            val title =
              if (audioState.mode == AudioPlaybackMode.AYAH_BY_AYAH && audioState.currentAyahInSurah > 0) {
                "${audioState.surahArabicName} • آية ${audioState.currentAyahInSurah}"
              } else {
                audioState.surahArabicName
              }
            Text(
              text = title,
              style = MaterialTheme.typography.labelLarge,
              color = MaterialTheme.colorScheme.onPrimary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            val subtitle =
              when {
                audioState.errorMessage != null -> audioState.errorMessage
                audioState.trackDescription.isNotBlank() ->
                  "${audioState.reciterName} • ${audioState.trackDescription}"
                else -> audioState.reciterName
              }
            Text(
              text = subtitle,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = onPrevious,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("audio_prev_button"),
            ) {
              Icon(
                imageVector =
                  if (audioState.mode == AudioPlaybackMode.FULL_SURAH) Icons.Rounded.Replay10
                  else Icons.Rounded.SkipPrevious,
                contentDescription = "السابق",
                tint = MaterialTheme.colorScheme.onPrimary,
              )
            }
            IconButton(
              onClick = onTogglePlayPause,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("audio_play_pause_button"),
            ) {
              Icon(
                imageVector = if (audioState.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                contentDescription = if (audioState.isPlaying) "إيقاف مؤقت" else "تشغيل",
                tint = MaterialTheme.colorScheme.onPrimary,
              )
            }
            IconButton(
              onClick = onNext,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("audio_next_button"),
            ) {
              Icon(
                imageVector =
                  if (audioState.mode == AudioPlaybackMode.FULL_SURAH) Icons.Rounded.Forward10
                  else Icons.Rounded.SkipNext,
                contentDescription = "التالي",
                tint = MaterialTheme.colorScheme.onPrimary,
              )
            }
            IconButton(
              onClick = onStop,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("audio_stop_button"),
            ) {
              Icon(
                imageVector = Icons.Rounded.Close,
                contentDescription = "إيقاف التلاوة",
                tint = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f),
              )
            }
          }
        }
        if (audioState.durationMs > 0) {
          val fraction =
            (audioState.positionMs.toFloat() / audioState.durationMs.toFloat()).coerceIn(0f, 1f)
          LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier.fillMaxWidth().height(3.dp),
            color = Color(0xFFF6D98D),
            trackColor = Color.White.copy(alpha = 0.2f),
          )
        }
      }
    }
  }
}

@Composable
fun SocialAccountsSection(
  title: String = "تواصل معي",
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Text(
      text = title,
      style = MaterialTheme.typography.titleLarge,
      color = MaterialTheme.colorScheme.onBackground,
    )
    QuranCatalog.socialAccounts.forEach { account ->
      SocialAccountCard(
        account = account,
        onClick = { openSocialAccount(context, account) },
      )
    }
  }
}

@Composable
private fun SocialAccountCard(
  account: SocialAccount,
  onClick: () -> Unit,
) {
  val (icon, badgeColor, tintColor) =
    when (account.platformName) {
      "سناب شات" -> Triple(Icons.Rounded.CameraAlt, Color(0xFFFFFC00), Color(0xFF1B1B1B))
      "إنستغرام" -> Triple(Icons.Rounded.PhotoCamera, Color(0xFFE1306C), Color.White)
      else -> Triple(Icons.Rounded.MusicNote, Color(0xFF111111), Color.White)
    }

  Surface(
    modifier =
      Modifier.fillMaxWidth()
        .testTag("social_${account.handle}")
        .clickable(onClick = onClick),
    shape = MaterialTheme.shapes.medium,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Surface(shape = CircleShape, color = badgeColor, modifier = Modifier.size(44.dp)) {
        Box(contentAlignment = Alignment.Center) {
          Icon(imageVector = icon, contentDescription = account.platformName, tint = tintColor)
        }
      }
      Spacer(modifier = Modifier.width(14.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = account.platformName,
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = account.handle,
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.primary,
        )
      }
      Icon(
        imageVector = Icons.AutoMirrored.Rounded.OpenInNew,
        contentDescription = "فتح الحساب",
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

fun openSocialAccount(context: Context, account: SocialAccount) {
  val uri = Uri.parse(account.url)
  val appIntent =
    Intent(Intent.ACTION_VIEW, uri).apply {
      setPackage(account.packageName)
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
  val browserIntent =
    Intent(Intent.ACTION_VIEW, uri).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

  runCatching { context.startActivity(appIntent) }
    .onFailure { runCatching { context.startActivity(browserIntent) } }
}
