package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.SurahInfo
import com.example.data.repository.QuranRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class RevelationFilter(val label: String) {
  ALL("الكل (١١٤)"),
  MECCAN("مكية"),
  MEDINAN("مدنية"),
}

enum class BrowseTab(val label: String) {
  SURAHS("السور"),
  JUZ("الأجزاء"),
  PAGES("الصفحات"),
}

class SurahListViewModel(
  private val quranRepository: QuranRepository,
) : ViewModel() {

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _revelationFilter = MutableStateFlow(RevelationFilter.ALL)
  val revelationFilter: StateFlow<RevelationFilter> = _revelationFilter.asStateFlow()

  private val _browseTab = MutableStateFlow(BrowseTab.SURAHS)
  val browseTab: StateFlow<BrowseTab> = _browseTab.asStateFlow()

  val filteredSurahs: StateFlow<List<SurahInfo>> =
    combine(quranRepository.surahsFlow, _searchQuery, _revelationFilter) { surahs, query, filter ->
        val q = query.trim().lowercase()
        surahs.filter { surah ->
          val matchesType =
            when (filter) {
              RevelationFilter.ALL -> true
              RevelationFilter.MECCAN -> surah.revelationType.equals("Meccan", ignoreCase = true)
              RevelationFilter.MEDINAN -> surah.revelationType.equals("Medinan", ignoreCase = true)
            }
          val matchesQuery =
            q.isEmpty() ||
              surah.arabicName.contains(query.trim()) ||
              surah.englishName.lowercase().contains(q) ||
              surah.englishNameTranslation.lowercase().contains(q) ||
              surah.number.toString() == q
          matchesType && matchesQuery
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  init {
    viewModelScope.launch { quranRepository.ensureInitialDataSeeded() }
  }

  fun onSearchQueryChange(query: String) {
    _searchQuery.value = query
  }

  fun onRevelationFilterChange(filter: RevelationFilter) {
    _revelationFilter.value = filter
  }

  fun onBrowseTabChange(tab: BrowseTab) {
    _browseTab.value = tab
  }

  companion object {
    fun factory(quranRepository: QuranRepository): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return SurahListViewModel(quranRepository) as T
        }
      }
  }
}
