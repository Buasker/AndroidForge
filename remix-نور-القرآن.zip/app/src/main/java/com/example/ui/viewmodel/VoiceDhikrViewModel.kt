package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.AdhkarSeedData
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.DhikrPhraseItem
import com.example.data.repository.QuranRepository
import com.example.dhikr.VoiceDhikrController
import com.example.dhikr.VoiceDhikrStatus
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VoiceDhikrViewModel(
  private val quranRepository: QuranRepository,
  preferencesRepository: UserPreferencesRepository,
  private val controller: VoiceDhikrController,
) : ViewModel() {

  val status: StateFlow<VoiceDhikrStatus> = controller.status

  val counters: StateFlow<List<DhikrPhraseItem>> =
    quranRepository.dhikrCountersFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue =
        AdhkarSeedData.initialVoiceDhikrCounters.map {
          DhikrPhraseItem(it.id, it.arabicTitle, it.subtitle, it.count, it.lastUpdated)
        },
    )

  init {
    viewModelScope.launch { quranRepository.ensureInitialDataSeeded() }
    viewModelScope.launch {
      preferencesRepository.readerSettingsFlow
        .map { it.voiceDhikrAllowPartialMatch }
        .collect { allow -> controller.allowPartialMatch = allow }
    }
  }

  fun startListening() {
    controller.startListening()
  }

  fun pauseListening() {
    controller.pauseListening()
  }

  fun onPermissionDenied() {
    controller.onPermissionDenied()
  }

  fun resetSingleCounter(id: String) {
    viewModelScope.launch { quranRepository.resetDhikr(id) }
  }

  fun resetAllCounters() {
    viewModelScope.launch { quranRepository.resetAllDhikr() }
  }

  companion object {
    fun factory(
      quranRepository: QuranRepository,
      preferencesRepository: UserPreferencesRepository,
      controller: VoiceDhikrController,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return VoiceDhikrViewModel(quranRepository, preferencesRepository, controller) as T
        }
      }
  }
}
