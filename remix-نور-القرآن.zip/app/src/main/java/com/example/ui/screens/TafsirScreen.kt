package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.ArrowDropDown
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuranCatalog
import com.example.data.model.SurahInfo
import com.example.ui.components.OctagonalBadge
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.viewmodel.TafsirUiState

@Composable
fun TafsirScreen(
  surahs: List<SurahInfo>,
  selectedSurahNumber: Int,
  selectedAyahFilter: Int?,
  tafsirEditionId: String,
  tafsirFontSize: Float,
  searchQuery: String,
  uiState: TafsirUiState,
  onSelectSurah: (Int) -> Unit,
  onSelectAyah: (Int?) -> Unit,
  onSelectEdition: (String) -> Unit,
  onFontSizeChange: (Float) -> Unit,
  onSearchQueryChange: (String) -> Unit,
  onRetry: () -> Unit,
  onOpenInMushaf: (surahNumber: Int, ayahNumber: Int) -> Unit,
  modifier: Modifier = Modifier,
) {
  var showSurahPicker by remember { mutableStateOf(false) }
  var showAyahPicker by remember { mutableStateOf(false) }
  val context = LocalContext.current

  val currentSurah = surahs.firstOrNull { it.number == selectedSurahNumber }
  val currentEditionMeta =
    QuranCatalog.tafsirEditions.firstOrNull { it.identifier == tafsirEditionId }
      ?: QuranCatalog.tafsirEditions.first()

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(modifier = Modifier.fillMaxSize().widthIn(max = 720.dp)) {
      Column(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "تفسير القرآن الكريم",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = { onFontSizeChange(tafsirFontSize + 2f) },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("tafsir_zoom_in"),
            ) {
              Icon(Icons.Rounded.ZoomIn, contentDescription = "تكبير خط التفسير")
            }
            IconButton(
              onClick = { onFontSizeChange(tafsirFontSize - 2f) },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("tafsir_zoom_out"),
            ) {
              Icon(Icons.Rounded.ZoomOut, contentDescription = "تصغير خط التفسير")
            }
          }
        }

        // Source attribution banner
        Surface(
          shape = MaterialTheme.shapes.small,
          color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(
              text = "الكتاب: ${currentEditionMeta.arabicName}",
              style = MaterialTheme.typography.labelLarge,
              color = MaterialTheme.colorScheme.onSecondaryContainer,
            )
            Text(
              text = "المصدر: ${currentEditionMeta.sourceAttribution}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }

        // Tafsir Edition Switcher
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(QuranCatalog.tafsirEditions) { edition ->
            FilterChip(
              selected = tafsirEditionId == edition.identifier,
              onClick = { onSelectEdition(edition.identifier) },
              label = { Text(edition.arabicName) },
              modifier = Modifier.testTag("tafsir_edition_${edition.identifier}"),
            )
          }
        }

        // Surah + Ayah Pickers
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OutlinedButton(
            onClick = { showSurahPicker = true },
            modifier = Modifier.weight(1.4f).testTag("tafsir_surah_picker"),
          ) {
            Text(
              text = currentSurah?.arabicName ?: "سورة $selectedSurahNumber",
              maxLines = 1,
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(Icons.Rounded.ArrowDropDown, contentDescription = null)
          }
          OutlinedButton(
            onClick = { showAyahPicker = true },
            modifier = Modifier.weight(1f).testTag("tafsir_ayah_picker"),
          ) {
            Text(
              text = if (selectedAyahFilter == null) "كل السورة" else "آية $selectedAyahFilter",
              maxLines = 1,
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(Icons.Rounded.ArrowDropDown, contentDescription = null)
          }
        }

        // Search inside Tafsir
        OutlinedTextField(
          value = searchQuery,
          onValueChange = onSearchQueryChange,
          placeholder = { Text("ابحث في التفسير عن كلمة أو موضوع…") },
          leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { onSearchQueryChange("") }) {
                Icon(Icons.Rounded.Clear, contentDescription = "مسح")
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedContainerColor = MaterialTheme.colorScheme.surface,
              unfocusedContainerColor = MaterialTheme.colorScheme.surface,
            ),
          modifier = Modifier.fillMaxWidth().testTag("tafsir_search_input"),
        )
      }

      when (uiState) {
        is TafsirUiState.Loading -> {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
          }
        }

        is TafsirUiState.Error -> {
          Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Text(uiState.message, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(14.dp))
            Button(onClick = onRetry) { Text("إعادة المحاولة") }
          }
        }

        is TafsirUiState.Success -> {
          if (uiState.items.isEmpty()) {
            Box(
              modifier = Modifier.fillMaxSize().padding(32.dp),
              contentAlignment = Alignment.Center,
            ) {
              Text(
                text = "لا توجد نتائج مطابقة داخل تفسير هذه السورة",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          } else {
            LazyColumn(
              modifier = Modifier.fillMaxSize(),
              contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 96.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              items(uiState.items, key = { "${it.surahNumber}_${it.ayahNumberInSurah}" }) { item ->
                Surface(
                  modifier = Modifier.fillMaxWidth().testTag("tafsir_card_${item.ayahNumberInSurah}"),
                  shape = MaterialTheme.shapes.medium,
                  color = MaterialTheme.colorScheme.surface,
                  border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                ) {
                  Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      Row(verticalAlignment = Alignment.CenterVertically) {
                        OctagonalBadge(number = item.ayahNumberInSurah, size = 34.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                          text = "${item.surahArabicName} • الآية ${item.ayahNumberInSurah}",
                          style = MaterialTheme.typography.titleMedium,
                          color = MaterialTheme.colorScheme.primary,
                        )
                      }
                      Row {
                        IconButton(
                          onClick = { onOpenInMushaf(item.surahNumber, item.ayahNumberInSurah) },
                          modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                          Icon(
                            imageVector = Icons.AutoMirrored.Rounded.MenuBook,
                            contentDescription = "الانتقال للآية في المصحف",
                            tint = MaterialTheme.colorScheme.primary,
                          )
                        }
                        IconButton(
                          onClick = {
                            val shareText =
                              "${item.quranArabicText} ﴿${item.ayahNumberInSurah}﴾\n\n" +
                                "${item.editionName}:\n${item.tafsirText}\n" +
                                "(المصدر: ${item.sourceAttribution}) — تطبيق نور القرآن"
                            val intent =
                              Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, shareText)
                              }
                            context.startActivity(Intent.createChooser(intent, "مشاركة التفسير"))
                          },
                          modifier = Modifier.minimumInteractiveComponentSize(),
                        ) {
                          Icon(
                            imageVector = Icons.Rounded.Share,
                            contentDescription = "مشاركة التفسير",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                          )
                        }
                      }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                      text = item.quranArabicText,
                      fontFamily = AmiriFontFamily,
                      fontSize = 22.sp,
                      lineHeight = 40.sp,
                      color = MaterialTheme.colorScheme.onSurface,
                      modifier = Modifier.fillMaxWidth(),
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                      text = item.tafsirText,
                      style =
                        MaterialTheme.typography.bodyLarge.copy(
                          fontSize = tafsirFontSize.sp,
                          lineHeight = (tafsirFontSize * 1.65f).sp,
                        ),
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically,
                    ) {
                      Text(
                        text = item.editionName,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.secondary,
                      )
                      TextButton(
                        onClick = { onOpenInMushaf(item.surahNumber, item.ayahNumberInSurah) },
                      ) {
                        Text("الانتقال إلى الآية في المصحف ←")
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showSurahPicker) {
    AlertDialog(
      onDismissRequest = { showSurahPicker = false },
      title = { Text("اختر السورة") },
      text = {
        LazyColumn(modifier = Modifier.height(360.dp)) {
          items(surahs, key = { it.number }) { surah ->
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .clickable {
                    onSelectSurah(surah.number)
                    showSurahPicker = false
                  }
                  .padding(vertical = 10.dp, horizontal = 8.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text("${surah.number}. ${surah.arabicName}", fontWeight = FontWeight.Medium)
              Text(
                "${surah.numberOfAyahs} آية",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showSurahPicker = false }) { Text("إغلاق") }
      },
    )
  }

  if (showAyahPicker) {
    val total = currentSurah?.numberOfAyahs ?: 7
    AlertDialog(
      onDismissRequest = { showAyahPicker = false },
      title = { Text("اختر الآية") },
      text = {
        LazyColumn(modifier = Modifier.height(320.dp)) {
          item {
            Text(
              text = "عرض تفسير السورة كاملة",
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.primary,
              modifier =
                Modifier.fillMaxWidth()
                  .clickable {
                    onSelectAyah(null)
                    showAyahPicker = false
                  }
                  .padding(vertical = 12.dp, horizontal = 8.dp),
            )
          }
          items((1..total).toList()) { num ->
            Text(
              text = "الآية رقم $num",
              modifier =
                Modifier.fillMaxWidth()
                  .clickable {
                    onSelectAyah(num)
                    showAyahPicker = false
                  }
                  .padding(vertical = 10.dp, horizontal = 8.dp),
            )
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showAyahPicker = false }) { Text("إغلاق") }
      },
    )
  }
}
