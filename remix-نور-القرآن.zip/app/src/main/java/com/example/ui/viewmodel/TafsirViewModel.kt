package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.SurahInfo
import com.example.data.model.TafsirAyahItem
import com.example.data.repository.QuranRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface TafsirUiState {
  data object Loading : TafsirUiState

  data class Success(val items: List<TafsirAyahItem>) : TafsirUiState

  data class Error(val message: String) : TafsirUiState
}

class TafsirViewModel(
  initialSurah: Int,
  initialAyah: Int,
  private val quranRepository: QuranRepository,
  private val preferencesRepository: UserPreferencesRepository,
) : ViewModel() {

  private val _selectedSurahNumber = MutableStateFlow(initialSurah.coerceIn(1, 114))
  val selectedSurahNumber: StateFlow<Int> = _selectedSurahNumber.asStateFlow()

  private val _selectedAyahFilter = MutableStateFlow<Int?>(if (initialAyah > 0) initialAyah else null)
  val selectedAyahFilter: StateFlow<Int?> = _selectedAyahFilter.asStateFlow()

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _rawItems = MutableStateFlow<TafsirUiState>(TafsirUiState.Loading)

  val surahs: StateFlow<List<SurahInfo>> =
    quranRepository.surahsFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList(),
    )

  val tafsirEditionId: StateFlow<String> =
    preferencesRepository.readerSettingsFlow
      .map { it.tafsirEdition }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "ar.muyassar",
      )

  val tafsirFontSize: StateFlow<Float> =
    preferencesRepository.readerSettingsFlow
      .map { it.tafsirFontSize }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 18f,
      )

  val uiState: StateFlow<TafsirUiState> =
    combine(_rawItems, _selectedAyahFilter, _searchQuery) { state, ayahFilter, query ->
        if (state !is TafsirUiState.Success) return@combine state
        val q = query.trim()
        val filtered =
          state.items.filter { item ->
            val matchesAyah = ayahFilter == null || item.ayahNumberInSurah == ayahFilter
            val matchesQuery =
              q.isEmpty() ||
                item.tafsirText.contains(q) ||
                item.quranArabicText.contains(q) ||
                item.ayahNumberInSurah.toString() == q
            matchesAyah && matchesQuery
          }
        TafsirUiState.Success(filtered)
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = TafsirUiState.Loading,
      )

  private var currentEdition = "ar.muyassar"

  init {
    viewModelScope.launch {
      quranRepository.ensureInitialDataSeeded()
      preferencesRepository.readerSettingsFlow
        .map { it.tafsirEdition }
        .distinctUntilChanged()
        .collect { edition ->
          currentEdition = edition
          loadSurahTafsir(_selectedSurahNumber.value, edition)
        }
    }
  }

  fun selectSurah(surahNumber: Int) {
    _selectedSurahNumber.value = surahNumber
    _selectedAyahFilter.value = null
    viewModelScope.launch { loadSurahTafsir(surahNumber, currentEdition) }
  }

  fun selectAyahFilter(ayahNumber: Int?) {
    _selectedAyahFilter.value = ayahNumber
  }

  fun onSearchQueryChange(query: String) {
    _searchQuery.value = query
  }

  fun selectEdition(editionId: String) {
    viewModelScope.launch { preferencesRepository.updateTafsirEdition(editionId) }
  }

  fun updateTafsirFontSize(newSize: Float) {
    viewModelScope.launch { preferencesRepository.updateTafsirFontSize(newSize) }
  }

  fun retry() {
    viewModelScope.launch { loadSurahTafsir(_selectedSurahNumber.value, currentEdition) }
  }

  private suspend fun loadSurahTafsir(surahNumber: Int, editionId: String) {
    _rawItems.value = TafsirUiState.Loading
    val result = quranRepository.loadSurahTafsir(surahNumber, editionId)
    _rawItems.value =
      result.fold(
        onSuccess = { list -> TafsirUiState.Success(list) },
        onFailure = { err ->
          TafsirUiState.Error(
            err.localizedMessage ?: "تعذر تحميل التفسير. يرجى التحقق من الاتصال بالإنترنت."
          )
        },
      )
  }

  companion object {
    fun factory(
      initialSurah: Int,
      initialAyah: Int,
      quranRepository: QuranRepository,
      preferencesRepository: UserPreferencesRepository,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return TafsirViewModel(initialSurah, initialAyah, quranRepository, preferencesRepository)
            as T
        }
      }
  }
}
