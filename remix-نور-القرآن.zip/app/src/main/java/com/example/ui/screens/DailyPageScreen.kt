package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.ReaderSettings
import com.example.share.DailyPagePosterGenerator
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.viewmodel.DailyPageUiState
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DailyPageScreen(
  uiState: DailyPageUiState,
  settings: ReaderSettings,
  onPreviousPage: () -> Unit,
  onNextPage: () -> Unit,
  onRetry: () -> Unit,
  onUpdateSchedule: (hour: Int, minute: Int, enabled: Boolean) -> Unit,
  onOpenInMushaf: (pageNumber: Int) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }
  var showTimePicker by remember { mutableStateOf(false) }
  var isBusy by remember { mutableStateOf(false) }

  val notificationPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      if (granted) {
        onUpdateSchedule(settings.dailyPageHour, settings.dailyPageMinute, true)
      } else {
        scope.launch {
          snackbarHostState.showSnackbar("يرجى السماح بالإشعارات لتفعيل تذكير الصفحة اليومية")
        }
      }
    }

  fun toggleDailyReminder(enabled: Boolean) {
    if (!enabled) {
      onUpdateSchedule(settings.dailyPageHour, settings.dailyPageMinute, false)
      return
    }
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val granted =
        ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
          PackageManager.PERMISSION_GRANTED
      if (!granted) {
        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        return
      }
    }
    onUpdateSchedule(settings.dailyPageHour, settings.dailyPageMinute, true)
  }

  fun exportPoster(targetPackage: String?, saveOnly: Boolean) {
    val ready = uiState as? DailyPageUiState.Ready ?: return
    if (isBusy) return
    isBusy = true
    scope.launch {
      val bitmap =
        withContext(Dispatchers.Default) {
          DailyPagePosterGenerator.generatePosterBitmap(
            context = context,
            pageNumber = ready.pageNumber,
            surahNames = ready.surahNames,
            ayahs = ready.ayahs,
          )
        }
      if (saveOnly) {
        val result =
          withContext(Dispatchers.IO) {
            DailyPagePosterGenerator.saveBitmapToGallery(context, bitmap, ready.pageNumber)
          }
        result.onSuccess {
          snackbarHostState.showSnackbar("تم حفظ صفحة ${ready.pageNumber} في معرض الصور")
        }.onFailure {
          snackbarHostState.showSnackbar("تعذر حفظ الصورة: ${it.localizedMessage ?: ""}")
        }
      } else {
        val result = DailyPagePosterGenerator.sharePoster(context, bitmap, ready.pageNumber, targetPackage)
        result.onFailure {
          snackbarHostState.showSnackbar("تعذر فتح تطبيق المشاركة")
        }
      }
      isBusy = false
    }
  }

  Scaffold(
    snackbarHost = { SnackbarHost(snackbarHostState) },
    contentWindowInsets = WindowInsets(0.dp),
    modifier = modifier.fillMaxSize(),
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(
        modifier =
          Modifier.fillMaxSize()
            .widthIn(max = 720.dp)
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        Text(
          text = "صفحة القرآن اليومية",
          style = MaterialTheme.typography.headlineLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
          text = "جهّز صفحة اليوم بتصميم إسلامي أنيق، واحفظها كصورة أو شاركها بضغطة زر",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        // Daily Reminder Card
        Surface(
          shape = MaterialTheme.shapes.medium,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Row(
              modifier = Modifier.weight(1f),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Rounded.NotificationsActive,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = "تذكير يومي بالصفحة",
                  style = MaterialTheme.typography.titleMedium,
                )
                val formattedTime =
                  String.format(
                    Locale.US,
                    "%02d:%02d",
                    settings.dailyPageHour,
                    settings.dailyPageMinute,
                  )
                TextButton(
                  onClick = { showTimePicker = true },
                  contentPadding = PaddingValues(0.dp),
                ) {
                  Icon(Icons.Rounded.Schedule, contentDescription = null, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("الوقت المحدد: $formattedTime (اضغط للتعديل)")
                }
              }
            }
            Switch(
              checked = settings.dailyPageNotificationsEnabled,
              onCheckedChange = ::toggleDailyReminder,
              modifier = Modifier.testTag("daily_page_reminder_switch"),
            )
          }
        }

        // Page Switcher Row
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          OutlinedButton(
            onClick = onPreviousPage,
            modifier = Modifier.testTag("daily_page_prev"),
          ) {
            Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("السابقة")
          }
          Text(
            text = "صفحة ${settings.dailyPageNumber} / ٦٠٤",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary,
          )
          OutlinedButton(
            onClick = onNextPage,
            modifier = Modifier.testTag("daily_page_next"),
          ) {
            Text("التالية")
            Spacer(modifier = Modifier.width(6.dp))
            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null)
          }
        }

        when (uiState) {
          is DailyPageUiState.Loading -> {
            Box(
              modifier = Modifier.fillMaxWidth().height(320.dp),
              contentAlignment = Alignment.Center,
            ) {
              CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
          }

          is DailyPageUiState.Error -> {
            Surface(
              shape = MaterialTheme.shapes.large,
              color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.4f),
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Text(
                  text = uiState.message,
                  style = MaterialTheme.typography.bodyLarge,
                  textAlign = TextAlign.Center,
                )
                Button(onClick = onRetry) { Text("إعادة المحاولة") }
              }
            }
          }

          is DailyPageUiState.Ready -> {
            // Islamic Decorative Preview Poster Card
            Surface(
              shape = RoundedCornerShape(24.dp),
              color = Color(0xFFFAF5EA),
              border = BorderStroke(3.dp, Color(0xFF0F5C4D)),
              shadowElevation = 4.dp,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(
                  modifier =
                    Modifier.fillMaxWidth()
                      .background(Color(0xFF0F5C4D), RoundedCornerShape(16.dp))
                      .padding(horizontal = 16.dp, vertical = 12.dp),
                  contentAlignment = Alignment.Center,
                ) {
                  Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                      text = uiState.surahNames.ifBlank { "القرآن الكريم" },
                      fontFamily = AmiriFontFamily,
                      fontSize = 24.sp,
                      fontWeight = FontWeight.Bold,
                      color = Color(0xFFF6D98D),
                      textAlign = TextAlign.Center,
                    )
                    Text(
                      text = "الصفحة ${uiState.pageNumber} من المصحف الشريف",
                      style = MaterialTheme.typography.labelMedium,
                      color = Color.White,
                    )
                  }
                }

                val combinedText =
                  uiState.ayahs.joinToString("  ") { ayah ->
                    "${ayah.arabicText} ﴿${ayah.numberInSurah}﴾"
                  }

                Text(
                  text = combinedText,
                  fontFamily = AmiriFontFamily,
                  fontSize = 22.sp,
                  lineHeight = 42.sp,
                  color = Color(0xFF1B211E),
                  textAlign = TextAlign.Center,
                  modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp),
                )

                Surface(
                  color = Color(0xFFF0E6D2),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.fillMaxWidth(),
                ) {
                  Text(
                    text = "نور القرآن • رفيقك إلى القرآن والطمأنينة",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color(0xFF0F5C4D),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(10.dp),
                  )
                }
              }
            }

            // Primary Actions: Save & Read
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Button(
                onClick = { exportPoster(targetPackage = null, saveOnly = true) },
                enabled = !isBusy,
                modifier = Modifier.weight(1f).testTag("daily_page_save_gallery"),
              ) {
                Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("حفظ بالمعرض")
              }
              OutlinedButton(
                onClick = { onOpenInMushaf(uiState.pageNumber) },
                modifier = Modifier.weight(1f),
              ) {
                Icon(Icons.AutoMirrored.Rounded.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("قراءة بالمصحف")
              }
            }

            Text(
              text = "مشاركة صفحة اليوم كصورة عبر:",
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onBackground,
            )

            FlowRow(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              OutlinedButton(
                onClick = { exportPoster("com.whatsapp", saveOnly = false) },
                enabled = !isBusy,
                modifier = Modifier.testTag("share_whatsapp"),
              ) {
                Text("واتساب")
              }
              OutlinedButton(
                onClick = { exportPoster("org.telegram.messenger", saveOnly = false) },
                enabled = !isBusy,
                modifier = Modifier.testTag("share_telegram"),
              ) {
                Text("تيليجرام")
              }
              OutlinedButton(
                onClick = { exportPoster("com.snapchat.android", saveOnly = false) },
                enabled = !isBusy,
                modifier = Modifier.testTag("share_snapchat"),
              ) {
                Text("سناب شات")
              }
              OutlinedButton(
                onClick = { exportPoster("com.instagram.android", saveOnly = false) },
                enabled = !isBusy,
                modifier = Modifier.testTag("share_instagram"),
              ) {
                Text("إنستغرام")
              }
              Button(
                onClick = { exportPoster(null, saveOnly = false) },
                enabled = !isBusy,
                modifier = Modifier.testTag("share_system"),
              ) {
                Icon(Icons.Rounded.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("مشاركة أخرى")
              }
            }
          }
        }
      }
    }
  }

  if (showTimePicker) {
    val pickerState =
      rememberTimePickerState(
        initialHour = settings.dailyPageHour,
        initialMinute = settings.dailyPageMinute,
        is24Hour = true,
      )
    AlertDialog(
      onDismissRequest = { showTimePicker = false },
      title = { Text("تحديد وقت التذكير اليومي") },
      text = { TimePicker(state = pickerState) },
      confirmButton = {
        Button(
          onClick = {
            onUpdateSchedule(
              pickerState.hour,
              pickerState.minute,
              settings.dailyPageNotificationsEnabled,
            )
            showTimePicker = false
          }
        ) {
          Text("حفظ الوقت")
        }
      },
      dismissButton = {
        TextButton(onClick = { showTimePicker = false }) { Text("إلغاء") }
      },
    )
  }
}
