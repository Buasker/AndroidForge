package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AmiriFontFamily
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinished: () -> Unit) {
  val alpha = remember { Animatable(0f) }
  val scale = remember { Animatable(0.88f) }

  LaunchedEffect(Unit) {
    alpha.animateTo(1f, animationSpec = tween(550, easing = FastOutSlowInEasing))
    scale.animateTo(1f, animationSpec = tween(550, easing = FastOutSlowInEasing))
    delay(700L)
    onFinished()
  }

  Box(
    modifier =
      Modifier.fillMaxSize()
        .background(
          Brush.verticalGradient(
            colors =
              listOf(
                Color(0xFF0A3D32),
                Color(0xFF0F5C4D),
                Color(0xFF082E26),
              )
          )
        ),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier = Modifier.padding(32.dp).alpha(alpha.value).scale(scale.value),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Surface(
        shape = RoundedCornerShape(32.dp),
        color = Color(0xFF0F5C4D),
        shadowElevation = 12.dp,
        modifier = Modifier.size(124.dp),
      ) {
        Image(
          painter = painterResource(id = R.drawable.noor_icon_fg_1794977135628),
          contentDescription = "شعار نور القرآن",
          modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(32.dp)),
        )
      }
      Spacer(modifier = Modifier.height(24.dp))
      Text(
        text = "نور القرآن",
        fontFamily = AmiriFontFamily,
        fontSize = 42.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFFF6D98D),
        textAlign = TextAlign.Center,
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "رفيقك إلى القرآن والطمأنينة",
        style = MaterialTheme.typography.titleMedium,
        color = Color.White.copy(alpha = 0.9f),
        textAlign = TextAlign.Center,
      )
    }
  }
}
