package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioPlaybackState
import com.example.data.firebase.AudioHostingProvider
import com.example.data.firebase.ExternalAudioMetadata
import com.example.data.firebase.FirebaseRecitationTrack
import com.example.data.firebase.FirebaseReciter
import com.example.data.local.QuranSeedData
import com.example.ui.components.OctagonalBadge
import com.example.ui.components.ReciterAvatar
import com.example.ui.theme.AmiriFontFamily
import java.util.Locale

data class ReciterDraftPayload(
  val reciterId: String,
  val arabicName: String,
  val riwayah: String,
  val styleArabic: String,
  val bioArabic: String,
  val photoUrl: String,
  val provider: AudioHostingProvider,
  val audioBaseUrl: String,
  val sortOrder: Long,
  val published: Boolean,
)

data class RecitationDraftPayload(
  val trackId: String,
  val reciterId: String,
  val reciterName: String,
  val surahNumber: Int,
  val surahArabicName: String,
  val description: String,
  val sortOrder: Long,
  val provider: AudioHostingProvider,
  val audioUrl: String,
  val externalAssetId: String,
  val durationSeconds: Long,
  val published: Boolean,
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReciterEditorDialog(
  existing: FirebaseReciter?,
  defaultSortOrder: Long,
  isBusy: Boolean,
  onDismiss: () -> Unit,
  onPreview: (ReciterDraftPayload) -> Unit,
  onSave: (ReciterDraftPayload) -> Unit,
) {
  var reciterId by remember(existing) { mutableStateOf(existing?.id ?: "") }
  var arabicName by remember(existing) { mutableStateOf(existing?.arabicName ?: "") }
  var riwayah by remember(existing) { mutableStateOf(existing?.effectiveRiwayah ?: "حفص عن عاصم") }
  var styleArabic by remember(existing) { mutableStateOf(existing?.styleArabic ?: "مرتل") }
  var photoUrl by remember(existing) { mutableStateOf(existing?.photoUrl ?: "") }
  var bioArabic by remember(existing) { mutableStateOf(existing?.bioArabic ?: "") }
  var sortOrderText by remember(existing) {
    mutableStateOf((existing?.sortOrder ?: defaultSortOrder).toString())
  }
  var provider by remember(existing) {
    mutableStateOf(AudioHostingProvider.fromId(existing?.hostingProvider))
  }
  var audioBaseUrl by remember(existing) { mutableStateOf(existing?.audioBaseUrl ?: "") }
  var published by remember(existing) { mutableStateOf(existing?.published ?: true) }

  fun buildPayload() =
    ReciterDraftPayload(
      reciterId = reciterId.trim(),
      arabicName = arabicName.trim(),
      riwayah = riwayah.trim(),
      styleArabic = styleArabic.trim().ifBlank { riwayah.trim() },
      bioArabic = bioArabic.trim(),
      photoUrl = photoUrl.trim(),
      provider = provider,
      audioBaseUrl = audioBaseUrl.trim(),
      sortOrder = sortOrderText.toLongOrNull()?.coerceIn(0L, 100_000L) ?: 0L,
      published = published,
    )

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (existing == null) "إضافة قارئ جديد" else "تعديل بيانات القارئ") },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          ReciterAvatar(
            photoUrl = photoUrl,
            contentDescription = arabicName.ifBlank { "صورة القارئ" },
            size = 54.dp,
          )
          Text(
            text = "معاينة الصورة الرمزية للقارئ كما ستظهر للمستخدمين",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        OutlinedTextField(
          value = reciterId,
          onValueChange = { reciterId = it },
          enabled = existing == null,
          label = { Text("معرّف القارئ (إنجليزي، مثل sheikh_ali)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("reciter_id_input"),
        )
        OutlinedTextField(
          value = arabicName,
          onValueChange = { arabicName = it },
          label = { Text("اسم القارئ بالعربية") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("reciter_name_input"),
        )
        OutlinedTextField(
          value = riwayah,
          onValueChange = { riwayah = it },
          label = { Text("الرواية (مثل: حفص عن عاصم)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("reciter_riwayah_input"),
        )
        OutlinedTextField(
          value = styleArabic,
          onValueChange = { styleArabic = it },
          label = { Text("الأسلوب (مرتل / مجود)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("reciter_style_input"),
        )
        OutlinedTextField(
          value = photoUrl,
          onValueChange = { photoUrl = it },
          label = { Text("رابط صورة القارئ HTTPS (اختياري)") },
          placeholder = { Text("https://example.com/reciter.jpg") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
          modifier = Modifier.fillMaxWidth().testTag("reciter_photo_input"),
        )
        OutlinedTextField(
          value = bioArabic,
          onValueChange = { bioArabic = it.take(600) },
          label = { Text("النبذة التعريفية عن القارئ (اختياري)") },
          minLines = 2,
          maxLines = 4,
          modifier = Modifier.fillMaxWidth().testTag("reciter_bio_input"),
        )
        OutlinedTextField(
          value = sortOrderText,
          onValueChange = { sortOrderText = it.filter(Char::isDigit).take(6) },
          label = { Text("ترتيب العرض") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.fillMaxWidth().testTag("reciter_sort_input"),
        )
        Text("مزود الاستضافة المجاني:", style = MaterialTheme.typography.labelLarge)
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          AudioHostingProvider.entries.forEach { entry ->
            FilterChip(
              selected = provider == entry,
              onClick = { provider = entry },
              label = { Text(entry.arabicLabel) },
            )
          }
        }
        OutlinedTextField(
          value = audioBaseUrl,
          onValueChange = { audioBaseUrl = it },
          label = { Text("رابط HTTPS الأساسي للسور الكاملة (اختياري)") },
          placeholder = { Text("https://.../") },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
          modifier = Modifier.fillMaxWidth().testTag("reciter_url_input"),
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("نشر القارئ للمستخدمين")
          Switch(checked = published, onCheckedChange = { published = it })
        }
        OutlinedButton(
          onClick = { onPreview(buildPayload()) },
          enabled = reciterId.isNotBlank() && arabicName.isNotBlank(),
          modifier = Modifier.fillMaxWidth().testTag("preview_reciter_before_publish_button"),
        ) {
          Icon(Icons.Rounded.Visibility, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("معاينة قبل النشر")
        }
      }
    },
    confirmButton = {
      Button(
        enabled = !isBusy && reciterId.isNotBlank() && arabicName.isNotBlank(),
        onClick = { onSave(buildPayload()) },
        modifier = Modifier.testTag("save_reciter_button"),
      ) {
        Text(if (isBusy) "جارٍ الحفظ…" else "حفظ")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("إلغاء") }
    },
  )
}

@Composable
fun ReciterPreviewDialog(
  draft: ReciterDraftPayload,
  isBusy: Boolean,
  onBackToEdit: (() -> Unit)?,
  onSaveDraft: (() -> Unit)?,
  onPublishNow: (() -> Unit)?,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("معاينة بطاقة القارئ قبل النشر") },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Surface(
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
          modifier = Modifier.fillMaxWidth().testTag("reciter_preview_card"),
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              ReciterAvatar(
                photoUrl = draft.photoUrl,
                contentDescription = draft.arabicName,
                size = 64.dp,
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                  text = draft.arabicName,
                  fontFamily = AmiriFontFamily,
                  fontSize = 23.sp,
                  fontWeight = FontWeight.Bold,
                )
                Text(
                  text = draft.riwayah.ifBlank { draft.styleArabic },
                  style = MaterialTheme.typography.labelLarge,
                  color = MaterialTheme.colorScheme.primary,
                )
                Surface(
                  shape = RoundedCornerShape(50),
                  color =
                    if (draft.published) MaterialTheme.colorScheme.primaryContainer
                    else MaterialTheme.colorScheme.errorContainer,
                ) {
                  Text(
                    text = if (draft.published) "الحالة: منشور للجميع" else "الحالة: مسودة (مخفي)",
                    style = MaterialTheme.typography.labelSmall,
                    color =
                      if (draft.published) MaterialTheme.colorScheme.onPrimaryContainer
                      else MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                  )
                }
              }
            }
            if (draft.bioArabic.isNotBlank()) {
              Text(
                text = draft.bioArabic,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Text(
              text = "الترتيب: ${draft.sortOrder} • ${draft.provider.arabicLabel}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
        if (onBackToEdit != null) {
          OutlinedButton(onClick = onBackToEdit, modifier = Modifier.fillMaxWidth()) {
            Text("العودة للتعديل")
          }
        }
        if (onSaveDraft != null) {
          OutlinedButton(
            onClick = onSaveDraft,
            enabled = !isBusy,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text("حفظ كمسودة")
          }
        }
      }
    },
    confirmButton = {
      if (onPublishNow != null) {
        Button(
          onClick = onPublishNow,
          enabled = !isBusy,
          modifier = Modifier.testTag("confirm_publish_reciter_button"),
        ) {
          Text(if (isBusy) "جارٍ النشر…" else "اعتماد ونشر")
        }
      } else {
        TextButton(onClick = onDismiss) { Text("إغلاق") }
      }
    },
    dismissButton = {
      if (onPublishNow != null) {
        TextButton(onClick = onDismiss) { Text("إغلاق") }
      }
    },
  )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RecitationTrackEditorDialog(
  reciterId: String,
  reciterName: String,
  existing: FirebaseRecitationTrack?,
  defaultSortOrder: Long,
  isBusy: Boolean,
  isProbingUrl: Boolean,
  probeResult: Result<ExternalAudioMetadata>?,
  onProbeUrl: (String) -> Unit,
  onDismiss: () -> Unit,
  onPreview: (RecitationDraftPayload) -> Unit,
  onSave: (RecitationDraftPayload) -> Unit,
) {
  var surahNumberText by remember(existing) {
    mutableStateOf(existing?.surahNumber?.toString() ?: "1")
  }
  val parsedSurah = surahNumberText.toIntOrNull()?.coerceIn(1, 114) ?: 1
  val autoSurahName =
    remember(parsedSurah) {
      QuranSeedData.surahs.firstOrNull { it.number == parsedSurah }?.arabicName
        ?: String.format(Locale.US, "سورة %d", parsedSurah)
    }
  var surahName by remember(existing) {
    mutableStateOf(existing?.surahArabicName ?: autoSurahName)
  }
  var description by remember(existing) { mutableStateOf(existing?.description ?: "") }
  var sortOrderText by remember(existing) {
    mutableStateOf((existing?.sortOrder ?: defaultSortOrder).toString())
  }
  var provider by remember(existing) {
    mutableStateOf(AudioHostingProvider.fromId(existing?.hostingProvider))
  }
  var audioUrl by remember(existing) { mutableStateOf(existing?.audioUrl ?: "https://") }
  var externalAssetId by remember(existing) { mutableStateOf(existing?.externalAssetId ?: "") }
  var durationText by remember(existing) {
    mutableStateOf(existing?.durationSeconds?.takeIf { it > 0 }?.toString() ?: "")
  }
  var published by remember(existing) { mutableStateOf(existing?.published ?: true) }

  fun buildPayload(): RecitationDraftPayload? {
    val validSurah = surahNumberText.toIntOrNull()?.takeIf { it in 1..114 } ?: return null
    return RecitationDraftPayload(
      trackId = existing?.id ?: "",
      reciterId = reciterId,
      reciterName = reciterName,
      surahNumber = validSurah,
      surahArabicName = surahName.trim().ifBlank { autoSurahName },
      description = description.trim(),
      sortOrder = sortOrderText.toLongOrNull()?.coerceIn(0L, 100_000L) ?: validSurah.toLong(),
      provider = provider,
      audioUrl = audioUrl.trim(),
      externalAssetId = externalAssetId.trim(),
      durationSeconds = durationText.toLongOrNull() ?: 0L,
      published = published,
    )
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (existing == null) "إضافة تلاوة ($reciterName)" else "تعديل التلاوة") },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        OutlinedTextField(
          value = surahNumberText,
          onValueChange = { input ->
            val digits = input.filter { it.isDigit() }.take(3)
            surahNumberText = digits
            digits.toIntOrNull()?.takeIf { it in 1..114 }?.let { num ->
              surahName =
                QuranSeedData.surahs.firstOrNull { it.number == num }?.arabicName ?: "سورة $num"
            }
          },
          label = { Text("رقم السورة (١ إلى ١١٤)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("track_surah_number_input"),
        )
        OutlinedTextField(
          value = surahName,
          onValueChange = { surahName = it },
          label = { Text("اسم السورة") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("track_surah_name_input"),
        )
        OutlinedTextField(
          value = description,
          onValueChange = { description = it.take(500) },
          label = { Text("وصف التلاوة (اختياري، مثل: تلاوة خاشعة - رواية حفص)") },
          minLines = 2,
          maxLines = 3,
          modifier = Modifier.fillMaxWidth().testTag("track_description_input"),
        )
        OutlinedTextField(
          value = sortOrderText,
          onValueChange = { sortOrderText = it.filter(Char::isDigit).take(6) },
          label = { Text("ترتيب التلاوة") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("track_sort_input"),
        )
        Text("مزود الاستضافة:", style = MaterialTheme.typography.labelLarge)
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(6.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          AudioHostingProvider.entries.forEach { entry ->
            FilterChip(
              selected = provider == entry,
              onClick = { provider = entry },
              label = { Text(entry.arabicLabel) },
            )
          }
        }
        OutlinedTextField(
          value = audioUrl,
          onValueChange = { audioUrl = it },
          label = { Text("رابط ملف الصوت المباشر (HTTPS فقط)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("track_url_input"),
        )
        OutlinedButton(
          onClick = { onProbeUrl(audioUrl) },
          enabled = !isProbingUrl && audioUrl.startsWith("https://"),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Icon(Icons.Rounded.Public, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text(if (isProbingUrl) "جارٍ فحص الرابط…" else "فحص توفر الرابط عبر HTTPS")
        }
        probeResult?.let { res ->
          val meta = res.getOrNull()
          if (meta != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                Icons.Rounded.CheckCircle,
                contentDescription = null,
                tint =
                  if (meta.reachable) MaterialTheme.colorScheme.primary
                  else MaterialTheme.colorScheme.error,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text =
                  if (meta.reachable) "متاح (${meta.contentLengthBytes / 1024} KB)"
                  else "الرابط غير مستجيب",
                style = MaterialTheme.typography.bodySmall,
              )
            }
          } else {
            Text(
              text = res.exceptionOrNull()?.localizedMessage ?: "الرابط غير صالح",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.error,
            )
          }
        }
        HorizontalDivider()
        OutlinedTextField(
          value = externalAssetId,
          onValueChange = { externalAssetId = it },
          label = { Text("معرّف الأصل الخارجي (اختياري)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
          value = durationText,
          onValueChange = { durationText = it.filter { ch -> ch.isDigit() }.take(6) },
          label = { Text("المدة بالثواني (اختياري)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text("نشر التلاوة للمستخدمين")
          Switch(checked = published, onCheckedChange = { published = it })
        }
        OutlinedButton(
          onClick = { buildPayload()?.let(onPreview) },
          enabled = surahNumberText.toIntOrNull() in 1..114 && audioUrl.isNotBlank(),
          modifier = Modifier.fillMaxWidth().testTag("preview_track_before_publish_button"),
        ) {
          Icon(Icons.Rounded.Visibility, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("معاينة التلاوة قبل النشر")
        }
      }
    },
    confirmButton = {
      val validSurah = surahNumberText.toIntOrNull()?.takeIf { it in 1..114 }
      Button(
        enabled = !isBusy && validSurah != null && audioUrl.isNotBlank(),
        onClick = { buildPayload()?.let(onSave) },
        modifier = Modifier.testTag("save_track_button"),
      ) {
        Text(if (isBusy) "جارٍ الحفظ…" else "حفظ التلاوة")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("إلغاء") }
    },
  )
}

@Composable
fun RecitationPreviewDialog(
  draft: RecitationDraftPayload,
  audioState: AudioPlaybackState,
  isBusy: Boolean,
  onPlayPreviewAudio: (RecitationDraftPayload) -> Unit,
  onSeekAudio: (Int) -> Unit,
  onStopAudio: () -> Unit,
  onBackToEdit: (() -> Unit)?,
  onSaveDraft: (() -> Unit)?,
  onPublishNow: (() -> Unit)?,
  onDismiss: () -> Unit,
) {
  val previewTrackId = draft.trackId.ifBlank { "preview_${draft.reciterId}_${draft.surahNumber}" }
  val isThisPreviewActive =
    audioState.isActive &&
      audioState.trackId == previewTrackId &&
      audioState.reciterId == draft.reciterId

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("معاينة التلاوة قبل النشر") },
    text = {
      Column(
        modifier = Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Surface(
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
          modifier = Modifier.fillMaxWidth().testTag("recitation_preview_card"),
        ) {
          Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              OctagonalBadge(number = draft.surahNumber, size = 42.dp)
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = draft.surahArabicName,
                  fontFamily = AmiriFontFamily,
                  fontSize = 22.sp,
                  fontWeight = FontWeight.Bold,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Text(
                  text = draft.reciterName,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.primary,
                )
              }
              Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp),
              ) {
                IconButton(
                  onClick = { onPlayPreviewAudio(draft.copy(trackId = previewTrackId)) },
                  modifier = Modifier.testTag("preview_track_audio_play_button"),
                ) {
                  if (isThisPreviewActive && audioState.isBuffering) {
                    CircularProgressIndicator(
                      modifier = Modifier.size(20.dp),
                      color = MaterialTheme.colorScheme.onPrimary,
                      strokeWidth = 2.dp,
                    )
                  } else {
                    Icon(
                      imageVector =
                        if (isThisPreviewActive && audioState.isPlaying) Icons.Rounded.Pause
                        else Icons.Rounded.PlayArrow,
                      contentDescription = "معاينة صوت التلاوة",
                      tint = MaterialTheme.colorScheme.onPrimary,
                    )
                  }
                }
              }
            }

            if (draft.description.isNotBlank()) {
              Text(
                text = draft.description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }

            Text(
              text =
                "${draft.provider.arabicLabel} • الترتيب: ${draft.sortOrder} • ${if (draft.published) "منشورة" else "مسودة"}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            if (isThisPreviewActive) {
              HorizontalDivider()
              if (audioState.errorMessage != null) {
                Text(
                  text = audioState.errorMessage,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.error,
                )
              }
              if (audioState.durationMs > 0) {
                Slider(
                  value =
                    audioState.positionMs.toFloat().coerceIn(0f, audioState.durationMs.toFloat()),
                  onValueChange = { onSeekAudio(it.toInt()) },
                  valueRange = 0f..audioState.durationMs.toFloat().coerceAtLeast(1f),
                )
              }
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text =
                    if (audioState.isBuffering) "جارٍ تحميل الصوت…"
                    else "${formatPreviewMs(audioState.positionMs)} / ${formatPreviewMs(audioState.durationMs)}",
                  style = MaterialTheme.typography.labelSmall,
                )
                IconButton(
                  onClick = onStopAudio,
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(Icons.Rounded.Stop, contentDescription = "إيقاف المعاينة")
                }
              }
            }
          }
        }

        if (onBackToEdit != null) {
          OutlinedButton(onClick = onBackToEdit, modifier = Modifier.fillMaxWidth()) {
            Text("العودة للتعديل")
          }
        }
        if (onSaveDraft != null) {
          OutlinedButton(
            onClick = onSaveDraft,
            enabled = !isBusy,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text("حفظ كمسودة")
          }
        }
      }
    },
    confirmButton = {
      if (onPublishNow != null) {
        Button(
          onClick = onPublishNow,
          enabled = !isBusy,
          modifier = Modifier.testTag("confirm_publish_track_button"),
        ) {
          Text(if (isBusy) "جارٍ النشر…" else "نشر التلاوة")
        }
      } else {
        TextButton(onClick = onDismiss) { Text("إغلاق") }
      }
    },
    dismissButton = {
      if (onPublishNow != null) {
        TextButton(onClick = onDismiss) { Text("إغلاق") }
      }
    },
  )
}

private fun formatPreviewMs(ms: Int): String {
  val total = (ms / 1000).coerceAtLeast(0)
  return String.format(Locale.US, "%02d:%02d", total / 60, total % 60)
}
