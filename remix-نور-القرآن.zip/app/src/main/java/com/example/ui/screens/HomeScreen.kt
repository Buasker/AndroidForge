package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.DailyReflection
import com.example.data.model.KhatmahPlan
import com.example.data.model.ReaderThemeMode
import com.example.data.model.ReadingProgress
import com.example.data.model.SurahInfo
import com.example.ui.components.OctagonalBadge
import com.example.ui.components.SurahRowCard
import com.example.ui.theme.AmiriFontFamily

@Composable
fun HomeScreen(
  readingProgress: ReadingProgress,
  dailyReflection: DailyReflection,
  featuredSurahs: List<SurahInfo>,
  bookmarksCount: Int,
  activeKhatmah: KhatmahPlan?,
  totalVoiceDhikrCount: Int,
  currentThemeMode: ReaderThemeMode,
  onToggleTheme: () -> Unit,
  onOpenSurah: (surahNumber: Int, ayahNumber: Int) -> Unit,
  onOpenAllSurahs: () -> Unit,
  onOpenTafsir: () -> Unit,
  onOpenAudioLibrary: () -> Unit,
  onOpenVoiceDhikr: () -> Unit,
  onOpenAdhkar: () -> Unit,
  onOpenKhatmah: () -> Unit,
  onOpenDailyPage: () -> Unit,
  onOpenBookmarks: () -> Unit,
  onOpenSearch: () -> Unit,
  onOpenSettings: () -> Unit,
  onOpenSocial: () -> Unit,
  onOpenDhikrStats: () -> Unit = {},
  onOpenReciters: () -> Unit = {},
  onOpenManageLocalReciters: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Top Arabic Branded Header
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "السلام عليكم ورحمة الله",
              style = MaterialTheme.typography.labelLarge,
              color = MaterialTheme.colorScheme.secondary,
            )
            Text(
              text = "نور القرآن",
              style = MaterialTheme.typography.displayLarge,
              color = MaterialTheme.colorScheme.onBackground,
            )
            Text(
              text = "رفيقك إلى القرآن والطمأنينة",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            IconButton(
              onClick = onOpenSearch,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("home_search_button"),
            ) {
              Icon(
                imageVector = Icons.Rounded.Search,
                contentDescription = "البحث الذكي",
                tint = MaterialTheme.colorScheme.onSurface,
              )
            }
            IconButton(
              onClick = onToggleTheme,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("home_theme_toggle"),
            ) {
              Icon(
                imageVector =
                  if (currentThemeMode == ReaderThemeMode.MIDNIGHT) Icons.Rounded.LightMode
                  else Icons.Rounded.DarkMode,
                contentDescription = "تبديل المظهر",
                tint = MaterialTheme.colorScheme.onSurface,
              )
            }
            IconButton(
              onClick = onOpenSettings,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("home_settings_button"),
            ) {
              Icon(
                imageVector = Icons.Rounded.Settings,
                contentDescription = "الإعدادات",
                tint = MaterialTheme.colorScheme.onSurface,
              )
            }
          }
        }
      }

      // Hero Continue Reading Card
      item {
        val progressFraction =
          if (readingProgress.totalAyahs > 0) {
            readingProgress.ayahNumberInSurah.toFloat() / readingProgress.totalAyahs.toFloat()
          } else 0f

        Surface(
          modifier =
            Modifier.fillMaxWidth()
              .testTag("continue_reading_card")
              .clickable {
                onOpenSurah(readingProgress.surahNumber, readingProgress.ayahNumberInSurah)
              },
          shape = MaterialTheme.shapes.large,
          shadowElevation = 4.dp,
        ) {
          Box(modifier = Modifier.fillMaxWidth().height(206.dp)) {
            Image(
              painter = painterResource(id = R.drawable.img_noor_banner_1794977136058),
              contentDescription = "خلفية نور القرآن",
              contentScale = ContentScale.Crop,
              modifier = Modifier.fillMaxSize(),
            )
            Box(
              modifier =
                Modifier.fillMaxSize()
                  .background(
                    Brush.horizontalGradient(
                      colors =
                        listOf(
                          Color(0xE6083028),
                          Color(0xBF0B3F34),
                          Color(0x75083028),
                        )
                    )
                  )
            )
            Column(
              modifier = Modifier.fillMaxSize().padding(20.dp),
              verticalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Surface(
                  color = Color.White.copy(alpha = 0.16f),
                  shape = RoundedCornerShape(50),
                ) {
                  Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Icon(
                      imageVector = Icons.AutoMirrored.Rounded.MenuBook,
                      contentDescription = null,
                      tint = Color(0xFFF6D98D),
                      modifier = Modifier.size(16.dp),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                      text = "آخر موضع قراءة",
                      style = MaterialTheme.typography.labelMedium,
                      color = Color.White,
                    )
                  }
                }
                Text(
                  text = "صفحة ${readingProgress.page}",
                  style = MaterialTheme.typography.labelLarge,
                  color = Color(0xFFF6D98D),
                )
              }

              Column {
                Text(
                  text = readingProgress.surahArabicName,
                  fontFamily = AmiriFontFamily,
                  fontSize = 30.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                )
                Text(
                  text = "الآية ${readingProgress.ayahNumberInSurah} من ${readingProgress.totalAyahs}",
                  style = MaterialTheme.typography.bodyMedium,
                  color = Color.White.copy(alpha = 0.88f),
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  LinearProgressIndicator(
                    progress = { progressFraction.coerceIn(0.05f, 1f) },
                    modifier = Modifier.weight(1f).height(6.dp).clip(CircleShape),
                    color = Color(0xFFF6D98D),
                    trackColor = Color.White.copy(alpha = 0.24f),
                  )
                  Spacer(modifier = Modifier.width(14.dp))
                  Button(
                    onClick = {
                      onOpenSurah(readingProgress.surahNumber, readingProgress.ayahNumberInSurah)
                    },
                    colors =
                      ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFF6D98D),
                        contentColor = Color(0xFF1A2823),
                      ),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    modifier = Modifier.testTag("resume_reading_button"),
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.PlayArrow,
                      contentDescription = null,
                      modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("متابعة", style = MaterialTheme.typography.labelLarge)
                  }
                }
              }
            }
          }
        }
      }

      // Main Feature Hub Cards (2 columns x 3 rows)
      item {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = "أقسام التطبيق",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            FeatureHubCard(
              title = "الذكر الصوتي",
              subtitle = "إجمالي: $totalVoiceDhikrCount",
              icon = Icons.Rounded.Mic,
              accentColor = MaterialTheme.colorScheme.primary,
              onClick = onOpenVoiceDhikr,
              testTag = "hub_voice_dhikr",
              modifier = Modifier.weight(1f),
            )
            FeatureHubCard(
              title = "المكتبة الصوتية",
              subtitle = "٨ قرّاء • تحميل",
              icon = Icons.Rounded.Headphones,
              accentColor = MaterialTheme.colorScheme.secondary,
              onClick = onOpenAudioLibrary,
              testTag = "hub_audio",
              modifier = Modifier.weight(1f),
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            FeatureHubCard(
              title = "ختمة القرآن",
              subtitle =
                if (activeKhatmah != null)
                  "${((activeKhatmah.pagesRead * 100f) / activeKhatmah.totalPages).toInt()}% مكتمل"
                else "ابدأ ختمة جديدة",
              icon = Icons.Rounded.CalendarMonth,
              accentColor = MaterialTheme.colorScheme.primary,
              onClick = onOpenKhatmah,
              testTag = "hub_khatmah",
              modifier = Modifier.weight(1f),
            )
            FeatureHubCard(
              title = "الصفحة اليومية",
              subtitle = "شارك صفحة كصورة",
              icon = Icons.Rounded.Image,
              accentColor = MaterialTheme.colorScheme.secondary,
              onClick = onOpenDailyPage,
              testTag = "hub_daily_page",
              modifier = Modifier.weight(1f),
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            FeatureHubCard(
              title = "تفسير القرآن",
              subtitle = "الميسّر والجلالين",
              icon = Icons.AutoMirrored.Rounded.MenuBook,
              accentColor = MaterialTheme.colorScheme.primary,
              onClick = onOpenTafsir,
              testTag = "hub_tafsir",
              modifier = Modifier.weight(1f),
            )
            FeatureHubCard(
              title = "الأذكار اليومية",
              subtitle = "الصباح والمساء والنوم",
              icon = Icons.Rounded.WbSunny,
              accentColor = MaterialTheme.colorScheme.secondary,
              onClick = onOpenAdhkar,
              testTag = "hub_adhkar",
              modifier = Modifier.weight(1f),
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            FeatureHubCard(
              title = "المفضلة والإشارات",
              subtitle = "$bookmarksCount آية محفوظة",
              icon = Icons.Rounded.Bookmark,
              accentColor = MaterialTheme.colorScheme.secondary,
              onClick = onOpenBookmarks,
              testTag = "hub_bookmarks",
              modifier = Modifier.weight(1f),
            )
            FeatureHubCard(
              title = "تواصل معي",
              subtitle = "حساباتي الاجتماعية",
              icon = Icons.Rounded.AutoAwesome,
              accentColor = MaterialTheme.colorScheme.primary,
              onClick = onOpenSocial,
              testTag = "hub_social",
              modifier = Modifier.weight(1f),
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            FeatureHubCard(
              title = "إحصائيات الأذكار",
              subtitle = "يومي وأسبوعي بالرسم",
              icon = Icons.Rounded.BarChart,
              accentColor = MaterialTheme.colorScheme.primary,
              onClick = onOpenDhikrStats,
              testTag = "hub_dhikr_stats",
              modifier = Modifier.weight(1f),
            )
            FeatureHubCard(
              title = "البحث الذكي",
              subtitle = "القرآن والتفسير والأذكار",
              icon = Icons.Rounded.Search,
              accentColor = MaterialTheme.colorScheme.secondary,
              onClick = onOpenSearch,
              testTag = "hub_search",
              modifier = Modifier.weight(1f),
            )
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            FeatureHubCard(
              title = "القرّاء",
              subtitle = "ملفات القرّاء والتلاوات",
              icon = Icons.Rounded.RecordVoiceOver,
              accentColor = MaterialTheme.colorScheme.primary,
              onClick = onOpenReciters,
              testTag = "hub_reciters",
              modifier = Modifier.weight(1f),
            )
            FeatureHubCard(
              title = "الإعدادات والتخصيص",
              subtitle = "المظهر والحساب والتنبيهات",
              icon = Icons.Rounded.Settings,
              accentColor = MaterialTheme.colorScheme.secondary,
              onClick = onOpenSettings,
              testTag = "hub_settings",
              modifier = Modifier.weight(1f),
            )
          }
          FeatureHubCard(
            title = "إدارة القرّاء والتلاوات",
            subtitle = "إضافة قارئ وتلاواته بالروابط المباشرة وتشغيلها",
            icon = Icons.AutoMirrored.Rounded.QueueMusic,
            accentColor = MaterialTheme.colorScheme.primary,
            onClick = onOpenManageLocalReciters,
            testTag = "hub_manage_reciters",
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }

      // Daily Reflection Card
      item {
        Surface(
          modifier =
            Modifier.fillMaxWidth()
              .testTag("daily_reflection_card")
              .clickable {
                onOpenSurah(dailyReflection.surahNumber, dailyReflection.ayahNumber)
              },
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.4f)),
          tonalElevation = 1.dp,
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Rounded.AutoAwesome,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.secondary,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "آية للتدبر",
                  style = MaterialTheme.typography.labelLarge,
                  color = MaterialTheme.colorScheme.secondary,
                )
              }
              Surface(
                shape = RoundedCornerShape(50),
                color = MaterialTheme.colorScheme.secondaryContainer,
              ) {
                Text(
                  text = dailyReflection.themeTag,
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSecondaryContainer,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text(
              text = dailyReflection.arabicText,
              fontFamily = AmiriFontFamily,
              fontSize = 26.sp,
              lineHeight = 46.sp,
              textAlign = TextAlign.Start,
              color = MaterialTheme.colorScheme.onSurface,
              modifier = Modifier.fillMaxWidth(),
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = dailyReflection.translationText,
              style = MaterialTheme.typography.bodyLarge,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "${dailyReflection.surahName} • آية ${dailyReflection.ayahNumber}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary,
              )
              Text(
                text = "اقرأ السورة ←",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary,
              )
            }
          }
        }
      }

      // Quick Juz Access Strip
      item {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text(
            text = "تصفح الأجزاء سريعاً",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
          )
          val highlightJuz = listOf(1 to 1, 15 to 17, 29 to 67, 30 to 78)
          LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(highlightJuz) { (juzNumber, startSurah) ->
              Surface(
                modifier =
                  Modifier.testTag("home_juz_$juzNumber").clickable {
                    onOpenSurah(startSurah, 1)
                  },
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.surfaceContainer,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  OctagonalBadge(number = juzNumber, size = 34.dp)
                  Spacer(modifier = Modifier.width(10.dp))
                  Column {
                    Text(
                      text = "الجزء $juzNumber",
                      style = MaterialTheme.typography.labelLarge,
                      color = MaterialTheme.colorScheme.onSurface,
                    )
                    Text(
                      text = "يبدأ من سورة $startSurah",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Essential Surahs
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "سور مختارة",
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onBackground,
          )
          TextButton(
            onClick = onOpenAllSurahs,
            modifier = Modifier.testTag("view_all_surahs_button"),
          ) {
            Text("عرض السور الـ١١٤")
          }
        }
      }

      items(featuredSurahs, key = { it.number }) { surah ->
        SurahRowCard(
          surah = surah,
          onClick = { onOpenSurah(surah.number, 1) },
        )
      }
    }
  }
}

@Composable
private fun FeatureHubCard(
  title: String,
  subtitle: String,
  icon: ImageVector,
  accentColor: Color,
  onClick: () -> Unit,
  testTag: String,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier.testTag(testTag).clickable(onClick = onClick),
    shape = MaterialTheme.shapes.medium,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    tonalElevation = 1.dp,
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 12.dp, vertical = 14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Surface(
        shape = CircleShape,
        color = accentColor.copy(alpha = 0.14f),
        modifier = Modifier.size(40.dp),
      ) {
        Box(contentAlignment = Alignment.Center) {
          Icon(
            imageVector = icon,
            contentDescription = title,
            tint = accentColor,
            modifier = Modifier.size(21.dp),
          )
        }
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = subtitle,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}
