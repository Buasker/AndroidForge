package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.DhikrDailyLog
import com.example.data.model.DhikrSourceType
import com.example.data.repository.QuranRepository
import com.example.dhikr.DhikrDateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class StatsPeriodMode(val titleArabic: String) {
  DAILY("يومي"),
  WEEKLY("أسبوعي"),
}

data class StatsChartPoint(
  val id: String,
  val primaryLabel: String,
  val secondaryLabel: String,
  val voiceCount: Int,
  val adhkarCount: Int,
  val topDhikrLabel: String?,
) {
  val totalCount: Int
    get() = voiceCount + adhkarCount
}

data class DhikrBreakdownItem(
  val dhikrId: String,
  val label: String,
  val sourceType: DhikrSourceType,
  val count: Int,
  val shareFraction: Float,
)

data class DhikrStatsUiState(
  val periodMode: StatsPeriodMode = StatsPeriodMode.DAILY,
  val dailyWindowDays: Int = 7,
  val points: List<StatsChartPoint> = emptyList(),
  val selectedPointIndex: Int = 0,
  val todayCount: Int = 0,
  val thisWeekCount: Int = 0,
  val periodTotalCount: Int = 0,
  val averageRate: Float = 0f,
  val peakPointLabel: String = "—",
  val peakPointCount: Int = 0,
  val currentStreakDays: Int = 0,
  val weekOverWeekPercent: Int? = null,
  val voiceTotalInPeriod: Int = 0,
  val adhkarTotalInPeriod: Int = 0,
  val breakdown: List<DhikrBreakdownItem> = emptyList(),
  val hasAnyData: Boolean = false,
) {
  val selectedPoint: StatsChartPoint?
    get() = points.getOrNull(selectedPointIndex)
}

object DhikrStatsAggregator {
  private const val WEEKLY_BUCKETS = 8

  fun buildState(
    logs: List<DhikrDailyLog>,
    periodMode: StatsPeriodMode,
    dailyWindowDays: Int,
    selectedPointIndex: Int?,
    todayEpochDay: Long = DhikrDateUtils.epochDayForMillis(),
  ): DhikrStatsUiState {
    val logsByDay = logs.groupBy { it.epochDay }
    val todayLogs = logsByDay[todayEpochDay].orEmpty()
    val todayCount = todayLogs.sumOf { it.count }

    val thisWeekStart = todayEpochDay - 6L
    val prevWeekStart = todayEpochDay - 13L
    val prevWeekEnd = todayEpochDay - 7L

    val thisWeekCount =
      logs.filter { it.epochDay in thisWeekStart..todayEpochDay }.sumOf { it.count }
    val prevWeekCount =
      logs.filter { it.epochDay in prevWeekStart..prevWeekEnd }.sumOf { it.count }

    val weekOverWeekPercent =
      if (prevWeekCount > 0) {
        (((thisWeekCount - prevWeekCount) * 100f) / prevWeekCount.toFloat()).toInt()
      } else {
        null
      }

    val currentStreakDays = calculateStreakDays(logsByDay, todayEpochDay)

    val points: List<StatsChartPoint>
    val windowStartDay: Long

    when (periodMode) {
      StatsPeriodMode.DAILY -> {
        val safeDays = dailyWindowDays.coerceIn(7, 14)
        windowStartDay = todayEpochDay - (safeDays - 1).toLong()
        points =
          (0 until safeDays).map { offset ->
            val day = windowStartDay + offset.toLong()
            val dayLogs = logsByDay[day].orEmpty()
            val voice =
              dayLogs.filter { it.sourceType == DhikrSourceType.VOICE }.sumOf { it.count }
            val adhkar =
              dayLogs.filter { it.sourceType == DhikrSourceType.ADHKAR }.sumOf { it.count }
            val topLabel =
              dayLogs
                .groupBy { it.label }
                .mapValues { (_, list) -> list.sumOf { it.count } }
                .maxByOrNull { it.value }
                ?.key
            val primary =
              if (day == todayEpochDay) "اليوم" else DhikrDateUtils.arabicShortDayName(day)
            StatsChartPoint(
              id = "day_$day",
              primaryLabel = primary,
              secondaryLabel = DhikrDateUtils.dayMonthLabel(day),
              voiceCount = voice,
              adhkarCount = adhkar,
              topDhikrLabel = topLabel,
            )
          }
      }
      StatsPeriodMode.WEEKLY -> {
        windowStartDay = todayEpochDay - (WEEKLY_BUCKETS * 7L - 1L)
        points =
          (0 until WEEKLY_BUCKETS).map { bucketIndex ->
            val weeksAgo = WEEKLY_BUCKETS - 1 - bucketIndex
            val bucketEnd = todayEpochDay - weeksAgo * 7L
            val bucketStart = bucketEnd - 6L
            val bucketLogs = logs.filter { it.epochDay in bucketStart..bucketEnd }
            val voice =
              bucketLogs.filter { it.sourceType == DhikrSourceType.VOICE }.sumOf { it.count }
            val adhkar =
              bucketLogs.filter { it.sourceType == DhikrSourceType.ADHKAR }.sumOf { it.count }
            val topLabel =
              bucketLogs
                .groupBy { it.label }
                .mapValues { (_, list) -> list.sumOf { it.count } }
                .maxByOrNull { it.value }
                ?.key
            val primary =
              when (weeksAgo) {
                0 -> "الحالي"
                1 -> "الماضي"
                else -> "أسبوع -${weeksAgo}"
              }
            StatsChartPoint(
              id = "week_$weeksAgo",
              primaryLabel = primary,
              secondaryLabel = DhikrDateUtils.weekRangeLabel(bucketStart, bucketEnd),
              voiceCount = voice,
              adhkarCount = adhkar,
              topDhikrLabel = topLabel,
            )
          }
      }
    }

    val periodLogs = logs.filter { it.epochDay in windowStartDay..todayEpochDay }
    val periodTotalCount = periodLogs.sumOf { it.count }
    val voiceTotalInPeriod =
      periodLogs.filter { it.sourceType == DhikrSourceType.VOICE }.sumOf { it.count }
    val adhkarTotalInPeriod =
      periodLogs.filter { it.sourceType == DhikrSourceType.ADHKAR }.sumOf { it.count }

    val averageRate =
      if (points.isNotEmpty()) periodTotalCount.toFloat() / points.size.toFloat() else 0f

    val peakPoint = points.maxByOrNull { it.totalCount }
    val peakPointLabel =
      if (peakPoint != null && peakPoint.totalCount > 0) {
        "${peakPoint.primaryLabel} (${peakPoint.secondaryLabel})"
      } else {
        "—"
      }
    val peakPointCount = peakPoint?.totalCount ?: 0

    val breakdown =
      if (periodTotalCount > 0) {
        periodLogs
          .groupBy { it.dhikrId }
          .map { (id, items) ->
            val sum = items.sumOf { it.count }
            val first = items.first()
            DhikrBreakdownItem(
              dhikrId = id,
              label = first.label,
              sourceType = first.sourceType,
              count = sum,
              shareFraction = (sum.toFloat() / periodTotalCount.toFloat()).coerceIn(0f, 1f),
            )
          }
          .sortedByDescending { it.count }
      } else {
        emptyList()
      }

    val safeSelectedIdx =
      (selectedPointIndex ?: (points.lastIndex.coerceAtLeast(0))).coerceIn(
        0,
        (points.size - 1).coerceAtLeast(0),
      )

    return DhikrStatsUiState(
      periodMode = periodMode,
      dailyWindowDays = dailyWindowDays,
      points = points,
      selectedPointIndex = safeSelectedIdx,
      todayCount = todayCount,
      thisWeekCount = thisWeekCount,
      periodTotalCount = periodTotalCount,
      averageRate = averageRate,
      peakPointLabel = peakPointLabel,
      peakPointCount = peakPointCount,
      currentStreakDays = currentStreakDays,
      weekOverWeekPercent = weekOverWeekPercent,
      voiceTotalInPeriod = voiceTotalInPeriod,
      adhkarTotalInPeriod = adhkarTotalInPeriod,
      breakdown = breakdown,
      hasAnyData = logs.any { it.count > 0 },
    )
  }

  private fun calculateStreakDays(
    logsByDay: Map<Long, List<DhikrDailyLog>>,
    todayEpochDay: Long,
  ): Int {
    fun hasActivity(day: Long): Boolean = logsByDay[day].orEmpty().sumOf { it.count } > 0

    var cursor =
      when {
        hasActivity(todayEpochDay) -> todayEpochDay
        hasActivity(todayEpochDay - 1L) -> todayEpochDay - 1L
        else -> return 0
      }

    var streak = 0
    while (hasActivity(cursor)) {
      streak++
      cursor--
    }
    return streak
  }
}

class DhikrStatsViewModel(
  private val quranRepository: QuranRepository,
  private val todayEpochDayProvider: () -> Long = { DhikrDateUtils.epochDayForMillis() },
) : ViewModel() {

  private val _periodMode = MutableStateFlow(StatsPeriodMode.DAILY)
  private val _dailyWindowDays = MutableStateFlow(7)
  private val _selectedPointIndex = MutableStateFlow<Int?>(null)

  val uiState: StateFlow<DhikrStatsUiState> =
    combine(
        quranRepository.dhikrDailyLogsFlow,
        _periodMode,
        _dailyWindowDays,
        _selectedPointIndex,
      ) { logs, mode, days, selectedIdx ->
        DhikrStatsAggregator.buildState(
          logs = logs,
          periodMode = mode,
          dailyWindowDays = days,
          selectedPointIndex = selectedIdx,
          todayEpochDay = todayEpochDayProvider(),
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue =
          DhikrStatsAggregator.buildState(
            logs = emptyList(),
            periodMode = StatsPeriodMode.DAILY,
            dailyWindowDays = 7,
            selectedPointIndex = null,
            todayEpochDay = todayEpochDayProvider(),
          ),
      )

  init {
    viewModelScope.launch { quranRepository.ensureInitialDataSeeded() }
  }

  fun selectPeriodMode(mode: StatsPeriodMode) {
    _periodMode.value = mode
    _selectedPointIndex.value = null
  }

  fun selectDailyWindowDays(days: Int) {
    _dailyWindowDays.value = if (days >= 14) 14 else 7
    _selectedPointIndex.value = null
  }

  fun selectPoint(index: Int) {
    _selectedPointIndex.value = index
  }

  companion object {
    fun factory(quranRepository: QuranRepository): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return DhikrStatsViewModel(quranRepository) as T
        }
      }
  }
}
