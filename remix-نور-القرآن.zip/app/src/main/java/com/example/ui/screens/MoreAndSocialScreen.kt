package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.RecordVoiceOver
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.SocialAccountsSection

private data class MoreMenuItem(
  val title: String,
  val subtitle: String,
  val icon: ImageVector,
  val accent: Color,
  val tag: String,
  val onClick: () -> Unit,
)

@Composable
fun MoreScreen(
  onOpenAudioLibrary: () -> Unit,
  onOpenVoiceDhikr: () -> Unit,
  onOpenKhatmah: () -> Unit,
  onOpenDailyPage: () -> Unit,
  onOpenBookmarks: () -> Unit,
  onOpenSearch: () -> Unit,
  onOpenSocial: () -> Unit,
  onOpenSettings: () -> Unit,
  onOpenDhikrStats: () -> Unit = {},
  onOpenReciters: () -> Unit = {},
  onOpenManageLocalReciters: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val menuItems =
    listOf(
      MoreMenuItem(
        title = "القرّاء والتلاوات",
        subtitle = "تصفح القرّاء والبحث عنهم وتشغيل تلاواتهم المضافة والمحدثة",
        icon = Icons.Rounded.RecordVoiceOver,
        accent = MaterialTheme.colorScheme.primary,
        tag = "more_reciters",
        onClick = onOpenReciters,
      ),
      MoreMenuItem(
        title = "إدارة القرّاء والتلاوات",
        subtitle = "إضافة قارئ جديد وربط تلاواته بالسور وتشغيلها محلياً",
        icon = Icons.AutoMirrored.Rounded.QueueMusic,
        accent = MaterialTheme.colorScheme.secondary,
        tag = "more_manage_reciters",
        onClick = onOpenManageLocalReciters,
      ),
      MoreMenuItem(
        title = "المكتبة الصوتية للقرآن",
        subtitle = "استمع إلى القرّاء مع التشغيل بالخلفية والتحميل دون إنترنت",
        icon = Icons.Rounded.Headphones,
        accent = MaterialTheme.colorScheme.secondary,
        tag = "more_audio",
        onClick = onOpenAudioLibrary,
      ),
      MoreMenuItem(
        title = "عداد الذكر الصوتي التلقائي",
        subtitle = "تسبيح تلقائي بالاستماع الصوتي دون ضغط أي زر",
        icon = Icons.Rounded.Mic,
        accent = Color(0xFF8C6214),
        tag = "more_voice_dhikr",
        onClick = onOpenVoiceDhikr,
      ),
      MoreMenuItem(
        title = "إحصائيات الأذكار والرسوم البيانية",
        subtitle = "رسوم بيانية تفاعلية لمعدل الذكر اليومي والأسبوعي",
        icon = Icons.Rounded.BarChart,
        accent = Color(0xFF0F5C4D),
        tag = "more_dhikr_stats",
        onClick = onOpenDhikrStats,
      ),
      MoreMenuItem(
        title = "ختمة القرآن الكريم",
        subtitle = "خطط لختمتك وتابع الصفحات اليومية ونسبة الإنجاز",
        icon = Icons.Rounded.CalendarMonth,
        accent = Color(0xFF0F5C4D),
        tag = "more_khatmah",
        onClick = onOpenKhatmah,
      ),
      MoreMenuItem(
        title = "صفحة القرآن اليومية للمشاركة",
        subtitle = "تصميم أنيق لصفحة اليوم جاهز للحفظ والمشاركة",
        icon = Icons.Rounded.Image,
        accent = Color(0xFF2E6F5E),
        tag = "more_daily_page",
        onClick = onOpenDailyPage,
      ),
      MoreMenuItem(
        title = "المفضلة والإشارات المرجعية",
        subtitle = "الآيات المحفوظة وملاحظاتك وتصنيفات التدبر والحفظ",
        icon = Icons.Rounded.Bookmark,
        accent = MaterialTheme.colorScheme.secondary,
        tag = "more_bookmarks",
        onClick = onOpenBookmarks,
      ),
      MoreMenuItem(
        title = "البحث الذكي الشامل",
        subtitle = "ابحث في السور والآيات والتفسير والأذكار من مكان واحد",
        icon = Icons.Rounded.Search,
        accent = Color(0xFF4A665A),
        tag = "more_search",
        onClick = onOpenSearch,
      ),
      MoreMenuItem(
        title = "تواصل معي",
        subtitle = "حسابات سناب شات وإنستغرام وتيك توك الرسمية",
        icon = Icons.Rounded.Person,
        accent = Color(0xFFE1306C),
        tag = "more_social",
        onClick = onOpenSocial,
      ),
      MoreMenuItem(
        title = "الإعدادات والتخصيص",
        subtitle = "المظهر، الخطوط، القارئ المفضل، والتنبيهات السبعة",
        icon = Icons.Rounded.Settings,
        accent = MaterialTheme.colorScheme.onSurfaceVariant,
        tag = "more_settings",
        onClick = onOpenSettings,
      ),
    )

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      item {
        Column(modifier = Modifier.padding(bottom = 6.dp)) {
          Text(
            text = "الأقسام والخدمات",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text = "جميع أدوات نور القرآن في متناول يدك",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      items(menuItems, key = { it.tag }) { item ->
        Surface(
          modifier =
            Modifier.fillMaxWidth()
              .testTag(item.tag)
              .clickable(onClick = item.onClick),
          shape = MaterialTheme.shapes.medium,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Surface(
              shape = CircleShape,
              color = item.accent.copy(alpha = 0.14f),
              modifier = Modifier.size(44.dp),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = item.icon,
                  contentDescription = null,
                  tint = item.accent,
                  modifier = Modifier.size(22.dp),
                )
              }
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = item.title,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = item.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    }
  }
}

@Composable
fun SocialScreen(modifier: Modifier = Modifier) {
  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    Column(
      modifier =
        Modifier.fillMaxSize()
          .widthIn(max = 720.dp)
          .verticalScroll(rememberScrollState())
          .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
      Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            text = "تواصل معي",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
          )
          Text(
            text = "يسعدني تواصلكم واقتراحاتكم لتطوير تطبيق نور القرآن عبر الحسابات الرسمية التالية:",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
          )
        }
      }

      SocialAccountsSection(title = "الحسابات الرسمية")

      Surface(
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Text(
            text = "نور القرآن — رفيقك إلى القرآن والطمأنينة",
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.primary,
          )
          Text(
            text = "نسأل الله أن ينفع بهذا العمل وأن يجعله خالصاً لوجهه الكريم.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    }
  }
}
