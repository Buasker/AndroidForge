package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.SearchMatchItem
import com.example.data.model.SearchResultType
import com.example.data.repository.QuranRepository
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

sealed interface SearchUiState {
  data object Idle : SearchUiState

  data object Searching : SearchUiState

  data class Results(val query: String, val matches: List<SearchMatchItem>) : SearchUiState

  data class Error(val message: String) : SearchUiState
}

@OptIn(FlowPreview::class)
class SearchViewModel(
  private val quranRepository: QuranRepository,
  private val preferencesRepository: UserPreferencesRepository,
) : ViewModel() {

  private val _query = MutableStateFlow("")
  val query: StateFlow<String> = _query.asStateFlow()

  private val _selectedTypeFilter = MutableStateFlow<SearchResultType?>(null)
  val selectedTypeFilter: StateFlow<SearchResultType?> = _selectedTypeFilter.asStateFlow()

  private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.Idle)
  val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

  val suggestedTopics = listOf("الرحمة", "الصبر", "النور", "الصلاة", "المغفرة", "الطمأنينة", "التقوى")

  init {
    viewModelScope.launch {
      _query.debounce(380).distinctUntilChanged().collectLatest { term ->
        executeSearch(term)
      }
    }
  }

  fun onQueryChange(newQuery: String) {
    _query.value = newQuery
    if (newQuery.trim().length < 2) {
      _uiState.value = SearchUiState.Idle
    }
  }

  fun selectTopic(topic: String) {
    _query.value = topic
  }

  fun selectTypeFilter(type: SearchResultType?) {
    _selectedTypeFilter.value = type
  }

  fun retry() {
    viewModelScope.launch { executeSearch(_query.value) }
  }

  private suspend fun executeSearch(term: String) {
    val trimmed = term.trim()
    if (trimmed.length < 2) {
      _uiState.value = SearchUiState.Idle
      return
    }
    _uiState.value = SearchUiState.Searching
    val settings = preferencesRepository.readerSettingsFlow.first()
    val result =
      quranRepository.smartSearch(
        query = trimmed,
        tafsirEdition = settings.tafsirEdition,
        translationEdition = settings.translationEdition,
      )
    _uiState.value =
      result.fold(
        onSuccess = { matches -> SearchUiState.Results(trimmed, matches) },
        onFailure = { err ->
          SearchUiState.Error(
            err.localizedMessage ?: "تعذر البحث حالياً. تأكد من الاتصال بالإنترنت."
          )
        },
      )
  }

  companion object {
    fun factory(
      quranRepository: QuranRepository,
      preferencesRepository: UserPreferencesRepository,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return SearchViewModel(quranRepository, preferencesRepository) as T
        }
      }
  }
}
