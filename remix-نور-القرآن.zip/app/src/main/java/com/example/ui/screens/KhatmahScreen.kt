package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CalendarMonth
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.KhatmahPlan
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.ceil

@Composable
fun KhatmahScreen(
  plans: List<KhatmahPlan>,
  todayEpochDay: Long,
  onCreatePlan: (title: String, durationDays: Int, startEpochDay: Long) -> Unit,
  onUpdateSchedule: (plan: KhatmahPlan, newTitle: String, newDurationDays: Int) -> Unit,
  onMarkPagesRead: (plan: KhatmahPlan, newPagesRead: Int) -> Unit,
  onTogglePause: (KhatmahPlan) -> Unit,
  onDeletePlan: (Long) -> Unit,
  onOpenMushafPage: (Int) -> Unit,
  modifier: Modifier = Modifier,
) {
  var showCreateDialog by remember { mutableStateOf(false) }
  var editingPlan by remember { mutableStateOf<KhatmahPlan?>(null) }
  var deletingPlan by remember { mutableStateOf<KhatmahPlan?>(null) }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0.dp),
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showCreateDialog = true },
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        modifier = Modifier.testTag("khatmah_create_fab"),
      ) {
        Icon(Icons.Rounded.Add, contentDescription = "إنشاء ختمة جديدة")
      }
    },
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      Column(modifier = Modifier.fillMaxSize().widthIn(max = 720.dp)) {
        Column(
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
          verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
          Text(
            text = "ختمة القرآن الكريم",
            style = MaterialTheme.typography.headlineLarge,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text = "خطط لختمتك وتابع الورد اليومي والصفحات المتبقية خطوة بخطوة",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        if (plans.isEmpty()) {
          Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Surface(
              shape = CircleShape,
              color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
              modifier = Modifier.size(76.dp),
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = Icons.Rounded.CalendarMonth,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(36.dp),
                )
              }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Text(
              text = "لا توجد ختمة نشطة بعد",
              style = MaterialTheme.typography.headlineMedium,
              color = MaterialTheme.colorScheme.onSurface,
              textAlign = TextAlign.Center,
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "أنشئ خطة ختمة جديدة باختيار المدة المناسبة لك وسيتم حساب عدد الصفحات اليومي تلقائياً.",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center,
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
              onClick = { showCreateDialog = true },
              modifier = Modifier.testTag("khatmah_empty_create_button"),
            ) {
              Icon(Icons.Rounded.Add, contentDescription = null)
              Spacer(modifier = Modifier.width(8.dp))
              Text("إنشاء ختمة جديدة")
            }
          }
        } else {
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 104.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
          ) {
            items(plans, key = { it.id }) { plan ->
              KhatmahPlanCard(
                plan = plan,
                todayEpochDay = todayEpochDay,
                onMarkPagesRead = { newPages -> onMarkPagesRead(plan, newPages) },
                onTogglePause = { onTogglePause(plan) },
                onEdit = { editingPlan = plan },
                onDelete = { deletingPlan = plan },
                onOpenMushaf = {
                  val targetPage = (plan.pagesRead + 1).coerceIn(1, plan.totalPages)
                  onOpenMushafPage(targetPage)
                },
              )
            }
          }
        }
      }
    }
  }

  if (showCreateDialog) {
    KhatmahPlanDialog(
      title = "إنشاء ختمة جديدة",
      initialName = "ختمة القرآن الكريم",
      initialDurationDays = 30,
      todayEpochDay = todayEpochDay,
      showStartDateSelector = true,
      onDismiss = { showCreateDialog = false },
      onConfirm = { name, days, startDay ->
        onCreatePlan(name, days, startDay)
        showCreateDialog = false
      },
    )
  }

  val planToEdit = editingPlan
  if (planToEdit != null) {
    val currentDays = (planToEdit.endDateEpochDay - planToEdit.startDateEpochDay).toInt().coerceIn(1, 365)
    KhatmahPlanDialog(
      title = "تعديل جدول الختمة",
      initialName = planToEdit.title,
      initialDurationDays = currentDays,
      todayEpochDay = planToEdit.startDateEpochDay,
      showStartDateSelector = false,
      onDismiss = { editingPlan = null },
      onConfirm = { name, days, _ ->
        onUpdateSchedule(planToEdit, name, days)
        editingPlan = null
      },
    )
  }

  val planToDelete = deletingPlan
  if (planToDelete != null) {
    AlertDialog(
      onDismissRequest = { deletingPlan = null },
      title = { Text("حذف الختمة") },
      text = { Text("هل تريد حذف «${planToDelete.title}»؟ لا يمكن التراجع عن هذا الإجراء.") },
      confirmButton = {
        TextButton(
          onClick = {
            onDeletePlan(planToDelete.id)
            deletingPlan = null
          }
        ) {
          Text("حذف", color = MaterialTheme.colorScheme.error)
        }
      },
      dismissButton = {
        TextButton(onClick = { deletingPlan = null }) { Text("إلغاء") }
      },
    )
  }
}

@Composable
private fun KhatmahPlanCard(
  plan: KhatmahPlan,
  todayEpochDay: Long,
  onMarkPagesRead: (Int) -> Unit,
  onTogglePause: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit,
  onOpenMushaf: () -> Unit,
) {
  val remainingPages = (plan.totalPages - plan.pagesRead).coerceAtLeast(0)
  val remainingDays = (plan.endDateEpochDay - todayEpochDay).coerceAtLeast(1L).toInt()
  val dailyTarget =
    if (remainingPages == 0) 0 else ceil(remainingPages.toDouble() / remainingDays.toDouble()).toInt()
  val progress = (plan.pagesRead.toFloat() / plan.totalPages.toFloat()).coerceIn(0f, 1f)
  val percent = (progress * 100).toInt()
  val isCompleted = remainingPages == 0

  val dateFormat = remember { SimpleDateFormat("dd MMM", Locale.forLanguageTag("ar")) }
  val startText = remember(plan.startDateEpochDay) {
    dateFormat.format(Date(TimeUnit.DAYS.toMillis(plan.startDateEpochDay)))
  }
  val endText = remember(plan.endDateEpochDay) {
    dateFormat.format(Date(TimeUnit.DAYS.toMillis(plan.endDateEpochDay)))
  }

  Surface(
    modifier = Modifier.fillMaxWidth().testTag("khatmah_card_${plan.id}"),
    shape = MaterialTheme.shapes.large,
    color = MaterialTheme.colorScheme.surface,
    border =
      BorderStroke(
        width = if (!plan.isPaused && !isCompleted) 1.5.dp else 1.dp,
        color =
          if (!plan.isPaused && !isCompleted) MaterialTheme.colorScheme.primary
          else MaterialTheme.colorScheme.outlineVariant,
      ),
  ) {
    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = plan.title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = "من $startText إلى $endText",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
        Surface(
          shape = MaterialTheme.shapes.small,
          color =
            when {
              isCompleted -> MaterialTheme.colorScheme.secondaryContainer
              plan.isPaused -> MaterialTheme.colorScheme.surfaceVariant
              else -> MaterialTheme.colorScheme.primaryContainer
            },
        ) {
          Text(
            text =
              when {
                isCompleted -> "مكتملة ✓"
                plan.isPaused -> "متوقفة مؤقتاً"
                else -> "نشطة"
              },
            style = MaterialTheme.typography.labelMedium,
            color =
              when {
                isCompleted -> MaterialTheme.colorScheme.onSecondaryContainer
                plan.isPaused -> MaterialTheme.colorScheme.onSurfaceVariant
                else -> MaterialTheme.colorScheme.onPrimaryContainer
              },
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
          )
        }
      }

      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = "${plan.pagesRead} من ${plan.totalPages} صفحة",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary,
          )
          Text(
            text = "$percent%",
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.secondary,
          )
        }
        LinearProgressIndicator(
          progress = { progress },
          modifier = Modifier.fillMaxWidth().height(9.dp).clip(CircleShape),
          color = MaterialTheme.colorScheme.primary,
          trackColor = MaterialTheme.colorScheme.surfaceVariant,
        )
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        KhatmahStatPill(
          label = "الورد اليومي",
          value = if (isCompleted) "تم" else "$dailyTarget صفحة",
          modifier = Modifier.weight(1f),
        )
        KhatmahStatPill(
          label = "المتبقي",
          value = "$remainingPages صفحة",
          modifier = Modifier.weight(1f),
        )
        KhatmahStatPill(
          label = "الأيام المتبقية",
          value = "$remainingDays يوم",
          modifier = Modifier.weight(1f),
        )
      }

      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
          text = "تسجيل الصفحات المقروءة:",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          OutlinedButton(
            onClick = { onMarkPagesRead(plan.pagesRead - 1) },
            enabled = plan.pagesRead > 0,
            contentPadding = PaddingValues(horizontal = 10.dp),
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Icon(Icons.Rounded.Remove, contentDescription = "إنقاص صفحة", modifier = Modifier.size(16.dp))
          }
          Slider(
            value = plan.pagesRead.toFloat(),
            onValueChange = { onMarkPagesRead(it.toInt()) },
            valueRange = 0f..plan.totalPages.toFloat(),
            modifier = Modifier.weight(1f),
          )
          OutlinedButton(
            onClick = { onMarkPagesRead(plan.pagesRead + 1) },
            enabled = plan.pagesRead < plan.totalPages,
            contentPadding = PaddingValues(horizontal = 10.dp),
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Icon(Icons.Rounded.Add, contentDescription = "إضافة صفحة", modifier = Modifier.size(16.dp))
          }
        }
        if (!isCompleted && dailyTarget > 0) {
          TextButton(
            onClick = { onMarkPagesRead(plan.pagesRead + dailyTarget) },
            modifier = Modifier.align(Alignment.End),
          ) {
            Text("إتمام ورد اليوم (+$dailyTarget صفحة)")
          }
        }
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Button(
          onClick = onOpenMushaf,
          modifier = Modifier.weight(1f).testTag("khatmah_open_mushaf_${plan.id}"),
        ) {
          Icon(Icons.AutoMirrored.Rounded.MenuBook, contentDescription = null, modifier = Modifier.size(18.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text("قراءة الورد في المصحف")
        }
        Spacer(modifier = Modifier.width(8.dp))
        IconButton(onClick = onTogglePause, modifier = Modifier.minimumInteractiveComponentSize()) {
          Icon(
            imageVector = if (plan.isPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
            contentDescription = if (plan.isPaused) "استئناف" else "إيقاف مؤقت",
          )
        }
        IconButton(onClick = onEdit, modifier = Modifier.minimumInteractiveComponentSize()) {
          Icon(Icons.Rounded.Edit, contentDescription = "تعديل الجدول")
        }
        IconButton(onClick = onDelete, modifier = Modifier.minimumInteractiveComponentSize()) {
          Icon(
            Icons.Rounded.DeleteOutline,
            contentDescription = "حذف الختمة",
            tint = MaterialTheme.colorScheme.error,
          )
        }
      }
    }
  }
}

@Composable
private fun KhatmahStatPill(
  label: String,
  value: String,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = MaterialTheme.shapes.small,
    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
      )
      Text(
        text = value,
        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
      )
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun KhatmahPlanDialog(
  title: String,
  initialName: String,
  initialDurationDays: Int,
  todayEpochDay: Long,
  showStartDateSelector: Boolean,
  onDismiss: () -> Unit,
  onConfirm: (name: String, days: Int, startEpochDay: Long) -> Unit,
) {
  var name by remember { mutableStateOf(initialName) }
  var daysText by remember { mutableStateOf(initialDurationDays.toString()) }
  var startOffsetDays by remember { mutableIntStateOf(0) }
  val presets = listOf(7, 15, 30, 60)

  val parsedDays = daysText.toIntOrNull()?.coerceIn(1, 365) ?: 30
  val estimatedDaily = ceil(604.0 / parsedDays).toInt()

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(title) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("اسم الختمة") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        Text(
          text = "اختر مدة الختمة بالأيام:",
          style = MaterialTheme.typography.labelLarge,
        )
        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          presets.forEach { preset ->
            FilterChip(
              selected = parsedDays == preset,
              onClick = { daysText = preset.toString() },
              label = { Text("$preset يوم") },
            )
          }
        }
        OutlinedTextField(
          value = daysText,
          onValueChange = { input ->
            if (input.all { it.isDigit() } && input.length <= 3) {
              daysText = input
            }
          },
          label = { Text("عدد الأيام (مخصص)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        if (showStartDateSelector) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
              selected = startOffsetDays == 0,
              onClick = { startOffsetDays = 0 },
              label = { Text("البداية اليوم") },
            )
            FilterChip(
              selected = startOffsetDays == 1,
              onClick = { startOffsetDays = 1 },
              label = { Text("البداية غداً") },
            )
          }
        }
        Surface(
          shape = MaterialTheme.shapes.small,
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Text(
            text = "الورد اليومي التقديري: $estimatedDaily صفحة يومياً لإتمام ٦٠٤ صفحات",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(10.dp),
          )
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onConfirm(name, parsedDays, todayEpochDay + startOffsetDays)
        }
      ) {
        Text("حفظ")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("إلغاء") }
    },
  )
}
