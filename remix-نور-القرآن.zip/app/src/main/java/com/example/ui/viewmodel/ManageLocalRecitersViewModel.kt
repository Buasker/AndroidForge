package com.example.ui.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioPlaybackState
import com.example.audio.QuranAudioPlayer
import com.example.data.firebase.ExternalAudioMetadata
import com.example.data.local.QuranSeedData
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.LocalRecitationTrack
import com.example.data.model.LocalReciter
import com.example.data.model.ReciterOption
import com.example.data.model.SurahInfo
import com.example.data.repository.QuranRepository
import com.example.dhikr.DhikrSpeechMatcher
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ManageLocalRecitersViewModel(
  private val quranRepository: QuranRepository,
  private val preferencesRepository: UserPreferencesRepository,
  private val audioPlayer: QuranAudioPlayer,
) : ViewModel() {

  private val _searchQuery = MutableStateFlow("")
  val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

  private val _selectedReciterId = MutableStateFlow<String?>(null)
  val selectedReciterId: StateFlow<String?> = _selectedReciterId.asStateFlow()

  private val _isBusy = MutableStateFlow(false)
  val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

  private val _isProbingUrl = MutableStateFlow(false)
  val isProbingUrl: StateFlow<Boolean> = _isProbingUrl.asStateFlow()

  private val _probeResult = MutableStateFlow<Result<ExternalAudioMetadata>?>(null)
  val probeResult: StateFlow<Result<ExternalAudioMetadata>?> = _probeResult.asStateFlow()

  private val _statusMessage = MutableStateFlow<String?>(null)
  val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

  val allLocalReciters: StateFlow<List<LocalReciter>> =
    quranRepository.localRecitersFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList(),
    )

  val filteredLocalReciters: StateFlow<List<LocalReciter>> =
    combine(allLocalReciters, _searchQuery) { list, query ->
        val clean = query.trim()
        if (clean.isEmpty()) {
          list
        } else {
          val norm = DhikrSpeechMatcher.normalizeArabic(clean)
          list.filter { reciter ->
            reciter.arabicName.contains(clean, ignoreCase = true) ||
              reciter.description.contains(clean, ignoreCase = true) ||
              reciter.riwayah.contains(clean, ignoreCase = true) ||
              (norm.isNotEmpty() &&
                (DhikrSpeechMatcher.normalizeArabic(reciter.arabicName).contains(norm) ||
                  DhikrSpeechMatcher.normalizeArabic(reciter.description).contains(norm) ||
                  DhikrSpeechMatcher.normalizeArabic(reciter.riwayah).contains(norm)))
          }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  val trackCountByReciter: StateFlow<Map<String, Int>> =
    quranRepository.allLocalRecitationsFlow
      .map { tracks -> tracks.groupingBy { it.reciterId }.eachCount() }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyMap(),
      )

  val selectedReciter: StateFlow<LocalReciter?> =
    combine(allLocalReciters, _selectedReciterId) { list, id ->
        if (id.isNullOrBlank()) null else list.firstOrNull { it.id == id }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null,
      )

  val recitationsForSelected: StateFlow<List<LocalRecitationTrack>> =
    _selectedReciterId
      .flatMapLatest { id ->
        if (id.isNullOrBlank()) flowOf(emptyList())
        else quranRepository.localRecitationsForReciterFlow(id)
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  val preferredReciterId: StateFlow<String> =
    preferencesRepository.readerSettingsFlow
      .map { it.reciterIdentifier }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = "ar.alafasy",
      )

  val surahs: StateFlow<List<SurahInfo>> =
    quranRepository.surahsFlow
      .map { list ->
        list.ifEmpty {
          QuranSeedData.surahs.map {
            SurahInfo(
              number = it.number,
              arabicName = it.arabicName,
              englishName = it.englishName,
              englishNameTranslation = it.englishNameTranslation,
              numberOfAyahs = it.numberOfAyahs,
              revelationType = it.revelationType,
            )
          }
        }
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue =
          QuranSeedData.surahs.map {
            SurahInfo(
              number = it.number,
              arabicName = it.arabicName,
              englishName = it.englishName,
              englishNameTranslation = it.englishNameTranslation,
              numberOfAyahs = it.numberOfAyahs,
              revelationType = it.revelationType,
            )
          },
      )

  val audioState: StateFlow<AudioPlaybackState> = audioPlayer.state

  init {
    viewModelScope.launch { quranRepository.ensureInitialDataSeeded() }
  }

  fun onSearchQueryChange(query: String) {
    _searchQuery.value = query
  }

  fun openReciter(reciterId: String) {
    _selectedReciterId.value = reciterId
    _probeResult.value = null
  }

  fun closeReciterDetail() {
    _selectedReciterId.value = null
    _probeResult.value = null
  }

  fun clearMessage() {
    _statusMessage.value = null
  }

  fun clearProbeResult() {
    _probeResult.value = null
  }

  fun probeAudioUrl(rawUrl: String) {
    if (_isProbingUrl.value) return
    val clean = rawUrl.trim()
    if (clean.isEmpty()) {
      _probeResult.value = Result.failure(IllegalArgumentException("يرجى إدخال رابط الصوت أولاً."))
      return
    }
    viewModelScope.launch {
      _isProbingUrl.value = true
      val probeTarget =
        runCatching { quranRepository.resolveUrlFromFullSurahSetting(clean, 1) }
          .getOrElse { clean }
      _probeResult.value = quranRepository.verifyAudioUrlReachable(probeTarget)
      _isProbingUrl.value = false
    }
  }

  fun importPhotoFromUri(uri: Uri, onImported: (String) -> Unit, onError: (String) -> Unit) {
    viewModelScope.launch {
      _isBusy.value = true
      val result = quranRepository.saveLocalReciterPhotoFromUri(uri)
      _isBusy.value = false
      result
        .onSuccess { path ->
          onImported(path)
          _statusMessage.value = "تم حفظ صورة القارئ بنجاح"
        }
        .onFailure { err ->
          val msg = err.localizedMessage ?: "تعذر استيراد الصورة"
          onError(msg)
          _statusMessage.value = msg
        }
    }
  }

  fun saveReciter(
    editingId: String?,
    arabicName: String,
    description: String,
    riwayah: String,
    photoPathOrUrl: String,
    fullSurahBaseUrl: String,
    onResult: (Result<LocalReciter>) -> Unit,
  ) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result =
        quranRepository.saveLocalReciter(
          editingId = editingId,
          arabicName = arabicName,
          description = description,
          riwayah = riwayah,
          photoPathOrUrl = photoPathOrUrl,
          fullSurahBaseUrl = fullSurahBaseUrl,
        )
      _isBusy.value = false
      result
        .onSuccess { saved ->
          _statusMessage.value =
            if (editingId == null) "تمت إضافة القارئ «${saved.arabicName}» وحفظه محلياً"
            else "تم تحديث بيانات القارئ «${saved.arabicName}»"
        }
        .onFailure { err ->
          _statusMessage.value = err.localizedMessage ?: "تعذر حفظ بيانات القارئ"
        }
      onResult(result)
    }
  }

  fun deleteReciter(reciter: LocalReciter) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      if (audioPlayer.state.value.reciterId == reciter.id) {
        audioPlayer.stop()
      }
      if (preferredReciterId.value == reciter.id) {
        preferencesRepository.updateReciter("ar.alafasy")
      }
      val result = quranRepository.deleteLocalReciter(reciter.id)
      _isBusy.value = false
      result
        .onSuccess {
          if (_selectedReciterId.value == reciter.id) {
            _selectedReciterId.value = null
          }
          _statusMessage.value = "تم حذف القارئ «${reciter.arabicName}» وجميع تلاواته"
        }
        .onFailure { err ->
          _statusMessage.value = err.localizedMessage ?: "تعذر حذف القارئ"
        }
    }
  }

  fun saveRecitation(
    reciterId: String,
    surahNumber: Int,
    audioUrl: String,
    notes: String,
    isEdit: Boolean,
    onResult: (Result<LocalRecitationTrack>) -> Unit,
  ) {
    if (_isBusy.value) return
    viewModelScope.launch {
      _isBusy.value = true
      val result =
        quranRepository.saveLocalRecitation(
          reciterId = reciterId,
          surahNumber = surahNumber,
          audioUrl = audioUrl,
          notes = notes,
          isEdit = isEdit,
        )
      _isBusy.value = false
      result
        .onSuccess { track ->
          _statusMessage.value =
            if (isEdit) "تم تحديث تلاوة ${track.surahArabicName}"
            else "تمت إضافة تلاوة ${track.surahArabicName} بنجاح"
        }
        .onFailure { err ->
          _statusMessage.value = err.localizedMessage ?: "تعذر حفظ التلاوة"
        }
      onResult(result)
    }
  }

  fun deleteRecitation(reciterId: String, track: LocalRecitationTrack) {
    viewModelScope.launch {
      val currentAudio = audioPlayer.state.value
      val trackId = "local_${reciterId}_${track.surahNumber}"
      if (currentAudio.isActive && currentAudio.trackId == trackId) {
        audioPlayer.stop()
      }
      quranRepository.deleteLocalRecitation(reciterId, track.surahNumber)
      _statusMessage.value = "تم حذف تلاوة ${track.surahArabicName}"
    }
  }

  fun setPreferredReciter(reciterId: String) {
    viewModelScope.launch {
      preferencesRepository.updateReciter(reciterId)
      audioPlayer.updateKnownReciters(
        RecitersViewModel.mergePublishedAndCatalogReciters(emptyList(), allLocalReciters.value)
      )
      _statusMessage.value = "تم تعيين القارئ كمفضّل في المصحف والمكتبة الصوتية"
    }
  }

  fun playLocalTrack(reciter: LocalReciter, track: LocalRecitationTrack) {
    val trackId = "local_${reciter.id}_${track.surahNumber}"
    val current = audioPlayer.state.value
    if (
      current.isActive &&
        current.trackId == trackId &&
        current.reciterId == reciter.id
    ) {
      audioPlayer.togglePlayPause()
    } else {
      syncReciterInPlayer(reciter)
      audioPlayer.playCustomRecitation(
        trackId = trackId,
        surahNumber = track.surahNumber,
        surahArabicName = track.surahArabicName,
        reciterId = reciter.id,
        reciterDisplayName = reciter.arabicName,
        audioUrl = track.audioUrl,
        description = track.notes,
      )
    }
  }

  fun playFullSurahSample(reciter: LocalReciter, surahNumber: Int = 1) {
    val surah =
      surahs.value.firstOrNull { it.number == surahNumber } ?: return
    val current = audioPlayer.state.value
    if (
      current.isActive &&
        current.trackId.isEmpty() &&
        current.surahNumber == surah.number &&
        current.reciterId == reciter.id
    ) {
      audioPlayer.togglePlayPause()
    } else {
      syncReciterInPlayer(reciter)
      audioPlayer.playFullSurah(surah, reciter.id, reciter.arabicName)
    }
  }

  private fun syncReciterInPlayer(reciter: LocalReciter) {
    val merged =
      RecitersViewModel.mergePublishedAndCatalogReciters(
        emptyList(),
        (allLocalReciters.value + reciter).distinctBy { it.id },
      )
    audioPlayer.updateKnownReciters(merged)
  }

  fun togglePlayPause() = audioPlayer.togglePlayPause()

  fun seekTo(ms: Int) = audioPlayer.seekTo(ms)

  fun seekBySeconds(sec: Int) = audioPlayer.seekBySeconds(sec)

  fun stopPlayback() = audioPlayer.stop()

  companion object {
    fun factory(
      quranRepository: QuranRepository,
      preferencesRepository: UserPreferencesRepository,
      audioPlayer: QuranAudioPlayer,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return ManageLocalRecitersViewModel(
            quranRepository = quranRepository,
            preferencesRepository = preferencesRepository,
            audioPlayer = audioPlayer,
          ) as T
        }
      }
  }
}
