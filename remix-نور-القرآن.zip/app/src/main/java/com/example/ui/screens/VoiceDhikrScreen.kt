package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BarChart
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Hearing
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.MicOff
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.model.DhikrPhraseItem
import com.example.dhikr.VoiceDhikrStatus
import com.example.dhikr.VoiceListeningPhase
import com.example.ui.theme.AmiriFontFamily

@Composable
fun VoiceDhikrScreen(
  status: VoiceDhikrStatus,
  counters: List<DhikrPhraseItem>,
  onStartListening: () -> Unit,
  onPauseListening: () -> Unit,
  onPermissionDenied: () -> Unit,
  onResetSingleCounter: (String) -> Unit,
  onResetAllCounters: () -> Unit,
  onOpenStats: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  var showResetAllConfirm by remember { mutableStateOf(false) }
  var pendingSingleReset by remember { mutableStateOf<DhikrPhraseItem?>(null) }
  var showPermissionRationale by remember { mutableStateOf(false) }

  val micPermissionLauncher =
    rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
      if (granted) {
        onStartListening()
      } else {
        onPermissionDenied()
        showPermissionRationale = true
      }
    }

  val infiniteTransition = rememberInfiniteTransition(label = "micPulse")
  val pulseScale by
    infiniteTransition.animateFloat(
      initialValue = 1f,
      targetValue = 1.12f,
      animationSpec = infiniteRepeatable(tween(750), RepeatMode.Reverse),
      label = "pulseScale",
    )

  val phaseBadgeText =
    when (status.phase) {
      VoiceListeningPhase.IDLE -> "متوقف حالياً"
      VoiceListeningPhase.STARTING -> "جاري تشغيل الميكروفون…"
      VoiceListeningPhase.LISTENING -> "الميكروفون يعمل ويستمع"
      VoiceListeningPhase.RECOGNIZING -> "جاري التعرف على الصوت"
      VoiceListeningPhase.NO_SPEECH_MATCH -> "لم يتم التعرف على الكلام"
      VoiceListeningPhase.MICROPHONE_ERROR -> "تعذر تشغيل الميكروفون"
    }

  val phaseContainerColor =
    when (status.phase) {
      VoiceListeningPhase.LISTENING -> MaterialTheme.colorScheme.primaryContainer
      VoiceListeningPhase.RECOGNIZING -> MaterialTheme.colorScheme.secondaryContainer
      VoiceListeningPhase.NO_SPEECH_MATCH -> MaterialTheme.colorScheme.tertiaryContainer
      VoiceListeningPhase.MICROPHONE_ERROR -> MaterialTheme.colorScheme.errorContainer
      VoiceListeningPhase.STARTING,
      VoiceListeningPhase.IDLE -> MaterialTheme.colorScheme.surfaceContainerHigh
    }

  val phaseContentColor =
    when (status.phase) {
      VoiceListeningPhase.LISTENING -> MaterialTheme.colorScheme.onPrimaryContainer
      VoiceListeningPhase.RECOGNIZING -> MaterialTheme.colorScheme.onSecondaryContainer
      VoiceListeningPhase.NO_SPEECH_MATCH -> MaterialTheme.colorScheme.onTertiaryContainer
      VoiceListeningPhase.MICROPHONE_ERROR -> MaterialTheme.colorScheme.onErrorContainer
      VoiceListeningPhase.STARTING,
      VoiceListeningPhase.IDLE -> MaterialTheme.colorScheme.onSurfaceVariant
    }

  val statusIcon =
    when (status.phase) {
      VoiceListeningPhase.RECOGNIZING -> Icons.Rounded.Hearing
      VoiceListeningPhase.LISTENING,
      VoiceListeningPhase.STARTING,
      VoiceListeningPhase.NO_SPEECH_MATCH ->
        if (status.isListening) Icons.Rounded.GraphicEq else Icons.Rounded.MicOff
      VoiceListeningPhase.MICROPHONE_ERROR -> Icons.Rounded.ErrorOutline
      VoiceListeningPhase.IDLE -> Icons.Rounded.MicOff
    }

  Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
    LazyColumn(
      modifier = Modifier.fillMaxSize().widthIn(max = 720.dp).testTag("voice_dhikr_list"),
      contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "عداد الذكر الصوتي التلقائي",
              style = MaterialTheme.typography.headlineLarge,
              color = MaterialTheme.colorScheme.onBackground,
              modifier = Modifier.weight(1f),
            )
            OutlinedButton(
              onClick = onOpenStats,
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
              modifier =
                Modifier.minimumInteractiveComponentSize().testTag("open_dhikr_stats_button"),
            ) {
              Icon(
                imageVector = Icons.Rounded.BarChart,
                contentDescription = null,
                modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text("الإحصائيات", style = MaterialTheme.typography.labelLarge)
            }
          }
          Text(
            text =
              "يستمع التطبيق لصوتك باللغة العربية ويحصي الأذكار تلقائياً دون لمس الشاشة، ويستمر في الاستماع حتى عند إطفاء الشاشة أو التنقل داخل التطبيق",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      // Listening Control Card
      item {
        Surface(
          shape = MaterialTheme.shapes.large,
          color =
            if (status.isListening) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)
            else MaterialTheme.colorScheme.surface,
          border =
            BorderStroke(
              1.5.dp,
              when {
                status.phase == VoiceListeningPhase.MICROPHONE_ERROR -> MaterialTheme.colorScheme.error
                status.isListening -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.outlineVariant
              },
            ),
          modifier = Modifier.fillMaxWidth().testTag("voice_listening_panel"),
        ) {
          Column(
            modifier = Modifier.padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Surface(
              shape = CircleShape,
              color =
                when {
                  status.phase == VoiceListeningPhase.MICROPHONE_ERROR ->
                    MaterialTheme.colorScheme.error
                  status.isListening -> MaterialTheme.colorScheme.primary
                  else -> MaterialTheme.colorScheme.surfaceContainerHigh
                },
              modifier =
                Modifier.size(72.dp).let { mod ->
                  if (status.isListening) mod.scale(pulseScale) else mod
                },
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(
                  imageVector = statusIcon,
                  contentDescription = phaseBadgeText,
                  tint =
                    when {
                      status.phase == VoiceListeningPhase.MICROPHONE_ERROR ->
                        MaterialTheme.colorScheme.onError
                      status.isListening -> MaterialTheme.colorScheme.onPrimary
                      else -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                  modifier = Modifier.size(34.dp),
                )
              }
            }

            Surface(
              shape = MaterialTheme.shapes.small,
              color = phaseContainerColor,
            ) {
              Text(
                text = phaseBadgeText,
                style = MaterialTheme.typography.labelLarge,
                color = phaseContentColor,
                modifier =
                  Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    .testTag("voice_status_phase_badge"),
              )
            }

            Text(
              text = status.statusMessage,
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onSurface,
              textAlign = TextAlign.Center,
              modifier = Modifier.testTag("voice_status_message"),
            )

            if (status.lastHeardText.isNotBlank()) {
              Surface(
                shape = MaterialTheme.shapes.small,
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier.fillMaxWidth(),
              ) {
                Text(
                  text = "ما سُمع: «${status.lastHeardText}»",
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.primary,
                  textAlign = TextAlign.Center,
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                )
              }
            }

            val diag = status.diagnostics
            if (
              diag.recognizedText.isNotBlank() ||
                diag.matchedDhikrTitles.isNotEmpty() ||
                !diag.rejectionReason.isNullOrBlank() ||
                diag.dbSaveStatus.isNotBlank() ||
                diag.eventSummary.isNotBlank()
            ) {
              Surface(
                shape = MaterialTheme.shapes.small,
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
                modifier = Modifier.fillMaxWidth().testTag("voice_diagnostics_panel"),
              ) {
                Column(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                  verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                  Text(
                    text = "التشخيص المؤقت لمحرك الصوت:",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                  )
                  if (diag.recognizedText.isNotBlank()) {
                    Text(
                      text = "• النص المعترف به: «${diag.recognizedText}»",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurface,
                    )
                  }
                  if (diag.matchedDhikrTitles.isNotEmpty()) {
                    Text(
                      text = "• الذكر المطابق: ${diag.matchedDhikrTitles.joinToString("، ")}",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.primary,
                    )
                  }
                  if (!diag.rejectionReason.isNullOrBlank()) {
                    Text(
                      text = "• سبب عدم الاحتساب/الرفض: ${diag.rejectionReason}",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.error,
                    )
                  }
                  if (diag.dbSaveStatus.isNotBlank()) {
                    Text(
                      text = "• حفظ العداد: ${diag.dbSaveStatus}",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                  if (diag.eventSummary.isNotBlank()) {
                    Text(
                      text = "• الحالة: ${diag.eventSummary}",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                }
              }
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Button(
                onClick = {
                  if (status.isListening) {
                    onPauseListening()
                  } else {
                    val granted =
                      ContextCompat.checkSelfPermission(
                        context,
                        Manifest.permission.RECORD_AUDIO,
                      ) == PackageManager.PERMISSION_GRANTED
                    if (granted) {
                      onStartListening()
                    } else {
                      micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }
                  }
                },
                colors =
                  ButtonDefaults.buttonColors(
                    containerColor =
                      if (status.isListening) MaterialTheme.colorScheme.error
                      else MaterialTheme.colorScheme.primary
                  ),
                modifier = Modifier.weight(1.6f).testTag("toggle_voice_listening_button"),
              ) {
                Icon(
                  imageVector = if (status.isListening) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                  contentDescription = null,
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (status.isListening) "إيقاف الاستماع مؤقتاً" else "بدء الاستماع الصوتي")
              }

              OutlinedButton(
                onClick = { showResetAllConfirm = true },
                modifier = Modifier.weight(1f).testTag("reset_all_dhikr_button"),
              ) {
                Icon(
                  imageVector = Icons.Rounded.Refresh,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("تصفير الكل")
              }
            }
          }
        }
      }

      // Independent Voice Dhikr Cards (Voice-driven ONLY — no tap-to-increment)
      items(counters, key = { it.id }) { item ->
        val justMatched = status.lastMatchedDhikrId == item.id && status.isListening
        val cardColor by
          animateColorAsState(
            targetValue =
              if (justMatched) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.65f)
              else MaterialTheme.colorScheme.surface,
            label = "dhikrCardBg",
          )

        Surface(
          modifier = Modifier.fillMaxWidth().testTag("voice_dhikr_card_${item.id}"),
          shape = MaterialTheme.shapes.medium,
          color = cardColor,
          border =
            BorderStroke(
              if (justMatched) 1.5.dp else 1.dp,
              if (justMatched) MaterialTheme.colorScheme.secondary
              else MaterialTheme.colorScheme.outlineVariant,
            ),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = item.arabicTitle,
                fontFamily = AmiriFontFamily,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = item.subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Surface(
                shape = CircleShape,
                color = MaterialTheme.colorScheme.primaryContainer,
              ) {
                Text(
                  text = item.count.toString(),
                  style = MaterialTheme.typography.headlineLarge,
                  color = MaterialTheme.colorScheme.onPrimaryContainer,
                  modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp),
                )
              }
              IconButton(
                onClick = { pendingSingleReset = item },
                modifier = Modifier.minimumInteractiveComponentSize(),
              ) {
                Icon(
                  imageVector = Icons.Rounded.Refresh,
                  contentDescription = "تصفير ${item.arabicTitle}",
                  tint = MaterialTheme.colorScheme.onSurfaceVariant,
                  modifier = Modifier.size(18.dp),
                )
              }
            }
          }
        }
      }
    }
  }

  if (showResetAllConfirm) {
    AlertDialog(
      onDismissRequest = { showResetAllConfirm = false },
      title = { Text("تأكيد إعادة التصفير") },
      text = { Text("هل تريد تصفير جميع عدادات الذكر الصوتي؟") },
      confirmButton = {
        Button(
          onClick = {
            onResetAllCounters()
            showResetAllConfirm = false
          }
        ) {
          Text("نعم، تصفير")
        }
      },
      dismissButton = {
        TextButton(onClick = { showResetAllConfirm = false }) { Text("إلغاء") }
      },
    )
  }

  pendingSingleReset?.let { target ->
    AlertDialog(
      onDismissRequest = { pendingSingleReset = null },
      title = { Text("تصفير العداد") },
      text = { Text("هل تريد تصفير عداد «${target.arabicTitle}»؟") },
      confirmButton = {
        Button(
          onClick = {
            onResetSingleCounter(target.id)
            pendingSingleReset = null
          }
        ) {
          Text("تصفير")
        }
      },
      dismissButton = {
        TextButton(onClick = { pendingSingleReset = null }) { Text("إلغاء") }
      },
    )
  }

  if (showPermissionRationale) {
    AlertDialog(
      onDismissRequest = { showPermissionRationale = false },
      title = { Text("صلاحية الميكروفون مطلوبة") },
      text = {
        Text(
          "يعمل عداد الذكر الصوتي بالاستماع إلى صوتك مباشرة على جهازك لاحتساب التسبيح تلقائياً. يرجى السماح بصلاحية الميكروفون من إعدادات التطبيق إذا تم رفضها مسبقاً."
        )
      },
      confirmButton = {
        Button(
          onClick = {
            showPermissionRationale = false
            val settingsIntent =
              Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", context.packageName, null),
              )
            runCatching { context.startActivity(settingsIntent) }
          }
        ) {
          Text("فتح الإعدادات")
        }
      },
      dismissButton = {
        TextButton(onClick = { showPermissionRationale = false }) { Text("إلغاء") }
      },
    )
  }
}
