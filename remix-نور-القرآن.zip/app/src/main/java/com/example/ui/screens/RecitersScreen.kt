package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Audiotrack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioPlaybackState
import com.example.data.firebase.AudioHostingProvider
import com.example.data.firebase.FirebaseRecitationTrack
import com.example.data.model.LocalRecitationTrack
import com.example.data.model.ReciterOption
import com.example.data.model.SurahInfo
import com.example.ui.components.OctagonalBadge
import com.example.ui.components.ReciterAvatar
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.viewmodel.ReciterSourceFilter
import java.util.Locale

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RecitersScreen(
  reciters: List<ReciterOption>,
  selectedReciter: ReciterOption?,
  preferredReciterId: String,
  searchQuery: String,
  sourceFilter: ReciterSourceFilter,
  trackSearchQuery: String,
  publishedTracks: List<FirebaseRecitationTrack>,
  catalogSurahs: List<SurahInfo>,
  downloadedSurahs: Set<Int>,
  downloadProgressMap: Map<Int, Float>,
  audioState: AudioPlaybackState,
  statusMessage: String?,
  onClearMessage: () -> Unit,
  onSearchQueryChange: (String) -> Unit,
  onSourceFilterChange: (ReciterSourceFilter) -> Unit,
  onOpenReciter: (String) -> Unit,
  onBackToRecitersList: () -> Unit,
  onTrackSearchQueryChange: (String) -> Unit,
  onSetPreferredReciter: (String) -> Unit,
  onPlayCloudRecitation: (FirebaseRecitationTrack, ReciterOption) -> Unit,
  onPlayCatalogSurah: (SurahInfo, ReciterOption) -> Unit,
  onTogglePlayPause: () -> Unit,
  onSeekTo: (Int) -> Unit,
  onSeekBySeconds: (Int) -> Unit,
  onStopPlayback: () -> Unit,
  onDownloadSurah: (SurahInfo) -> Unit,
  onDeleteDownload: (Int) -> Unit,
  localTracks: List<LocalRecitationTrack> = emptyList(),
  onPlayLocalRecitation: (LocalRecitationTrack, ReciterOption) -> Unit = { _, _ -> },
  onOpenManageLocalReciters: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val snackbarHostState = remember { SnackbarHostState() }

  LaunchedEffect(statusMessage) {
    if (statusMessage != null) {
      snackbarHostState.showSnackbar(statusMessage)
      onClearMessage()
    }
  }

  BackHandler(enabled = selectedReciter != null) {
    onBackToRecitersList()
  }

  Scaffold(
    snackbarHost = { SnackbarHost(snackbarHostState) },
    contentWindowInsets = WindowInsets(0.dp),
    modifier = modifier.fillMaxSize(),
  ) { innerPadding ->
    Box(
      modifier = Modifier.fillMaxSize().padding(innerPadding),
      contentAlignment = Alignment.TopCenter,
    ) {
      if (selectedReciter == null) {
        RecitersDirectoryContent(
          reciters = reciters,
          preferredReciterId = preferredReciterId,
          searchQuery = searchQuery,
          sourceFilter = sourceFilter,
          onSearchQueryChange = onSearchQueryChange,
          onSourceFilterChange = onSourceFilterChange,
          onOpenReciter = onOpenReciter,
          onOpenManageLocalReciters = onOpenManageLocalReciters,
        )
      } else {
        ReciterDetailContent(
          reciter = selectedReciter,
          isPreferred = selectedReciter.identifier == preferredReciterId,
          trackSearchQuery = trackSearchQuery,
          publishedTracks = publishedTracks,
          localTracks = localTracks,
          catalogSurahs = catalogSurahs,
          downloadedSurahs = downloadedSurahs,
          downloadProgressMap = downloadProgressMap,
          audioState = audioState,
          onBackToRecitersList = onBackToRecitersList,
          onTrackSearchQueryChange = onTrackSearchQueryChange,
          onSetPreferredReciter = { onSetPreferredReciter(selectedReciter.identifier) },
          onPlayCloudRecitation = { track -> onPlayCloudRecitation(track, selectedReciter) },
          onPlayLocalRecitation = { track -> onPlayLocalRecitation(track, selectedReciter) },
          onPlayCatalogSurah = { surah -> onPlayCatalogSurah(surah, selectedReciter) },
          onTogglePlayPause = onTogglePlayPause,
          onSeekTo = onSeekTo,
          onSeekBySeconds = onSeekBySeconds,
          onStopPlayback = onStopPlayback,
          onDownloadSurah = onDownloadSurah,
          onDeleteDownload = onDeleteDownload,
        )
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RecitersDirectoryContent(
  reciters: List<ReciterOption>,
  preferredReciterId: String,
  searchQuery: String,
  sourceFilter: ReciterSourceFilter,
  onSearchQueryChange: (String) -> Unit,
  onSourceFilterChange: (ReciterSourceFilter) -> Unit,
  onOpenReciter: (String) -> Unit,
  onOpenManageLocalReciters: () -> Unit,
) {
  LazyColumn(
    modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = "القرّاء والتلاوات",
          style = MaterialTheme.typography.headlineLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
          text = "استعرض القرّاء المعتمدين والمحدّثين باستمرار (${reciters.size} قارئاً) واستمع لتلاواتهم في الخلفية",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        OutlinedButton(
          onClick = onOpenManageLocalReciters,
          modifier = Modifier.fillMaxWidth().testTag("reciters_open_manage_local"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.QueueMusic,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text("إدارة القرّاء والتلاوات المضافة")
        }
      }
    }

    item {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = onSearchQueryChange,
          placeholder = { Text("ابحث باسم القارئ أو الرواية أو النبذة…") },
          leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(
                onClick = { onSearchQueryChange("") },
                modifier = Modifier.minimumInteractiveComponentSize(),
              ) {
                Icon(Icons.Rounded.Clear, contentDescription = "مسح البحث")
              }
            }
          },
          singleLine = true,
          shape = RoundedCornerShape(14.dp),
          colors =
            OutlinedTextFieldDefaults.colors(
              focusedContainerColor = MaterialTheme.colorScheme.surface,
              unfocusedContainerColor = MaterialTheme.colorScheme.surface,
            ),
          modifier = Modifier.fillMaxWidth().testTag("reciters_search_input"),
        )

        FlowRow(
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          ReciterSourceFilter.entries.forEach { filter ->
            FilterChip(
              selected = sourceFilter == filter,
              onClick = { onSourceFilterChange(filter) },
              label = { Text(filter.label) },
              modifier = Modifier.testTag("reciter_filter_${filter.name.lowercase(Locale.US)}"),
            )
          }
        }
      }
    }

    if (reciters.isEmpty()) {
      item {
        Surface(
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          modifier = Modifier.fillMaxWidth().testTag("reciters_empty_state"),
        ) {
          Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Text(
              text = "لا توجد نتائج مطابقة",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
            )
            Text(
              text = "جرّب البحث باسم آخر أو اختيار تصفية «الجميع».",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    } else {
      items(reciters, key = { it.identifier }) { reciter ->
        val isPreferred = reciter.identifier == preferredReciterId
        val riwayahLabel = reciter.riwayah.ifBlank { reciter.styleArabic }
        Surface(
          modifier =
            Modifier.fillMaxWidth()
              .testTag("reciter_directory_card_${reciter.identifier}")
              .clickable { onOpenReciter(reciter.identifier) },
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.surface,
          border =
            BorderStroke(
              1.dp,
              if (isPreferred) MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
              else MaterialTheme.colorScheme.outlineVariant,
            ),
          tonalElevation = 1.dp,
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            ReciterAvatar(
              photoUrl = reciter.photoUrl,
              contentDescription = reciter.arabicName,
              size = 56.dp,
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                Text(
                  text = reciter.arabicName,
                  fontFamily = AmiriFontFamily,
                  fontSize = 21.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.weight(1f, fill = false),
                )
                if (reciter.isCloudSynced) {
                  Icon(
                    imageVector = Icons.Rounded.CloudDone,
                    contentDescription = "محدّث سحابياً",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp),
                  )
                }
              }

              if (riwayahLabel.isNotBlank()) {
                Text(
                  text = riwayahLabel,
                  style = MaterialTheme.typography.labelMedium,
                  color = MaterialTheme.colorScheme.primary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }

              if (reciter.bioArabic.isNotBlank()) {
                Text(
                  text = reciter.bioArabic,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 2,
                  overflow = TextOverflow.Ellipsis,
                )
              }

              Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                if (isPreferred) {
                  Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                  ) {
                    Text(
                      text = "القارئ المفضل",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onPrimaryContainer,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                  }
                }
                if (reciter.isLocalCustom) {
                  Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
                  ) {
                    Text(
                      text = "مضاف محلياً",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSecondaryContainer,
                      modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    )
                  }
                }
              }
            }
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
              contentDescription = "فتح تلاوات القارئ",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ReciterDetailContent(
  reciter: ReciterOption,
  isPreferred: Boolean,
  trackSearchQuery: String,
  publishedTracks: List<FirebaseRecitationTrack>,
  localTracks: List<LocalRecitationTrack>,
  catalogSurahs: List<SurahInfo>,
  downloadedSurahs: Set<Int>,
  downloadProgressMap: Map<Int, Float>,
  audioState: AudioPlaybackState,
  onBackToRecitersList: () -> Unit,
  onTrackSearchQueryChange: (String) -> Unit,
  onSetPreferredReciter: () -> Unit,
  onPlayCloudRecitation: (FirebaseRecitationTrack) -> Unit,
  onPlayLocalRecitation: (LocalRecitationTrack) -> Unit,
  onPlayCatalogSurah: (SurahInfo) -> Unit,
  onTogglePlayPause: () -> Unit,
  onSeekTo: (Int) -> Unit,
  onSeekBySeconds: (Int) -> Unit,
  onStopPlayback: () -> Unit,
  onDownloadSurah: (SurahInfo) -> Unit,
  onDeleteDownload: (Int) -> Unit,
) {
  val supportsFullSurahCatalog =
    reciter.defaultSurahServerUrl.isNotBlank() ||
      reciter.everyAyahFolder != null ||
      reciter.islamicNetworkId != null
  val riwayahLabel = reciter.riwayah.ifBlank { reciter.styleArabic }

  LazyColumn(
    modifier = Modifier.fillMaxSize().widthIn(max = 720.dp),
    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    item {
      TextButton(
        onClick = onBackToRecitersList,
        modifier = Modifier.testTag("reciters_back_to_list"),
      ) {
        Icon(
          imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text("العودة إلى قائمة القرّاء")
      }
    }

    item {
      Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
        tonalElevation = 1.dp,
        modifier = Modifier.fillMaxWidth().testTag("reciter_profile_header"),
      ) {
        Column(
          modifier = Modifier.padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            ReciterAvatar(
              photoUrl = reciter.photoUrl,
              contentDescription = reciter.arabicName,
              size = 72.dp,
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
              Text(
                text = reciter.arabicName,
                fontFamily = AmiriFontFamily,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
              )
              if (riwayahLabel.isNotBlank()) {
                Text(
                  text = riwayahLabel,
                  style = MaterialTheme.typography.labelLarge,
                  color = MaterialTheme.colorScheme.primary,
                )
              }
              if (reciter.isCloudSynced) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                  Icon(
                    imageVector = Icons.Rounded.CloudDone,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(15.dp),
                  )
                  Text(
                    text = "قارئ محدّث عبر المنصة",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                  )
                }
              } else if (reciter.isLocalCustom) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                  Icon(
                    imageVector = Icons.AutoMirrored.Rounded.QueueMusic,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(15.dp),
                  )
                  Text(
                    text = "قارئ مضاف محلياً",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                  )
                }
              }
            }
          }

          if (reciter.bioArabic.isNotBlank()) {
            Text(
              text = reciter.bioArabic,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }

          OutlinedButton(
            onClick = onSetPreferredReciter,
            enabled = !isPreferred,
            modifier = Modifier.fillMaxWidth().testTag("set_preferred_reciter_btn"),
          ) {
            Icon(
              imageVector =
                if (isPreferred) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(if (isPreferred) "القارئ المفضل الحالي" else "تعيين كقارئ مفضل")
          }
        }
      }
    }

    if (audioState.isActive) {
      item {
        Surface(
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
          modifier = Modifier.fillMaxWidth().testTag("reciters_inline_player"),
        ) {
          Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = audioState.surahArabicName,
                  fontFamily = AmiriFontFamily,
                  fontSize = 22.sp,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.onSurface,
                )
                Text(
                  text =
                    audioState.errorMessage
                      ?: buildString {
                        append(audioState.reciterName)
                        if (audioState.trackDescription.isNotBlank()) {
                          append(" • ")
                          append(audioState.trackDescription)
                        }
                        append(" • ")
                        append(if (audioState.isBuffering) "جارٍ التحميل…" else "قيد التشغيل")
                      },
                  style = MaterialTheme.typography.bodySmall,
                  color =
                    if (audioState.errorMessage != null) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.primary,
                )
              }
              Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                  onClick = { onSeekBySeconds(-10) },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(Icons.Rounded.Replay10, contentDescription = "تأخير ١٠ ثوانٍ")
                }
                Surface(
                  shape = CircleShape,
                  color = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(48.dp),
                ) {
                  IconButton(onClick = onTogglePlayPause) {
                    if (audioState.isBuffering) {
                      CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp,
                      )
                    } else {
                      Icon(
                        imageVector =
                          if (audioState.isPlaying) Icons.Rounded.Pause
                          else Icons.Rounded.PlayArrow,
                        contentDescription = "تشغيل أو إيقاف",
                        tint = MaterialTheme.colorScheme.onPrimary,
                      )
                    }
                  }
                }
                IconButton(
                  onClick = { onSeekBySeconds(10) },
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(Icons.Rounded.Forward10, contentDescription = "تقديم ١٠ ثوانٍ")
                }
                IconButton(
                  onClick = onStopPlayback,
                  modifier = Modifier.minimumInteractiveComponentSize(),
                ) {
                  Icon(Icons.Rounded.Stop, contentDescription = "إيقاف")
                }
              }
            }

            if (audioState.durationMs > 0) {
              Slider(
                value = audioState.positionMs.toFloat().coerceIn(0f, audioState.durationMs.toFloat()),
                onValueChange = { onSeekTo(it.toInt()) },
                valueRange = 0f..audioState.durationMs.toFloat().coerceAtLeast(1f),
              )
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text(
                  text = formatReciterMs(audioState.positionMs),
                  style = MaterialTheme.typography.labelSmall,
                )
                Text(
                  text = formatReciterMs(audioState.durationMs),
                  style = MaterialTheme.typography.labelSmall,
                )
              }
            }
          }
        }
      }
    }

    item {
      OutlinedTextField(
        value = trackSearchQuery,
        onValueChange = onTrackSearchQueryChange,
        placeholder = { Text("ابحث في تلاوات وسور القارئ…") },
        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
        trailingIcon = {
          if (trackSearchQuery.isNotEmpty()) {
            IconButton(
              onClick = { onTrackSearchQueryChange("") },
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
              Icon(Icons.Rounded.Clear, contentDescription = "مسح")
            }
          }
        },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        colors =
          OutlinedTextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
          ),
        modifier = Modifier.fillMaxWidth().testTag("reciter_tracks_search_input"),
      )
    }

    if (localTracks.isNotEmpty()) {
      item {
        Text(
          text = "التلاوات المضافة محلياً (${localTracks.size})",
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )
      }

      items(localTracks, key = { "local_${it.reciterId}_${it.surahNumber}" }) { track ->
        val localTrackId = "local_${track.reciterId}_${track.surahNumber}"
        val isThisTrackActive =
          audioState.isActive &&
            audioState.trackId == localTrackId &&
            audioState.reciterId == reciter.identifier

        Surface(
          modifier =
            Modifier.fillMaxWidth()
              .clickable { onPlayLocalRecitation(track) }
              .testTag("local_track_card_${track.surahNumber}"),
          shape = MaterialTheme.shapes.medium,
          color =
            if (isThisTrackActive) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f)
            else MaterialTheme.colorScheme.surface,
          border =
            BorderStroke(
              1.dp,
              if (isThisTrackActive) MaterialTheme.colorScheme.primary
              else MaterialTheme.colorScheme.outlineVariant,
            ),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            OctagonalBadge(number = track.surahNumber.coerceIn(1, 114), size = 40.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
              Text(
                text = track.surahArabicName,
                fontFamily = AmiriFontFamily,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              if (track.notes.isNotBlank()) {
                Text(
                  text = track.notes,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 2,
                  overflow = TextOverflow.Ellipsis,
                )
              }
              Text(
                text = "سورة رقم ${track.surahNumber} • رابط مباشر محفوظ محلياً",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            IconButton(
              onClick = { onPlayLocalRecitation(track) },
              modifier =
                Modifier.minimumInteractiveComponentSize()
                  .testTag("play_local_track_${track.surahNumber}"),
            ) {
              Icon(
                imageVector =
                  if (isThisTrackActive && audioState.isPlaying) Icons.Rounded.Pause
                  else Icons.Rounded.PlayArrow,
                contentDescription = "تشغيل التلاوة",
                tint = MaterialTheme.colorScheme.primary,
              )
            }
          }
        }
      }
    }

    if (publishedTracks.isNotEmpty()) {
      item {
        Text(
          text = "التلاوات المنشورة (${publishedTracks.size})",
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )
      }

      items(publishedTracks, key = { "cloud_${it.id}" }) { track ->
        val isThisTrackActive =
          audioState.isActive &&
            audioState.trackId == track.id &&
            audioState.reciterId == reciter.identifier

        Surface(
          modifier =
            Modifier.fillMaxWidth()
              .clickable { onPlayCloudRecitation(track) }
              .testTag("cloud_track_card_${track.id}"),
          shape = MaterialTheme.shapes.medium,
          color =
            if (isThisTrackActive) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.42f)
            else MaterialTheme.colorScheme.surface,
          border =
            BorderStroke(
              1.dp,
              if (isThisTrackActive) MaterialTheme.colorScheme.primary
              else MaterialTheme.colorScheme.outlineVariant,
            ),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            OctagonalBadge(
              number = track.surahNumber.toInt().coerceIn(1, 114),
              size = 40.dp,
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
              Text(
                text = track.surahArabicName,
                fontFamily = AmiriFontFamily,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              if (track.description.isNotBlank()) {
                Text(
                  text = track.description,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  maxLines = 2,
                  overflow = TextOverflow.Ellipsis,
                )
              }
              val metaLine =
                buildList {
                  add(AudioHostingProvider.fromId(track.hostingProvider).arabicLabel)
                  if (track.durationSeconds > 0) {
                    add(formatReciterDurationSeconds(track.durationSeconds))
                  }
                }.joinToString(" • ")
              Text(
                text = metaLine,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
            IconButton(
              onClick = { onPlayCloudRecitation(track) },
              modifier =
                Modifier.minimumInteractiveComponentSize()
                  .testTag("play_cloud_track_${track.id}"),
            ) {
              Icon(
                imageVector =
                  if (isThisTrackActive && audioState.isPlaying) Icons.Rounded.Pause
                  else Icons.Rounded.PlayArrow,
                contentDescription = "تشغيل التلاوة",
                tint = MaterialTheme.colorScheme.primary,
              )
            }
          }
        }
      }
    }

    if (supportsFullSurahCatalog) {
      item {
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "سور المصحف الكاملة (${catalogSurahs.size})",
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onBackground,
        )
      }

      items(catalogSurahs, key = { "surah_${it.number}" }) { surah ->
        val isThisSurahPlaying =
          audioState.isActive &&
            audioState.trackId.isEmpty() &&
            audioState.surahNumber == surah.number &&
            audioState.reciterId == reciter.identifier
        val isDownloaded = surah.number in downloadedSurahs
        val progress = downloadProgressMap[surah.number]

        Surface(
          modifier =
            Modifier.fillMaxWidth()
              .clickable { onPlayCatalogSurah(surah) }
              .testTag("reciter_surah_${surah.number}"),
          shape = MaterialTheme.shapes.medium,
          color =
            if (isThisSurahPlaying) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
            else MaterialTheme.colorScheme.surface,
          border =
            BorderStroke(
              1.dp,
              if (isThisSurahPlaying) MaterialTheme.colorScheme.primary
              else MaterialTheme.colorScheme.outlineVariant,
            ),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            OctagonalBadge(number = surah.number, size = 38.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = surah.arabicName,
                fontFamily = AmiriFontFamily,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Text(
                text =
                  if (isDownloaded) "${surah.numberOfAyahs} آية • محفوظ دون إنترنت"
                  else "${surah.revelationArabic} • ${surah.numberOfAyahs} آية",
                style = MaterialTheme.typography.labelSmall,
                color =
                  if (isDownloaded) MaterialTheme.colorScheme.primary
                  else MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }

            if (progress != null) {
              Box(modifier = Modifier.size(48.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                  progress = { progress },
                  modifier = Modifier.size(26.dp),
                  strokeWidth = 2.5.dp,
                )
              }
            } else if (isDownloaded) {
              IconButton(
                onClick = { onDeleteDownload(surah.number) },
                modifier = Modifier.minimumInteractiveComponentSize(),
              ) {
                Icon(
                  imageVector = Icons.Rounded.CheckCircle,
                  contentDescription = "محمل دون إنترنت - اضغط للحذف",
                  tint = MaterialTheme.colorScheme.primary,
                )
              }
            } else {
              IconButton(
                onClick = { onDownloadSurah(surah) },
                modifier = Modifier.minimumInteractiveComponentSize(),
              ) {
                Icon(
                  imageVector = Icons.Rounded.Download,
                  contentDescription = "تحميل السورة",
                  tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }

            IconButton(
              onClick = { onPlayCatalogSurah(surah) },
              modifier = Modifier.minimumInteractiveComponentSize(),
            ) {
              Icon(
                imageVector =
                  if (isThisSurahPlaying && audioState.isPlaying) Icons.Rounded.Pause
                  else Icons.Rounded.PlayArrow,
                contentDescription = "تشغيل السورة",
                tint = MaterialTheme.colorScheme.primary,
              )
            }
          }
        }
      }
    } else if (publishedTracks.isEmpty() && localTracks.isEmpty()) {
      item {
        Surface(
          shape = MaterialTheme.shapes.large,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          modifier = Modifier.fillMaxWidth().testTag("reciter_no_tracks_empty"),
        ) {
          Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Icon(
              imageVector = Icons.Rounded.Audiotrack,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary,
              modifier = Modifier.size(34.dp),
            )
            Text(
              text =
                if (reciter.isLocalCustom) "لا توجد تلاوات مضافة لهذا القارئ"
                else "لا توجد تلاوات منشورة حالياً",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
            )
            Text(
              text =
                when {
                  trackSearchQuery.isNotBlank() -> "لا توجد تلاوات مطابقة لعبارة البحث."
                  reciter.isLocalCustom -> "أضف رابط تلاوة أو رابط سورة كاملة من قسم «إدارة القرّاء»."
                  else -> "ستظهر التلاوات فور نشرها من لوحة الإدارة."
                },
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }
      }
    }
  }
}

private fun formatReciterMs(ms: Int): String {
  val totalSeconds = (ms / 1000).coerceAtLeast(0)
  val hours = totalSeconds / 3600
  val minutes = (totalSeconds % 3600) / 60
  val seconds = totalSeconds % 60
  return if (hours > 0) String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
  else String.format(Locale.US, "%02d:%02d", minutes, seconds)
}

private fun formatReciterDurationSeconds(seconds: Long): String {
  val total = seconds.coerceAtLeast(0L)
  val mins = total / 60
  val secs = total % 60
  return String.format(Locale.US, "%02d:%02d", mins, secs)
}
