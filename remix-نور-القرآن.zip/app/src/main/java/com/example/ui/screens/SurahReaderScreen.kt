package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.automirrored.rounded.MenuBook
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BookmarkBorder
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material.icons.rounded.ZoomOut
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioPlaybackState
import com.example.data.model.AyahItem
import com.example.data.model.QuranCatalog
import com.example.data.model.ReaderSettings
import com.example.data.model.ReaderThemeMode
import com.example.data.model.ReciterOption
import com.example.data.model.SurahInfo
import com.example.ui.components.MiniAudioPlayerBar
import com.example.ui.components.OctagonalBadge
import com.example.ui.theme.AmiriFontFamily
import com.example.ui.viewmodel.SurahReaderUiState
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SurahReaderScreen(
  uiState: SurahReaderUiState,
  readerSettings: ReaderSettings,
  bookmarkedKeys: Set<String>,
  audioState: AudioPlaybackState,
  scrollToAyah: Int,
  isPageMode: Boolean,
  activePage: Int,
  onBack: () -> Unit,
  onRetry: () -> Unit,
  onNavigateToSurah: (Int) -> Unit,
  onSwitchToPage: (Int) -> Unit,
  onSwitchToSurahMode: () -> Unit,
  onOpenTafsir: (surahNumber: Int, ayahNumber: Int) -> Unit,
  onToggleBookmark: (AyahItem) -> Unit,
  onRecordProgress: (AyahItem) -> Unit,
  onPlayAyah: (AyahItem) -> Unit,
  onPlaySurahFromStart: () -> Unit,
  onTogglePlayPause: () -> Unit,
  onAudioPrevious: () -> Unit,
  onAudioNext: () -> Unit,
  onAudioStop: () -> Unit,
  onZoomIn: () -> Unit,
  onZoomOut: () -> Unit,
  onResetFontSize: () -> Unit,
  onArabicFontSizeChange: (Float) -> Unit,
  onTranslationFontSizeChange: (Float) -> Unit,
  onShowTranslationChange: (Boolean) -> Unit,
  onTranslationEditionChange: (String) -> Unit,
  onReciterChange: (String) -> Unit,
  onThemeModeChange: (ReaderThemeMode) -> Unit,
  onVolumeChange: (Float) -> Unit,
  reciters: List<ReciterOption> = QuranCatalog.reciters,
  onOpenManageReciters: () -> Unit = {},
) {
  var showSettingsSheet by remember { mutableStateOf(false) }
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val context = LocalContext.current
  val listState = rememberLazyListState()

  var initialScrollApplied by remember(uiState) { mutableStateOf(false) }
  val latestFontSize by rememberUpdatedState(readerSettings.arabicFontSize)
  var pinchScaleAccumulator by remember { mutableFloatStateOf(1f) }

  LaunchedEffect(uiState, scrollToAyah) {
    if (uiState is SurahReaderUiState.SurahSuccess && !initialScrollApplied && scrollToAyah > 1) {
      val index = uiState.ayahs.indexOfFirst { it.numberInSurah == scrollToAyah }
      if (index >= 0) {
        listState.scrollToItem(index + 1)
      }
      initialScrollApplied = true
    }
  }

  LaunchedEffect(listState.firstVisibleItemIndex, uiState) {
    when (uiState) {
      is SurahReaderUiState.SurahSuccess -> {
        val idx = (listState.firstVisibleItemIndex - 1).coerceIn(0, uiState.ayahs.lastIndex)
        uiState.ayahs.getOrNull(idx)?.let(onRecordProgress)
      }
      is SurahReaderUiState.PageSuccess -> {
        val idx = (listState.firstVisibleItemIndex - 1).coerceIn(0, uiState.ayahs.lastIndex)
        uiState.ayahs.getOrNull(idx)?.let(onRecordProgress)
      }
      else -> {}
    }
  }

  LaunchedEffect(audioState.currentAyahInSurah, audioState.surahNumber, uiState) {
    if (
      audioState.isActive &&
        audioState.currentAyahInSurah > 0 &&
        uiState is SurahReaderUiState.SurahSuccess &&
        audioState.surahNumber == uiState.surah.number
    ) {
      val idx = uiState.ayahs.indexOfFirst { it.numberInSurah == audioState.currentAyahInSurah }
      if (idx >= 0) {
        listState.animateScrollToItem(idx + 1)
      }
    }
  }

  LaunchedEffect(audioState.errorMessage) {
    val err = audioState.errorMessage
    if (!err.isNullOrBlank()) {
      snackbarHostState.showSnackbar(err)
    }
  }

  Scaffold(
    snackbarHost = { SnackbarHost(snackbarHostState) },
    topBar = {
      Column {
        TopAppBar(
          title = {
            when (uiState) {
              is SurahReaderUiState.SurahSuccess -> {
                Column {
                  Text(
                    text = uiState.surah.arabicName,
                    fontFamily = AmiriFontFamily,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  Text(
                    text = "${uiState.surah.revelationArabic} • ${uiState.surah.numberOfAyahs} آية • ص ${uiState.ayahs.firstOrNull()?.page ?: activePage}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                  )
                }
              }
              is SurahReaderUiState.PageSuccess -> {
                Column {
                  Text(
                    text = "صفحة ${uiState.pageNumber} من ٦٠٤",
                    style = MaterialTheme.typography.titleLarge,
                    maxLines = 1,
                  )
                  Text(
                    text = uiState.surahNames,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
              }
              else -> Text("المصحف الشريف", style = MaterialTheme.typography.titleLarge)
            }
          },
          navigationIcon = {
            IconButton(
              onClick = onBack,
              modifier = Modifier.minimumInteractiveComponentSize().testTag("reader_back_button"),
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                contentDescription = "رجوع",
              )
            }
          },
          actions = {
            if (uiState is SurahReaderUiState.SurahSuccess || uiState is SurahReaderUiState.PageSuccess) {
              TextButton(
                onClick = {
                  if (isPageMode) onSwitchToSurahMode()
                  else onSwitchToPage(activePage)
                },
                modifier = Modifier.testTag("toggle_page_mode_button"),
              ) {
                Text(
                  text = if (isPageMode) "عرض السورة" else "عرض الصفحة",
                  style = MaterialTheme.typography.labelLarge,
                )
              }
            }
            IconButton(
              onClick = { showSettingsSheet = true },
              modifier = Modifier.minimumInteractiveComponentSize().testTag("reader_settings_button"),
            ) {
              Icon(
                imageVector = Icons.Rounded.Tune,
                contentDescription = "إعدادات القراءة",
              )
            }
          },
          colors =
            TopAppBarDefaults.topAppBarColors(
              containerColor = MaterialTheme.colorScheme.background,
            ),
        )

        // Dedicated Quran Text Zoom Controls Strip (Inside Surah/Page Reader)
        Surface(
          color = MaterialTheme.colorScheme.surfaceContainer,
          tonalElevation = 1.dp,
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              IconButton(
                onClick = onZoomIn,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("quran_zoom_in"),
              ) {
                Icon(
                  imageVector = Icons.Rounded.ZoomIn,
                  contentDescription = "تكبير خط القرآن",
                  tint = MaterialTheme.colorScheme.primary,
                )
              }
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
              ) {
                Text(
                  text = "${readerSettings.arabicFontSize.toInt()}",
                  style = MaterialTheme.typography.labelLarge,
                  color = MaterialTheme.colorScheme.onSurface,
                  modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                )
              }
              IconButton(
                onClick = onZoomOut,
                modifier = Modifier.minimumInteractiveComponentSize().testTag("quran_zoom_out"),
              ) {
                Icon(
                  imageVector = Icons.Rounded.ZoomOut,
                  contentDescription = "تصغير خط القرآن",
                  tint = MaterialTheme.colorScheme.primary,
                )
              }
            }

            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              Text(
                text = "حجم خط القرآن",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              TextButton(
                onClick = onResetFontSize,
                modifier = Modifier.testTag("quran_zoom_reset"),
              ) {
                Icon(
                  imageVector = Icons.Rounded.Refresh,
                  contentDescription = null,
                  modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("افتراضي", style = MaterialTheme.typography.labelMedium)
              }
            }
          }
        }
      }
    },
    bottomBar = {
      MiniAudioPlayerBar(
        audioState = audioState,
        onTogglePlayPause = onTogglePlayPause,
        onPrevious = onAudioPrevious,
        onNext = onAudioNext,
        onStop = onAudioStop,
        onOpenTarget = {},
        modifier = Modifier.padding(bottom = 8.dp),
      )
    },
  ) { innerPadding ->
    // Pinch-to-Zoom gesture applied strictly to Quran reading text size
    Box(
      modifier =
        Modifier.fillMaxSize()
          .padding(innerPadding)
          .pointerInput(Unit) {
            detectTransformGestures { _, _, zoom, _ ->
              if (zoom != 1f) {
                pinchScaleAccumulator *= zoom
                if (kotlin.math.abs(pinchScaleAccumulator - 1f) >= 0.04f) {
                  val target = (latestFontSize * pinchScaleAccumulator).coerceIn(18f, 52f)
                  onArabicFontSizeChange(target)
                  pinchScaleAccumulator = 1f
                }
              }
            }
          },
      contentAlignment = Alignment.TopCenter,
    ) {
      when (uiState) {
        is SurahReaderUiState.Loading -> {
          Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(14.dp))
            Text(
              text = "جارٍ فتح الآيات الكريمة…",
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
        }

        is SurahReaderUiState.Error -> {
          Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Text(
              text = "تعذر تحميل النص",
              style = MaterialTheme.typography.headlineMedium,
              color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = uiState.message,
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              textAlign = TextAlign.Center,
            )
            Spacer(modifier = Modifier.height(18.dp))
            Button(onClick = onRetry, modifier = Modifier.testTag("reader_retry_button")) {
              Text("إعادة المحاولة")
            }
          }
        }

        is SurahReaderUiState.SurahSuccess -> {
          LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().widthIn(max = 760.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            item(key = "surah_banner") {
              SurahBannerCard(
                surah = uiState.surah,
                isPlayingThisSurah =
                  audioState.isActive &&
                    audioState.surahNumber == uiState.surah.number &&
                    audioState.isPlaying,
                onPlaySurah = {
                  if (audioState.isActive && audioState.surahNumber == uiState.surah.number) {
                    onTogglePlayPause()
                  } else {
                    onPlaySurahFromStart()
                  }
                },
              )
            }

            items(uiState.ayahs, key = { "${it.surahNumber}_${it.numberInSurah}" }) { ayah ->
              val isPlayingThisAyah =
                audioState.isActive &&
                  audioState.surahNumber == ayah.surahNumber &&
                  audioState.currentAyahInSurah == ayah.numberInSurah
              val bookmarkKey = "${ayah.surahNumber}_${ayah.numberInSurah}"

              AyahCard(
                surahName = uiState.surah.arabicName,
                ayah = ayah,
                isBookmarked = bookmarkKey in bookmarkedKeys,
                isCurrentlyPlaying = isPlayingThisAyah,
                isAudioActuallyPlaying = isPlayingThisAyah && audioState.isPlaying,
                arabicFontSize = readerSettings.arabicFontSize,
                translationFontSize = readerSettings.translationFontSize,
                showTranslation = readerSettings.showTranslation,
                onPlayClick = { onPlayAyah(ayah) },
                onTafsirClick = { onOpenTafsir(ayah.surahNumber, ayah.numberInSurah) },
                onBookmarkClick = {
                  onToggleBookmark(ayah)
                  onRecordProgress(ayah)
                },
                onCopyClick = {
                  copyAyahToClipboard(context, uiState.surah.arabicName, ayah)
                  scope.launch { snackbarHostState.showSnackbar("تم نسخ الآية الكريمة") }
                },
                onShareClick = { shareAyahIntent(context, uiState.surah.arabicName, ayah) },
              )
            }

            item(key = "surah_footer") {
              Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                if (uiState.surah.number > 1) {
                  OutlinedButton(
                    onClick = { onNavigateToSurah(uiState.surah.number - 1) },
                    modifier = Modifier.weight(1f).testTag("prev_surah_button"),
                  ) {
                    Icon(
                      imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                      contentDescription = null,
                      modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("السورة السابقة")
                  }
                }
                if (uiState.surah.number < 114) {
                  Button(
                    onClick = { onNavigateToSurah(uiState.surah.number + 1) },
                    modifier = Modifier.weight(1f).testTag("next_surah_button"),
                  ) {
                    Text("السورة التالية")
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                      imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                      contentDescription = null,
                      modifier = Modifier.size(18.dp),
                    )
                  }
                }
              }
            }
          }
        }

        is SurahReaderUiState.PageSuccess -> {
          LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().widthIn(max = 760.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            item(key = "page_header") {
              Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = MaterialTheme.shapes.medium,
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Column {
                    Text(
                      text = "صفحة ${uiState.pageNumber} من ٦٠٤",
                      style = MaterialTheme.typography.titleMedium,
                      color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                    Text(
                      text = uiState.surahNames,
                      style = MaterialTheme.typography.bodyMedium,
                      color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                  }
                  Button(
                    onClick = onPlaySurahFromStart,
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.PlayArrow,
                      contentDescription = null,
                      modifier = Modifier.size(18.dp),
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("تلاوة")
                  }
                }
              }
            }

            items(uiState.ayahs, key = { "${it.surahNumber}_${it.numberInSurah}" }) { ayah ->
              val isPlayingThisAyah =
                audioState.isActive &&
                  audioState.surahNumber == ayah.surahNumber &&
                  audioState.currentAyahInSurah == ayah.numberInSurah
              val bookmarkKey = "${ayah.surahNumber}_${ayah.numberInSurah}"

              AyahCard(
                surahName = ayah.surahArabicName,
                ayah = ayah,
                isBookmarked = bookmarkKey in bookmarkedKeys,
                isCurrentlyPlaying = isPlayingThisAyah,
                isAudioActuallyPlaying = isPlayingThisAyah && audioState.isPlaying,
                arabicFontSize = readerSettings.arabicFontSize,
                translationFontSize = readerSettings.translationFontSize,
                showTranslation = readerSettings.showTranslation,
                onPlayClick = { onPlayAyah(ayah) },
                onTafsirClick = { onOpenTafsir(ayah.surahNumber, ayah.numberInSurah) },
                onBookmarkClick = {
                  onToggleBookmark(ayah)
                  onRecordProgress(ayah)
                },
                onCopyClick = {
                  copyAyahToClipboard(context, ayah.surahArabicName, ayah)
                  scope.launch { snackbarHostState.showSnackbar("تم نسخ الآية الكريمة") }
                },
                onShareClick = { shareAyahIntent(context, ayah.surahArabicName, ayah) },
              )
            }

            item(key = "page_footer") {
              Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                if (uiState.pageNumber > 1) {
                  OutlinedButton(
                    onClick = { onSwitchToPage(uiState.pageNumber - 1) },
                    modifier = Modifier.weight(1f).testTag("prev_page_button"),
                  ) {
                    Text("الصفحة السابقة")
                  }
                }
                if (uiState.pageNumber < 604) {
                  Button(
                    onClick = { onSwitchToPage(uiState.pageNumber + 1) },
                    modifier = Modifier.weight(1f).testTag("next_page_button"),
                  ) {
                    Text("الصفحة التالية")
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showSettingsSheet) {
    ModalBottomSheet(onDismissRequest = { showSettingsSheet = false }) {
      ReaderSettingsSheetContent(
        settings = readerSettings,
        reciters = reciters,
        onArabicFontSizeChange = onArabicFontSizeChange,
        onResetFontSize = onResetFontSize,
        onTranslationFontSizeChange = onTranslationFontSizeChange,
        onShowTranslationChange = onShowTranslationChange,
        onTranslationEditionChange = onTranslationEditionChange,
        onReciterChange = onReciterChange,
        onThemeModeChange = onThemeModeChange,
        onVolumeChange = onVolumeChange,
        onOpenManageReciters = {
          showSettingsSheet = false
          onOpenManageReciters()
        },
      )
    }
  }
}

private fun copyAyahToClipboard(context: Context, surahName: String, ayah: AyahItem) {
  val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
  val copyText =
    buildString {
      append(ayah.arabicText)
      append(" ﴿${ayah.numberInSurah}﴾")
      if (ayah.translationText.isNotBlank()) {
        append("\n\n")
        append(ayah.translationText)
      }
      append("\n— $surahName (${ayah.surahNumber}:${ayah.numberInSurah})")
    }
  clipboard.setPrimaryClip(ClipData.newPlainText("آية قرآنية", copyText))
}

private fun shareAyahIntent(context: Context, surahName: String, ayah: AyahItem) {
  val shareText =
    "${ayah.arabicText} ﴿${ayah.numberInSurah}﴾\n— $surahName (آية ${ayah.numberInSurah}) | تطبيق نور القرآن"
  val intent =
    Intent(Intent.ACTION_SEND).apply {
      type = "text/plain"
      putExtra(Intent.EXTRA_TEXT, shareText)
    }
  context.startActivity(Intent.createChooser(intent, "مشاركة الآية الكريمة"))
}

@Composable
private fun SurahBannerCard(
  surah: SurahInfo,
  isPlayingThisSurah: Boolean,
  onPlaySurah: () -> Unit,
) {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = MaterialTheme.shapes.large,
    shadowElevation = 2.dp,
  ) {
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .background(
            Brush.linearGradient(
              colors =
                listOf(
                  Color(0xFF0C4C3F),
                  Color(0xFF156554),
                  Color(0xFF1D4E59),
                )
            )
          )
          .padding(horizontal = 20.dp, vertical = 22.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = surah.arabicName,
        fontFamily = AmiriFontFamily,
        fontSize = 34.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFFF6D98D),
        textAlign = TextAlign.Center,
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
        text = "${surah.revelationArabic} • ${surah.numberOfAyahs} آية • ${surah.englishName}",
        style = MaterialTheme.typography.bodyMedium,
        color = Color.White.copy(alpha = 0.88f),
        textAlign = TextAlign.Center,
      )

      if (surah.number != 1 && surah.number != 9) {
        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = Color.White.copy(alpha = 0.18f))
        Spacer(modifier = Modifier.height(14.dp))
        Text(
          text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
          fontFamily = AmiriFontFamily,
          fontSize = 26.sp,
          color = Color.White,
          textAlign = TextAlign.Center,
        )
      }

      Spacer(modifier = Modifier.height(16.dp))
      Button(
        onClick = onPlaySurah,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = Color(0xFFF6D98D),
            contentColor = Color(0xFF192822),
          ),
        modifier = Modifier.testTag("play_surah_button"),
      ) {
        Icon(
          imageVector = if (isPlayingThisSurah) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
          contentDescription = null,
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = if (isPlayingThisSurah) "إيقاف التلاوة" else "الاستماع إلى السورة",
          style = MaterialTheme.typography.labelLarge,
        )
      }
    }
  }
}

@Composable
private fun AyahCard(
  surahName: String,
  ayah: AyahItem,
  isBookmarked: Boolean,
  isCurrentlyPlaying: Boolean,
  isAudioActuallyPlaying: Boolean,
  arabicFontSize: Float,
  translationFontSize: Float,
  showTranslation: Boolean,
  onPlayClick: () -> Unit,
  onTafsirClick: () -> Unit,
  onBookmarkClick: () -> Unit,
  onCopyClick: () -> Unit,
  onShareClick: () -> Unit,
) {
  val containerColor by
    animateColorAsState(
      targetValue =
        if (isCurrentlyPlaying) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)
        else MaterialTheme.colorScheme.surface,
      label = "ayahCardColor",
    )
  val borderColor by
    animateColorAsState(
      targetValue =
        if (isCurrentlyPlaying) MaterialTheme.colorScheme.primary
        else MaterialTheme.colorScheme.outlineVariant,
      label = "ayahBorderColor",
    )

  Surface(
    modifier = Modifier.fillMaxWidth().testTag("ayah_card_${ayah.numberInSurah}"),
    shape = MaterialTheme.shapes.medium,
    color = containerColor,
    border = BorderStroke(if (isCurrentlyPlaying) 1.5.dp else 1.dp, borderColor),
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          OctagonalBadge(number = ayah.numberInSurah, size = 36.dp)
          Column {
            Text(
              text = "${surahName.removePrefix("سُورَةُ ").removePrefix("سورة ")} • ص ${ayah.page}",
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
              text = "الجزء ${ayah.juz}",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary,
            )
          }
          if (ayah.sajda) {
            Surface(
              shape = RoundedCornerShape(50),
              color = MaterialTheme.colorScheme.secondaryContainer,
            ) {
              Text(
                text = "سجدة",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
              )
            }
          }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
          IconButton(
            onClick = onPlayClick,
            modifier =
              Modifier.minimumInteractiveComponentSize().testTag("ayah_play_${ayah.numberInSurah}"),
          ) {
            Icon(
              imageVector =
                if (isAudioActuallyPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
              contentDescription = if (isAudioActuallyPlaying) "إيقاف" else "تشغيل الآية",
              tint = MaterialTheme.colorScheme.primary,
            )
          }
          IconButton(
            onClick = onTafsirClick,
            modifier =
              Modifier.minimumInteractiveComponentSize().testTag("ayah_tafsir_${ayah.numberInSurah}"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Rounded.MenuBook,
              contentDescription = "تفسير الآية",
              tint = MaterialTheme.colorScheme.secondary,
              modifier = Modifier.size(20.dp),
            )
          }
          IconButton(
            onClick = onBookmarkClick,
            modifier =
              Modifier.minimumInteractiveComponentSize()
                .testTag("ayah_bookmark_${ayah.numberInSurah}"),
          ) {
            Icon(
              imageVector =
                if (isBookmarked) Icons.Rounded.Bookmark else Icons.Rounded.BookmarkBorder,
              contentDescription = if (isBookmarked) "إزالة من المفضلة" else "حفظ في المفضلة",
              tint =
                if (isBookmarked) MaterialTheme.colorScheme.secondary
                else MaterialTheme.colorScheme.onSurfaceVariant,
            )
          }
          IconButton(
            onClick = onCopyClick,
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Icon(
              imageVector = Icons.Rounded.ContentCopy,
              contentDescription = "نسخ الآية",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(18.dp),
            )
          }
          IconButton(
            onClick = onShareClick,
            modifier = Modifier.minimumInteractiveComponentSize(),
          ) {
            Icon(
              imageVector = Icons.Rounded.Share,
              contentDescription = "مشاركة الآية",
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(18.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Exact Quranic Uthmani Text with generous line height so Tashkeel/Harakat never clip
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Text(
          text = ayah.arabicText,
          style =
            TextStyle(
              fontFamily = AmiriFontFamily,
              fontSize = arabicFontSize.sp,
              lineHeight = (arabicFontSize * 1.95f).sp,
              textAlign = TextAlign.Start,
              color = MaterialTheme.colorScheme.onSurface,
              platformStyle = PlatformTextStyle(includeFontPadding = true),
            ),
          modifier = Modifier.fillMaxWidth().testTag("ayah_arabic_text_${ayah.numberInSurah}"),
        )
      }

      if (showTranslation && ayah.translationText.isNotBlank()) {
        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
        Spacer(modifier = Modifier.height(12.dp))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
          Text(
            text = ayah.translationText,
            style =
              MaterialTheme.typography.bodyLarge.copy(
                fontSize = translationFontSize.sp,
                lineHeight = (translationFontSize * 1.55f).sp,
              ),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth(),
          )
        }
      }
    }
  }
}

@Composable
private fun ReaderSettingsSheetContent(
  settings: ReaderSettings,
  reciters: List<ReciterOption>,
  onArabicFontSizeChange: (Float) -> Unit,
  onResetFontSize: () -> Unit,
  onTranslationFontSizeChange: (Float) -> Unit,
  onShowTranslationChange: (Boolean) -> Unit,
  onTranslationEditionChange: (String) -> Unit,
  onReciterChange: (String) -> Unit,
  onThemeModeChange: (ReaderThemeMode) -> Unit,
  onVolumeChange: (Float) -> Unit,
  onOpenManageReciters: () -> Unit,
) {
  Column(
    modifier =
      Modifier.fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp)
        .padding(bottom = 32.dp),
    verticalArrangement = Arrangement.spacedBy(18.dp),
  ) {
    Text(
      text = "إعدادات القراءة والاستماع",
      style = MaterialTheme.typography.headlineMedium,
      color = MaterialTheme.colorScheme.onSurface,
    )

    // Preset Font Sizes
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text("حجم خط القرآن (${settings.arabicFontSize.toInt()})", style = MaterialTheme.typography.labelLarge)
        TextButton(onClick = onResetFontSize) { Text("استعادة الافتراضي") }
      }
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("صغير" to 22f, "متوسط" to 28f, "كبير" to 34f, "كبير جداً" to 42f).forEach {
          (label, sizeVal) ->
          FilterChip(
            selected = kotlin.math.abs(settings.arabicFontSize - sizeVal) < 1.5f,
            onClick = { onArabicFontSizeChange(sizeVal) },
            label = { Text(label) },
          )
        }
      }
      Slider(
        value = settings.arabicFontSize,
        onValueChange = onArabicFontSizeChange,
        valueRange = 18f..52f,
      )
    }

    // Theme Mode Selector
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Text("مظهر القراءة", style = MaterialTheme.typography.labelLarge)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        ReaderThemeMode.entries.forEach { mode ->
          val selected = settings.themeMode == mode
          Surface(
            modifier =
              Modifier.weight(1f)
                .testTag("theme_option_${mode.name.lowercase()}")
                .clickable { onThemeModeChange(mode) },
            shape = RoundedCornerShape(12.dp),
            color =
              if (selected) MaterialTheme.colorScheme.primaryContainer
              else MaterialTheme.colorScheme.surfaceContainer,
            border =
              BorderStroke(
                1.dp,
                if (selected) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.outlineVariant,
              ),
          ) {
            Box(
              modifier = Modifier.padding(vertical = 10.dp),
              contentAlignment = Alignment.Center,
            ) {
              Text(
                text = mode.label,
                style = MaterialTheme.typography.labelMedium,
                color =
                  if (selected) MaterialTheme.colorScheme.onPrimaryContainer
                  else MaterialTheme.colorScheme.onSurface,
              )
            }
          }
        }
      }
    }

    // Volume Control
    Column {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("مستوى صوت التلاوة", style = MaterialTheme.typography.labelLarge)
        Text("${(settings.volumeLevel * 100).toInt()}%", style = MaterialTheme.typography.labelMedium)
      }
      Slider(value = settings.volumeLevel, onValueChange = onVolumeChange, valueRange = 0f..1f)
    }

    // Translation Toggle + Edition
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Column {
        Text("عرض الترجمة الإنجليزية", style = MaterialTheme.typography.labelLarge)
        Text(
          "إظهار ترجمة معاني الآيات أسفل النص",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
      Switch(checked = settings.showTranslation, onCheckedChange = onShowTranslationChange)
    }

    if (settings.showTranslation) {
      Column {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
          Text("حجم خط الترجمة", style = MaterialTheme.typography.labelLarge)
          Text("${settings.translationFontSize.toInt()}", style = MaterialTheme.typography.labelMedium)
        }
        Slider(
          value = settings.translationFontSize,
          onValueChange = onTranslationFontSizeChange,
          valueRange = 12f..24f,
        )
      }

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("نسخة الترجمة", style = MaterialTheme.typography.labelLarge)
        QuranCatalog.translationEditions.forEach { edition ->
          val selected = settings.translationEdition == edition.identifier
          Surface(
            modifier =
              Modifier.fillMaxWidth().clickable { onTranslationEditionChange(edition.identifier) },
            shape = RoundedCornerShape(12.dp),
            color =
              if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
              else MaterialTheme.colorScheme.surfaceContainer,
            border =
              BorderStroke(
                1.dp,
                if (selected) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.outlineVariant,
              ),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(edition.name, style = MaterialTheme.typography.titleMedium)
                Text(
                  edition.scholar,
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
              if (selected) {
                Icon(
                  imageVector = Icons.Rounded.Check,
                  contentDescription = "محدد",
                  tint = MaterialTheme.colorScheme.primary,
                )
              }
            }
          }
        }
      }
    }

    // All Reciters Selector (Catalog + Cloud + Local Custom)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text("القارئ المفضل (${reciters.size})", style = MaterialTheme.typography.labelLarge)
        TextButton(
          onClick = onOpenManageReciters,
          modifier = Modifier.testTag("reader_manage_reciters_button"),
        ) {
          Text("إدارة القرّاء")
        }
      }
      reciters.forEach { reciter ->
        val selected = settings.reciterIdentifier == reciter.identifier
        val subtitle = reciter.riwayah.ifBlank { reciter.styleArabic }
        Surface(
          modifier =
            Modifier.fillMaxWidth()
              .testTag("reader_reciter_option_${reciter.identifier}")
              .clickable { onReciterChange(reciter.identifier) },
          shape = RoundedCornerShape(12.dp),
          color =
            if (selected) MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f)
            else MaterialTheme.colorScheme.surfaceContainer,
          border =
            BorderStroke(
              1.dp,
              if (selected) MaterialTheme.colorScheme.secondary
              else MaterialTheme.colorScheme.outlineVariant,
            ),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
              ) {
                Text(reciter.arabicName, style = MaterialTheme.typography.titleMedium)
                if (reciter.isLocalCustom) {
                  Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                  ) {
                    Text(
                      text = "مضاف محلياً",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onPrimaryContainer,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
                    )
                  }
                } else if (reciter.isCloudSynced) {
                  Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f),
                  ) {
                    Text(
                      text = "المنصة",
                      style = MaterialTheme.typography.labelSmall,
                      color = MaterialTheme.colorScheme.onSecondaryContainer,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
                    )
                  }
                }
              }
              if (subtitle.isNotBlank()) {
                Text(
                  subtitle,
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
            if (selected) {
              Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = "محدد",
                tint = MaterialTheme.colorScheme.secondary,
              )
            }
          }
        }
      }
    }
  }
}
