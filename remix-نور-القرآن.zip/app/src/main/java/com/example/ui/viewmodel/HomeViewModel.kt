package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.local.UserPreferencesRepository
import com.example.data.model.DailyReflection
import com.example.data.model.KhatmahPlan
import com.example.data.model.QuranCatalog
import com.example.data.model.ReadingProgress
import com.example.data.model.SurahInfo
import com.example.data.repository.QuranRepository
import java.util.Calendar
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(
  private val quranRepository: QuranRepository,
  preferencesRepository: UserPreferencesRepository,
) : ViewModel() {

  private val featuredSurahNumbers = setOf(1, 18, 36, 55, 67, 112)

  val dailyReflection: DailyReflection = run {
    val dayOfYear = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
    QuranCatalog.reflections[dayOfYear % QuranCatalog.reflections.size]
  }

  val readingProgress: StateFlow<ReadingProgress> =
    preferencesRepository.readingProgressFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = ReadingProgress(),
    )

  val featuredSurahs: StateFlow<List<SurahInfo>> =
    quranRepository.surahsFlow
      .map { surahs -> surahs.filter { it.number in featuredSurahNumbers } }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList(),
      )

  val bookmarksCount: StateFlow<Int> =
    quranRepository.bookmarksFlow
      .map { it.size }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0,
      )

  val activeKhatmah: StateFlow<KhatmahPlan?> =
    quranRepository.khatmahPlansFlow
      .map { list -> list.firstOrNull { !it.isPaused } ?: list.firstOrNull() }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = null,
      )

  val totalVoiceDhikrCount: StateFlow<Int> =
    quranRepository.dhikrCountersFlow
      .map { list -> list.sumOf { it.count } }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0,
      )

  init {
    viewModelScope.launch { quranRepository.ensureInitialDataSeeded() }
  }

  companion object {
    fun factory(
      quranRepository: QuranRepository,
      preferencesRepository: UserPreferencesRepository,
    ): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return HomeViewModel(quranRepository, preferencesRepository) as T
        }
      }
  }
}
