package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.KhatmahPlan
import com.example.data.repository.QuranRepository
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class KhatmahViewModel(
  private val quranRepository: QuranRepository,
) : ViewModel() {

  val plans: StateFlow<List<KhatmahPlan>> =
    quranRepository.khatmahPlansFlow.stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList(),
    )

  fun todayEpochDay(): Long = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis())

  fun createPlan(title: String, durationDays: Int, startEpochDay: Long = todayEpochDay()) {
    val safeDays = durationDays.coerceIn(1, 365)
    val endEpochDay = startEpochDay + safeDays
    viewModelScope.launch {
      quranRepository.saveKhatmahPlan(
        KhatmahPlan(
          title = title.ifBlank { "ختمة $safeDays يوماً" },
          startDateEpochDay = startEpochDay,
          endDateEpochDay = endEpochDay,
          totalPages = 604,
          pagesRead = 0,
          isPaused = false,
        )
      )
    }
  }

  fun updateSchedule(plan: KhatmahPlan, newTitle: String, newDurationDays: Int) {
    val safeDays = newDurationDays.coerceIn(1, 365)
    viewModelScope.launch {
      quranRepository.saveKhatmahPlan(
        plan.copy(
          title = newTitle.ifBlank { plan.title },
          endDateEpochDay = plan.startDateEpochDay + safeDays,
        )
      )
    }
  }

  fun markPagesRead(plan: KhatmahPlan, newPagesRead: Int) {
    viewModelScope.launch {
      quranRepository.saveKhatmahPlan(
        plan.copy(pagesRead = newPagesRead.coerceIn(0, plan.totalPages))
      )
    }
  }

  fun togglePause(plan: KhatmahPlan) {
    viewModelScope.launch {
      quranRepository.saveKhatmahPlan(plan.copy(isPaused = !plan.isPaused))
    }
  }

  fun deletePlan(planId: Long) {
    viewModelScope.launch { quranRepository.deleteKhatmahPlan(planId) }
  }

  companion object {
    fun factory(quranRepository: QuranRepository): ViewModelProvider.Factory =
      object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
          return KhatmahViewModel(quranRepository) as T
        }
      }
  }
}
