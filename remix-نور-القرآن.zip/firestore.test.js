const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const OWNER_UID = "owner_mlwnhlnh_uid";
const OWNER_EMAIL = "mlwnhlnh@gmail.com";
const NORMAL_USER_UID = "normal_user_123";
const OTHER_USER_UID = "other_user_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

function pastDate(msAgo = 5000) {
  return new Date(Date.now() - msAgo);
}

test("Unauthenticated users (guests) can browse published reciters/tracks ONLY and cannot write/edit/delete or read private data", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const seed = context.firestore();
    await seed.collection("reciters").doc("reciter_seed").set({
      arabicName: "مشاري العفاسي",
      styleArabic: "حفص عن عاصم",
      riwayah: "حفص عن عاصم",
      bioArabic: "قارئ وإمام المسجد الكبير بالكويت",
      photoUrl: "https://archive.org/download/noor-quran/alafasy.jpg",
      sortOrder: 1,
      hostingProvider: "github_releases",
      audioBaseUrl: "https://github.com/Buasker/noor-quran-audio/releases/download/v1/",
      published: true,
      createdBy: OWNER_UID,
      createdAt: pastDate(10000),
      updatedAt: pastDate(10000),
    });
    await seed.collection("reciters").doc("reciter_draft").set({
      arabicName: "قارئ مسودة",
      styleArabic: "مرتل",
      hostingProvider: "github_releases",
      audioBaseUrl: "",
      published: false,
      createdBy: OWNER_UID,
      createdAt: pastDate(10000),
      updatedAt: pastDate(10000),
    });
    await seed.collection("reciters").doc("reciter_seed").collection("recitations").doc("001").set({
      reciterId: "reciter_seed",
      surahNumber: 1,
      surahArabicName: "سورة الفاتحة",
      description: "تلاوة خاشعة",
      sortOrder: 1,
      hostingProvider: "github_releases",
      audioUrl: "https://github.com/Buasker/noor-quran-audio/releases/download/v1/001.mp3",
      published: true,
      uploadedBy: OWNER_UID,
      createdAt: pastDate(10000),
      updatedAt: pastDate(10000),
    });
    await seed.collection("reciters").doc("reciter_seed").collection("recitations").doc("002").set({
      reciterId: "reciter_seed",
      surahNumber: 2,
      surahArabicName: "سورة البقرة",
      hostingProvider: "github_releases",
      audioUrl: "https://github.com/Buasker/noor-quran-audio/releases/download/v1/002.mp3",
      published: false,
      uploadedBy: OWNER_UID,
      createdAt: pastDate(10000),
      updatedAt: pastDate(10000),
    });
  });

  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertSucceeds(unauthDb.collection("reciters").where("published", "==", true).get());
  await assertSucceeds(
    unauthDb.collection("reciters").doc("reciter_seed").collection("recitations").where("published", "==", true).get()
  );
  await assertFails(unauthDb.collection("reciters").doc("reciter_draft").get()); // Draft hidden
  await assertFails(unauthDb.collection("reciters").doc("reciter_seed").collection("recitations").doc("002").get());
  await assertFails(unauthDb.collection("admins").doc(OWNER_UID).get());
  await assertFails(unauthDb.collection("reciters").get()); // unfiltered query rejected
  await assertFails(
    unauthDb.collection("reciters").doc("reciter_1").set({
      arabicName: "قارئ جديد",
      styleArabic: "مرتل",
      hostingProvider: "github_releases",
      audioBaseUrl: "https://github.com/Buasker/noor-quran-audio/releases/download/v1/",
      published: true,
      createdBy: "anon",
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );
  await assertFails(
    unauthDb.collection("reciters").doc("reciter_seed").collection("recitations").doc("003").set({
      reciterId: "reciter_seed",
      surahNumber: 3,
      surahArabicName: "سورة آل عمران",
      hostingProvider: "direct_https",
      audioUrl: "https://archive.org/download/reciter_seed/003.mp3",
      published: true,
      uploadedBy: "anon",
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );
  await assertFails(
    unauthDb.collection("reciters").doc("reciter_seed").collection("recitations").doc("001").update({
      audioUrl: "https://evil.example.com/001.mp3",
      updatedAt: pastDate(),
    })
  );
  await assertFails(
    unauthDb.collection("reciters").doc("reciter_seed").collection("recitations").doc("001").delete()
  );
  await assertFails(unauthDb.collection("users").doc(NORMAL_USER_UID).collection("bookmarks").get());
});

test("Normal authenticated user & lookalike email (mlwnhInh@gmail.com) CANNOT create, update, reorder, or delete reciters or recitations", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const adminSeed = context.firestore();
    await adminSeed.collection("reciters").doc("ar_alafasy").set({
      arabicName: "مشاري العفاسي",
      styleArabic: "حفص عن عاصم",
      hostingProvider: "github_releases",
      audioBaseUrl: "https://github.com/Buasker/noor-quran-audio/releases/download/ar_alafasy/",
      published: true,
      createdBy: OWNER_UID,
      createdAt: pastDate(10000),
      updatedAt: pastDate(10000),
    });
    await adminSeed.collection("reciters").doc("ar_alafasy").collection("recitations").doc("001").set({
      reciterId: "ar_alafasy",
      surahNumber: 1,
      surahArabicName: "سورة الفاتحة",
      hostingProvider: "github_releases",
      audioUrl: "https://github.com/Buasker/noor-quran-audio/releases/download/ar_alafasy/001.mp3",
      externalAssetId: "gh_asset_1001",
      fileSizeBytes: 512000,
      durationSeconds: 45,
      published: true,
      uploadedBy: OWNER_UID,
      createdAt: pastDate(10000),
      updatedAt: pastDate(10000),
    });
  });

  const userDb = testEnv.authenticatedContext(NORMAL_USER_UID, {
    email: "user@example.com",
    email_verified: true,
  }).firestore();

  const lookalikeGmailDb = testEnv.authenticatedContext("lookalike_uid", {
    email: "mlwnhInh@gmail.com",
    email_verified: true,
  }).firestore();

  // Normal user CAN read published reciters and published recitations via filtered query
  await assertSucceeds(userDb.collection("reciters").where("published", "==", true).get());
  await assertSucceeds(
    userDb.collection("reciters").doc("ar_alafasy").collection("recitations").where("published", "==", true).get()
  );
  // Normal user CANNOT list all reciters (including drafts)
  await assertFails(userDb.collection("reciters").get());

  // Normal user and lookalike email CANNOT add/edit/reorder/delete reciters or tracks
  for (const db of [userDb, lookalikeGmailDb]) {
    await assertFails(
      db.collection("reciters").doc("hacker_reciter").set({
        arabicName: "قارئ غير مصرح",
        styleArabic: "مرتل",
        hostingProvider: "github_releases",
        audioBaseUrl: "https://github.com/evil/repo/releases/download/v1/",
        published: true,
        createdBy: NORMAL_USER_UID,
        createdAt: pastDate(),
        updatedAt: pastDate(),
      })
    );
    await assertFails(
      db.collection("reciters").doc("ar_alafasy").update({
        arabicName: "تم التعديل",
        sortOrder: 99,
        updatedAt: pastDate(),
      })
    );
    await assertFails(db.collection("reciters").doc("ar_alafasy").delete());
    await assertFails(
      db.collection("reciters").doc("ar_alafasy").collection("recitations").doc("002").set({
        reciterId: "ar_alafasy",
        surahNumber: 2,
        surahArabicName: "سورة البقرة",
        hostingProvider: "internet_archive",
        audioUrl: "https://archive.org/download/ar_alafasy/002.mp3",
        published: true,
        uploadedBy: NORMAL_USER_UID,
        createdAt: pastDate(),
        updatedAt: pastDate(),
      })
    );
    await assertFails(
      db.collection("reciters").doc("ar_alafasy").collection("recitations").doc("001").update({
        sortOrder: 5,
        updatedAt: pastDate(),
      })
    );
    await assertFails(
      db.collection("reciters").doc("ar_alafasy").collection("recitations").doc("001").delete()
    );
  }
});

test("Spoofed unverified OWNER_EMAIL and client-side /admins writes are strictly blocked", async () => {
  const spoofDb = testEnv.authenticatedContext("spoof_uid", {
    email: OWNER_EMAIL,
    email_verified: false,
  }).firestore();

  await assertFails(
    spoofDb.collection("reciters").doc("reciter_spoof").set({
      arabicName: "محاولة انتحال",
      styleArabic: "مرتل",
      hostingProvider: "direct_https",
      audioBaseUrl: "https://archive.org/download/spoof/",
      published: true,
      createdBy: "spoof_uid",
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );

  // Client writes to /admins/{uid} are completely blocked even for verified owner
  const ownerDb = testEnv.authenticatedContext(OWNER_UID, {
    email: OWNER_EMAIL,
    email_verified: true,
  }).firestore();
  await assertFails(
    spoofDb.collection("admins").doc("spoof_uid").set({
      uid: "spoof_uid",
      email: OWNER_EMAIL,
      role: "super_admin",
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );
  await assertFails(
    ownerDb.collection("admins").doc("another_uid").set({
      uid: "another_uid",
      email: "friend@example.com",
      role: "super_admin",
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );

  // Even if another email has superAdmin custom claim or /admins doc, only OWNER_EMAIL is permitted
  const rogueClaimDb = testEnv.authenticatedContext("rogue_claim_uid", {
    email: "mlwnhInh@gmail.com",
    email_verified: true,
    superAdmin: true,
    role: "super_admin",
  }).firestore();
  await assertFails(
    rogueClaimDb.collection("reciters").doc("reciter_rogue").set({
      arabicName: "محاولة بحساب آخر",
      styleArabic: "مرتل",
      hostingProvider: "direct_https",
      audioBaseUrl: "https://archive.org/download/rogue/",
      published: true,
      createdBy: "rogue_claim_uid",
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );
});

test("Verified OWNER_EMAIL (mlwnhlnh@gmail.com) CAN create, edit, reorder, and delete reciters & tracks; SSRF/invalid surah blocked", async () => {
  const ownerDb = testEnv.authenticatedContext(OWNER_UID, {
    email: OWNER_EMAIL,
    email_verified: true,
  }).firestore();

  const created = pastDate(10000);

  // SSRF / userinfo @ / http / localhost / non-443 / .internal / CGNAT URLs rejected even for Owner
  for (const badUrl of [
    "http://insecure.example.com/audio/",
    "https://127.0.0.1/admin/",
    "https://localhost/audio/",
    "https://printer.local/audio/",
    "https://metadata.google.internal/computeMetadata/v1/",
    "https://169.254.169.254/latest/meta-data/",
    "https://192.168.1.10/audio/",
    "https://100.64.0.1/audio/",
    "https://example.com:8443/audio/",
    "https://mp3quran.net@evil.com/audio/",
    "https://example.com/bad space/",
  ]) {
    await assertFails(
      ownerDb.collection("reciters").doc("bad_reciter").set({
        arabicName: "قارئ تجريبي",
        styleArabic: "مرتل",
        hostingProvider: "direct_https",
        audioBaseUrl: badUrl,
        published: true,
        createdBy: OWNER_UID,
        createdAt: created,
        updatedAt: created,
      })
    );
    await assertFails(
      ownerDb.collection("reciters").doc("bad_photo_reciter").set({
        arabicName: "قارئ بصورة خبيثة",
        styleArabic: "مرتل",
        photoUrl: badUrl,
        hostingProvider: "direct_https",
        audioBaseUrl: "",
        published: true,
        createdBy: OWNER_UID,
        createdAt: created,
        updatedAt: created,
      })
    );
  }

  // Create reciter as Owner with full rich profile (photoUrl, bioArabic, riwayah, sortOrder, optional empty audioBaseUrl)
  await assertSucceeds(
    ownerDb.collection("reciters").doc("khalid_jaleel").set({
      arabicName: "خالد الجليل",
      styleArabic: "تلاوة خاشعة",
      riwayah: "حفص عن عاصم",
      bioArabic: "إمام وخطيب جامع الملك خالد بالرياض",
      photoUrl: "https://archive.org/download/noor-quran/khalid.jpg",
      sortOrder: 0,
      hostingProvider: "github_releases",
      audioBaseUrl: "https://github.com/Buasker/noor-quran-audio/releases/download/khalid_jaleel/",
      published: true,
      createdBy: OWNER_UID,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Create reciter without base URL (tracks added individually later)
  await assertSucceeds(
    ownerDb.collection("reciters").doc("reciter_tracks_only").set({
      arabicName: "قارئ التلاوات الفردية",
      styleArabic: "ترتيل",
      riwayah: "ورش عن نافع",
      sortOrder: 1,
      hostingProvider: "direct_https",
      audioBaseUrl: "",
      published: false,
      createdBy: OWNER_UID,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Invalid surahNumber (0 or 999) rejected
  await assertFails(
    ownerDb.collection("reciters").doc("khalid_jaleel").collection("recitations").doc("track_invalid").set({
      reciterId: "khalid_jaleel",
      surahNumber: 999,
      surahArabicName: "سورة غير صالحة",
      hostingProvider: "direct_https",
      audioUrl: "https://archive.org/download/khalid_jaleel/001.mp3",
      published: true,
      uploadedBy: OWNER_UID,
      createdAt: created,
      updatedAt: created,
    })
  );

  // Register recitation tracks (legacy doc ID + custom track ID for multiple recitations of same surah)
  for (const [docId, surahNum, provider, url, desc, order] of [
    ["018", 18, "github_releases", "https://github.com/Buasker/noor-quran-audio/releases/download/khalid_jaleel/018.mp3", "من صلاة الفجر", 0],
    ["track_018_taraweeh", 18, "internet_archive", "https://archive.org/download/khalid_jaleel/018_tar.mp3", "من صلاة التراويح", 1],
    ["020", 20, "mp3quran", "https://server10.mp3quran.net/jleel/020.mp3", "تلاوة كاملة", 2],
    ["021", 21, "direct_https", "https://cdn.jsdelivr.net/gh/Buasker/noor-quran-audio/021.mp3", "", 3],
  ]) {
    await assertSucceeds(
      ownerDb.collection("reciters").doc("khalid_jaleel").collection("recitations").doc(docId).set({
        reciterId: "khalid_jaleel",
        surahNumber: surahNum,
        surahArabicName: "سورة من المصحف",
        description: desc,
        sortOrder: order,
        hostingProvider: provider,
        audioUrl: url,
        externalAssetId: `asset_${docId}`,
        fileSizeBytes: 1840000,
        durationSeconds: 600,
        published: true,
        uploadedBy: OWNER_UID,
        createdAt: created,
        updatedAt: created,
      })
    );
  }

  // Partial update & reorder by Owner succeed; immutable createdBy / createdAt / shadow fields rejected
  await assertSucceeds(
    ownerDb.collection("reciters").doc("khalid_jaleel").update({
      styleArabic: "تلاوة خاشعة",
      bioArabic: "نبذة محدثة للقارئ",
      sortOrder: 3,
      updatedAt: pastDate(1000),
    })
  );
  await assertSucceeds(
    ownerDb.collection("reciters").doc("khalid_jaleel").collection("recitations").doc("track_018_taraweeh").update({
      description: "تلاوة خاشعة محدثة",
      sortOrder: 0,
      updatedAt: pastDate(1000),
    })
  );
  await assertFails(
    ownerDb.collection("reciters").doc("khalid_jaleel").update({
      createdAt: pastDate(500),
      updatedAt: pastDate(500),
    })
  );
  await assertFails(
    ownerDb.collection("reciters").doc("khalid_jaleel").update({
      shadowField: true,
      updatedAt: pastDate(500),
    })
  );

  // Owner can list all reciters (including drafts) and delete recitations & reciters
  await assertSucceeds(ownerDb.collection("reciters").get());
  await assertSucceeds(
    ownerDb.collection("reciters").doc("khalid_jaleel").collection("recitations").doc("018").delete()
  );
  await assertSucceeds(ownerDb.collection("reciters").doc("khalid_jaleel").delete());
});

test("Normal user profile & bookmarks: self-escalation blocked and cross-user isolation enforced", async () => {
  const userDb = testEnv.authenticatedContext(NORMAL_USER_UID, {
    email: "user@example.com",
    email_verified: true,
  }).firestore();
  const otherDb = testEnv.authenticatedContext(OTHER_USER_UID, {
    email: "other@example.com",
    email_verified: true,
  }).firestore();

  // Normal user cannot register as super_admin
  await assertFails(
    userDb.collection("users").doc(NORMAL_USER_UID).set({
      userId: NORMAL_USER_UID,
      displayName: "مستخدم",
      role: "super_admin",
      createdAt: pastDate(),
      updatedAt: pastDate(),
    })
  );

  // Normal user CAN create profile with role 'user'
  const created = pastDate(8000);
  await assertSucceeds(
    userDb.collection("users").doc(NORMAL_USER_UID).set({
      userId: NORMAL_USER_UID,
      displayName: "قارئ نور القرآن",
      role: "user",
      createdAt: created,
      updatedAt: created,
    })
  );

  // Normal user cannot mutate own role
  await assertFails(
    userDb.collection("users").doc(NORMAL_USER_UID).update({
      role: "super_admin",
      updatedAt: pastDate(),
    })
  );

  // Cross-user profile read/write blocked
  await assertFails(otherDb.collection("users").doc(NORMAL_USER_UID).get());
  await assertFails(otherDb.collection("users").get());

  // Normal user bookmark CRUD & cross-user denial
  await assertSucceeds(
    userDb.collection("users").doc(NORMAL_USER_UID).collection("bookmarks").doc("1_1").set({
      userId: NORMAL_USER_UID,
      surahNumber: 1,
      ayahNumber: 1,
      category: "تدبر",
      note: "بداية الفاتحة",
      createdAt: created,
      updatedAt: created,
    })
  );
  await assertSucceeds(userDb.collection("users").doc(NORMAL_USER_UID).collection("bookmarks").get());
  await assertFails(otherDb.collection("users").doc(NORMAL_USER_UID).collection("bookmarks").get());
  await assertFails(otherDb.collection("users").doc(NORMAL_USER_UID).collection("bookmarks").doc("1_1").delete());
});
