/**
 * Trusted Admin CLI utility to upload or delete Surah audio assets on free GitHub Releases
 * and register/remove metadata in Cloud Firestore (`/reciters/{reciterId}/recitations/{surahId}`).
 *
 * Zero secrets are ever packaged inside the Android APK. Run strictly from a trusted admin host:
 *   export GITHUB_TOKEN="<your_github_pat_with_repo_scope>"
 *   export GOOGLE_APPLICATION_CREDENTIALS="/path/to/service-account.json"
 *
 * Upload example:
 *   node scripts/upload-recitation-github.mjs upload \
 *     --owner Buasker --repo noor-quran-audio --tag recitations-v1 \
 *     --reciter khalid_jaleel --surah 18 --surah-name "سورة الكهف" \
 *     --file ./018.mp3 --admin-uid "<SUPER_ADMIN_UID>"
 *
 * Delete example:
 *   node scripts/upload-recitation-github.mjs delete \
 *     --owner Buasker --repo noor-quran-audio \
 *     --reciter khalid_jaleel --surah 18
 */
import fs from "node:fs";
import path from "node:path";
import { initializeApp, applicationDefault } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";

const DATABASE_ID = "ai-studio-android-3e077e8e-16b3-485e-a78a-e49778517a58";
const PROJECT_ID = "noor-quran-b214a";

function parseArgs(argv) {
  const args = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const token = argv[i];
    if (token.startsWith("--")) {
      const key = token.slice(2);
      const next = argv[i + 1];
      if (!next || next.startsWith("--")) {
        args[key] = true;
      } else {
        args[key] = next;
        i++;
      }
    } else {
      args._.push(token);
    }
  }
  return args;
}

async function githubFetch(url, token, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
      ...(options.headers || {}),
    },
  });
  return response;
}

async function ensureRelease(owner, repo, tag, token) {
  const getRes = await githubFetch(
    `https://api.github.com/repos/${owner}/${repo}/releases/tags/${tag}`,
    token
  );
  if (getRes.ok) return getRes.json();
  if (getRes.status !== 404) {
    throw new Error(`Failed reading release (${getRes.status}): ${await getRes.text()}`);
  }
  const createRes = await githubFetch(
    `https://api.github.com/repos/${owner}/${repo}/releases`,
    token,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tag_name: tag,
        name: `Noor Quran Audio (${tag})`,
        body: "Free Quran recitations hosted via GitHub Releases.",
        draft: false,
        prerelease: false,
      }),
    }
  );
  if (!createRes.ok) {
    throw new Error(`Failed creating release (${createRes.status}): ${await createRes.text()}`);
  }
  return createRes.json();
}

const args = parseArgs(process.argv.slice(2));
const command = args._[0];
const token = process.env.GITHUB_TOKEN;

if (!command || !["upload", "delete"].includes(command)) {
  console.error("Usage: node scripts/upload-recitation-github.mjs <upload|delete> [options]");
  process.exit(1);
}
if (!token) {
  console.error("GITHUB_TOKEN environment variable is required.");
  process.exit(1);
}

initializeApp({
  credential: applicationDefault(),
  projectId: PROJECT_ID,
});
const db = getFirestore(DATABASE_ID);

const owner = args.owner;
const repo = args.repo;
const reciterId = args.reciter;
const surahNumber = Number(args.surah);
const surahId = String(surahNumber).padStart(3, "0");

if (!owner || !repo || !reciterId || !(surahNumber >= 1 && surahNumber <= 114)) {
  console.error("Required: --owner, --repo, --reciter, --surah (1..114)");
  process.exit(1);
}

const trackRef = db
  .collection("reciters")
  .doc(reciterId)
  .collection("recitations")
  .doc(surahId);

if (command === "upload") {
  const tag = args.tag || "recitations-v1";
  const surahArabicName = args["surah-name"];
  const filePath = args.file;
  const adminUid = args["admin-uid"] || "super_admin";
  if (!surahArabicName || !filePath) {
    console.error("Upload requires --surah-name and --file");
    process.exit(1);
  }
  const absFile = path.resolve(filePath);
  const fileBytes = fs.readFileSync(absFile);
  const release = await ensureRelease(owner, repo, tag, token);
  const assetName = `${reciterId}_${surahId}.mp3`;

  const existing = (release.assets || []).find((a) => a.name === assetName);
  if (existing) {
    await githubFetch(
      `https://api.github.com/repos/${owner}/${repo}/releases/assets/${existing.id}`,
      token,
      { method: "DELETE" }
    );
  }

  const uploadBase = release.upload_url.split("{")[0];
  const uploadRes = await githubFetch(`${uploadBase}?name=${assetName}`, token, {
    method: "POST",
    headers: { "Content-Type": "audio/mpeg" },
    body: fileBytes,
  });
  if (!uploadRes.ok) {
    throw new Error(`Upload failed (${uploadRes.status}): ${await uploadRes.text()}`);
  }
  const uploaded = await uploadRes.json();

  await trackRef.set({
    reciterId,
    surahNumber,
    surahArabicName,
    hostingProvider: "github_releases",
    audioUrl: uploaded.browser_download_url,
    externalAssetId: String(uploaded.id),
    fileSizeBytes: uploaded.size ?? fileBytes.length,
    published: true,
    uploadedBy: adminUid,
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  });
  console.log(`Uploaded ${assetName} (${uploaded.browser_download_url}) and registered in Firestore.`);
} else {
  const snap = await trackRef.get();
  if (snap.exists) {
    const assetId = snap.get("externalAssetId");
    if (assetId) {
      await githubFetch(
        `https://api.github.com/repos/${owner}/${repo}/releases/assets/${assetId}`,
        token,
        { method: "DELETE" }
      );
    }
    await trackRef.delete();
  }
  console.log(`Deleted recitation ${reciterId}/${surahId} from Firestore and GitHub Release.`);
}
