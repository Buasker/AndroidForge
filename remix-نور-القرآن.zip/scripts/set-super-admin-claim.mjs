/**
 * Admin CLI utility to assign Firebase Custom Claims (`superAdmin: true`, `role: "super_admin"`)
 * and create `/admins/{uid}` in Firestore for the Super Admin account.
 *
 * Prerequisites (never store credentials or passwords in code):
 * 1. Download a Firebase Service Account JSON key from Firebase Console -> Project Settings -> Service Accounts.
 * 2. Export: `export GOOGLE_APPLICATION_CREDENTIALS="/path/to/service-account.json"`
 * 3. Install `firebase-admin` in a temporary directory or global node_modules and run:
 *    `node scripts/set-super-admin-claim.mjs mlwnhlnh@gmail.com`
 */
import { initializeApp, applicationDefault } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore, FieldValue } from "firebase-admin/firestore";

const targetEmail = (process.argv[2] || "mlwnhlnh@gmail.com").trim();
const databaseId = "ai-studio-android-3e077e8e-16b3-485e-a78a-e49778517a58";

initializeApp({
  credential: applicationDefault(),
  projectId: "noor-quran-b214a",
});

const auth = getAuth();
const db = getFirestore(databaseId);

const userRecord = await auth.getUserByEmail(targetEmail);
await auth.setCustomUserClaims(userRecord.uid, {
  superAdmin: true,
  role: "super_admin",
});

await db.collection("admins").doc(userRecord.uid).set(
  {
    uid: userRecord.uid,
    email: userRecord.email ?? targetEmail,
    role: "super_admin",
    createdAt: FieldValue.serverTimestamp(),
    updatedAt: FieldValue.serverTimestamp(),
  },
  { merge: true }
);

console.log(`Super Admin claims & /admins/${userRecord.uid} provisioned for ${userRecord.email}`);
